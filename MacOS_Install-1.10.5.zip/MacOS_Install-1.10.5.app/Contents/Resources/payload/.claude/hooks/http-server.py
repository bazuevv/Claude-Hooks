#!/usr/bin/env python3
"""Локальный HTTP-сервер для связи webview JS → файловая система.

Запускается хуком patch-claude-webview.py на SessionStart.
Убивается хуком на SessionEnd (через PID-файл).

Endpoints:
  POST /webview-error — тело = JSON с исключением webview, дописывает строку в
                        .claude/hooks-runtime/webview-errors.log (свои ошибки страницы
                        иначе нигде не видны: в логи VSCode они не попадают)
  POST /save-log      — тело = текст лога, сохраняет в .claude/hooks-runtime/debug-log-<ts>.txt
  POST /locale-drift  — тело = JSON {items: [{section,label,title}, ...]}, перезаписывает
                        .claude/hooks-runtime/locales-drift-pending.json (последний снимок DOM
                        меню /, который JS-локализатор отправляет при появлении меню)
  POST /models-list   — тело = JSON {models: [{value,displayName,description,isActive}, ...]},
                        перезаписывает .claude/hooks-runtime/models-list.json (каталог моделей
                        из popup селектора, для построения внешнего переключателя моделей)
  GET  /ping          — возвращает {"status": "ok"} (alive-check)
  GET  /accounts      — список settings-файлов ~/.claude/settings*.json как
                        аккаунтов провайдеров (кнопка Accs в футере)
  POST /accounts      — тело = JSON {file: "settings_glm.json"}, делает этот
                        файл активным ~/.claude/settings.json
  POST /restart-exthost — кладёт заявку на перезапуск extension host
                        (.claude/hooks-runtime/restart-exthost-request.json);
                        сам перезапуск делает блок, инжектированный
                        patch-extension-csp.py в extension.js
  GET  /restart-exthost — приняло ли расширение последнюю заявку
                        ({token, acked}); ложь означает, что инжекция
                        не работает и смена аккаунта не применится
  GET  /list-projects — возвращает список папок проектов в ~/.claude/projects/ с числом сессий
                        и декодированным путём
  POST /move-session  — тело = JSON {session_id, source_project, target_project},
                        перемещает .jsonl сессии между папками проектов
  POST /create-project— тело = JSON {path}, создаёт папку для проекта в ~/.claude/projects/
                        с кодированием пути (не-alphanum → '-')
  GET  /limit-reset-alert — состояние монитора сброса 5-часового окна лимита
                        (включён ли, снимок кэша, окно-свидетель, последний сигнал;
                        поле playing — играет ли звук сейчас, его опрашивает
                        кнопка «Стоп» в webview)
  POST /limit-reset-alert-test — немедленно проигрывает notification.mp3
                        (проверка звука руками; реальный сброс ждать нельзя)
  POST /limit-reset-alert-stop — гасит играющий звук (кнопка «Стоп»)
"""

import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid
import threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import unquote

# Разбор транскрипта — единственная тяжёлая операция сервера (первый
# проход по файлу в десятки мегабайт занимает около секунды). Лочим её,
# чтобы параллельные запросы не гонялись за файлом состояния.
_CACHE_LOCK = threading.Lock()

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    tomllib = None

# Разобранный claude-custom-config.toml, обновляется по mtime.
_CONFIG_CACHE = {"mtime": 0.0, "data": {}}
_CONFIG_LOCK = threading.Lock()

# Параметры, которые подтягиваются на лету и перезапуска НЕ требуют:
# cacheKeepalive* обновляет applyLiveConfig() в claude-custom.js через
# /custom-config, inputRingColor — модуль INPUT RING оттуда же,
# serverLog* перечитывает hook_log на каждой записи,
# serverConfigWatchSec читает сам наблюдатель на каждом цикле,
# codexPayloadCapture читает мост перед каждым запросом,
# limitResetAlert* перечитывает монитор сброса лимита (limit_alert.py)
# на каждом цикле — рестарт на правке этих ключей терял бы окно-свидетель.
# Список обязан совпадать с тем, что там реально обновляется, иначе
# сервер будет либо зря перезапускаться, либо не перезапускаться,
# когда надо.
HOT_KEYS = frozenset({
    "cpuProbeEnabled", "cpuProbeIntervalSec", "cpuProbeMaxMinutes",
    "messageCostsEnabled",
    "messageCostsRefreshIntervalSec",
    "messageCostAccounts",
    "zaiUsageCacheTtlSec",
    "accountUsageBackgroundEnabled",
    "accountUsageBackgroundIntervalSec",
    "cacheKeepaliveMinutes",
    "cacheKeepaliveMessage",
    "cacheKeepaliveMinContext",
    "cacheKeepaliveTtlMinutes",
    "cacheKeepaliveTtlMinutesAnthropic",
    "cacheKeepaliveTtlMinutesOpenai",
    "cacheKeepaliveTtlMinutesZai",
    "cacheKeepaliveTtlMinutesCustom",
    "inputRingColor",
    "serverLog",
    "serverLogMaxBytes",
    "serverConfigWatchSec",
    "codexPayloadCapture",
    "limitResetAlert",
    "limitResetAlertMode",
    "limitResetAlertPercent",
    "limitResetAlertPollSec",
    "limitResetAlertRepeatMin",
    "limitResetAlertPlaySec",
    "limitResetAlertDuckOthers",
    "limitResetAlertMinVolume",
})

DEFAULT_CONFIG_WATCH_SEC = 10

# Выставляется наблюдателем; main() после выхода из serve_forever()
# смотрит на него и решает, делать exec или просто завершиться.
_RESTART_REQUESTED = False

# cache_usage лежит рядом; при запуске скриптом sys.path[0] — эта папка,
# но вставляем явно, чтобы импорт не зависел от способа запуска.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cache_usage  # noqa: E402
import message_timestamps  # noqa: E402
import account_usage_history  # noqa: E402
import account_usage_monitor  # noqa: E402
import hook_log  # noqa: E402
import account_switcher  # noqa: E402
import codex_bridge_manager  # noqa: E402
import limit_alert  # noqa: E402
import cpu_probe  # noqa: E402
import openai_bootstrap  # noqa: E402
from hook_paths import ROOT as HOOK_ROOT, RUNTIME, GLOBAL_INSTALL, bypass_dir


def _log(message: str) -> None:
    hook_log.log("server", message)

PORT = int(os.environ.get("CLAUDE_HTTP_PORT", "18923"))

# Время правки исходников на момент старта. Отдаётся в /ping, чтобы
# patch-claude-webview.py мог отличить «сервер жив» от «сервер жив, но
# поднят со старой версии кода». Без этого правки в файлах ниже молча
# не подхватываются до ручного убийства процесса.
#
# ВАЖНО: добавил серверу новый локальный импорт — впиши его сюда,
# иначе изменения в нём не будут поводом для перезапуска. Тот же список
# продублирован в _server_sources_mtime() внутри patch-claude-webview.py;
# они обязаны совпадать. Конфиг тоже здесь: правка serverLog должна
# доезжать до сервера без ручного перезапуска.
SOURCE_FILES = ("http-server.py", "cache_usage.py", "hook_log.py",
                "hook_supervisor.py", "account_switcher.py", "openai_bootstrap.py", "settings_hooks.py", "hook_paths.py", "codex_bridge_manager.py",
                "codex_anthropic_bridge.py", "codex_app_server.py",
                "limit_alert.py", "cpu_probe.py", "cpu_probe_windows.py", "message_timestamps.py", "message_costs.py", "account_usage_history.py", "account_usage_monitor.py", "usage_history_store.py", "quota_periods.py", "image_export.py", "image-export.ps1")
CONFIG_FILE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "patches", "claude-custom-config.toml",
)


def _sources_mtime() -> float:
    """Только код. Конфиг сюда НЕ входит намеренно: все, кому он нужен,
    перечитывают его на лету — hook_log на каждую запись, endpoint
    /custom-config по mtime. Держать конфиг в этом списке значило бы
    перезапускать сервер на каждую правку настройки, а каждый перезапуск
    — это окно, в котором webview получает «недоступен»."""
    here = os.path.dirname(os.path.abspath(__file__))
    newest = 0.0
    for name in SOURCE_FILES:
        try:
            newest = max(newest, os.path.getmtime(os.path.join(here, name)))
        except OSError:
            pass
    return newest


SCRIPT_MTIME = _sources_mtime()
PROJECT_DIR = os.environ.get("CLAUDE_PROJECT_DIR", "")
LOGS_DIR = str(RUNTIME)

# Корневая папка проектов Claude Code (где хранятся .jsonl сессии чатов).
CLAUDE_PROJECTS_DIR = os.path.expanduser("~/.claude/projects")

# Лимит на размер тела POST — защита от случайного DoS
MAX_BODY_BYTES = 1 * 1024 * 1024  # 1 MB

LOCALE_DRIFT_FILE = (
    os.path.join(LOGS_DIR, "locales-drift-pending.json") if LOGS_DIR else ""
)
MODELS_LIST_FILE = (
    os.path.join(LOGS_DIR, "models-list.json") if LOGS_DIR else ""
)

# Заявка на перезапуск extension host и подтверждение её приёма.
#
# Смена аккаунта провайдера подменяет ~/.claude/settings.json, но `env`
# оттуда применяет к себе CLI-процесс `claude` при старте, а стартует он
# один раз на активацию extension host (в логе расширения за 11 дней
# ровно 5 строк «Spawn-env probe captured» — по числу активаций, не по
# числу диалогов). Значит, чтобы смена подействовала, нужен новый
# процесс CLI, то есть перезапуск хоста.
#
# Webview вызвать команду VSCode не может, поэтому связь идёт через файл:
# сюда пишет заявку этот сервер, а читает её блок, который
# patch-extension-csp.py инжектит в extension.js. Он же на активации
# запоминает токен как базовый — новый токен означает «перезапустись»,
# а тот же самый (после перезапуска) — «уже сделано», иначе получился бы
# бесконечный цикл.
#
# Путь заявки привязан к проекту (LOGS_DIR), и инжектированный блок
# выводит его из корня воркспейса своего окна. Поэтому область действия
# сама собой оказывается правильной: чужие проекты заявку не видят,
# а окна с этим же проектом перезапустятся каждое по одному разу.
RESTART_REQUEST_FILE = (
    os.path.join(LOGS_DIR, "restart-exthost-request.json") if LOGS_DIR else ""
)
RESTART_ACK_FILE = (
    os.path.join(LOGS_DIR, "restart-exthost-ack.json") if LOGS_DIR else ""
)

# UUID4-формат для имени файла сессии — защита от directory traversal
# при перемещении файлов между папками.
SESSION_ID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
    re.IGNORECASE,
)

# Имя папки проекта в ~/.claude/projects/. Claude Code кодирует
# абсолютный путь проекта, заменяя каждый не [a-zA-Z0-9] символ на '-'.
# Примеры:
#   /home/vladimir → -home-vladimir
#   /home/vladimir/Документы/Projects/Flying_Player
#     → -home-vladimir-----------Projects-Flying-Player
PROJECT_DIR_NAME_RE = re.compile(r"^-[A-Za-z0-9-]+$")


def encode_project_path(abs_path: str) -> str:
    """Кодирует абсолютный путь проекта в имя папки ~/.claude/projects/.
    Каждый символ, не входящий в [a-zA-Z0-9], заменяется на '-'.
    """
    return re.sub(r"[^A-Za-z0-9]", "-", abs_path)


def _decode_for_display(encoded_name: str) -> str:
    """Fallback-отображение, когда настоящий путь проекта неизвестен
    (например, в папке нет ни одной сессии с правильным cwd).
    Заменяет ведущий '-' на '/' — даёт хотя бы 1:1 соответствие
    имени папки и строки в списке.
    """
    if encoded_name.startswith("-"):
        return "/" + encoded_name[1:]
    return encoded_name


CWD_MARKER_FILENAME = ".cwd"


def _real_path_from_cwd(encoded_name: str) -> str | None:
    """Возвращает реальный путь проекта для папки encoded_name.

    Источники в порядке приоритета:
      1. Файл `.cwd` в папке проекта (создаётся POST /create-project и
         любым переносом — это явный «маркер» пути, чтобы пустые папки
         тоже знали свой путь).
      2. `cwd` из любой .jsonl-сессии папки, при условии что
         `encode_project_path(cwd) == encoded_name` (защита от
         перенесённых сессий, чей старый cwd принадлежит другому
         проекту).

    Возвращает None, если ни один источник не дал валидный путь.
    """
    project_dir = os.path.join(CLAUDE_PROJECTS_DIR, encoded_name)
    if not os.path.isdir(project_dir):
        return None

    # 1. Маркер-файл .cwd
    marker = os.path.join(project_dir, CWD_MARKER_FILENAME)
    if os.path.isfile(marker):
        try:
            with open(marker, "r", encoding="utf-8") as f:
                value = f.read().strip()
            if (value and os.path.isabs(value)
                    and encode_project_path(value) == encoded_name):
                return value
        except OSError:
            pass

    # 2. cwd из любой .jsonl с совпадающим энкодингом
    try:
        files = [f for f in os.listdir(project_dir) if f.endswith(".jsonl")]
    except OSError:
        return None
    MAX_LINES_TO_SCAN = 20
    for fname in files:
        path = os.path.join(project_dir, fname)
        try:
            with open(path, "r", encoding="utf-8") as f:
                for _ in range(MAX_LINES_TO_SCAN):
                    line = f.readline()
                    if not line:
                        break
                    if '"cwd"' not in line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    cwd = obj.get("cwd") if isinstance(obj, dict) else None
                    if (isinstance(cwd, str) and cwd
                            and encode_project_path(cwd) == encoded_name):
                        return cwd
        except OSError:
            continue
    return None


def _session_project(session_id: str) -> str | None:
    if not session_id or not SESSION_ID_RE.fullmatch(session_id):
        return None
    if not os.path.isdir(CLAUDE_PROJECTS_DIR):
        return None
    matches = [entry.name for entry in os.scandir(CLAUDE_PROJECTS_DIR)
               if entry.is_dir(follow_symlinks=False)
               and os.path.isfile(os.path.join(entry.path, session_id + ".jsonl"))]
    return _real_path_from_cwd(matches[0]) if len(matches) == 1 else None


def _write_cwd_marker(project_dir: str, abs_path: str) -> None:
    """Создаёт/обновляет файл .cwd в папке проекта.
    Молча игнорирует ошибки записи — функция вспомогательная.
    """
    marker = os.path.join(project_dir, CWD_MARKER_FILENAME)
    try:
        with open(marker, "w", encoding="utf-8") as f:
            f.write(abs_path)
    except OSError:
        pass


def _rewrite_cwd_in_jsonl(path: str, new_cwd: str) -> int:
    """Перезаписывает в jsonl корневое поле `cwd` всех валидных JSON-строк
    на `new_cwd`. Возвращает число изменённых строк.

    Атомарно через tmp-файл + os.replace. Строки без поля cwd либо
    нераспарсиваемые — переносятся как есть.
    """
    tmp = path + ".rewrite.tmp"
    changed = 0
    try:
        with open(path, "r", encoding="utf-8") as src, \
                open(tmp, "w", encoding="utf-8") as dst:
            for line in src:
                if '"cwd"' in line:
                    try:
                        obj = json.loads(line)
                        if isinstance(obj, dict) and "cwd" in obj:
                            if obj.get("cwd") != new_cwd:
                                obj["cwd"] = new_cwd
                                line = (json.dumps(obj, ensure_ascii=False)
                                        + "\n")
                                changed += 1
                    except json.JSONDecodeError:
                        pass
                dst.write(line)
        os.replace(tmp, path)
    except OSError:
        if os.path.isfile(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
        raise
    return changed


def _atomic_write_json(path: str, payload: dict) -> None:
    """Атомарная запись JSON: tmp-файл рядом + os.replace.
    Защищает от частично записанного файла, если процесс упадёт во время write.
    """
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


_WEBVIEW_PATCHER = None


def _load_webview_patcher():
    """Лениво импортирует patch-claude-webview.py как модуль.

    Через importlib, потому что дефис в имени файла не даёт написать
    обычный import. Модуль на верхнем уровне только объявляет
    константы и функции (вся работа — под `if __name__`), так что
    импорт безопасен. Результат кэшируется: endpoint дёргается
    периодически.
    """
    global _WEBVIEW_PATCHER
    if _WEBVIEW_PATCHER is None:
        import importlib.util

        path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "patch-claude-webview.py")
        spec = importlib.util.spec_from_file_location("claude_webview_patcher", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _WEBVIEW_PATCHER = module
    return _WEBVIEW_PATCHER


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # тишина в stdout: сервер запущен с DEVNULL

    def log_error(self, format, *args):
        # Ошибки запросов (битый HTTP, обрыв соединения) — в журнал,
        # а не в никуда. Именно здесь всплывёт, если webview рвёт
        # соединения по таймауту.
        try:
            _log("ошибка запроса: " + (format % args))
        except Exception:
            pass

    def handle_one_request(self):
        try:
            BaseHTTPRequestHandler.handle_one_request(self)
        except (ConnectionResetError, BrokenPipeError) as exc:
            # Обычное дело, когда webview закрыл вкладку в середине
            # запроса. Пишем на всякий случай, но без паники.
            _log(f"соединение разорвано клиентом: {type(exc).__name__}")

    def _cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors_headers()
        self.end_headers()

    def do_GET(self):
        if self.path == "/ping":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({
                "status": "ok",
                "pid": os.getpid(),
                "script_mtime": SCRIPT_MTIME,
                "hook_root": str(HOOK_ROOT),
            }).encode())
            return

        if self.path == "/list-projects":
            self._handle_list_projects()
            return

        if self.path == "/vscode-settings":
            self._handle_vscode_settings()
            return

        if self.path.split("?", 1)[0] == "/cache-usage":
            self._handle_cache_usage()
            return

        if self.path.split("?", 1)[0] == "/message-times":
            self._handle_message_times()
            return

        if self.path.split("?", 1)[0] == "/mood-history":
            self._handle_mood_history()
            return

        if self.path.split("?", 1)[0] == "/bypass":
            self._handle_bypass_get()
            return

        if self.path.split("?", 1)[0] == "/custom-config":
            self._handle_custom_config()
            return

        if self.path.split("?", 1)[0] == "/config-schema":
            self._handle_config_schema()
            return

        if self.path.split("?", 1)[0] == "/accounts":
            self._handle_accounts_get()
            return

        if self.path.split("?", 1)[0] == "/account-usage-history":
            self._handle_account_usage_history()
            return

        if self.path.split("?", 1)[0] == "/account-env":
            self._handle_account_env_get()
            return

        if self.path.split("?", 1)[0] == "/restart-exthost":
            self._handle_restart_exthost_get()
            return

        if self.path.split("?", 1)[0] == "/limit-reset-alert":
            self._handle_limit_reset_alert()
            return

        self.send_response(404)
        self.end_headers()

    def _handle_custom_config(self) -> None:
        """Отдаёт claude-custom-config.toml как JSON.

        Зачем: значения конфига попадают в webview через bootstrap,
        а тот читается ровно один раз — при загрузке окна. Правка
        настройки не действовала до Reload Window, и это регулярно
        сбивало с толку (порог поддержания показывался старый, хотя
        в файле стоял новый). Тот же приём уже применён для
        emojiButtonPlacement, здесь он распространён на весь конфиг.

        Разбор кэшируется по mtime: endpoint опрашивают несколько окон
        раз в несколько секунд, парсить TOML каждый раз незачем.
        """
        try:
            mtime = os.path.getmtime(CONFIG_FILE)
        except OSError:
            self._json_response(404, {"ok": False, "error": "конфиг не найден"})
            return

        with _CONFIG_LOCK:
            if mtime != _CONFIG_CACHE["mtime"]:
                if tomllib is None:
                    self._json_response(500, {
                        "ok": False, "error": "нужен Python 3.11+ (tomllib)",
                    })
                    return
                try:
                    with open(CONFIG_FILE, "rb") as fh:
                        _CONFIG_CACHE["data"] = tomllib.load(fh)
                except Exception as exc:
                    # Битый TOML — не повод отдавать мусор: пусть webview
                    # продолжит жить на значениях из bootstrap.
                    self._json_response(500, {
                        "ok": False, "error": f"TOML невалиден: {exc}",
                    })
                    return
                _CONFIG_CACHE["mtime"] = mtime
                _log(f"конфиг перечитан (mtime={mtime:.3f})")
            data = dict(_CONFIG_CACHE["data"])

        active = account_switcher.current_account_runtime()
        provider = cache_usage.cache_provider(active.get("model"), active.get("provider"))
        self._json_response(200, {
            "ok": True, "mtime": mtime, "config": data,
            "cache_provider": provider,
            "cache_ttl_minutes": cache_usage.cache_ttl(
                data.get("cacheKeepaliveTtlMinutes", 60),
                {p: data.get(key) for p, key in cache_usage.CACHE_TTL_CONFIG_KEYS.items()},
                provider=provider,
            ),
        })

    # --- панель настроек: описание конфига и запись значений --------------
    #
    # Панель открывается из контекстного меню страницы и правит тот же
    # claude-custom-config.toml, что и рука. Отсюда два требования, и оба
    # определяют устройство ниже.
    #
    # Первое: файл — документация. Над каждым параметром лежит абзац
    # комментария, объясняющий, зачем он и что сломается без него; часть
    # из них написана по следам поломок. Перезаписать файл через
    # `tomllib` + сериализатор нельзя: tomllib комментарии не хранит, и
    # первая же правка из панели стёрла бы весь этот текст. Поэтому
    # запись построчная — меняется правая часть строки `ключ = значение`,
    # всё остальное остаётся байт в байт.
    #
    # Второе: те же комментарии — готовые подсказки для панели. Второй
    # раз описывать параметры в JS значило бы завести два расходящихся
    # источника правды о том, что делает флаг.

    # Заголовок раздела в конфиге: `# ==== Название ====`. Хвост из
    # `=` необязателен — важно только начало, чтобы обычный комментарий,
    # начинающийся со знака равенства, случайно не стал разделом.
    _SECTION_RE = re.compile(r"^={3,}\s*(.+?)\s*=*$")

    # Перечень допустимых значений строкового параметра: строка вида
    # `Варианты: mode | mood` в его комментарии. Держать список там же,
    # где объяснение, — то же правило, что и с разделами: панель
    # получает выбор сама, а человек, читающий TOML руками, видит
    # варианты рядом с описанием, а не в чужом файле.
    _OPTIONS_RE = re.compile(r"^Варианты\s*:\s*(.+)$", re.IGNORECASE)

    @staticmethod
    def _config_lines() -> list:
        with open(CONFIG_FILE, encoding="utf-8") as fh:
            return fh.read().split("\n")

    @classmethod
    def _describe_config(cls, lines: list) -> list:
        """Разбирает конфиг в список параметров с их комментариями.

        Комментарий параметра — непрерывный блок строк `#` прямо над
        ним. Пустая строка блок обрывает: она отделяет абзац про один
        параметр от абзаца про другой.

        Разделы задаются в самом файле строками вида
        `# ==== Название ====`. Держать их там, а не списком в коде —
        то же правило, что и с подсказками: новый параметр попадает
        в раздел сам, по своему месту в файле, и человеку, читающему
        TOML руками, разделы видны так же, как в панели.
        """
        items = []
        comment: list[str] = []
        section = ""
        for raw in lines:
            line = raw.strip()
            if line.startswith("#"):
                text = line.lstrip("#").strip()
                marker = cls._SECTION_RE.match(text)
                if marker:
                    section = marker.group(1).strip()
                    comment = []
                    continue
                comment.append(text)
                continue
            if not line:
                comment = []
                continue
            if "=" not in line:
                comment = []
                continue
            key = line.split("=", 1)[0].strip()
            if not key or not key.replace("_", "").isalnum():
                comment = []
                continue
            value_text = line.split("=", 1)[1].strip()
            items.append({
                "key": key,
                "hint": "\n".join(comment).strip(),
                "raw": value_text,
                "section": section,
            })
            comment = []
        return items

    @classmethod
    def _parse_options(cls, hint: str) -> list:
        """Достаёт перечень значений из строки `Варианты: a | b` в hint.

        Пустой список означает «параметр свободный»: панель нарисует
        обычное поле ввода. Разделитель именно `|` — запятая встречается
        в обычном тексте комментария, а вертикальная черта нет.
        """
        for line in str(hint or "").split("\n"):
            match = cls._OPTIONS_RE.match(line.strip())
            if not match:
                continue
            values = [v.strip() for v in match.group(1).split("|")]
            return [v for v in values if v]
        return []

    def _handle_config_schema(self) -> None:
        """Отдаёт параметры конфига вместе с описаниями и значениями.

        Отдельный endpoint, а не поле в `/custom-config`: тот опрашивают
        несколько окон раз в несколько секунд ради актуальных значений,
        и таскать в каждом ответе килобайты комментариев незачем.
        Схема нужна ровно в момент открытия панели.
        """
        try:
            lines = self._config_lines()
        except OSError as exc:
            self._json_response(500, {"ok": False, "error": str(exc)})
            return
        if tomllib is None:
            self._json_response(500, {
                "ok": False, "error": "нужен Python 3.11+ (tomllib)",
            })
            return
        try:
            with open(CONFIG_FILE, "rb") as fh:
                data = tomllib.load(fh)
        except Exception as exc:  # noqa: BLE001
            self._json_response(500, {"ok": False, "error": f"TOML невалиден: {exc}"})
            return

        items = []
        for item in self._describe_config(lines):
            key = item["key"]
            if key not in data:
                continue  # ключ внутри секции или закомментирован
            value = data[key]
            # Панель умеет редактировать скаляры. Правило по типу, а не
            # по списку: новый флаг должен появляться в панели сам —
            # тот же принцип, что в форме настроек аккаунта.
            if not isinstance(value, (bool, int, float, str)):
                continue
            entry = {
                "key": key,
                "value": value,
                "type": ("bool" if isinstance(value, bool)
                         else "number" if isinstance(value, (int, float))
                         else "string"),
                "hint": item["hint"],
                "section": item.get("section") or "Прочее",
            }
            options = self._parse_options(item["hint"])
            if options and entry["type"] == "string":
                # Значение из файла попадает в список, даже если его там
                # нет: показать неизвестное значение как первый вариант
                # значило бы соврать про файл — ровно та ловушка, что
                # была с `effortLevel: "max"` в настройках аккаунта.
                if value not in options:
                    options = [value] + options
                entry["options"] = options
            items.append(entry)

        self._json_response(200, {
            "ok": True,
            "items": items,
            "path": CONFIG_FILE,
        })

    @staticmethod
    def _format_toml_value(value) -> str:
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            return repr(value)
        text = str(value)
        return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'

    def _handle_config_post(self) -> None:
        """Записывает значения в TOML, сохраняя комментарии и порядок."""
        body = self._read_body()
        if body is None:
            return
        try:
            payload = json.loads(body.decode("utf-8"))
        except Exception:  # noqa: BLE001
            self._json_response(400, {"ok": False, "error": "тело не JSON"})
            return
        values = payload.get("values") if isinstance(payload, dict) else None
        if not isinstance(values, dict) or not values:
            self._json_response(400, {"ok": False, "error": "ожидалось {values: {...}}"})
            return

        try:
            lines = self._config_lines()
        except OSError as exc:
            self._json_response(500, {"ok": False, "error": str(exc)})
            return

        # Значение вне перечня из комментария не записываем: модуль его
        # не поймёт и молча откатится на своё поведение по умолчанию,
        # а в файле останется настройка, которая выглядит заданной и
        # не действует. Молчаливое бездействие хуже отказа.
        for item in self._describe_config(lines):
            key = item["key"]
            if key not in values:
                continue
            options = self._parse_options(item["hint"])
            if options and values[key] not in options:
                self._json_response(400, {
                    "ok": False,
                    "error": (f"{key}: значение {values[key]!r} не из перечня "
                              + " | ".join(options)),
                })
                return

        changed = []
        remaining = dict(values)
        for i, raw in enumerate(lines):
            stripped = raw.strip()
            if not stripped or stripped.startswith("#") or "=" not in stripped:
                continue
            key = stripped.split("=", 1)[0].strip()
            if key not in remaining:
                continue
            new_value = remaining.pop(key)
            # Отступ строки сохраняем: в этом файле его нет, но правило
            # «трогаем только правую часть» должно держаться и дальше.
            indent = raw[: len(raw) - len(raw.lstrip())]
            lines[i] = f"{indent}{key} = {self._format_toml_value(new_value)}"
            changed.append(key)

        if remaining:
            # Дописывать новые ключи в конец файла панель не должна: он
            # разбит на разделы с объяснениями, и ключ без абзаца над ним
            # выпал бы из этого строя. Незнакомый ключ — почти наверняка
            # опечатка или устаревшее окно.
            self._json_response(400, {
                "ok": False,
                "error": "неизвестные параметры: " + ", ".join(sorted(remaining)),
            })
            return

        text = "\n".join(lines)
        if tomllib is not None:
            # Проверяем ДО записи: сломанный конфиг оставил бы webview
            # без настроек до ручной починки файла.
            try:
                tomllib.loads(text)
            except Exception as exc:  # noqa: BLE001
                self._json_response(500, {
                    "ok": False, "error": f"после правки TOML невалиден: {exc}",
                })
                return

        try:
            tmp = CONFIG_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                fh.write(text)
            os.replace(tmp, CONFIG_FILE)
        except OSError as exc:
            self._json_response(500, {"ok": False, "error": str(exc)})
            return

        _log("панель настроек: " + ", ".join(
            f"{k}={values[k]}" for k in changed) or "нечего менять")
        self._json_response(200, {"ok": True, "changed": changed})

    # --- сигнал сброса 5-часового лимита ----------------------------------
    #
    # Автомат свидетеля, проигрыватель и цикл мониторинга живут в
    # limit_alert.py и крутятся собственным daemon-потоком (см. main);
    # здесь только транспорт для диагностики и проверки звука.

    def _handle_limit_reset_alert(self) -> None:
        """Состояние монитора: включён ли, снимок кэша, окно-свидетель."""
        self._json_response(200, {"ok": True, **limit_alert.status()})

    def _handle_limit_reset_alert_test(self) -> None:
        """Немедленно проигрывает notification.mp3 — проверка руками."""
        self._json_response(200, limit_alert.test_play())

    def _handle_limit_reset_alert_stop(self) -> None:
        """Гасит играющий звук — клик по кнопке «Стоп» в футере."""
        self._json_response(200, {"ok": True, "stopped": limit_alert.stop()})

    # --- переключение аккаунтов ------------------------------------------
    #
    # Логика подмены ~/.claude/settings.json живёт в account_switcher.py;
    # здесь только транспорт для кнопки Accs в футере.

    def _handle_account_usage_history(self) -> None:
        from urllib.parse import parse_qs, urlsplit
        query = parse_qs(urlsplit(self.path).query)
        filename = query.get("file", [""])[0]
        try:
            state_dir = LOGS_DIR
            data = account_usage_history.details(filename, state_dir,
                mode=query.get("mode", ["day"])[0], selected=query.get("date", [None])[0])
        except ValueError as exc:
            self._json_response(400, {"ok": False, "error": str(exc)})
            return
        except Exception as exc:
            _log(f"account usage history failed: {type(exc).__name__}")
            self._json_response(500, {"ok": False, "error": "Не удалось прочитать историю использования"})
            return
        self._json_response(200, data)

    def _handle_accounts_get(self) -> None:
        from urllib.parse import parse_qs, urlsplit
        openai_bootstrap.ensure_ready()
        refresh = parse_qs(urlsplit(self.path).query).get("refresh_usage") == ["1"]
        try:
            accounts = account_switcher.list_accounts(refresh_usage=refresh,
                usage_recorder=lambda entry, sources: account_usage_monitor.record_entry(
                    entry, sources, LOGS_DIR))
        except Exception as exc:  # noqa: BLE001 — endpoint не роняет сервер
            self._json_response(500, {"ok": False, "error": str(exc)})
            return
        self._json_response(200, {"ok": True, "accounts": accounts})

    def _handle_accounts_post(self) -> None:
        body = self._read_body()
        if body is None:
            return
        try:
            payload = json.loads(body.decode("utf-8"))
        except Exception:
            self._json_response(400, {"ok": False, "error": "тело не JSON"})
            return
        if not isinstance(payload, dict):
            self._json_response(400, {"ok": False, "error": "ожидался объект"})
            return

        target = str(payload.get("file") or "")
        if target == "settings_openai.json":
            ready, bridge_message = codex_bridge_manager.ensure()
            if not ready:
                self._json_response(503, {
                    "ok": False, "error": bridge_message,
                    "accounts": account_switcher.list_accounts(),
                })
                return
        # revert — возврат прежнего аккаунта после отказа от перезапуска.
        # Отличить его от обычного переключения сервер сам не может:
        # запрос тот же самый. Знает об этом только модалка, она и
        # сообщает — иначе в истории панели Usage каждый отказ выглядел
        # бы как два переключения подряд.
        revert = bool(payload.get("revert"))
        try:
            ok, message = account_switcher.switch_account(target, revert=revert)
        except Exception as exc:  # noqa: BLE001
            self._json_response(500, {"ok": False, "error": str(exc)})
            return

        _log(f"переключение аккаунта на {target!r}"
             f"{' (откат)' if revert else ''}: {message}")
        self._json_response(200 if ok else 400, {
            "ok": ok,
            "message": message,
            "accounts": account_switcher.list_accounts(),
        })

    # --- правка настроек аккаунта ----------------------------------------
    #
    # Панель Accs умеет не только выбирать аккаунт, но и править его
    # файл — по шестерёнке в строке. Разделов два: `env` (провайдер) и
    # скалярные настройки верхнего уровня (`model`, `language`, …), без
    # которых у аккаунта Anthropic редактор был бы пуст.
    #
    # Значения ходят как есть, включая токены: сервер слушает только
    # localhost, а webview, который их запрашивает, живёт на той же
    # машине. В журнал они не попадают — там только имена.
    #
    # Имя endpoint'а осталось прежним (`/account-env`), хотя разделов
    # теперь два: его знает webview, загруженный до этой правки, а
    # bootstrap перечитывается только при Reload Window. Переименование
    # оставило бы такие окна с мёртвой шестерёнкой.

    def _handle_account_env_get(self) -> None:
        filename = ""
        if "?" in self.path:
            for part in self.path.split("?", 1)[1].split("&"):
                if part.startswith("file="):
                    filename = unquote(part[len("file="):])
        try:
            ok, message, config = account_switcher.read_account_config(filename)
        except Exception as exc:  # noqa: BLE001 — endpoint не роняет сервер
            self._json_response(500, {"ok": False, "error": str(exc)})
            return
        if not ok:
            self._json_response(400, {"ok": False, "error": message})
            return
        # `env` отдаётся тем же ключом, что и раньше: старый webview
        # читает только его и продолжает работать. То же про
        # `subscription`: ключа нет у webview, загруженного до
        # появления раздела, — отсутствие значит «не знаю», не «нет».
        # None (OpenAI: подписка автоматическая из Codex id_token)
        # отдаётся тоже отсутствием ключа — поле не рисуется вовсе.
        body = {
            "ok": True,
            "file": filename,
            "env": config["env"],
            "settings": config["settings"],
            "hints": account_switcher.hints(),
        }
        if config["subscription"] is not None:
            body["subscription"] = config["subscription"]
            body["subscriptionFields"] = config["subscriptionFields"]
        self._json_response(200, body)

    def _handle_account_env_post(self) -> None:
        body = self._read_body()
        if body is None:
            return
        try:
            payload = json.loads(body.decode("utf-8"))
        except Exception:
            self._json_response(400, {"ok": False, "error": "тело не JSON"})
            return
        if not isinstance(payload, dict):
            self._json_response(400, {"ok": False, "error": "ожидался объект"})
            return

        filename = str(payload.get("file") or "")
        # Отсутствующий раздел — это «не трогать», а не «очистить»:
        # старый webview шлёт одно `env`, и его правка не должна
        # стирать настройки верхнего уровня. То же про подписку:
        # ключа нет у webview до появления раздела.
        env = payload.get("env")
        settings = payload.get("settings")
        subscription = payload.get("subscription")

        results = []
        try:
            if isinstance(subscription, dict):
                results.append(account_switcher.write_subscription(
                    filename, subscription.get("paidAt"),
                    subscription.get("days"), subscription.get("email"),
                    subscription.get("plan")))
            if env is not None or settings is not None or not results:
                results.append(account_switcher.write_account_config(
                    filename, env, settings))
        except Exception as exc:  # noqa: BLE001
            self._json_response(500, {"ok": False, "error": str(exc)})
            return
        ok = all(r[0] for r in results)
        message = " ".join(r[1] for r in results)

        names = ", ".join(sorted(
            list(env if isinstance(env, dict) else [])
            + list(settings if isinstance(settings, dict) else [])
        )) or "—"
        if isinstance(subscription, dict):
            names += " + подписка"
        _log(f"правка настроек {filename!r}: {message} [{names}]")
        self._json_response(200 if ok else 400, {
            "ok": ok,
            "message": message,
            "accounts": account_switcher.list_accounts(),
        })

    # --- перезапуск extension host ---------------------------------------
    #
    # Транспорт для модального окна, которое панель Accs показывает после
    # смены аккаунта. Сам перезапуск делает не сервер: он лишь кладёт
    # заявку, а команду `workbench.action.restartExtensionHost` вызывает
    # блок, инжектированный в extension.js (см. RESTART_REQUEST_FILE).

    @staticmethod
    def _read_restart_token(path: str) -> str:
        """Токен из файла заявки/подтверждения ('' при любой проблеме).

        Оба файла пишем мы сами, но читать их приходится вперемешку с
        записью из другого процесса, поэтому битый или наполовину
        записанный JSON здесь — штатная ситуация, а не ошибка.
        """
        if not path:
            return ""
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, json.JSONDecodeError):
            return ""
        token = data.get("token") if isinstance(data, dict) else None
        return token if isinstance(token, str) else ""

    def _handle_restart_exthost_post(self) -> None:
        """Кладёт заявку на перезапуск extension host.

        Тело запроса может содержать `sessionId` — идентификатор
        диалога, из которого нажали «Перезапустить». Он нужен, чтобы
        после рестарта открыть заново ИМЕННО эту сессию: панель,
        созданную умершим хостом, оживить нельзя, а новый хост о ней
        уже ничего не знает. Своё имя знает только сам webview
        (`window.__claudeSessionId`), поэтому он его и передаёт.
        """
        if not LOGS_DIR:
            self._json_response(500, {
                "ok": False, "error": "CLAUDE_PROJECT_DIR не задан",
            })
            return

        session_id = ""
        window_id = ""
        body = self._read_body()
        if body:
            try:
                payload = json.loads(body.decode("utf-8"))
                if isinstance(payload, dict):
                    window_id = payload.get("windowId", "")
                    value = payload.get("sessionId")
                    if isinstance(value, str):
                        session_id = value
            except Exception:
                # Тело необязательное: без sessionId заявка остаётся
                # рабочей, просто вкладку переоткрыть будет нечем.
                pass

        from hook_supervisor import window_registration
        window = window_registration(window_id, LOGS_DIR) if GLOBAL_INSTALL else None
        if window:
            # The explicit sender takes precedence over a stale/moved transcript.
            projects = window["projects"]
            project = projects[0] if projects else ""
        else:
            window_id = ""
            project = _session_project(session_id) if GLOBAL_INSTALL else PROJECT_DIR
        if not project and not window:
            self._json_response(400, {"ok": False, "error":
                "Не удалось определить проект сессии. Перезапустите нужное окно VS Code вручную."})
            return
        token = uuid.uuid4().hex
        try:
            os.makedirs(LOGS_DIR, exist_ok=True)
            # Через временный файл: наблюдатель в extension.js читает
            # заявку по таймеру и может попасть ровно в момент записи.
            tmp = RESTART_REQUEST_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"token": token, "ts": time.time(),
                           "project": project,
                           "windowId": window_id,
                           "sessionId": session_id}, fh)
            os.replace(tmp, RESTART_REQUEST_FILE)
        except OSError as exc:
            self._json_response(500, {"ok": False, "error": str(exc)})
            return

        _log(f"заявка на перезапуск extension host: token={token} "
             f"session={session_id or '—'}")
        self._json_response(200, {"ok": True, "token": token})

    def _handle_restart_exthost_get(self) -> None:
        """Приняло ли расширение последнюю заявку.

        Нужен для честного сообщения об отказе: если инжекция в
        extension.js не применилась (например, после обновления
        расширения), заявка так и останется без подтверждения — и
        модальное окно скажет об этом вместо того, чтобы висеть
        в ожидании перезапуска, которого не будет.
        """
        requested = self._read_restart_token(RESTART_REQUEST_FILE)
        acked = self._read_restart_token(RESTART_ACK_FILE)
        self._json_response(200, {
            "ok": True,
            "token": requested,
            "acked": bool(requested) and requested == acked,
        })

    # --- bypass-режим ---------------------------------------------------
    #
    # Ровно тот же marker-файл, что ставит bypass-magic-word.py по слову
    # `да!`: .claude/hooks-runtime/<session_id> с меткой времени внутри.
    # PreToolUse хук bypass-check.sh проверяет только факт существования
    # файла, поэтому кнопка в футере и магическое слово — два входа
    # в один механизм, а не два независимых состояния.

    def _bypass_marker(self, session_id: str) -> str:
        return str(bypass_dir(PROJECT_DIR) / session_id)

    def _bypass_session_arg(self, source: str) -> str | None:
        """Достаёт и валидирует session id. None — ответ уже отправлен."""
        if not PROJECT_DIR and not GLOBAL_INSTALL:
            self._json_response(500, {"ok": False, "error": "CLAUDE_PROJECT_DIR не задан"})
            return None
        if not source or not SESSION_ID_RE.match(source):
            self._json_response(400, {"ok": False, "error": "некорректный session id"})
            return None
        return source

    def _handle_bypass_get(self) -> None:
        requested = ""
        if "?" in self.path:
            for part in self.path.split("?", 1)[1].split("&"):
                if part.startswith("session="):
                    requested = part[len("session="):]
        session_id = self._bypass_session_arg(requested)
        if session_id is None:
            return

        marker = self._bypass_marker(session_id)
        since = None
        if os.path.isfile(marker):
            try:
                with open(marker, encoding="utf-8") as fh:
                    since = float(fh.read().strip() or 0) or None
            except (OSError, ValueError):
                since = None
        self._json_response(200, {
            "ok": True,
            "active": os.path.isfile(marker),
            "since": since,
        })

    def _handle_bypass_post(self) -> None:
        body = self._read_body()
        if body is None:
            return
        try:
            payload = json.loads(body.decode("utf-8"))
        except Exception:
            self._json_response(400, {"ok": False, "error": "тело не JSON"})
            return
        if not isinstance(payload, dict):
            self._json_response(400, {"ok": False, "error": "ожидался объект"})
            return

        session_id = self._bypass_session_arg(str(payload.get("session") or ""))
        if session_id is None:
            return

        marker = self._bypass_marker(session_id)
        want = bool(payload.get("active"))
        try:
            if want:
                os.makedirs(os.path.dirname(marker), exist_ok=True)
                with open(marker, "w", encoding="utf-8") as fh:
                    fh.write(f"{time.time()}\n")
            elif os.path.isfile(marker):
                os.remove(marker)
        except OSError as exc:
            self._json_response(500, {"ok": False, "error": str(exc)})
            return

        self._json_response(200, {"ok": True, "active": os.path.isfile(marker)})

    def _handle_webview_error(self) -> None:
        """Складывает исключения из webview в один журнал.

        Своих ошибок webview нам не показывал вовсе: devtools открыты не
        всегда, а в логи VSCode исключения страницы не попадают. Из-за
        этого поломку 2026-09-01 («вкладки пустые, бандл цел, наш JS
        исполняется») нечем было даже локализовать — журнал знал только
        про install/init, но не про падения.

        Пишем строками в один файл, а не файлом на ошибку, как
        /save-log: ошибка обычно повторяется десятками, и каталог
        засорился бы мгновенно. Размер ограничен — журнал ведётся ради
        последнего инцидента, а не вечно.
        """
        raw = self._read_body()
        if raw is None:
            return
        if not LOGS_DIR:
            self._json_response(500, {"ok": False, "error": "LOGS_DIR не найден"})
            return
        try:
            payload = json.loads(raw.decode("utf-8", errors="replace"))
        except Exception:
            payload = {"raw": raw.decode("utf-8", errors="replace")[:2000]}

        path = os.path.join(LOGS_DIR, "webview-errors.log")
        try:
            os.makedirs(LOGS_DIR, exist_ok=True)
            # Простая ротация: перед записью подрезаем хвостом.
            if os.path.isfile(path) and os.path.getsize(path) > 512 * 1024:
                with open(path, "r", encoding="utf-8", errors="replace") as fh:
                    tail = fh.readlines()[-500:]
                with open(path, "w", encoding="utf-8") as fh:
                    fh.writelines(tail)
            stamp = time.strftime("%Y-%m-%d %H:%M:%S")
            with open(path, "a", encoding="utf-8") as fh:
                fh.write(f"{stamp} {json.dumps(payload, ensure_ascii=False)}\n")
        except OSError as exc:
            self._json_response(500, {"ok": False, "error": str(exc)})
            return

        _log(f"webview-error: {str(payload.get('message'))[:200]}")
        self._json_response(200, {"ok": True})

    def _resolve_transcript(self):
        """Находит транскрипт сессии и TTL для запросов о кэше.

        Общий для /cache-usage и /mood-history: оба отвечают об
        одной и той же сессии, и разъехавшийся поиск означал бы,
        что окно истории показывает не ту переписку, что стрелка.

        Возвращает (транскрипт, ttl, каталог состояния) либо None —
        в последнем случае ответ об ошибке уже отправлен.
        """
        if not PROJECT_DIR and not GLOBAL_INSTALL:
            self._json_response(500, {
                "ok": False, "error": "CLAUDE_PROJECT_DIR не задан",
            })
            return

        requested = ""
        if "?" in self.path:
            for part in self.path.split("?", 1)[1].split("&"):
                if part.startswith("session="):
                    requested = part[len("session="):]

        project_dir = os.path.join(
            CLAUDE_PROJECTS_DIR, encode_project_path(PROJECT_DIR)
        )
        if requested:
            # Validate before constructing paths, including the cross-project lookup.
            if not SESSION_ID_RE.match(requested):
                self._json_response(400, {
                    "ok": False, "error": "Некорректный идентификатор сессии",
                })
                return
            transcript = os.path.join(project_dir, requested + ".jsonl")
            if not os.path.isfile(transcript):
                # The shared server's cwd can differ from the open/resumed tab.
                # Search by the exact UUID, never by another project's newest chat.
                matches = []
                if os.path.isdir(CLAUDE_PROJECTS_DIR):
                    for entry in os.scandir(CLAUDE_PROJECTS_DIR):
                        if entry.is_dir(follow_symlinks=False):
                            candidate = os.path.join(entry.path, requested + ".jsonl")
                            if os.path.isfile(candidate):
                                matches.append(candidate)
                if len(matches) != 1:
                    self._json_response(404 if not matches else 409, {
                        "ok": False,
                        "error": "История этой сессии ещё не найдена. Отправьте сообщение и откройте Usage снова." if not matches else
                                 "Сессия найдена в нескольких проектах",
                    })
                    return
                transcript = matches[0]
        else:
            if GLOBAL_INSTALL:
                self._json_response(400, {"ok": False, "error": "Укажите session для общей установки"})
                return
            if not os.path.isdir(project_dir):
                self._json_response(404, {
                    "ok": False,
                    "error": "История проекта отсутствует. Откройте сессию Claude и отправьте сообщение.",
                })
                return
            transcript = ""
            newest = -1.0
            try:
                entries = os.listdir(project_dir)
            except OSError as exc:
                self._json_response(500, {
                    "ok": False, "error": f"listdir failed: {exc}",
                })
                return
            for entry in entries:
                if not entry.endswith(".jsonl"):
                    continue
                full = os.path.join(project_dir, entry)
                try:
                    mtime = os.path.getmtime(full)
                except OSError:
                    continue
                if mtime > newest:
                    newest, transcript = mtime, full
            if not transcript:
                self._json_response(404, {
                    "ok": False, "error": "в проекте нет сессий",
                })
                return

        # Общий TTL — резерв для провайдера без отдельной настройки.
        ttl = _config_value("cacheKeepaliveTtlMinutes", 60)
        if not (isinstance(ttl, int) and not isinstance(ttl, bool) and ttl > 0):
            ttl = 60

        state_dir = LOGS_DIR
        return transcript, ttl, state_dir

    def _handle_message_times(self) -> None:
        from urllib.parse import parse_qs, urlsplit
        if not parse_qs(urlsplit(self.path).query).get("session", [""])[0]:
            self._json_response(400, {"ok": False, "error": "session is required"})
            return
        resolved = self._resolve_transcript()
        if resolved is None:
            return
        transcript, _, state_dir = resolved
        try:
            data = message_timestamps.snapshot(
                transcript, state_dir,
                include_messages=parse_qs(urlsplit(self.path).query).get("include_messages") == ["1"],
                running=parse_qs(urlsplit(self.path).query).get("running") == ["1"],
            )
        except OSError as exc:
            self._json_response(500, {"ok": False, "error": str(exc)})
            return
        self._json_response(200, {"ok": True, **data})

    def _handle_message_stop(self) -> None:
        from urllib.parse import parse_qs, urlsplit
        if not parse_qs(urlsplit(self.path).query).get("session", [""])[0]:
            self._json_response(400, {"ok": False, "error": "session is required"})
            return
        body = self._read_body()
        if body is None:
            return
        try:
            payload = json.loads(body)
            ids = payload.get("message_ids")
            if not isinstance(ids, list) or not ids or len(ids) > 100 or not all(isinstance(i, str) for i in ids):
                raise ValueError("message_ids is required")
            ended = payload.get("completed_at")
            if not isinstance(ended, str):
                raise ValueError("completed_at is required")
        except (ValueError, AttributeError) as exc:
            self._json_response(400, {"ok": False, "error": str(exc)})
            return
        resolved = self._resolve_transcript()
        if resolved is None:
            return
        transcript, _, state_dir = resolved
        try:
            data = message_timestamps.record_stop(transcript, state_dir, message_ids=ids,
                                                 completed_at=ended, source="ui_stop")
            cpu_probe.note_event(transcript, 'ui_stop', completed_at=ended)
        except (OSError, ValueError) as exc:
            self._json_response(400, {"ok": False, "error": str(exc)})
            return
        self._json_response(200, {"ok": True, **data})

    def _handle_cache_usage(self) -> None:
        """Статистика prompt-кэша сессии для кнопки Cache в футере.

        Сессия определяется по самому свежему .jsonl в папке проекта
        (~/.claude/projects/<кодированный cwd>/) — webview собственного
        session_id не знает, а свежий файл почти всегда и есть текущая
        сессия. Явный ?session=<uuid> перекрывает автоопределение:
        нужно, чтобы посмотреть уже закрытую сессию.

        Разбор инкрементальный, состояние — в hooks-runtime, поэтому
        повторные нажатия кнопки почти бесплатны даже на транскрипте
        в десятки мегабайт.
        """
        resolved = self._resolve_transcript()
        if resolved is None:
            return
        transcript, ttl, state_dir = resolved
        try:
            with _CACHE_LOCK:
                stats = cache_usage.collect(
                    transcript, state_dir=state_dir, ttl_minutes=ttl,
                    ttl_by_provider=_cache_ttl_by_provider(),
                )
                active = account_switcher.current_account_runtime()
                stats["cache_provider"] = cache_usage.cache_provider(
                    active.get("model"), active.get("provider"),
                )
                stats["ttl_minutes"] = cache_usage.cache_ttl(
                    ttl, _cache_ttl_by_provider(), provider=stats["cache_provider"],
                )
                configured_model = active.get("model")
                if isinstance(configured_model, str) and configured_model:
                    stats["model"] = configured_model
                if active.get("provider") == "openai":
                    bridge_usage = codex_bridge_manager.bridge_usage_snapshot(
                        timeout=1.0,
                    )
                    session_key = os.path.basename(transcript)
                    if session_key.endswith(".jsonl"):
                        session_key = session_key[:-6]
                    cache_usage.apply_openai_usage(
                        stats, bridge_usage, session_key,
                    )
                    cache_usage.apply_openai_fallback(
                        stats, stats.get("model") or configured_model or "",
                    )
        except Exception as exc:
            self._json_response(500, {"ok": False, "error": str(exc)})
            return

        self._json_response(200 if stats.get("ok") else 404, stats)

    def _handle_mood_history(self) -> None:
        """История индикатора Mood за сессию — ряд накопленных чисел.

        Сессия ищется тем же способом, что и для /cache-usage, и ответ
        строится из того же разобранного состояния: история — это не
        отдельная запись событий, а пересчёт уже имеющегося транскрипта,
        поэтому она полна с первого хода сессии, включая ходы, сделанные
        до появления самого окна истории.

        Значение шкалы здесь не считается: его формула живёт в JS, и
        вторая копия рано или поздно разошлась бы с первой.
        """
        resolved = self._resolve_transcript()
        if resolved is None:
            return
        transcript, ttl, state_dir = resolved
        try:
            with _CACHE_LOCK:
                data = cache_usage.collect_series(
                    transcript, state_dir=state_dir, ttl_minutes=ttl,
                    ttl_by_provider=_cache_ttl_by_provider(),
                )
        except Exception as exc:  # noqa: BLE001 — endpoint не роняет сервер
            self._json_response(500, {"ok": False, "error": str(exc)})
            return
        self._json_response(200 if data.get("ok") else 404, data)

    def _handle_vscode_settings(self) -> None:
        """Отдаёт webview'у актуальные значения настроек из VSCode
        Settings UI (сейчас — только emojiButtonPlacement).

        Зачем: те же значения приезжают в bootstrap при следующем
        UserPromptSubmit, но применяются лишь после Reload Window.
        Опрос этого endpoint'а позволяет claude-custom.js подхватывать
        смену настройки почти сразу, как это уже сделано для CSS.

        Логика чтения settings.json (JSONC + приоритет workspace над
        user) живёт в patch-claude-webview.py и импортируется отсюда,
        чтобы не держать две расходящиеся копии парсера.
        """
        try:
            settings = _load_webview_patcher()._apply_vscode_settings({})
        except Exception as e:  # noqa: BLE001 — endpoint не должен ронять сервер
            self._json_response(500, {"error": f"settings read failed: {e}"})
            return
        self._json_response(200, settings)

    def _handle_list_projects(self) -> None:
        """Возвращает список папок-проектов в ~/.claude/projects/.

        Для каждой папки: encoded_name, число .jsonl-сессий, размер на диске
        и попытка декодирования обратно в реальный путь (если такая папка
        существует и кодировка совпадает — путь считается «надёжным»).
        """
        if not os.path.isdir(CLAUDE_PROJECTS_DIR):
            self._json_response(200, {"projects": []})
            return

        projects = []
        try:
            entries = sorted(os.listdir(CLAUDE_PROJECTS_DIR))
        except OSError as e:
            self._json_response(500, {"error": f"listdir failed: {e}"})
            return

        for entry in entries:
            full = os.path.join(CLAUDE_PROJECTS_DIR, entry)
            if not os.path.isdir(full):
                continue

            session_count = 0
            last_mtime = 0
            try:
                for fname in os.listdir(full):
                    if fname.endswith(".jsonl"):
                        session_count += 1
                        try:
                            mtime = os.path.getmtime(os.path.join(full, fname))
                            if mtime > last_mtime:
                                last_mtime = mtime
                        except OSError:
                            pass
            except OSError:
                continue

            real_path = _real_path_from_cwd(entry)
            projects.append({
                "encoded_name": entry,
                "real_path": real_path,
                "display_name": real_path or _decode_for_display(entry),
                "session_count": session_count,
                "last_mtime": last_mtime,
            })

        # Сортируем по последней активности (более свежие — выше)
        projects.sort(key=lambda p: p["last_mtime"], reverse=True)
        self._json_response(200, {"projects": projects})

    def _read_body(self, max_bytes=MAX_BODY_BYTES) -> bytes | None:
        """Читает тело POST с защитой от слишком больших payload'ов."""
        length = int(self.headers.get("Content-Length", 0))
        if length < 0 or length > max_bytes:
            self.send_response(413)
            self._cors_headers()
            self.end_headers()
            return None
        return self.rfile.read(length)

    def _json_response(self, code: int, payload: dict) -> None:
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self._cors_headers()
        self.end_headers()
        self.wfile.write(json.dumps(payload, ensure_ascii=False).encode())

    def do_POST(self):
        if self.path == "/image-export":
            import image_export
            raw = self._read_body(image_export.MAX_REQUEST_BYTES)
            if raw is None:
                return
            try:
                result = image_export.export_image(json.loads(raw))
            except (ValueError, TypeError) as exc:
                self._json_response(400, {"ok": False, "error": str(exc)})
            except Exception:
                self._json_response(500, {"ok": False, "error": "Не удалось скопировать или сохранить изображение"})
            else:
                self._json_response(200, result)
            return

        if self.path.split("?", 1)[0] == "/message-times":
            self._handle_message_stop()
            return

        if self.path == "/bypass":
            self._handle_bypass_post()
            return

        if self.path == "/accounts":
            self._handle_accounts_post()
            return

        if self.path == "/account-env":
            self._handle_account_env_post()
            return

        if self.path == "/restart-exthost":
            self._handle_restart_exthost_post()
            return

        if self.path == "/custom-config":
            self._handle_config_post()
            return

        if self.path == "/limit-reset-alert-test":
            self._handle_limit_reset_alert_test()
            return

        if self.path == "/limit-reset-alert-stop":
            self._handle_limit_reset_alert_stop()
            return

        if self.path == "/webview-error":
            self._handle_webview_error()
            return

        if self.path == "/save-log":
            raw = self._read_body()
            if raw is None:
                return
            body = raw.decode("utf-8", errors="replace")

            if not LOGS_DIR:
                self._json_response(500, {"error": "LOGS_DIR not found"})
                return
            os.makedirs(LOGS_DIR, exist_ok=True)

            ts = time.strftime("%Y-%m-%d_%H-%M-%S")
            filename = f"debug-log-{ts}.txt"
            filepath = os.path.join(LOGS_DIR, filename)
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(body)

            self._json_response(200, {
                "status": "saved",
                "file": filename,
                "path": filepath,
            })
            return

        if self.path == "/locale-drift":
            raw = self._read_body()
            if raw is None:
                return
            try:
                data = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as e:
                self._json_response(400, {"error": f"invalid JSON: {e}"})
                return

            items = data.get("items") if isinstance(data, dict) else None
            if not isinstance(items, list):
                self._json_response(400, {
                    "error": "expected body {\"items\": [{section,label,title}, ...], \"texts\": [str, ...]}",
                })
                return
            # texts — необязательное поле; если не передано, оставим пустой список
            raw_texts = data.get("texts") if isinstance(data, dict) else None
            if raw_texts is not None and not isinstance(raw_texts, list):
                raw_texts = None

            # Нормализуем items
            cleaned_items = []
            for it in items:
                if not isinstance(it, dict):
                    continue
                cleaned_items.append({
                    "section": str(it.get("section") or "").strip() or None,
                    "label": str(it.get("label") or "").strip(),
                    "title": str(it.get("title") or "").strip(),
                })

            # Нормализуем texts: только строки, страпленные, дедуп с сохранением порядка
            cleaned_texts = []
            seen_texts = set()
            if raw_texts:
                for t in raw_texts:
                    if not isinstance(t, str):
                        continue
                    s = t.strip()
                    if not s or s in seen_texts:
                        continue
                    seen_texts.add(s)
                    cleaned_texts.append(s)

            if not LOCALE_DRIFT_FILE:
                self._json_response(500, {"error": "LOCALE_DRIFT_FILE not configured"})
                return
            os.makedirs(os.path.dirname(LOCALE_DRIFT_FILE), exist_ok=True)

            payload = {
                "collected_at": time.strftime("%Y-%m-%dT%H:%M:%S%z") or
                                time.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "items": cleaned_items,
                "texts": cleaned_texts,
            }
            _atomic_write_json(LOCALE_DRIFT_FILE, payload)

            self._json_response(200, {
                "status": "saved",
                "items_count": len(cleaned_items),
                "texts_count": len(cleaned_texts),
                "path": LOCALE_DRIFT_FILE,
            })
            return

        if self.path == "/models-list":
            raw = self._read_body()
            if raw is None:
                return
            try:
                data = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as e:
                self._json_response(400, {"error": f"invalid JSON: {e}"})
                return

            models = data.get("models") if isinstance(data, dict) else None
            if not isinstance(models, list):
                self._json_response(400, {
                    "error": "expected body {\"models\": [{value,displayName,description,isActive}, ...]}",
                })
                return

            cleaned = []
            for m in models:
                if not isinstance(m, dict):
                    continue
                value = m.get("value")
                cleaned.append({
                    "value": (str(value).strip() if value else None) or None,
                    "displayName": str(m.get("displayName") or "").strip(),
                    "description": str(m.get("description") or "").strip(),
                    "isActive": bool(m.get("isActive")),
                })

            if not MODELS_LIST_FILE:
                self._json_response(500, {"error": "MODELS_LIST_FILE not configured"})
                return
            os.makedirs(os.path.dirname(MODELS_LIST_FILE), exist_ok=True)

            payload = {
                "collected_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                "models": cleaned,
            }
            _atomic_write_json(MODELS_LIST_FILE, payload)

            self._json_response(200, {
                "status": "saved",
                "count": len(cleaned),
                "path": MODELS_LIST_FILE,
            })
            return

        if self.path == "/move-session":
            self._handle_move_session()
            return

        if self.path == "/copy-session":
            self._handle_copy_session()
            return

        if self.path == "/create-project":
            self._handle_create_project()
            return

        if self.path == "/diag":
            # Самодиагностика webview: JS-патч присылает {tag, data},
            # сервер аппендит в .claude/hooks-runtime/session-mover-diag.log
            # с таймстампом. Используется только для отладки.
            raw = self._read_body()
            if raw is None:
                return
            try:
                data = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as e:
                self._json_response(400, {"error": f"invalid JSON: {e}"})
                return
            log_path = os.path.join(LOGS_DIR or "/tmp",
                                    "session-mover-diag.log")
            try:
                os.makedirs(os.path.dirname(log_path), exist_ok=True)
                line = "[" + time.strftime("%H:%M:%S") + "] " + \
                       json.dumps(data, ensure_ascii=False) + "\n"
                with open(log_path, "a", encoding="utf-8") as f:
                    f.write(line)
            except OSError as e:
                self._json_response(500, {"error": str(e)})
                return
            self._json_response(200, {"status": "ok"})
            return

        self.send_response(404)
        self._cors_headers()
        self.end_headers()

    def _find_session_owner(self, session_id: str) -> str | None:
        """Сканирует ~/.claude/projects/* и возвращает имя папки, в которой
        лежит <session_id>.jsonl. Если файлов с таким UUID несколько —
        возвращает самый свежий (по mtime). None если не найдено.
        """
        if not os.path.isdir(CLAUDE_PROJECTS_DIR):
            return None
        candidates: list[tuple[float, str]] = []
        try:
            entries = os.listdir(CLAUDE_PROJECTS_DIR)
        except OSError:
            return None
        for entry in entries:
            path = os.path.join(CLAUDE_PROJECTS_DIR, entry, session_id + ".jsonl")
            if os.path.isfile(path):
                try:
                    candidates.append((os.path.getmtime(path), entry))
                except OSError:
                    candidates.append((0, entry))
        if not candidates:
            return None
        candidates.sort(reverse=True)
        return candidates[0][1]

    def _handle_move_session(self) -> None:
        """Перемещает .jsonl-файл сессии между папками проектов.

        Body: {"session_id": "<uuid>", "target_project": "<encoded>",
               "source_project": "<encoded>"?}
        source_project опционален: если не указан — ищется во всех
        папках ~/.claude/projects/, чтобы UI не нужно было знать
        текущий проект webview.
        """
        raw = self._read_body()
        if raw is None:
            return
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            self._json_response(400, {"error": f"invalid JSON: {e}"})
            return

        if not isinstance(data, dict):
            self._json_response(400, {"error": "expected JSON object"})
            return

        session_id = data.get("session_id")
        source = data.get("source_project")
        target = data.get("target_project")

        # Валидация: session_id должен быть UUID; source/target — имена
        # вида '-...' с только [A-Za-z0-9-]. Это защита от directory
        # traversal (../../etc/passwd и т.п.).
        if not isinstance(session_id, str) or not SESSION_ID_RE.match(session_id):
            self._json_response(400, {"error": "invalid session_id (expected UUID)"})
            return
        if not isinstance(target, str) or not PROJECT_DIR_NAME_RE.match(target):
            self._json_response(400, {"error": "invalid target_project"})
            return

        # source_project: если указан — валидируем; если нет — auto-detect
        # сканированием всех папок ~/.claude/projects/.
        if source is None:
            source = self._find_session_owner(session_id)
            if source is None:
                self._json_response(404, {
                    "error": f"session {session_id} not found in any project",
                })
                return
        else:
            if not isinstance(source, str) or not PROJECT_DIR_NAME_RE.match(source):
                self._json_response(400, {"error": "invalid source_project"})
                return

        if source == target:
            self._json_response(400, {"error": "source and target are the same"})
            return

        src_dir = os.path.join(CLAUDE_PROJECTS_DIR, source)
        dst_dir = os.path.join(CLAUDE_PROJECTS_DIR, target)
        src_file = os.path.join(src_dir, session_id + ".jsonl")
        dst_file = os.path.join(dst_dir, session_id + ".jsonl")

        if not os.path.isfile(src_file):
            self._json_response(404, {"error": "source session file not found"})
            return
        if not os.path.isdir(dst_dir):
            self._json_response(404, {"error": "target project folder not found"})
            return
        if os.path.exists(dst_file):
            self._json_response(409, {
                "error": "session with same id already exists in target",
                "dst_file": dst_file,
            })
            return

        # Перемещаем не только .jsonl, но и одноимённую папку с артефактами
        # сессии (state.json, contents/...), если она существует.
        moved_extras = []
        src_extras = os.path.join(src_dir, session_id)
        dst_extras = os.path.join(dst_dir, session_id)
        try:
            shutil.move(src_file, dst_file)
            if os.path.isdir(src_extras) and not os.path.exists(dst_extras):
                shutil.move(src_extras, dst_extras)
                moved_extras.append(session_id + "/")
        except (OSError, shutil.Error) as e:
            self._json_response(500, {"error": f"move failed: {e}"})
            return

        # Перезаписываем `cwd` внутри jsonl на путь нового проекта.
        # Путь берём через _real_path_from_cwd(target) — он смотрит сначала
        # на маркер-файл .cwd, потом на cwd любой сессии целевой папки.
        # Это убирает необходимость передавать target_path с UI.
        cwd_changed = 0
        rewrite_skipped_reason = None
        target_real = _real_path_from_cwd(target)
        if target_real:
            try:
                cwd_changed = _rewrite_cwd_in_jsonl(dst_file, target_real)
            except OSError as e:
                rewrite_skipped_reason = f"rewrite failed: {e}"
            # Обновим маркер на всякий случай (если его не было).
            _write_cwd_marker(dst_dir, target_real)
        else:
            rewrite_skipped_reason = (
                "no .cwd marker and no native session in target project — "
                "create the project via POST /create-project first"
            )

        self._json_response(200, {
            "status": "moved",
            "session_id": session_id,
            "source_project": source,
            "target_project": target,
            "from": src_file,
            "to": dst_file,
            "moved_extras": moved_extras,
            "cwd_rewritten_lines": cwd_changed,
            "new_cwd": target_real,
            "rewrite_skipped_reason": rewrite_skipped_reason,
        })

    def _handle_copy_session(self) -> None:
        """Копирует .jsonl-файл сессии в другой проект.

        В отличие от /move-session:
          - исходный файл остаётся на месте,
          - копии генерируется НОВЫЙ session_id (UUID v4), чтобы избежать
            коллизий с оригиналом и активной сессией,
          - в каждой строке копии sessionId и cwd заменяются на новые,
          - попутная папка-артефакт <session_id>/ тоже копируется
            и переименовывается в <new_session_id>/.

        Body: {"session_id": "<uuid>", "target_project": "<encoded>",
               "source_project": "<encoded>"?}
        """
        raw = self._read_body()
        if raw is None:
            return
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            self._json_response(400, {"error": f"invalid JSON: {e}"})
            return
        if not isinstance(data, dict):
            self._json_response(400, {"error": "expected JSON object"})
            return

        session_id = data.get("session_id")
        source = data.get("source_project")
        target = data.get("target_project")

        if not isinstance(session_id, str) or not SESSION_ID_RE.match(session_id):
            self._json_response(400, {"error": "invalid session_id"})
            return
        if not isinstance(target, str) or not PROJECT_DIR_NAME_RE.match(target):
            self._json_response(400, {"error": "invalid target_project"})
            return

        if source is None:
            source = self._find_session_owner(session_id)
            if source is None:
                self._json_response(404, {
                    "error": f"session {session_id} not found in any project",
                })
                return
        else:
            if not isinstance(source, str) or not PROJECT_DIR_NAME_RE.match(source):
                self._json_response(400, {"error": "invalid source_project"})
                return

        src_dir = os.path.join(CLAUDE_PROJECTS_DIR, source)
        dst_dir = os.path.join(CLAUDE_PROJECTS_DIR, target)
        src_file = os.path.join(src_dir, session_id + ".jsonl")

        if not os.path.isfile(src_file):
            self._json_response(404, {"error": "source session file not found"})
            return
        if not os.path.isdir(dst_dir):
            self._json_response(404, {"error": "target project folder not found"})
            return

        new_session_id = str(uuid.uuid4())
        dst_file = os.path.join(dst_dir, new_session_id + ".jsonl")

        target_real = _real_path_from_cwd(target)
        rewrite_skipped_reason = None
        if not target_real:
            rewrite_skipped_reason = (
                "no .cwd marker and no native session in target project — "
                "create the project via POST /create-project first"
            )

        # Копируем построчно, заменяя sessionId (всегда) и cwd
        # (если target_real известен). cwd в полях типа Bash-команд
        # не трогаем — обновляем только корневое поле объекта.
        lines_total = 0
        sid_changed = 0
        cwd_changed = 0
        try:
            with open(src_file, "r", encoding="utf-8") as src, \
                    open(dst_file, "w", encoding="utf-8") as dst:
                for line in src:
                    lines_total += 1
                    try:
                        obj = json.loads(line)
                        if isinstance(obj, dict):
                            mod = False
                            if "sessionId" in obj and obj.get("sessionId") != new_session_id:
                                obj["sessionId"] = new_session_id
                                sid_changed += 1
                                mod = True
                            if (target_real and "cwd" in obj
                                    and obj.get("cwd") != target_real):
                                obj["cwd"] = target_real
                                cwd_changed += 1
                                mod = True
                            if mod:
                                line = (json.dumps(obj, ensure_ascii=False)
                                        + "\n")
                    except json.JSONDecodeError:
                        pass
                    dst.write(line)
        except OSError as e:
            if os.path.isfile(dst_file):
                try:
                    os.remove(dst_file)
                except OSError:
                    pass
            self._json_response(500, {"error": f"copy failed: {e}"})
            return

        # Папка-артефакт сессии: копируем и переименовываем в new_session_id
        copied_extras = []
        src_extras = os.path.join(src_dir, session_id)
        dst_extras = os.path.join(dst_dir, new_session_id)
        if os.path.isdir(src_extras) and not os.path.exists(dst_extras):
            try:
                shutil.copytree(src_extras, dst_extras)
                copied_extras.append(new_session_id + "/")
            except (OSError, shutil.Error) as e:
                rewrite_skipped_reason = (
                    (rewrite_skipped_reason + "; " if rewrite_skipped_reason else "")
                    + f"copytree extras failed: {e}"
                )

        if target_real:
            _write_cwd_marker(dst_dir, target_real)

        self._json_response(200, {
            "status": "copied",
            "source_session_id": session_id,
            "new_session_id": new_session_id,
            "source_project": source,
            "target_project": target,
            "from": src_file,
            "to": dst_file,
            "lines_total": lines_total,
            "sessionId_rewritten_lines": sid_changed,
            "cwd_rewritten_lines": cwd_changed,
            "new_cwd": target_real,
            "copied_extras": copied_extras,
            "rewrite_skipped_reason": rewrite_skipped_reason,
        })

    def _handle_create_project(self) -> None:
        """Создаёт папку для нового проекта в ~/.claude/projects/.

        Body: {"path": "/abs/path/to/project"}.
        Папка проекта на диске НЕ создаётся — это делает пользователь.
        Здесь создаётся только директория в ~/.claude/projects/, чтобы
        туда можно было перемещать сессии.
        """
        raw = self._read_body()
        if raw is None:
            return
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            self._json_response(400, {"error": f"invalid JSON: {e}"})
            return

        path = data.get("path") if isinstance(data, dict) else None
        if not isinstance(path, str) or not path.strip():
            self._json_response(400, {"error": "expected {\"path\": \"<abs path>\"}"})
            return
        path = path.strip()
        if not os.path.isabs(path):
            self._json_response(400, {"error": "path must be absolute"})
            return

        encoded = encode_project_path(path)
        # Доп. проверка: имя должно начинаться с '-' (т.е. path с '/')
        # и состоять только из разрешённых символов.
        if not PROJECT_DIR_NAME_RE.match(encoded):
            self._json_response(400, {
                "error": f"encoded name invalid: {encoded!r}",
            })
            return

        target_dir = os.path.join(CLAUDE_PROJECTS_DIR, encoded)
        already_existed = os.path.isdir(target_dir)
        try:
            os.makedirs(target_dir, exist_ok=True)
        except OSError as e:
            self._json_response(500, {"error": f"mkdir failed: {e}"})
            return

        # Сохраняем введённый пользователем путь как маркер. Это
        # единственный источник истины для пустых только что созданных
        # папок — без него _real_path_from_cwd не смог бы определить
        # реальный путь, и UI показывал бы fallback /encoded[1:].
        _write_cwd_marker(target_dir, path)

        self._json_response(200, {
            "status": "ok",
            "encoded_name": encoded,
            "target_dir": target_dir,
            "already_existed": already_existed,
        })


def _bootstrap_cwd_markers() -> None:
    """Создаёт .cwd-маркер для каждой папки в ~/.claude/projects/,
    у которой его ещё нет, но из cwd её сессий можно вычислить путь.

    Выполняется один раз при старте сервера. Делает UI-список проектов
    сразу содержащим читаемые real_path'ы, без необходимости отдельной
    миграции от пользователя.
    """
    if not os.path.isdir(CLAUDE_PROJECTS_DIR):
        return
    try:
        entries = os.listdir(CLAUDE_PROJECTS_DIR)
    except OSError:
        return
    for entry in entries:
        if not PROJECT_DIR_NAME_RE.match(entry):
            continue
        project_dir = os.path.join(CLAUDE_PROJECTS_DIR, entry)
        if not os.path.isdir(project_dir):
            continue
        if os.path.isfile(os.path.join(project_dir, CWD_MARKER_FILENAME)):
            continue
        real = _real_path_from_cwd(entry)  # fallback на jsonl-сканирование
        if real:
            _write_cwd_marker(project_dir, real)


def _cache_ttl_by_provider() -> dict:
    return {provider: _config_value(key, None)
            for provider, key in cache_usage.CACHE_TTL_CONFIG_KEYS.items()}


def _config_value(key: str, default):
    """Значение параметра из конфига через тот же mtime-кэш, что и
    endpoint /custom-config — правка видна без перезапуска сервера."""
    try:
        mtime = os.path.getmtime(CONFIG_FILE)
    except OSError:
        return default
    with _CONFIG_LOCK:
        if mtime != _CONFIG_CACHE["mtime"]:
            if tomllib is None:
                return default
            try:
                with open(CONFIG_FILE, "rb") as fh:
                    _CONFIG_CACHE["data"] = tomllib.load(fh)
                _CONFIG_CACHE["mtime"] = mtime
            except Exception:
                return default
        return _CONFIG_CACHE["data"].get(key, default)


def _read_config_dict() -> dict:
    if tomllib is None:
        return {}
    try:
        with open(CONFIG_FILE, "rb") as fh:
            data = tomllib.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        # Битый или недописанный TOML (редактор сохраняет не атомарно) —
        # молча пропускаем цикл, иначе наблюдатель принял бы это за
        # «все параметры исчезли» и устроил перезапуск на ровном месте.
        return {}


def _cold_snapshot(cfg: dict) -> dict:
    """Только те параметры, чья правка требует перезапуска."""
    return {k: v for k, v in cfg.items() if k not in HOT_KEYS}


def _rebuild_bootstrap() -> None:
    """Просит патчер пересобрать bootstrap webview.

    Сам по себе перезапуск сервера webview-параметры не применяет — они
    живут в bootstrap. Поэтому перед рестартом дёргаем патчер как
    подпроцесс, ровно тем же способом, каким его запускает harness:
    вызывать его внутренности из чужого процесса было бы хрупко.
    """
    patcher = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "patch-claude-webview.py"
    )
    if not os.path.isfile(patcher):
        return
    payload = json.dumps({
        "hook_event_name": "SessionStart",
        "session_id": "config-watch",
        "cwd": PROJECT_DIR,
    })
    try:
        subprocess.run(
            [sys.executable, patcher],
            input=payload, text=True, capture_output=True, timeout=30,
            env={**os.environ, "CLAUDE_PROJECT_DIR": PROJECT_DIR},
        )
        _log("bootstrap пересобран")
    except Exception as exc:
        _log(f"пересборка bootstrap не удалась: {exc}")


def _watch_config(server) -> None:
    """Следит за «холодными» параметрами конфига и перезапускает сервер.

    Горячие параметры (HOT_KEYS) игнорируются: их правка применяется
    без перезапуска, а лишний рестарт — это окно, в котором webview
    получает «недоступен».
    """
    baseline = _cold_snapshot(_read_config_dict())
    global _RESTART_REQUESTED
    while True:
        cfg = _read_config_dict()
        delay = cfg.get("serverConfigWatchSec", DEFAULT_CONFIG_WATCH_SEC)
        if not isinstance(delay, int) or isinstance(delay, bool) or delay <= 0:
            # Наблюдение выключено. Не выходим из потока: параметр сам
            # горячий, и его можно вернуть, не перезапуская сервер.
            time.sleep(DEFAULT_CONFIG_WATCH_SEC)
            continue
        time.sleep(delay)

        current = _cold_snapshot(_read_config_dict())
        if not current or current == baseline:
            continue

        changed = sorted(
            k for k in set(current) | set(baseline)
            if current.get(k) != baseline.get(k)
        )
        _log("конфиг: изменились " + ", ".join(changed)
             + " — пересобираю bootstrap и перезапускаюсь")
        _rebuild_bootstrap()
        _RESTART_REQUESTED = True
        # shutdown() из этого же потока безопасен: мы не внутри
        # serve_forever(), в отличие от обработчика сигнала.
        server.shutdown()
        return


def main():
    if not PROJECT_DIR and not GLOBAL_INSTALL:
        print("CLAUDE_PROJECT_DIR not set", file=sys.stderr)
        sys.exit(1)

    _bootstrap_cwd_markers()

    runtime_dir = LOGS_DIR
    os.makedirs(runtime_dir, exist_ok=True)
    pid_file = os.path.join(runtime_dir, "http-server.pid")

    # ThreadingHTTPServer, а не HTTPServer: webview опрашивает сервер
    # несколькими таймерами (состояние ByPass и настройки — каждые 5 с,
    # поддержание кэша — раз в минуту), плюс клики по кнопкам. На
    # однопоточном сервере первый разбор большого транскрипта (~1 с)
    # блокировал очередь, и опросы отваливались по таймауту — в webview
    # это выглядело как «http-server.py недоступен».
    # Занятый порт — не авария, а нормальный исход гонки: два окна
    # прислали сообщение одновременно, оба не увидели сервера и оба
    # его запустили. Победитель уже слушает, проигравший должен тихо
    # уйти — и, главное, НЕ трогать pid-файл. Поэтому pid пишется
    # только после успешного bind.
    try:
        server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError as exc:
        _log(f"порт {PORT} занят ({exc}) — уже есть живой сервер, выхожу")
        return

    with open(pid_file, "w") as f:
        f.write(str(os.getpid()))

    # Сигналы логируем ДО выхода: иначе в журнале остаётся только
    # обрыв записей, и не отличить внешний SIGTERM (кто-то погасил)
    # от падения. Номер сигнала сразу показывает, кто инициатор:
    # 15 — штатная остановка хуком, 2 — Ctrl+C, 9 в лог не попадёт
    # никогда (SIGKILL не перехватывается) — и это тоже улика.
    def _on_signal(signum, _frame):
        _log(f"получен сигнал {signum} ({signal.Signals(signum).name}) — останавливаюсь")
        # shutdown() блокируется до выхода serve_forever(), а обработчик
        # сигнала выполняется ВНУТРИ него, в главном потоке: прямой
        # вызов — гарантированный дедлок (проверено, сервер повисал
        # с занятым портом и переставал принимать соединения).
        # Документированный способ — звать shutdown() из другого потока.
        threading.Thread(target=server.shutdown, daemon=True).start()

    for _sig in (signal.SIGTERM, signal.SIGINT):
        try:
            signal.signal(_sig, _on_signal)
        except (ValueError, OSError):
            pass

    threading.Thread(target=_watch_config, args=(server,), daemon=True).start()
    # Сигнал сброса 5-часового окна лимита — независимый цикл (limit_alert):
    # живёт своей логикой и не делит состояние с наблюдателем конфига.
    threading.Thread(target=limit_alert.run_monitor, daemon=True).start()

    openai_stop = threading.Event()
    threading.Thread(target=openai_bootstrap.run_monitor, args=(openai_stop,), daemon=True).start()

    quota_stop = threading.Event()
    threading.Thread(target=account_usage_monitor.run_monitor, args=(
        LOGS_DIR, quota_stop), daemon=True).start()
    _log(
        f"старт: порт {PORT}, project_dir={PROJECT_DIR}, "
        f"script_mtime={SCRIPT_MTIME:.3f}, python={sys.version.split()[0]}"
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        _log("KeyboardInterrupt")
    except BaseException as exc:
        _log(f"падение serve_forever: {type(exc).__name__}: {exc}")
        raise
    finally:
        openai_stop.set()
        quota_stop.set()
        _log("завершение: закрываю сокет и убираю pid-файл")
        server.server_close()
        if os.path.isfile(pid_file):
            os.remove(pid_file)

    if _RESTART_REQUESTED:
        # exec вместо spawn: pid сохраняется, а сокет уже закрыт (и всё
        # равно помечен CLOEXEC), так что новый процесс займёт порт без
        # гонки с самим собой.
        _log("перезапуск по изменению конфига: exec")
        os.execv(sys.executable, [sys.executable, os.path.abspath(__file__)])


if __name__ == "__main__":
    main()
