#!/usr/bin/env python3
"""Lifecycle and safe status access for the loopback Codex bridge."""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
from typing import Any

from host_platform import process_command


BRIDGE_HOST = "127.0.0.1"
BRIDGE_PORT = int(os.environ.get("CLAUDE_OPENAI_BRIDGE_PORT", "18925"))
HERE = os.path.dirname(os.path.abspath(__file__))
BRIDGE_SCRIPT = os.path.join(HERE, "codex_anthropic_bridge.py")
APP_SERVER_CLIENT = os.path.join(HERE, "codex_app_server.py")
BRIDGE_USAGE_FILE = os.path.join(
    os.path.dirname(HERE), "hooks-runtime", "codex-bridge-usage.json",
)


def _url(path: str) -> str:
    return f"http://{BRIDGE_HOST}:{BRIDGE_PORT}{path}"


def _read(path: str, timeout: float = 1.0) -> dict[str, Any] | None:
    try:
        with urllib.request.urlopen(_url(path), timeout=timeout) as response:
            value = json.loads(response.read().decode("utf-8"))
    except (OSError, ValueError, urllib.error.URLError):
        return None
    return value if isinstance(value, dict) else None


def health(timeout: float = 0.5) -> dict[str, Any] | None:
    value = _read("/health", timeout)
    if not value or value.get("service") != "claude-openai-bridge":
        return None
    return value


def account_snapshot(timeout: float = 8.0) -> dict[str, Any] | None:
    value = _read("/account", timeout)
    return value if value and value.get("ok") is True else None


def bridge_usage_snapshot(timeout: float = 1.0) -> dict[str, Any] | None:
    """Return the last atomic Usage snapshot without depending on /account.

    ``/account`` asks Codex App Server for fresh account/rate-limit data and
    can legitimately take longer than the Usage popup's one-second budget.
    The bridge already persists every token-usage update atomically, so that
    file is the stable source for model, effort, cache and context counters.
    """
    try:
        with open(BRIDGE_USAGE_FILE, encoding="utf-8") as handle:
            value = json.load(handle)
    except (OSError, ValueError, TypeError):
        value = None
    if isinstance(value, dict) and value.get("session_key_hash"):
        return value

    snapshot = account_snapshot(timeout=timeout)
    usage = snapshot.get("bridgeUsage") if isinstance(snapshot, dict) else None
    return usage if isinstance(usage, dict) else None


def _source_mtime() -> float:
    return max(os.path.getmtime(BRIDGE_SCRIPT), os.path.getmtime(APP_SERVER_CLIENT),
               os.path.getmtime(os.path.join(HERE, "bridge_recovery.py")))


def _owned_pid(pid: Any) -> int | None:
    if not isinstance(pid, int) or pid <= 1:
        return None
    command = process_command(pid)
    if command is None:
        return None
    return pid if os.path.normcase(BRIDGE_SCRIPT) in os.path.normcase(command) else None


def stop() -> bool:
    current = health()
    pid = _owned_pid(current.get("pid") if current else None)
    if pid is None:
        return False
    os.kill(pid, signal.SIGTERM)
    for _ in range(30):
        if health(0.1) is None:
            return True
        time.sleep(0.1)
    return True


def ensure() -> tuple[bool, str]:
    current = health()
    if current:
        reported = current.get("sourceMtime")
        if isinstance(reported, (int, float)) and reported >= _source_mtime():
            return True, "мост OpenAI уже работает"
        stop()

    subprocess.Popen(
        [sys.executable, BRIDGE_SCRIPT, "--host", BRIDGE_HOST,
         "--port", str(BRIDGE_PORT)],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
    )
    for _ in range(60):
        current = health(0.2)
        if current:
            return True, "мост OpenAI запущен"
        time.sleep(0.1)
    return False, "мост OpenAI не запустился; проверьте авторизацию Codex"


if __name__ == "__main__":
    ok, message = ensure()
    print(json.dumps({"ok": ok, "message": message, "health": health()},
                     ensure_ascii=False))
    raise SystemExit(0 if ok else 1)
