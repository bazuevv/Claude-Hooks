/*
 * Кастомный JavaScript для webview расширения Claude Code (anthropic.claude-code).
 *
 * Канонический источник — этот файл. Хук .claude/hooks/patch-claude-webview.py
 * инлайнит его содержимое в bootstrap-блок внутри webview/index.js
 * (CSP блокирует <script src> к внешним webview-ресурсам).
 *
 * Конфигурация — `.claude/patches/claude-custom-config.toml`. Хук
 * подставляет её в bootstrap как `window.__CLAUDE_CUSTOM_CONFIG__`.
 * Поддерживаемые ключи:
 *   - logs (bool)            : включить/выключить console.log + warn
 *   - pollIntervalMs (int)   : период пуллинга CSS, мс (по умолчанию 5000)
 *   - throttleMs (int)       : минимальный интервал между обновлениями
 *                              CSS на DOM-мутациях, мс (по умолчанию 200)
 *
 * Workflow редактирования: правишь файл → новая сессия Claude Code или
 * UserPromptSubmit-хук синхронизирует его в webview → Reload Window /
 * закрыть-открыть панель Claude Code, чтобы перезапустился bootstrap.
 *
 * Для CSS отдельный reload не нужен — он горячо перезагружается через
 * <link rel="stylesheet"> с cache-bust query (пуллинг + DOM-мутации).
 */

// Context comes from the owning extension host, not a guessed session path.
if (!window.__claudeWindowContextListener) {
  window.__claudeWindowContextListener = true;
  window.addEventListener('message', function (event) {
    var data = event.data;
    if (data && data.__claudeCustom === 'window-context' &&
        typeof data.windowId === 'string' && /^[a-f0-9]{32}$/.test(data.windowId)) {
      window.__claudeWindowId = data.windowId;
    }
  });
}

// Share native appearance, never another custom control's identity.
function claudeNativeButtonClasses(donor) {
  var classes = donor && typeof donor.className === 'string' ? donor.className : '';
  return classes.split(/\s+/).filter(function (name) {
    return name && name.indexOf('claude-') !== 0;
  }).join(' ');
}

// === LAZY COLLAPSED THINKING ===
// The native <details> hides pixels, but still mounts its Markdown subtree.
// Keep the native hooks, summary and toggle handler; omit the body until open.
(function () {
  if (window.__claudeCollapsedThinking) return;
  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  var state = window.__claudeCollapsedThinking = { state: 'disabled', skipped: 0 };
  if (cfg.lazyCollapsedThinking !== true || cfg.safeMode === true) return;
  if (typeof rf1 !== 'function' || typeof R !== 'function' ||
      !/thinkingBlock:/.test(String(rf1)) || !/thinkingContent/.test(String(rf1)) ||
      !/open:/.test(String(rf1))) {
    state.state = 'unsupported-bundle';
    return;
  }
  var original = rf1;
  rf1 = function () {
    // Always call the original: it owns React state even while collapsed.
    var element = original.apply(this, arguments);
    if (!element || element.type !== 'details' || !element.props || element.props.open ||
        !Array.isArray(element.props.children) || element.props.children.length !== 2 ||
        !element.props.children[0] || element.props.children[0].type !== 'summary' ||
        !element.props.children[1] || element.props.children[1].type !== 'div') return element;
    state.skipped++;
    return R(element.type, Object.assign({}, element.props, {
      children: [element.props.children[0], null],
    }), element.key == null ? undefined : element.key);
  };
  state.state = 'installed';
})();
// === END LAZY COLLAPSED THINKING ===

// === COALESCED MARKDOWN ===
(function () {
  if (window.__claudeMarkdownRender) return;
  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  var interval = cfg.markdownRenderIntervalMs;
  var showPartialParagraph = cfg.markdownShowPartialParagraph === true;
  var wholeWords = cfg.markdownWholeWords === true;
  var wholeSentences = cfg.markdownWholeSentences === true;
  var animateSentences = wholeSentences && cfg.markdownAnimateSentences === true;
  var sentenceSegmenter = wholeSentences && typeof Intl !== 'undefined' && typeof Intl.Segmenter === 'function'
    ? new Intl.Segmenter('ru', { granularity: 'sentence' }) : null;
  var graphemes = animateSentences && typeof Intl !== 'undefined' && typeof Intl.Segmenter === 'function'
    ? new Intl.Segmenter('ru', { granularity: 'grapheme' }) : null;
  var stats = window.__claudeMarkdownRender = { state: 'disabled', interval_ms: interval,
    partial_paragraphs: showPartialParagraph,
    whole_words: wholeWords,
    whole_sentences: wholeSentences,
    animate_sentences: animateSentences, animation_ticks: 0, animation_rate: 0,
    animation_receive_rate: 0, animation_max_queue: 0,
    animation_queue: 0, animation_ready_queue: 0, animation_waiting_sentence: 0,
    animation_queue_peak: 0, animation_min_rate: 50, animation_buffer_target: 500,
    animation_end_events: 0, animation_end_binding: 'unavailable',
    animation_resumed: 0, animation_reset_ends_ignored: 0,
    animation_frame_max_gap_ms: 0, animation_late_frames: 0,
    coalesced: 0, flushes: 0, renders: 0, mounts: 0, unmounts: 0, keyed_blocks: 0 };
  if (cfg.safeMode === true || typeof interval !== 'number' || !isFinite(interval) || interval <= 0) return;
  // Hook aliases and the native renderer belong to this bundle version.
  if (typeof r$ !== 'function' || !/isPartialText:/.test(String(r$)) || !/remarkPlugins:/.test(String(r$)) ||
      typeof F !== 'function' || typeof U1 !== 'function' || !/useRef/.test(String(U1)) ||
      typeof l !== 'function' || !/useState/.test(String(l)) ||
      typeof Q9 !== 'function' || !/useLayoutEffect/.test(String(Q9)) ||
      typeof b5 !== 'function' || !/useMemo/.test(String(b5)) ||
      typeof jK !== 'object' || !jK || typeof jK.compare !== 'function' ||
      !/content\.key/.test(String(jK.compare)) || !/Nn0/.test(String(jK.type)) ||
      typeof Nn0 !== 'function' || !/isPartialText/.test(String(Nn0))) {
    stats.state = 'unsupported-bundle';
    return;
  }
  var useFrames = typeof requestAnimationFrame === 'function' && typeof cancelAnimationFrame === 'function';
  stats.animation_scheduler = useFrames ? 'animation-frame' : 'timeout-fallback';
  function scheduleRender(callback, delay) {
    var task = { id: null, cancelled: false }, due = performance.now() + delay;
    if (!useFrames) task.id = setTimeout(callback, delay);
    else {
      function frame() {
        if (task.cancelled) return;
        if (performance.now() >= due) callback();
        else task.id = requestAnimationFrame(frame);
      }
      task.id = requestAnimationFrame(frame);
    }
    return task;
  }
  function cancelRender(task) {
    if (!task) return;
    task.cancelled = true;
    if (useFrames) cancelAnimationFrame(task.id); else clearTimeout(task.id);
  }
  // Native assistant messages use content.key = hash + lastModifiedTime as
  // React keys. Every streamed chunk therefore unmounts the whole subtree.
  // Stabilize ONLY text/thinking keys and preserve revision-based invalidation
  // separately: content objects are mutable, so the native memo comparison alone
  // would otherwise compare the new revision to itself and skip real updates.
  var nativeJSX = F, nativeCompare = jK.compare, blockIds = new WeakMap();
  var endedBlocks = new WeakMap(), endListeners = new WeakMap();
  var resettingSessions = new WeakSet(), resetBusyEnds = new WeakSet();
  function sessionBusy(session) {
    var busy = session && session.busy;
    return busy && typeof busy === 'object' ? busy.value : busy;
  }
  function finishSession(session, reason) {
    reason = reason || 'busy';
    if (resettingSessions.has(session) || (reason === 'busy' && resetBusyEnds.has(session))) {
      stats.animation_reset_ends_ignored++; return;
    }
    var messages = session && session.messages;
    if (messages && !Array.isArray(messages)) messages = messages.value;
    if (!Array.isArray(messages)) return;
    messages.forEach(function (message) {
      if (!Array.isArray(message.content)) return;
      message.content.forEach(function (block) {
        if (!block || !block.content || !/^(text|thinking)$/.test(block.content.type) || endedBlocks.has(block)) return;
        var listeners = endListeners.get(block);
        if (!block.isPartial && (!listeners || !listeners.size)) return;
        endedBlocks.set(block, { session: session, reason: reason, turn: session.sendTurnIdx,
          source: block.content.type === 'thinking' ? block.content.thinking : block.content.text });
        if (listeners) listeners.forEach(function (notify) { notify(block); });
      });
    });
    resetBusyEnds.delete(session);
    stats.animation_end_events++;
  }
  if (animateSentences) {
    window.__claudeFinishMarkdownSession = finishSession;
    // Cancellation can leave content.isPartial=true forever. Observe the actual
    // session boundary, and release only blocks owned by that session.
    if (typeof yQ === 'function' && yQ.prototype &&
        /this\.busy\.value=/.test(String(yQ.prototype.endTurn)) &&
        /interruptClaude/.test(String(yQ.prototype.interrupt))) {
      ['endTurn', 'interrupt'].forEach(function (name) {
        var nativeMethod = yQ.prototype[name];
        yQ.prototype[name] = function () {
          var wasBusy = sessionBusy(this);
          var result = nativeMethod.apply(this, arguments);
          if (name === 'interrupt' || wasBusy === true) finishSession(this, name);
          return result;
        };
      });
      if (typeof yQ.prototype.resetPerProcessState === 'function' &&
          /this\.endTurn\(/.test(String(yQ.prototype.resetPerProcessState))) {
        var nativeReset = yQ.prototype.resetPerProcessState;
        yQ.prototype.resetPerProcessState = function () {
          resettingSessions.add(this); resetBusyEnds.add(this);
          try { return nativeReset.apply(this, arguments); }
          finally { resettingSessions.delete(this); }
        };
      }
      stats.animation_end_binding = 'installed';
    }
  }
  var nativeContent = Nn0;
  Nn0 = function (props) {
    var tree = nativeContent.apply(this, arguments);
    if (tree && (tree.type === r$ || (typeof rf1 === 'function' && tree.type === rf1))) {
      return nativeJSX(tree.type, Object.assign({}, tree.props, { __claudeBlock: props.content }), tree.key);
    }
    return tree;
  };
  F = function (type, props, key) {
    var block = type === jK && props && props.content;
    if (block && block.content && (block.content.type === 'text' || block.content.type === 'thinking')) {
      props = Object.assign({}, props, { __claudeRevision: block.key });
      if (key === block.key) {
        if (!blockIds.has(block)) blockIds.set(block, 'claude-stream-' + (++stats.keyed_blocks));
        key = blockIds.get(block);
      }
    }
    return nativeJSX(type, props, key);
  };
  jK.compare = function (previous, next) {
    return previous.__claudeRevision === next.__claudeRevision && nativeCompare(previous, next);
  };
  // Thinking uses isCurrentlyThinking on its parent, not isPartialText on r$.
  // Carry this display-only flag down so its held text is released on completion.
  if ((wholeWords || wholeSentences) && typeof rf1 === 'function') {
    var nativeThinking = rf1;
    rf1 = function (props) {
      var tree = nativeThinking.apply(this, arguments);
      var children = tree && tree.props && tree.props.children;
      var body = Array.isArray(children) && children[1];
      var markdown = body && body.props && body.props.children;
      if (!tree || tree.type !== 'details' || !body || body.type !== 'div' ||
          !markdown || markdown.type !== r$) return tree;
      var child = nativeJSX(r$, Object.assign({}, markdown.props, {
        __claudeStreaming: props.isCurrentlyThinking === true,
        __claudeBlock: props.__claudeBlock,
      }), markdown.key == null ? undefined : markdown.key);
      var nextBody = nativeJSX(body.type, Object.assign({}, body.props, { children: child }),
        body.key == null ? undefined : body.key);
      return nativeJSX(tree.type, Object.assign({}, tree.props, { children: [children[0], nextBody] }),
        tree.key == null ? undefined : tree.key);
    };
  }
  var original = r$;
  function same(a, b) {
    return a.content === b.content && a.context === b.context && a.isPartialText === b.isPartialText &&
      a.__claudeStreaming === b.__claudeStreaming;
  }
  function immediate(previous, next) {
    // Never temporarily show a different message or keep the partial-text filter
    // after completion. Thinking has no partial flag: its last chunk uses the timer.
    return previous.isPartialText !== next.isPartialText ||
      previous.__claudeStreaming !== next.__claudeStreaming ||
      typeof previous.content !== 'string' || typeof next.content !== 'string' ||
      !next.content.startsWith(previous.content);
  }
  function completeSentences(text, state) {
    var cache = state.sentences;
    if (cache && cache.text === text) return text.slice(0, cache.end);
    var start = cache && text.startsWith(cache.text) ? cache.end : 0;
    var tail = text.slice(start), end = start;
    // A following separator confirms that a dot is not the first half of a
    // decimal or URL. The final completion bypasses this display-only buffer.
    var finished = /[.!?…]["'»”’\)\]\}*_`]*\s+$/u;
    var abbreviation = /(?:^|\s)(?:[a-zа-яё]|т\.\s*[деп]|ул|стр|рис|см|им|руб|коп|млн|млрд|dr|mr|mrs|ms|prof|etc)\.\s*$/iu;
    var code = null;
    // ICU does not treat U+2026 as a sentence terminator. Normalize only for
    // segmentation (same UTF-16 length), then inspect and display original text.
    var parts = sentenceSegmenter ? sentenceSegmenter.segment(tail.replace(/…/g, '.')) : [{ segment: tail, index: 0 }];
    for (var part of parts) {
      var segment = tail.slice(part.index, part.index + part.segment.length);
      // Do not publish a sentence boundary inside an unfinished Markdown code span/block.
      for (var marker of segment.matchAll(/(?<!\\)(`+|~{3,})/g)) {
        var token = marker[1];
        if (!code) code = token;
        else if (token[0] === code[0] && (code.length >= 3 ? token.length >= code.length : token.length === code.length)) code = null;
      }
      if (!code && finished.test(segment) && !abbreviation.test(segment) &&
          !/^\s*(?:[-*>]\s*)?\d+[.)]\s+$/u.test(segment)) end = start + part.index + part.segment.length;
    }
    state.sentences = { text: text, end: end };
    return text.slice(0, end);
  }
  function reportAnimationQueue(a) {
    var total = a.active && typeof a.source === 'string' && typeof a.painted === 'string'
      ? Math.max(0, a.source.length - a.painted.length) : 0;
    var ready = total && typeof a.target === 'string'
      ? Math.min(total, Math.max(0, a.target.length - a.painted.length)) : 0;
    var wasEmpty = stats.animation_queue === 0;
    stats.animation_queue += total - (a.reportedTotal || 0);
    stats.animation_ready_queue += ready - (a.reportedReady || 0);
    stats.animation_waiting_sentence = stats.animation_queue - stats.animation_ready_queue;
    if (wasEmpty && total) stats.animation_queue_peak = stats.animation_queue;
    else stats.animation_queue_peak = Math.max(stats.animation_queue_peak, stats.animation_queue);
    a.reportedTotal = total; a.reportedReady = ready;
  }
  function animateText(target, source, streaming) {
    // Existing history / reopening a thinking block starts at its current text.
    // Only subsequent appended, completed sentences enter the animation queue.
    var output = l(target), painted = output[0], setPainted = output[1];
    var ref = U1(null), now = performance.now();
    if (!ref.current) ref.current = { target: target, painted: target, source: source,
      rate: 24, received: 0, sampled: now, lastTick: now, deadline: now,
      arrival: null, arrivalGap: 1000, readyAt: null, readyGap: 1500,
      timer: null, active: true, streaming: streaming, hasStreamed: streaming, credit: 0 };
    var a = ref.current, stepMs = Math.max(50, interval);
    // A resumed stream may follow a partially printed final sentence. Keep its
    // visible prefix while waiting for the next complete sentence, never rewind.
    if (streaming && typeof target === 'string' && typeof source === 'string' &&
        typeof a.painted === 'string' && source.startsWith(a.painted) && a.painted.startsWith(target)) target = a.painted;
    function sampleRate(time) {
      var elapsed = time - a.sampled;
      if (elapsed >= 250) {
        // Sample silence as well as packets. A burst must not permanently set
        // the typing rate to its instantaneous transport speed.
        var weight = 1 - Math.exp(-elapsed / 4000);
        a.rate = Math.max(4,
          a.rate * (1 - weight) + a.received * 1000 / elapsed * weight);
        a.sampled = time; a.received = 0;
      }
      stats.animation_receive_rate = Math.round(a.rate);
    }
    Q9(function () {
      var time = performance.now();
      if (typeof source === 'string' && typeof a.source === 'string' && source.startsWith(a.source)) {
        var added = source.length - a.source.length;
        a.received += added;
        if (added > 0) {
          if (a.arrival !== null) a.arrivalGap = Math.min(12000,
            Math.max(time - a.arrival, a.arrivalGap * Math.exp(-(time - a.arrival) / 15000)));
          a.arrival = time;
        }
      } else {
        a.rate = 24; a.received = 0; a.sampled = time;
        a.arrival = null; a.arrivalGap = 1000; a.readyAt = null; a.readyGap = 1500;
      }
      sampleRate(time);
      a.source = source;
      reportAnimationQueue(a);
    }, [source]);
    Q9(function () {
      var time = performance.now(), wasStreaming = a.streaming;
      a.streaming = streaming;
      a.hasStreamed = a.hasStreamed || streaming;
      if (streaming && typeof target === 'string' && typeof a.target === 'string' &&
          target.length > a.target.length && target.startsWith(a.target)) {
        if (a.readyAt !== null) a.readyGap = Math.min(12000,
          Math.max(time - a.readyAt, a.readyGap * Math.exp(-(time - a.readyAt) / 15000)));
        a.readyAt = time;
      }
      a.target = target;
      function cancel() { cancelRender(a.timer); a.timer = null; }
      if (typeof target !== 'string' || typeof a.painted !== 'string' || !target.startsWith(a.painted) ||
          (!a.hasStreamed && !streaming)) {
        cancel(); a.painted = target; setPainted(target); reportAnimationQueue(a); return;
      }
      reportAnimationQueue(a);
      if (a.painted === target) { cancel(); return; }
      // Only a completed response gets a catch-up deadline. While streaming,
      // retain a reserve for packet gaps and sentence-boundary buffering.
      if (wasStreaming && !streaming) {
        a.deadline = time + 3000;
        a.finishSpeed = Math.max(stats.animation_min_rate, (a.lastSpeed || stats.animation_min_rate) * 1.15,
          (target.length - a.painted.length) / 3);
      }
      function tick() {
        a.timer = null;
        if (!a.active) return;
        var tickNow = performance.now(), remaining = a.target.length - a.painted.length;
        sampleRate(tickNow);
        var secondsLeft = Math.max(stepMs / 1000, (a.deadline - tickNow) / 1000);
        var silence = a.arrival === null ? 0 : tickNow - a.arrival;
        var readySilence = a.readyAt === null ? 0 : tickNow - a.readyAt;
        var reserveMs = Math.min(15000, Math.max(2000,
          a.arrivalGap * 1.25, a.readyGap * 1.25, silence, readySilence));
        // Preserve a modest reserve, but drain excess independently of receipt
        // rate. No fixed ceiling: larger queues must produce faster catch-up.
        var excess = Math.max(0, remaining - stats.animation_buffer_target);
        var speed = a.streaming
          ? Math.max(stats.animation_min_rate,
            Math.min(a.rate, remaining * 1000 / reserveMs) + excess / 0.5)
          : Math.max(a.finishSpeed || stats.animation_min_rate, remaining / secondsLeft);
        a.lastSpeed = speed;
        if (!a.streaming) a.finishSpeed = speed;
        stats.animation_reserve_ms = Math.round(reserveMs);
        stats.animation_receipt_pause_ms = Math.round(silence);
        var elapsed = Math.max(0, tickNow - a.lastTick);
        stats.animation_frame_max_gap_ms = Math.max(stats.animation_frame_max_gap_ms, Math.round(elapsed));
        if (elapsed > Math.max(100, stepMs * 2)) stats.animation_late_frames++;
        // A throttled timer or a hidden tab must not accumulate seconds of
        // typing credit and dump it as one chunk when drawing resumes.
        if (a.streaming) elapsed = Math.min(elapsed, Math.max(100, stepMs));
        var budget = speed * elapsed / 1000 + a.credit;
        var count = Math.max(0, Math.floor(budget));
        a.credit = budget - count; a.lastTick = tickNow;
        var end = Math.min(a.target.length, a.painted.length + count);
        if (!a.streaming && tickNow >= a.deadline) end = a.target.length;
        if (end > a.painted.length && end < a.target.length) {
          if (graphemes) {
            for (var part of graphemes.segment(a.target.slice(a.painted.length))) {
              var boundary = a.painted.length + part.index + part.segment.length;
              if (boundary >= end) { end = boundary; break; }
            }
          } else if (/[\uD800-\uDBFF]/.test(a.target[end - 1])) end++;
        }
        stats.animation_ticks++; stats.animation_rate = Math.round(speed);
        stats.animation_max_queue = Math.max(stats.animation_max_queue, remaining);
        if (end !== a.painted.length) {
          // Charge the whole grapheme, including any units rounded up above.
          a.credit -= end - a.painted.length - count;
          a.painted = a.target.slice(0, end); setPainted(a.painted);
        }
        reportAnimationQueue(a);
        if (end < a.target.length) a.timer = scheduleRender(tick, stepMs);
      }
      if (a.timer === null) {
        a.lastTick = time; a.credit = 0;
        a.timer = scheduleRender(tick, stepMs);
      }
    }, [target, streaming]);
    Q9(function () {
      a.active = true;
      reportAnimationQueue(a);
      return function () {
        a.active = false; cancelRender(a.timer); a.timer = null;
        reportAnimationQueue(a);
      };
    }, []);
    return typeof target === 'string' && typeof painted === 'string' && target.startsWith(painted) ? painted : target;
  }
  r$ = function (props) {
    stats.renders++;
    var ended = l(0), block = props.__claudeBlock;
    var boundary = block && endedBlocks.get(block);
    if (boundary && (props.isPartialText === true || props.__claudeStreaming === true) &&
        props.content !== boundary.source && sessionBusy(boundary.session) === true &&
        (boundary.reason !== 'interrupt' || boundary.turn !== boundary.session.sendTurnIdx)) {
      endedBlocks.delete(block); boundary = null; stats.animation_resumed++;
    }
    var stopped = !!boundary;
    Q9(function () {
      if (!block || !animateSentences || stopped ||
          (props.isPartialText !== true && props.__claudeStreaming !== true)) return;
      var listeners = endListeners.get(block);
      if (!listeners) { listeners = new Set(); endListeners.set(block, listeners); }
      var notify = function () { ended[1](function (version) { return version + 1; }); };
      listeners.add(notify);
      return function () { listeners.delete(notify); };
    }, [block, props.isPartialText, props.__claudeStreaming, stopped]);
    var pair = l(props), shown = pair[0], setShown = pair[1];
    var pending = U1(null);
    if (!pending.current) pending.current = { latest: props, shown: props,
      last: performance.now(), timer: null };
    var state = pending.current;
    Q9(function () {
      state.latest = props;
      function flush() {
        state.timer = null;
        state.last = performance.now();
        if (!same(state.shown, state.latest)) {
          state.shown = state.latest;
          stats.flushes++;
          setShown(state.latest);
        }
      }
      if (same(state.shown, props)) {
        if (state.timer !== null) { cancelRender(state.timer); state.timer = null; }
        return;
      }
      var wait = interval - (performance.now() - state.last);
      if (immediate(state.shown, props) || wait <= 0) {
        if (state.timer !== null) cancelRender(state.timer);
        flush();
      } else {
        stats.coalesced++;
        // Do not restart on every chunk: continuous streaming must not starve it.
        if (state.timer === null) state.timer = scheduleRender(flush, wait);
      }
    }, [props.content, props.context, props.isPartialText, props.__claudeStreaming]);
    Q9(function () {
      stats.mounts++;
      return function () {
        stats.unmounts++;
        if (state.timer !== null) cancelRender(state.timer);
        state.timer = null;
      };
    }, []);
    var visible = stopped || immediate(shown, props) ? props : shown;
    var displayText = visible.content;
    if (!stopped && (wholeWords || wholeSentences) && (visible.isPartialText === true || visible.__claudeStreaming === true) &&
        typeof displayText === 'string') {
      if (wholeSentences) displayText = completeSentences(displayText, state);
      else {
        // A whitespace boundary is unambiguous even for hyphenated words, URLs,
        // numbers and Markdown. Never guess that a pause means the word is finished.
        var end = displayText.length;
        while (end > 0 && !/\s/u.test(displayText[end - 1])) end--;
        displayText = displayText.slice(0, end);
      }
    }
    if (animateSentences) displayText = animateText(displayText, props.content,
      !stopped && (props.isPartialText === true || props.__claudeStreaming === true));
    // Returning the same child element lets React retain the native subtree.
    // Its own state (link menu, copy buttons) can still update independently.
    return b5(function () {
      // Native wL0 hides the entire last paragraph of a partial answer. Bypass
      // that display filter only; retain the real streaming flag in our state
      // so completion, trailing flushes and the received message stay unchanged.
      var rendered = Object.assign({}, visible, { content: displayText });
      if (stopped || (showPartialParagraph && visible.isPartialText)) rendered.isPartialText = false;
      return F(original, rendered);
    },
      [displayText, visible.context, visible.isPartialText, visible.__claudeStreaming, stopped]);
  };
  stats.state = 'installed';
})();
// === END COALESCED MARKDOWN ===

// === USER MESSAGE OUTSIDE COLLAPSE ===
(function () {
  if (window.__claudeUserMessageCollapse) return;
  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  var stats = window.__claudeUserMessageCollapse = { state: 'disabled', collapsed: 0, expandedMedium: 0, expandedMax: 0 };
  if (cfg.safeMode === true || cfg.userMessageOutsideCollapse !== true) return;
  var initial = cfg.userMessageInitialHeightPx;
  var medium = cfg.userMessageMediumHeightPx;
  var maximum = cfg.userMessageMaxHeightPx;
  if (!Number.isInteger(initial) || initial < 60 || !Number.isInteger(medium) || medium <= initial ||
      !Number.isInteger(maximum) || maximum <= medium) {
    initial = 60; medium = 200; maximum = 400;
  }
  var selector = '[data-transcript-message][class*="userMessageContainer_"] ' +
    '[class*="expandableContainer_"] > [class*="buttonContainer_"] button[class*="collapseButton_"]';
  var collapsing = false;
  var selectionAtMouseDown = null;
  function fold(button) {
    var frame = button.closest('[class*="expandableContainer_"]');
    if (frame) frame.removeAttribute('data-claude-message-height');
    button.click(); stats.collapsed++;
  }
  function messageParts(event) {
    var target = event.target && (event.target.nodeType === 3 ? event.target.parentElement : event.target);
    if (!target || !target.closest) return null;
    var bubble = target.closest('[class*="userMessage_"]');
    if (!bubble || !bubble.closest('[data-transcript-message][class*="userMessageContainer_"]')) return null;
    if (target.closest('a, button, input, textarea, select, [role="button"], [contenteditable="true"], [class*="userMessageAttachments_"]')) return null;
    var frame = bubble.querySelector('[class*="expandableContainer_"]');
    var content = frame && frame.querySelector(':scope > div > [class*="content_"]');
    if (!content) return null;
    // A scrollbar click/drag must scroll, not change the message height.
    if (typeof event.clientX === 'number' && content.contains(target)) {
      var rect = content.getBoundingClientRect();
      var left = rect.left + content.clientLeft;
      if (event.clientX < left || event.clientX >= left + content.clientWidth) return null;
    }
    return { bubble: bubble, frame: frame, content: content };
  }
  function collapseOutside(event) {
    if (collapsing || (typeof event.button === 'number' && event.button !== 0)) return;
    var previousSelection = selectionAtMouseDown;
    selectionAtMouseDown = null;
    var selection = window.getSelection && window.getSelection();
    var selectedOnPress = previousSelection &&
      (previousSelection.target === event.target ||
       (event.target && event.target.contains && event.target.contains(previousSelection.target))) &&
      (typeof event.timeStamp !== 'number' || typeof previousSelection.timeStamp !== 'number' ||
       (event.timeStamp >= previousSelection.timeStamp && event.timeStamp - previousSelection.timeStamp < 2000));
    // The browser may clear the selection on mousedown, before this click fires.
    if (selectedOnPress || (selection && !selection.isCollapsed)) return;
    collapsing = true;
    try {
      document.querySelectorAll(selector).forEach(function (button) {
        var bubble = button.closest('[class*="userMessage_"]') || button.closest('[class*="expandableContainer_"]');
        if (!bubble || bubble.contains(event.target) || button.isConnected === false) return;
        // Use the native action so React state, measured height and focus stay consistent.
        fold(button);
      });
      if (event.detail > 1) return;
      var parts = messageParts(event);
      if (!parts) return;
      var frame = parts.frame;
      var content = parts.content;
      var more = frame.querySelector('button[class*="expandButton_"]');
      var less = frame.querySelector('button[class*="collapseButton_"]');
      if (more && content.scrollHeight > content.clientHeight + 1) {
        frame.setAttribute('data-claude-message-height', 'medium');
        more.click(); stats.expandedMedium++;
      } else if (less) {
        if (frame.getAttribute('data-claude-message-height') !== 'max' && content.scrollHeight > content.clientHeight + 1) {
          frame.setAttribute('data-claude-message-height', 'max'); stats.expandedMax++;
        } else fold(less);
      }
    } finally { collapsing = false; }
  }
  function handleMouseDown(event) {
    var selection = window.getSelection && window.getSelection();
    selectionAtMouseDown = (typeof event.button !== 'number' || event.button === 0) &&
      selection && !selection.isCollapsed
      ? { target: event.target, timeStamp: event.timeStamp } : null;
    if (collapsing || event.detail !== 2 || (typeof event.button === 'number' && event.button !== 0)) return;
    if (messageParts(event)) event.preventDefault();
  }
  function expandMaximum(event) {
    if (collapsing || (typeof event.button === 'number' && event.button !== 0)) return;
    var parts = messageParts(event);
    if (!parts) return;
    event.preventDefault();
    var selection = window.getSelection && window.getSelection();
    if (selection && !selection.isCollapsed && selection.removeAllRanges &&
        (parts.bubble.contains(selection.anchorNode) || parts.bubble.contains(selection.focusNode))) {
      selection.removeAllRanges();
    }
    collapsing = true;
    try {
      var frame = parts.frame;
      var more = frame.querySelector('button[class*="expandButton_"]');
      var less = frame.querySelector('button[class*="collapseButton_"]');
      if (!more && !less) return;
      if (frame.getAttribute('data-claude-message-height') !== 'max') stats.expandedMax++;
      frame.setAttribute('data-claude-message-height', 'max');
      if (more) more.click();
    } finally { collapsing = false; }
  }
  document.addEventListener('mousedown', handleMouseDown, true);
  document.addEventListener('click', collapseOutside, true);
  document.addEventListener('dblclick', expandMaximum, true);
  document.documentElement.style.setProperty('--claude-user-message-initial-height', initial + 'px');
  document.documentElement.style.setProperty('--claude-user-message-medium-height', medium + 'px');
  document.documentElement.style.setProperty('--claude-user-message-max-height', maximum + 'px');
  document.documentElement.setAttribute('data-claude-user-message-collapse', 'outside');
  stats.state = 'installed';
})();
// === END USER MESSAGE OUTSIDE COLLAPSE ===

(function () {
  if (window.__claudeCustomScriptInstalled) return;
  window.__claudeCustomScriptInstalled = true;

  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  var LOGS_ENABLED = cfg.logs === true;
  var POLL_MS = typeof cfg.pollIntervalMs === 'number' && cfg.pollIntervalMs > 0
    ? cfg.pollIntervalMs : 5000;
  var THROTTLE_MS = typeof cfg.throttleMs === 'number' && cfg.throttleMs >= 0
    ? cfg.throttleMs : 200;
  var VISIBILITY_REFRESH_DELAY_MS =
    typeof cfg.visibilityRefreshDelayMs === 'number' && cfg.visibilityRefreshDelayMs >= 0
      ? cfg.visibilityRefreshDelayMs
      : 0;
  var DEBUG_OVERLAY_ENABLED = cfg.debugOverlay === true;
  var AUTO_PING_AFTER_SILENCE_SEC = typeof cfg.autoPingAfterSilenceSec === 'number' && cfg.autoPingAfterSilenceSec > 0
    ? cfg.autoPingAfterSilenceSec : 0;
  var PING_INTERVAL_SEC = typeof cfg.pingIntervalSec === 'number' && cfg.pingIntervalSec > 0
    ? cfg.pingIntervalSec : 0;
  var MAX_PINGS = typeof cfg.maxPingsPerProcessing === 'number' && cfg.maxPingsPerProcessing >= 0
    ? cfg.maxPingsPerProcessing : 0; // 0 = без ограничений

  /* ============================================================
   * PERF PROBE — прибор, а не функция
   *
   * Родился из отказа 2026-09-02: содержимое вкладки появлялось через
   * 30–40 с после Reload Window, поле ввода моргало по контуру и не
   * принимало ввод, потом всё проходило само. Бандл был цел, наш JS
   * исполнялся, в webview-errors.log — ни одного исключения, и датчик
   * пустой вкладки молчал (его setTimeout сам исполнился с
   * опозданием, когда рисовать уже было что). То есть главный поток
   * был ЗАНЯТ, а не сломан — но чем именно, сказать было нечем.
   *
   * Прибор мерит три вещи, и порядок здесь важен:
   *
   * 1. `lag` — насколько опаздывает секундный таймер. Это единственный
   *    показатель, который НЕ зависит от нашего кода: он одинаково
   *    ловит и наши сканы, и чужой рендер. Без него любая цифра ниже
   *    остаётся уликой без состава преступления.
   * 2. `ours` — сколько миллисекунд за интервал провели в наших
   *    обработчиках, с разбивкой по именам. Вместе с `lag` даёт
   *    главный ответ: наша это вина или чужая. Большой lag при
   *    крошечном `ours` — значит виноват не патч.
   * 3. `dom` — размер дерева и число ходов в нём. Проверяет
   *    предположение, которое до сих пор проверить было нечем:
   *    виртуализирует ли расширение список сообщений. Если нет, то
   *    querySelectorAll по всему документу на каждую мутацию — это
   *    O(размер переписки) десять раз в секунду.
   *
   * Отчёт уходит в hooks-runtime/webview-errors.log с `kind: "perf"`
   * своим fetch'ем, а не через claudeReportError: у того лимит
   * в 20 отправок на страницу, и регулярные сводки съели бы квоту,
   * оставив настоящее исключение без канала.
   *
   * Молчит, пока всё в порядке (см. пороги), — иначе журнал
   * заполнился бы ровными строками «всё хорошо», в которых
   * настоящую аномалию пришлось бы искать глазами. Исключение —
   * первый отчёт: он baseline, по нему видно норму этой машины.
   *
   * Диагностика, а не функция: safeMode прибор НЕ гасит. В
   * безопасный режим уходят именно при поломке, и остаться там без
   * измерений — ровно та ситуация, из которой прибор и родился.
   *
   * Управление: `perfProbe` в claude-custom-config.toml.
   * ============================================================ */
  var PERF_ENABLED = cfg.perfProbe !== false;
  var PERF_INTERVAL_MS = 10000;

  // Пороги отчёта. Бюджет наших обработчиков — 150 мс на 10 с, то есть
  // 1.5% главного потока: выше этого патч уже заметен пользователю.
  // Лаг таймера в 500 мс — та граница, за которой ввод в поле начинает
  // «залипать»: кадр держится дольше трёх периодов отрисовки.
  var PERF_BUDGET_MS = 150;
  var PERF_LAG_MS = 500;

  // Предел отчётов на страницу. Непрерывная проблема опишется первыми
  // же сводками; дальше это дубликаты, а место в журнале общее
  // со сборщиком исключений.
  var PERF_MAX_REPORTS = 60;

  var perfBuckets = {};   // имя → {calls, ms}
  var perfCounters = {};  // имя → число событий (мутации, сканы)
  var perfLagMax = 0;
  var perfLagSum = 0;
  var perfLagTicks = 0;
  var perfReports = 0;
  var perfLastTick = 0;
  var perfLastFlush = 0;
  var perfObservers = [];
  var perfSupported = [];
  var perfLong = { count: 0, total_ms: 0, max_ms: 0, samples: [] };
  var perfFrames = { count: 0, total_ms: 0, max_ms: 0, samples: [] };
  var perfMarkdown = { calls: 0, total_ms: 0, max_ms: 0, max_chars: 0 };
  var perfMarkdownState = 'disabled';
  var perfRestoreMarkdown = null;

  function perfStartMarkdown() {
    if (cfg.perfNativeMarkdown !== true) return;
    // This binding belongs to the installed bundle, not window. Only wrap
    // the verified synchronous react-markdown component; fail closed on updates.
    if (typeof b41 !== 'function' || !/\.parse\(/.test(String(b41)) || !/\.runSync\(/.test(String(b41))) {
      perfMarkdownState = 'unsupported-bundle';
      return;
    }
    var original = b41;
    var wrapped = function () {
      var started = performance.now();
      var props = arguments[0];
      try { return original.apply(this, arguments); }
      finally {
        var elapsed = performance.now() - started;
        perfMarkdown.calls++;
        perfMarkdown.total_ms += elapsed;
        perfMarkdown.max_ms = Math.max(perfMarkdown.max_ms, elapsed);
        perfMarkdown.max_chars = Math.max(perfMarkdown.max_chars,
          props && typeof props.children === 'string' ? props.children.length : 0);
      }
    };
    b41 = wrapped;
    perfMarkdownState = 'installed';
    perfRestoreMarkdown = function () {
      if (b41 === wrapped) b41 = original;
      perfMarkdownState = 'finished';
    };
  }

  // Browser attribution complements our wrappers: native React/Markdown and
  // style/layout work otherwise do not appear in the measured custom handlers.
  function perfRecordLong(target, entry, frame) {
    var duration = Math.round(entry.duration || 0);
    target.count++;
    target.total_ms += duration;
    target.max_ms = Math.max(target.max_ms, duration);
    var sample = { start_ms: Math.round(entry.startTime), duration_ms: duration };
    if (frame) {
      sample.blocking_ms = Math.round(entry.blockingDuration || 0);
      sample.render_start_ms = Math.round(entry.renderStart || 0);
      sample.style_layout_start_ms = Math.round(entry.styleAndLayoutStart || 0);
      sample.scripts = Array.from(entry.scripts || []).sort(function (a, b) { return b.duration - a.duration; })
        .slice(0, 5).map(function (script) {
          return { duration_ms: Math.round(script.duration || 0),
            forced_layout_ms: Math.round(script.forcedStyleAndLayoutDuration || 0),
            function: String(script.sourceFunctionName || '').slice(0, 120),
            source: String(script.sourceURL || '').split('?')[0].slice(-240),
            position: script.sourceCharPosition,
            invoker: String(script.invoker || '').slice(0, 160),
            invoker_type: script.invokerType };
        });
    } else {
      sample.attribution = Array.from(entry.attribution || []).slice(0, 3).map(function (item) {
        return { name: item.name, container_type: item.containerType };
      });
    }
    target.samples.push(sample);
    target.samples.sort(function (a, b) { return b.duration_ms - a.duration_ms; });
    target.samples.length = Math.min(target.samples.length, 5);
  }

  function perfStartObservers() {
    if (typeof PerformanceObserver !== 'function') return;
    ['longtask', 'long-animation-frame'].forEach(function (type) {
      if (!(PerformanceObserver.supportedEntryTypes || []).includes(type)) return;
      try {
        var observer = new PerformanceObserver(function (list) {
          list.getEntries().forEach(function (entry) {
            perfRecordLong(type === 'longtask' ? perfLong : perfFrames, entry, type !== 'longtask');
          });
        });
        observer.observe({ type: type, buffered: true });
        perfObservers.push(observer);
        perfSupported.push(type);
      } catch (e) {}
    });
  }

  function perfAdd(name, ms) {
    var b = perfBuckets[name];
    if (!b) { b = perfBuckets[name] = { calls: 0, ms: 0 }; }
    b.calls++;
    b.ms += ms;
  }

  /**
   * Обёртка-измеритель. Возвращает функцию с той же семантикой, что
   * и переданная: прибор не имеет права менять поведение того, что
   * измеряет, — включая исключения (finally, а не try/catch).
   */
  function perfWrap(name, fn) {
    if (!PERF_ENABLED) return fn;
    return function () {
      var t0 = performance.now();
      try {
        return fn.apply(this, arguments);
      } finally {
        perfAdd(name, performance.now() - t0);
      }
    };
  }

  function perfBump(name, n) {
    if (!PERF_ENABLED) return;
    perfCounters[name] = (perfCounters[name] || 0) + (n || 1);
  }

  /** Снимок размера дерева. Считается раз в интервал, не на мутацию. */
  function perfDom() {
    try {
      return {
        nodes: document.getElementsByTagName('*').length,
        messages: document.querySelectorAll('[data-testid="assistant-message"]').length,
        // Именно эти узлы обходит tagTimestampLines на каждой мутации.
        paragraphs: document.querySelectorAll('[data-testid="assistant-message"] p').length,
        inputs: document.querySelectorAll('[class*="inputContainer_"]').length,
      };
    } catch (e) {
      return { error: String(e && e.message || e) };
    }
  }

  function perfFlush(force) {
    var now = performance.now();
    var interval = Math.max(1, now - perfLastFlush);
    perfLastFlush = now;
    var ticks = perfLagTicks;
    var lagAvg = ticks ? Math.round(perfLagSum / ticks) : 0;
    var oursMs = 0;
    var ours = {};
    for (var name in perfBuckets) {
      if (!perfBuckets.hasOwnProperty(name)) continue;
      var b = perfBuckets[name];
      oursMs += b.ms;
      ours[name] = { calls: b.calls, ms: Math.round(b.ms) };
    }

    var loud = force === true || perfReports === 0
      || oursMs >= PERF_BUDGET_MS
      || perfLagMax >= PERF_LAG_MS
      || perfLong.max_ms >= PERF_LAG_MS || perfFrames.max_ms >= PERF_LAG_MS;

    if (loud && perfReports < PERF_MAX_REPORTS) {
      perfReports++;
      try {
        fetch('http://localhost:18923/webview-error', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            kind: 'perf',
            message: 'ours ' + Math.round(oursMs) + ' мс / '
              + (Math.round(interval) / 1000) + ' с · лаг таймера макс '
              + Math.round(perfLagMax) + ' мс'
              + (perfReports === 1 ? ' · baseline' : ''),
            interval_sec: Math.round(interval) / 1000,
            nominal_interval_sec: PERF_INTERVAL_MS / 1000,
            ours_ms: Math.round(oursMs),
            ours: ours,
            counters: perfCounters,
            lag: { max: Math.round(perfLagMax), avg: lagAvg, ticks: ticks },
            dom: perfDom(),
            safe_mode: cfg.safeMode === true,
            locale: cfg.locale || 'en',
            localizer_installed: window.__claudeLocalizerInstalled === true,
            visibility: document.visibilityState,
            focused: document.hasFocus(),
            heap_mb: performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1048576) : null,
            attribution_supported: perfSupported,
            long_tasks: perfLong,
            long_frames: perfFrames,
            native_markdown_state: perfMarkdownState,
            collapsed_thinking: window.__claudeCollapsedThinking,
            markdown_render: window.__claudeMarkdownRender,
            user_message_collapse: window.__claudeUserMessageCollapse,
            native_markdown: { calls: perfMarkdown.calls, total_ms: Math.round(perfMarkdown.total_ms),
              max_ms: Math.round(perfMarkdown.max_ms), max_chars: perfMarkdown.max_chars },
            stylesheet_links: document.querySelectorAll('link[rel="stylesheet"]').length,
            href: location.href.slice(0, 200),
            ts: Date.now(),
          }),
          keepalive: true,
        }).catch(function () {});
      } catch (e) {}
    }

    perfBuckets = {};
    perfCounters = {};
    perfLagMax = 0;
    perfLagSum = 0;
    perfLagTicks = 0;
    perfLong = { count: 0, total_ms: 0, max_ms: 0, samples: [] };
    perfFrames = { count: 0, total_ms: 0, max_ms: 0, samples: [] };
    perfMarkdown = { calls: 0, total_ms: 0, max_ms: 0, max_chars: 0 };
    if (perfReports >= PERF_MAX_REPORTS) {
      perfObservers.forEach(function (observer) { observer.disconnect(); });
      if (perfRestoreMarkdown) { perfRestoreMarkdown(); perfRestoreMarkdown = null; }
    }
  }

  function perfInit() {
    if (!PERF_ENABLED) return;
    perfLastTick = performance.now();
    perfLastFlush = perfLastTick;
    perfStartObservers();
    perfStartMarkdown();
    // Лаг считается по секундному таймеру, а не по requestAnimationFrame:
    // rAF в скрытой вкладке не вызывается вовсе, и фоновые панели
    // рисовали бы картину «поток свободен» при любой загрузке.
    setInterval(function () {
      var now = performance.now();
      var lag = now - perfLastTick - 1000;
      perfLastTick = now;
      if (lag < 0) lag = 0;
      if (lag > perfLagMax) perfLagMax = lag;
      perfLagSum += lag;
      perfLagTicks++;
    }, 1000);
    setInterval(perfFlush, PERF_INTERVAL_MS);
  }

  // Наружу — чтобы модули футера мерили свои сканы тем же прибором:
  // вторая реализация счётчика разошлась бы с первой, и сравнивать
  // цифры из одного отчёта стало бы нельзя.
  window.__claudePerf = {
    wrap: perfWrap,
    bump: perfBump,
    enabled: PERF_ENABLED,
    /** Внеочередная сводка — для отладки из консоли. */
    flush: function () { perfFlush(true); },
  };

  // === Locale-drift detector ===
  // Когда в DOM появляется выпадашка меню `/` ([class*="menuPopup_"]),
  // collectMenuItems() пробегает по всем её пунктам и собирает тройки
  // {section, label, title}. Дальше maybeCollectAndSend (debounced 500мс)
  // отправляет результат POST'ом на локальный http-server.py
  // (.claude/hooks/http-server.py, endpoint /locale-drift), который
  // перезаписывает .claude/hooks-runtime/locales-drift-pending.json.
  // Анализатор drift в localize.py читает этот файл и эмитит warning,
  // если найден дрейф (английский title там, где у нас должен быть
  // русский) или новая команда (label, которой нет в словаре).
  // localhost (а не 127.0.0.1) — для консистентности с уже работающим
  // fetch на /save-log; CSP webview допускает оба, но используем один и тот же.
  var LOCALE_DRIFT_URL = 'http://localhost:18923/locale-drift';
  var LOCALE_DRIFT_DEBOUNCE_MS = 500;
  var localeDriftTimer = null;
  var lastDriftHash = '';
  var driftSendInFlight = false;

  // Сборщик каталога моделей. Когда в DOM появляется popup селектора
  // моделей (`[class*="modelItem_"]`), отправляем на /models-list полный
  // список моделей (включая value-ID, который недоступен из textContent
  // и достаётся через React-fiber `.key`). Файл models-list.json — это
  // готовый каталог для построения внешнего переключателя моделей.
  var MODELS_LIST_URL = 'http://localhost:18923/models-list';
  var MODELS_LIST_DEBOUNCE_MS = 500;
  var modelsListTimer = null;
  var lastModelsHash = '';
  var modelsSendInFlight = false;

  /**
   * On-demand пинг через fetch к api.anthropic.com. Работает благодаря
   * патчу CSP в extension.js (connect-src https://api.anthropic.com).
   * Вызывается по клику на 📡 в overlay.
   */
  var onDemandPingState = 'idle'; // 'idle' | 'checking' | 'online' | 'offline' | 'csp_blocked'
  var onDemandPingTs = 0;
  var onDemandPingMs = 0; // время пинга в мс (только при online)
  var autoPingCount = 0;  // счётчик автоматических пингов за текущий processing
  var inlinePingClicked = false; // клик по 📡 в строке — показать результат

  function onDemandPing() {
    if (onDemandPingState === 'checking') return;
    onDemandPingState = 'checking';
    onDemandPingTs = Date.now();
    var startTime = Date.now();
    var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timeoutId = setTimeout(function () {
      if (controller) controller.abort();
      onDemandPingState = 'offline';
      onDemandPingTs = Date.now();
      logInfo('on-demand ping timeout → offline');
    }, 5000);

    fetch('https://api.anthropic.com/', {
      method: 'HEAD',
      mode: 'no-cors',
      cache: 'no-store',
      signal: controller ? controller.signal : undefined,
    }).then(function () {
      clearTimeout(timeoutId);
      onDemandPingMs = Date.now() - startTime;
      onDemandPingState = 'online';
      onDemandPingTs = Date.now();
      logInfo('on-demand ping → online (' + onDemandPingMs + 'ms)');
    }).catch(function (e) {
      clearTimeout(timeoutId);
      var elapsed = Date.now() - startTime;
      if (e && e.name === 'AbortError') return; // timeout уже обработан
      if (elapsed < 200) {
        onDemandPingState = 'csp_blocked';
        logInfo('on-demand ping csp_blocked (' + elapsed + 'ms)');
      } else {
        onDemandPingState = 'offline';
        logInfo('on-demand ping offline (' + elapsed + 'ms)');
      }
      onDemandPingTs = Date.now();
    });
  }

  function logInfo() {
    if (!LOGS_ENABLED) return;
    try { console.log.apply(console, ['[claude-custom]'].concat([].slice.call(arguments))); } catch (_) {}
  }
  function logWarn() {
    if (!LOGS_ENABLED) return;
    try { console.warn.apply(console, ['[claude-custom]'].concat([].slice.call(arguments))); } catch (_) {}
  }

  /**
   * ===== Compact-confirm popup =====
   *
   * Иконка автосжатия — `<button class="usage_<hash> usageButtonV2_<hash>"
   * title="N% context used — click to compact">` в правом нижнем углу
   * inputFooter. Один клик по ней мгновенно запускает /compact, что
   * легко сделать случайно. Перехватываем click в capture-фазе и
   * показываем confirmation popup рядом с иконкой; реальный compact
   * запускается только при подтверждении («Сжать»).
   *
   * Логика обхода capture-listener'а: при подтверждении ставим
   * dataset.compactConfirmed='true', потом target.click(). При повторном
   * проходе через наш listener этот флаг прочитан и удалён, событие
   * пропускается дальше — React-handler срабатывает.
   *
   * Стили popup'а через VSCode CSS-vars (--vscode-editorHoverWidget-*),
   * чтобы выглядел как нативный hover-tooltip того же UI.
   */

  var COMPACT_CONFIRM_ID = 'claude-compact-confirm';

  function hideCompactConfirmPopup() {
    var popup = document.getElementById(COMPACT_CONFIRM_ID);
    if (popup) popup.remove();
    document.removeEventListener('click', compactOutsideClickHandler, true);
    document.removeEventListener('keydown', compactKeydownHandler, true);
  }

  function compactOutsideClickHandler(e) {
    var popup = document.getElementById(COMPACT_CONFIRM_ID);
    if (popup && !popup.contains(e.target)) {
      // Если клик за пределами — закрыть; click на самой usage-кнопке
      // тоже считаем «закрытием», чтобы повторный клик не открывал
      // дублирующий popup.
      hideCompactConfirmPopup();
    }
  }

  function compactKeydownHandler(e) {
    if (e.key === 'Escape') {
      hideCompactConfirmPopup();
    } else if (e.key === 'Enter') {
      var yesBtn = document.getElementById('claude-compact-yes');
      if (yesBtn) yesBtn.click();
    }
  }

  /**
   * Показывает confirmation popup для /compact.
   *
   * @param target — DOM-узел, относительно которого позиционируется popup.
   * @param onConfirm — опциональный callback. Если задан, вызывается
   *   вместо штатного `target.click()` (нужно для debug-overlay-иконки,
   *   когда настоящей usage-кнопки в DOM ещё нет — кликать нечего).
   */
  function showCompactConfirmPopup(target, onConfirm) {
    hideCompactConfirmPopup();

    var popup = document.createElement('div');
    popup.id = COMPACT_CONFIRM_ID;
    popup.style.cssText = [
      'position: fixed',
      'background: var(--vscode-editorHoverWidget-background, rgba(40,40,40,0.97))',
      'color: var(--vscode-editorHoverWidget-foreground, #ddd)',
      'border: 1px solid var(--vscode-editorHoverWidget-border, rgba(255,255,255,0.1))',
      'border-radius: 6px',
      'padding: 10px 12px',
      'font-size: 13px',
      'font-family: -apple-system, BlinkMacSystemFont, sans-serif',
      'box-shadow: 0 4px 14px rgba(0,0,0,0.35)',
      'z-index: 100000',
      'min-width: 200px',
    ].join(';');

    var msg = document.createElement('div');
    msg.style.cssText = 'margin-bottom: 10px;';
    msg.textContent = 'Сжать контекст сейчас?';
    popup.appendChild(msg);

    var btnRow = document.createElement('div');
    btnRow.style.cssText = 'display: flex; gap: 8px;';

    function makeBtn(id, label, primary) {
      var b = document.createElement('button');
      b.id = id;
      b.type = 'button';
      b.textContent = label;
      var bg = primary
        ? 'var(--vscode-button-background, #0e639c)'
        : 'var(--vscode-button-secondaryBackground, #3a3d41)';
      var fg = primary
        ? 'var(--vscode-button-foreground, #fff)'
        : 'var(--vscode-button-secondaryForeground, #ccc)';
      b.style.cssText = [
        'flex: 1',
        'padding: 5px 10px',
        'cursor: pointer',
        'background: ' + bg,
        'color: ' + fg,
        'border: none',
        'border-radius: 4px',
        'font-size: 12px',
        'font-family: inherit',
      ].join(';');
      return b;
    }

    // «Сжать» — attention-стиль (жёлтый): операция необратимая, но
    // не разрушительная как «Очистить разговор», поэтому warning, а не
    // destructive. Текст оставляем не-жирным, чтобы не звать к клику.
    var yesBtn = makeBtn('claude-compact-yes', 'Сжать', true);
    // Цвет — ярко-жёлтый напрямую, без VSCode-переменной:
    // --vscode-statusBarItem-warningBackground = #cca700 (горчичный),
    // что в Electron-webview выглядит тускло. Берём чистый amber.
    yesBtn.style.background = '#FBCD44';
    yesBtn.style.color = '#000';
    // «Отмена» — primary-стиль (синий) + bold, чтобы безопасное
    // действие визуально доминировало (см. тот же паттерн в
    // showClearConfirmPopup).
    var noBtn = makeBtn('claude-compact-no', 'Отмена', true);
    noBtn.style.fontWeight = 'bold';
    btnRow.appendChild(yesBtn);
    btnRow.appendChild(noBtn);
    popup.appendChild(btnRow);

    document.body.appendChild(popup);

    // Позиционирование над иконкой; если не помещается — под ней.
    var rect = target.getBoundingClientRect();
    var pRect = popup.getBoundingClientRect();
    var top = rect.top - pRect.height - 8;
    if (top < 8) top = rect.bottom + 8;
    var left = rect.left + rect.width / 2 - pRect.width / 2;
    if (left < 8) left = 8;
    if (left + pRect.width > window.innerWidth - 8) {
      left = window.innerWidth - pRect.width - 8;
    }
    popup.style.top = top + 'px';
    popup.style.left = left + 'px';

    yesBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      hideCompactConfirmPopup();
      if (typeof onConfirm === 'function') {
        // Альтернативный путь: вызов из debug-overlay, где target —
        // фиктивная иконка-триггер, а реальное действие /compact
        // отправляется коллбэком через textarea.
        onConfirm();
        return;
      }
      target.dataset.compactConfirmed = 'true';
      // Триггерим оригинальный click; наш capture-listener увидит флаг
      // и пропустит событие дальше — React-handler запустит compact.
      target.click();
    });
    noBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      hideCompactConfirmPopup();
    });

    // Регистрируем outside-click и Escape с задержкой, чтобы текущее
    // событие click (которое и открыло popup) не закрыло его сразу же.
    setTimeout(function () {
      document.addEventListener('click', compactOutsideClickHandler, true);
      document.addEventListener('keydown', compactKeydownHandler, true);
    }, 0);

    yesBtn.focus();
  }

  /**
   * Отправляет slash-команду (например, "/compact") как сообщение
   * пользователя — нужен для случаев, когда нативной кнопки в UI нет
   * (например, /compact icon появляется только при заполненном контексте).
   *
   * React-controlled textarea игнорирует обычное `ta.value = ...`,
   * поэтому используем native value setter из прототипа
   * HTMLTextAreaElement — он триггерит React-tracker, и компонент
   * подхватывает значение. Затем dispatch input → keydown Enter.
   *
   * Возвращает true, если textarea найдена, false иначе.
   */
  function triggerSlashCommandViaInput(cmd) {
    // Composer в Claude Code 2.x — это <div contentEditable="plaintext-only"
    // role="textbox" aria-label="Message input">, НЕ <textarea>. Поэтому
    // ищем contenteditable, а не textarea.
    var input =
      document.querySelector('[role="textbox"][contenteditable][aria-label*="essage" i]') ||
      document.querySelector('[role="textbox"][contenteditable]') ||
      document.querySelector('div[contenteditable]');
    if (!input) {
      logWarn('triggerSlashCommand: composer (contenteditable) not found');
      return false;
    }
    try {
      input.focus();
      // execCommand('insertText') триггерит native input event с
      // правильным inputType, который React-handler onInput подхватывает
      // как штатный ввод (в отличие от прямой записи в textContent).
      // selectAll + insertText заменяет существующий текст (если был).
      document.execCommand('selectAll', false, null);
      var inserted = document.execCommand('insertText', false, cmd);
      if (!inserted) {
        // Fallback: ручная установка textContent + диспатч InputEvent.
        input.textContent = cmd;
        input.dispatchEvent(new InputEvent('input', {
          bubbles: true, cancelable: true,
          inputType: 'insertText', data: cmd,
        }));
      }
      logInfo('triggerSlashCommand: set', JSON.stringify(cmd),
        '→ textContent=', JSON.stringify(input.textContent));

      setTimeout(function () {
        // (1) Найти кнопку отправки (sendButton_/sendIcon_/aria-label).
        var sendBtn = null;
        var p = input.parentElement;
        while (p && p !== document.body && !sendBtn) {
          sendBtn = p.querySelector(
            'button[class*="sendButton_"],' +
            'button[class*="sendIcon_"],' +
            'button[aria-label*="send" i],' +
            'button[aria-label*="отправ" i]'
          );
          p = p.parentElement;
        }
        if (sendBtn && !sendBtn.disabled) {
          sendBtn.click();
          logInfo('triggerSlashCommand: clicked send button',
            sendBtn.getAttribute('aria-label') || sendBtn.className);
          return;
        }
        if (sendBtn) {
          logWarn('triggerSlashCommand: send button found but disabled');
        }
        // (2) Last resort: Enter keydown — React's onKeyDown handler
        // обычно его слушает (см. webview/index.js: r.key==="Enter").
        input.dispatchEvent(new KeyboardEvent('keydown', {
          key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
          bubbles: true, cancelable: true,
        }));
        logInfo('triggerSlashCommand: dispatched Enter on composer');
      }, 50);
      return true;
    } catch (e) {
      logWarn('triggerSlashCommandViaInput failed:', e && e.message ? e.message : e);
      return false;
    }
  }

  function compactClickInterceptor(e) {
    var target = e.target.closest && e.target.closest('button[class*="usage_"]');
    if (!target) return;
    // Не дёргаем подтверждение для кнопок без характерного title:
    // фильтр снижает риск зацепить чужой usage_ от другого компонента.
    var title = target.getAttribute('title') || '';
    if (title.indexOf('compact') < 0 && title.indexOf('сжат') < 0) return;

    if (target.dataset.compactConfirmed === 'true') {
      delete target.dataset.compactConfirmed;
      return; // прошли подтверждение — пропускаем дальше к React
    }
    e.stopPropagation();
    e.preventDefault();
    showCompactConfirmPopup(target);
  }

  /**
   * Confirmation для пункта меню `/` «Очистить разговор». По аналогии
   * с compactClickInterceptor: capture-listener, dataset-флаг для
   * пропуска повторного click'а. Идентификация цели — по label в
   * `[class*="commandLabel_"]` (точное совпадение с RU- или EN-вариантом
   * после локализации словарём). Сам action React'а — открыть новый чат
   * без сохранения текущего; легко сделать случайно, потому и confirm.
   */
  var CLEAR_CONFIRM_ID = 'claude-clear-confirm';

  function hideClearConfirmPopup() {
    var popup = document.getElementById(CLEAR_CONFIRM_ID);
    if (popup) popup.remove();
    document.removeEventListener('click', clearOutsideClickHandler, true);
    document.removeEventListener('keydown', clearKeydownHandler, true);
  }

  function clearOutsideClickHandler(e) {
    var popup = document.getElementById(CLEAR_CONFIRM_ID);
    if (popup && !popup.contains(e.target)) hideClearConfirmPopup();
  }

  function clearKeydownHandler(e) {
    if (e.key === 'Escape') {
      hideClearConfirmPopup();
    } else if (e.key === 'Enter') {
      var yesBtn = document.getElementById('claude-clear-yes');
      if (yesBtn) yesBtn.click();
    }
  }

  function showClearConfirmPopup(target) {
    hideClearConfirmPopup();

    var popup = document.createElement('div');
    popup.id = CLEAR_CONFIRM_ID;
    popup.style.cssText = [
      'position: fixed',
      'background: var(--vscode-editorHoverWidget-background, rgba(40,40,40,0.97))',
      'color: var(--vscode-editorHoverWidget-foreground, #ddd)',
      'border: 1px solid var(--vscode-editorHoverWidget-border, rgba(255,255,255,0.1))',
      'border-radius: 6px',
      'padding: 10px 12px',
      'font-size: 13px',
      'font-family: -apple-system, BlinkMacSystemFont, sans-serif',
      'box-shadow: 0 4px 14px rgba(0,0,0,0.35)',
      'z-index: 100000',
      'min-width: 240px',
    ].join(';');

    var msg = document.createElement('div');
    msg.style.cssText = 'margin-bottom: 10px;';
    msg.textContent = 'Очистить разговор? Текущий чат будет удален.';
    popup.appendChild(msg);

    var btnRow = document.createElement('div');
    btnRow.style.cssText = 'display: flex; gap: 8px;';

    function makeBtn(id, label, primary) {
      var b = document.createElement('button');
      b.id = id;
      b.type = 'button';
      b.textContent = label;
      var bg = primary
        ? 'var(--vscode-button-background, #0e639c)'
        : 'var(--vscode-button-secondaryBackground, #3a3d41)';
      var fg = primary
        ? 'var(--vscode-button-foreground, #fff)'
        : 'var(--vscode-button-secondaryForeground, #ccc)';
      b.style.cssText = [
        'flex: 1',
        'padding: 5px 10px',
        'cursor: pointer',
        'background: ' + bg,
        'color: ' + fg,
        'border: none',
        'border-radius: 4px',
        'font-size: 12px',
        'font-family: inherit',
      ].join(';');
      return b;
    }

    // «Очистить» — деструктивное действие (удаляет текущий чат), красный
    // фон вместо синего primary; шрифт остаётся обычным, чтобы кнопка
    // не «звала» к клику.
    var yesBtn = makeBtn('claude-clear-yes', 'Очистить', true);
    yesBtn.style.background =
      'var(--vscode-statusBarItem-errorBackground, #c42b1c)';
    yesBtn.style.color =
      'var(--vscode-statusBarItem-errorForeground, #fff)';
    // «Отмена» — безопасное действие по умолчанию: синий primary + bold,
    // чтобы визуально доминировала и снижала риск случайного клика по
    // красной деструктивной кнопке.
    var noBtn = makeBtn('claude-clear-no', 'Отмена', true);
    noBtn.style.fontWeight = 'bold';
    btnRow.appendChild(yesBtn);
    btnRow.appendChild(noBtn);
    popup.appendChild(btnRow);

    document.body.appendChild(popup);

    // Позиционирование: над пунктом «Очистить разговор», прижато к
    // левому краю самого пункта (чтобы попап стоял прямо над текстом
    // лейбла, а не плавал по центру). Если сверху не помещается —
    // сдвигаем под пункт; по горизонтали — clamp к viewport'у.
    var rect = target.getBoundingClientRect();
    var pRect = popup.getBoundingClientRect();
    var top = rect.top - pRect.height - 8;
    if (top < 8) top = rect.bottom + 8;
    var left = rect.left;
    if (left < 8) left = 8;
    if (left + pRect.width > window.innerWidth - 8) {
      left = window.innerWidth - pRect.width - 8;
    }
    popup.style.top = top + 'px';
    popup.style.left = left + 'px';

    yesBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      hideClearConfirmPopup();
      target.dataset.clearConfirmed = 'true';
      target.click();
    });
    noBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      hideClearConfirmPopup();
    });

    setTimeout(function () {
      document.addEventListener('click', clearOutsideClickHandler, true);
      document.addEventListener('keydown', clearKeydownHandler, true);
    }, 0);

    yesBtn.focus();
  }

  function clearClickInterceptor(e) {
    var target = e.target.closest && e.target.closest('[class*="commandItem_"]');
    if (!target) return;
    var labelEl = target.querySelector('[class*="commandLabel_"]');
    var label = labelEl ? (labelEl.textContent || '').trim() : '';
    // Сравниваем с обеими локалями: словарь подменяет RU после первого
    // открытия меню, но при cold-start меню сначала появляется в EN.
    if (label !== 'Очистить разговор' && label !== 'Clear conversation') return;

    if (target.dataset.clearConfirmed === 'true') {
      delete target.dataset.clearConfirmed;
      return;
    }
    e.stopPropagation();
    e.preventDefault();
    showClearConfirmPopup(target);
  }

  /**
   * Помечает абзацы ассистентского сообщения, начинающиеся с эмодзи 📬,
   * классом `.claude-ts-line` (на него рассчитан CSS из claude-custom.css).
   */
  function tagTimestampLines() {
    var nodes = document.querySelectorAll(
      '[data-testid="assistant-message"] p:not(.claude-ts-line)'
    );
    for (var i = 0; i < nodes.length; i++) {
      var p = nodes[i];
      var text = (p.textContent || '').replace(/^[\s ]+/, '');
      if (text.indexOf('\u{1F4EC} ') === 0) {
        p.classList.add('claude-ts-line');
      }
    }
  }

  /**
   * Перевешивает <link rel="stylesheet"> к claude-custom.css с уникальным
   * query-параметром, чтобы браузер качал файл заново. <link> идёт под
   * CSP `style-src vscode-resource:` — это работает, в отличие от fetch
   * (его CSP `connect-src` режет). Старый <link> удаляется только после
   * успешной загрузки нового.
   *
   * Не делает refresh, если вкладка не активна (`document.visibilityState
   * !== 'visible'`) — фоновые webview-панели не дёргают диск и не плодят
   * `?t=…` URL'ы в DevTools Sources. При активации вкладки сработает
   * handler на `visibilitychange` (см. init), который догоняет CSS.
   */
  var lastCssRefresh = 0;
  function refreshCustomCss() {
    refreshCalls++;
    // visibilityState в Anthropic-webview всегда 'visible', поэтому
    // используем document.hasFocus(): только сфокусированная вкладка
    // VSCode действительно «активная». Это даёт нам нужное поведение —
    // refreshCustomCss работает только в активной вкладке.
    if (!document.hasFocus()) {
      refreshSkippedNotFocused++;
      return;
    }
    var now = Date.now();
    if (now - lastCssRefresh < THROTTLE_MS) {
      refreshSkippedThrottled++;
      return;
    }
    lastCssRefresh = now;
    refreshExecuted++;

    // Подстраховка: удалить «зависший» <style> от старой fetch-реализации,
    // если он остался в DOM — иначе он будет перебивать свежий <link>.
    var staleStyle = document.getElementById('claude-custom-style');
    if (staleStyle && staleStyle.parentNode) {
      staleStyle.parentNode.removeChild(staleStyle);
    }

    var existing = document.getElementById('claude-custom-css');
    if (!existing) return;
    var baseHref = (existing.href || '').split('?')[0];
    if (!baseHref) return;

    var fresh = document.createElement('link');
    fresh.rel = 'stylesheet';
    fresh.href = baseHref + '?t=' + now;
    fresh.onload = function () {
      if (existing.parentNode) existing.parentNode.removeChild(existing);
      fresh.id = 'claude-custom-css';
      logInfo('css link refreshed at', new Date().toISOString());
    };
    fresh.onerror = function () {
      if (fresh.parentNode) fresh.parentNode.removeChild(fresh);
      logWarn('css link load failed');
    };
    document.head.appendChild(fresh);
  }

  /**
   * Persistent debug-overlay в правом верхнем углу webview. Виден на
   * любой вкладке (активной и неактивной). Показывает обратный отсчёт
   * до следующего CSS-poll'а. При visibility-resume переключается в
   * режим «refresh через …» и потом возвращается в обычный режим.
   *
   * Стили инлайн (cssText), чтобы overlay не зависел от перезагружаемого
   * claude-custom.css.
   */
  var initTimeMs = Date.now();
  var lastPollAt = initTimeMs;
  var overlayMode = 'poll'; // 'poll' | 'visibility'
  var visibilityResumeAt = 0;

  // Диагностика — для понимания, почему visibility-resume countdown
  // не срабатывает в этом расширении (см. issue от 2026-04-28).
  var lastVisibilityState = document.visibilityState;
  var lastVisibilityChangeAt = null;
  var lastVisibilityChangeNewState = null;
  var visibilityChangeCount = 0;
  var lastFocusState = document.hasFocus();
  var lastFocusChangeAt = null;
  var focusChangeCount = 0;
  // Счётчики refreshCustomCss: показывают, что фильтры действительно
  // блокируют ненужные refresh'и.
  var refreshCalls = 0;
  var refreshSkippedNotFocused = 0;
  var refreshSkippedThrottled = 0;
  var refreshExecuted = 0;

  // Лог переходов состояний сессии — хранит последние MAX_STATE_LOG
  // записей с таймстампами. Копируется через 📋.
  var MAX_STATE_LOG_DISPLAY = 20; // сколько показывать в overlay
  var stateLog = [];              // полный лог (без лимита)
  var prevTrackedStates = {};

  // Текущие состояния — используются и в overlay, и в inline-индикаторе
  var busyState = false;
  var actuallyStreaming = false;
  var busyNoStreamSec = 0;
  var contentSilenceSec = 0;
  var lastDomMutationAt = Date.now(); // последнее изменение DOM (любое)
  var lastContentLen = 0;             // длина контента последнего assistant-message
  var lastContentChangeAt = Date.now(); // когда контент последний раз менялся

  function trackStateChange(key, newVal) {
    var prev = prevTrackedStates[key];
    if (prev === newVal) return;
    prevTrackedStates[key] = newVal;
    if (prev === undefined) return; // первичная инициализация — не логируем
    var ts = new Date().toLocaleTimeString('ru-RU', {hour12: false});
    var entry = ts + ' ' + key + ': ' + prev + ' → ' + newVal;
    stateLog.push(entry);
  }

  // Доступ к session-store через React Fiber tree.
  // sessionStore — экземпляр класса Wn (см. webview/index.js): содержит
  // .activeSession (signal с текущей session) и .sessions (signal-массив).
  // session — экземпляр eX: .busy, .connection, .error, .messages, и т.п.
  var sessionStore = null;       // Wn-instance
  var sessionStoreFoundAt = null;
  var lastSessionFindAttempt = 0;
  var sessionFindDiag = '';      // диагностика последнего поиска

  function createDebugBuffer(overlay) {
    var box = document.createElement('div');
    box.id = 'claude-custom-debug-buffer';
    box.style.cssText = 'width:280px;max-width:45vw;margin-top:6px;white-space:normal;';
    var label = document.createElement('div');
    label.id = 'claude-custom-debug-buffer-value';
    label.style.cssText = 'color:#e5d95c;';
    var meter = document.createElement('progress');
    meter.id = 'claude-custom-debug-buffer-meter';
    meter.max = 1; meter.value = 0;
    meter.setAttribute('aria-label', 'Оставшийся буфер текста');
    meter.title = 'Шкала относительно пикового размера текущего буфера';
    meter.style.cssText = 'display:block;width:100%;height:10px;margin:4px 0;accent-color:#e5d95c;';
    var detail = document.createElement('div');
    detail.id = 'claude-custom-debug-buffer-detail';
    detail.style.cssText = 'font-size:11px;color:#bbb;white-space:pre-line;';
    [box, label, meter, detail].forEach(function (node) { node.__claudeOwnNode = true; });
    box.appendChild(label); box.appendChild(meter); box.appendChild(detail);
    overlay.appendChild(box);
  }

  function updateDebugBuffer() {
    var label = document.getElementById('claude-custom-debug-buffer-value');
    var meter = document.getElementById('claude-custom-debug-buffer-meter');
    var detail = document.getElementById('claude-custom-debug-buffer-detail');
    if (!label || !meter || !detail) return;
    var s = window.__claudeMarkdownRender || {};
    var total = s.animation_queue || 0, ready = s.animation_ready_queue || 0;
    var peak = Math.max(1, total, s.animation_queue_peak || 0);
    var text = 'Буфер: ' + total + ' симв.';
    var info = s.animate_sentences
      ? 'К печати: ' + ready + ' · Ждут предложения: ' + (s.animation_waiting_sentence || 0) +
        '\nСкорость: ' + (ready ? s.animation_rate || 0 : 0) + ' симв/с · минимум ' + (s.animation_min_rate || 50) + ' симв/с' +
        '\nОриентир буфера: ' + (s.animation_buffer_target || 500) + ' симв. · скорость без потолка'
      : 'Постепенная печать отключена';
    if (label.textContent !== text) label.textContent = text;
    if (meter.max !== peak) meter.max = peak;
    if (meter.value !== total) meter.value = total;
    if (detail.textContent !== info) detail.textContent = info;
  }

  function ensureDebugOverlay() {
    var overlay = document.getElementById('claude-custom-debug');
    if (overlay) return overlay;
    overlay = document.createElement('div');
    overlay.id = 'claude-custom-debug';
    overlay.style.cssText =
      'position:fixed;top:12px;right:12px;z-index:99999;' +
      'background:rgba(0,0,0,0.85);color:#fff;' +
      'padding:8px 14px;border-radius:6px;' +
      'font:12px/1.4 monospace;pointer-events:none;user-select:none;' +
      'box-shadow:0 2px 8px rgba(0,0,0,0.5);' +
      'min-width:240px;max-width:50vw;max-height:80vh;' +
      'overflow:auto;text-align:left;white-space:pre-wrap;word-break:break-all;';
    // Свёрнутая панель: statusIcon + ➕ + 📋 (горизонтальная полоска)
    var miniBar = document.createElement('div');
    miniBar.id = 'claude-custom-debug-mini';
    miniBar.style.cssText =
      'display:none;align-items:center;gap:6px;' +
      'pointer-events:auto;user-select:none;';

    var miniStatus = document.createElement('span');
    miniStatus.id = 'claude-custom-debug-mini-status';
    miniStatus.style.cssText = 'font-size:14px;';
    miniBar.appendChild(miniStatus);

    // Текстовый контейнер — updateDebugOverlay обновляет его, а не overlay
    var textDiv = document.createElement('div');
    textDiv.id = 'claude-custom-debug-text';
    overlay.appendChild(textDiv);
    createDebugBuffer(overlay);

    /* Метка «это наш узел» — по ней базовый наблюдатель отличает свои
     * мутации от чужих (см. init). Оверлей живёт в том же body, что и
     * приложение, и его записи иначе выглядели бы как активность
     * страницы: обновляли бы отметку времени последней мутации, на
     * которой держится детектор тишины, и запускали бы обход дерева.
     * То есть патч будил бы сам себя.
     *
     * Помечаются ровно те узлы, в которые мы пишем: цель мутации —
     * всегда один из них, а не корень оверлея. Проверка по свойству,
     * а не через `contains`: она стоит одно сравнение на запись, а
     * записей в шторме тысячи. */
    overlay.__claudeOwnNode = true;
    textDiv.__claudeOwnNode = true;
    miniBar.__claudeOwnNode = true;
    miniStatus.__claudeOwnNode = true;

    // Панель иконок (правый верхний угол, видна только в развёрнутом виде)
    var iconsBar = document.createElement('div');
    iconsBar.id = 'claude-custom-debug-icons';
    iconsBar.style.cssText =
      'position:absolute;top:4px;right:6px;display:flex;gap:6px;' +
      'align-items:center;pointer-events:auto;user-select:none;';

    var isMinimized = true;
    textDiv.style.display = 'none';
    iconsBar.style.display = 'none';
    miniBar.style.display = 'flex';
    overlay.style.minWidth = 'auto';
    overlay.style.maxWidth = 'auto';
    overlay.style.padding = '4px 8px';

    function btnStyle() { return 'cursor:pointer;font-size:13px;opacity:0.6;'; }
    function hoverIn(el) { el.style.opacity = '1'; }
    function hoverOut(el) { el.style.opacity = '0.6'; }

    // Кнопка сворачивания (в развёрнутом виде)
    var collapseBtn = document.createElement('span');
    collapseBtn.textContent = '▲';
    collapseBtn.title = 'Свернуть';
    collapseBtn.style.cssText = btnStyle() + 'font-size:20px;line-height:1;position:relative;top:-2px;';
    collapseBtn.addEventListener('mouseenter', function () { hoverIn(collapseBtn); });
    collapseBtn.addEventListener('mouseleave', function () { hoverOut(collapseBtn); });
    collapseBtn.addEventListener('click', function () {
      isMinimized = true;
      textDiv.style.display = 'none';
      iconsBar.style.display = 'none';
      miniBar.style.display = 'flex';
      overlay.style.minWidth = 'auto';
      overlay.style.maxWidth = 'auto';
      overlay.style.padding = '4px 8px';
      collapseBtn.textContent = '▲';
    });

    // Кнопка копирования (в развёрнутом виде)
    var copyBtn = document.createElement('span');
    copyBtn.textContent = '📋';
    copyBtn.title = 'Скопировать содержимое';
    copyBtn.style.cssText = btnStyle();
    copyBtn.addEventListener('mouseenter', function () { hoverIn(copyBtn); });
    copyBtn.addEventListener('mouseleave', function () { hoverOut(copyBtn); });
    copyBtn.addEventListener('click', function () {
      try {
        // Копируем overlay-текст + ПОЛНЫЙ лог (не обрезанный)
        var overlayText = textDiv.textContent || '';
        // Заменяем отображаемый лог на полный
        var displayLogHeader = '—— state log (' + stateLog.length + ' total) ——';
        var idx = overlayText.indexOf('—— state log');
        var text;
        if (idx >= 0) {
          text = overlayText.substring(0, idx) +
            '—— FULL state log (' + stateLog.length + ' entries) ——\n' +
            stateLog.join('\n');
        } else {
          text = overlayText + '\n—— FULL state log (' + stateLog.length + ' entries) ——\n' +
            stateLog.join('\n');
        }
        navigator.clipboard.writeText(text).then(function () {
          copyBtn.textContent = '✅';
          setTimeout(function () { copyBtn.textContent = '📋'; }, 1500);
        });
      } catch (e) {
        try {
          var range = document.createRange();
          range.selectNodeContents(textDiv);
          var sel = window.getSelection();
          sel.removeAllRanges();
          sel.addRange(range);
          document.execCommand('copy');
          sel.removeAllRanges();
          copyBtn.textContent = '✅';
          setTimeout(function () { copyBtn.textContent = '📋'; }, 1500);
        } catch (e2) {}
      }
    });

    // Кнопка пинга
    var pingBtn = document.createElement('span');
    pingBtn.textContent = '📡';
    pingBtn.title = 'Проверить интернет (on-demand ping)';
    pingBtn.style.cssText = btnStyle();
    pingBtn.addEventListener('mouseenter', function () { hoverIn(pingBtn); });
    pingBtn.addEventListener('mouseleave', function () { hoverOut(pingBtn); });
    pingBtn.addEventListener('click', function () {
      onDemandPing();
      pingBtn.textContent = '⏳';
      // Возвращаем 📡 как только пинг завершится (не по таймеру)
      var checkId = setInterval(function () {
        if (onDemandPingState !== 'checking') {
          clearInterval(checkId);
          pingBtn.textContent = '📡';
        }
      }, 100);
      // Safety: максимум 10 сек
      setTimeout(function () { clearInterval(checkId); pingBtn.textContent = '📡'; }, 10000);
    });

    // Кнопка сохранения лога в файл
    var saveBtn = document.createElement('span');
    saveBtn.textContent = '💾';
    saveBtn.title = 'Сохранить лог в файл';
    saveBtn.style.cssText = btnStyle();
    saveBtn.addEventListener('mouseenter', function () { hoverIn(saveBtn); });
    saveBtn.addEventListener('mouseleave', function () { hoverOut(saveBtn); });
    saveBtn.addEventListener('click', function () {
      var text = (textDiv.textContent || '').trim();
      var logStart = text.indexOf('—— state log');
      if (logStart >= 0) text = text.substring(0, logStart).trim();
      text += '\n—— FULL state log (' + stateLog.length + ' entries) ——\n'
        + stateLog.join('\n');
      // Include the most recent performance counters in the automatic log.
      if (window.__claudePerf) window.__claudePerf.flush();
      saveBtn.textContent = '⏳';
      fetch('http://localhost:18923/save-log', {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain' },
        body: text,
      }).then(function (r) { return r.json(); })
        .then(function (data) {
          if (data.status === 'saved') {
            saveBtn.textContent = '✅';
            saveBtn.title = 'Сохранено: ' + data.file;
            logInfo('log saved:', data.path);
          } else {
            saveBtn.textContent = '❌';
            logWarn('save error:', data.error);
          }
          setTimeout(function () { saveBtn.textContent = '💾'; saveBtn.title = 'Сохранить лог в файл'; }, 2000);
        })
        .catch(function (e) {
          saveBtn.textContent = '❌';
          saveBtn.title = 'HTTP-сервер недоступен';
          logWarn('save failed:', e);
          setTimeout(function () { saveBtn.textContent = '💾'; saveBtn.title = 'Сохранить лог в файл'; }, 2000);
        });
    });

    // Кнопка вызова /compact с подтверждением. Нужна, когда нативная
    // usage-иконка ещё не показалась (контекст не заполнен), но хочется
    // принудительно сжать историю или просто проверить confirm-popup.
    var compactBtn = document.createElement('span');
    compactBtn.textContent = '🗜';
    compactBtn.title = '/compact (с подтверждением)';
    compactBtn.style.cssText = btnStyle();
    compactBtn.addEventListener('mouseenter', function () { hoverIn(compactBtn); });
    compactBtn.addEventListener('mouseleave', function () { hoverOut(compactBtn); });
    compactBtn.addEventListener('click', function (e) {
      // stopPropagation, чтобы outside-click handler popup'а (если уже
      // открыт другой) не среагировал на этот же click.
      e.stopPropagation();
      showCompactConfirmPopup(compactBtn, function () {
        triggerSlashCommandViaInput('/compact');
      });
    });

    // Быстрые переключатели модели — короткие текстовые кнопки S/O/H.
    // Клик по кнопке открывает модельный popup через UI и кликает нужный
    // modelItem_ напрямую (без отправки сообщения в чат).
    // Алиасы взяты из models-list.json:
    // `default` → Sonnet, `opus` → Opus 4.7, `haiku` → Haiku 4.5.

    // Ждёт появления элемента в DOM (не более maxWait мс), затем вызывает cb(true/false).
    function waitForElement(selector, maxWait, cb) {
      var waited = 0;
      var interval = 60;
      function check() {
        if (document.querySelector(selector)) { cb(true); return; }
        waited += interval;
        if (waited < maxWait) { setTimeout(check, interval); } else { cb(false); }
      }
      setTimeout(check, interval);
    }

    // Ищет modelItem_ с нужным alias через React-fiber key и кликает его.
    function tryClickModelItemByKey(alias) {
      var items = document.querySelectorAll('[class*="modelItem_"]');
      for (var i = 0; i < items.length; i++) {
        var el = items[i];
        for (var k in el) {
          if (k.indexOf('__reactFiber') === 0) {
            var fiber = el[k];
            if (fiber && fiber.key === alias) { el.click(); return true; }
            break;
          }
        }
      }
      return false;
    }

    // Ищет кнопку, открывающую модельный popup. Пробует:
    //   1. Классовые паттерны `modelSelector_` / `modelTrigger_` / `modelPicker_`
    //   2. Кнопку «Show command menu (/)» → потом «Сменить модель…»
    function findModelSelectorTrigger() {
      var patterns = [
        '[class*="modelSelector_"]',
        '[class*="modelTrigger_"]',
        '[class*="modelPicker_"]',
        '[class*="modelChooser_"]',
      ];
      for (var i = 0; i < patterns.length; i++) {
        var el = document.querySelector(patterns[i]);
        if (el) return el;
      }
      return null;
    }

    // Ищет кнопку команд-меню «Show command menu (/)» по title / aria-label.
    function findCommandMenuButton() {
      return (
        document.querySelector('button[title="Show command menu (/)"]') ||
        document.querySelector('button[aria-label="Show command menu (/)"]') ||
        document.querySelector('button[title*="command menu" i]') ||
        document.querySelector('button[aria-label*="command menu" i]')
      );
    }

    // Ищет commandItem_ в открытом меню по тексту label.
    function findMenuItemByText(text) {
      var items = document.querySelectorAll('[class*="commandItem_"]');
      for (var i = 0; i < items.length; i++) {
        if (items[i].textContent.indexOf(text) !== -1) return items[i];
      }
      return null;
    }

    // === Silent-режим: прячем popup'ы пока идёт автоматический клик ===
    // CSS-правило сидит постоянно, активируется через body[data-claude-silent-switch="1"].
    // visibility:hidden НЕ блокирует программный .click(), только убирает визуальный
    // показ. Так что React-handler модельного пункта срабатывает штатно, но
    // пользователь не видит «всплытие → исчезновение» меню.
    function ensureSilentStyleInjected() {
      if (document.getElementById('claude-silent-switch-style')) return;
      var s = document.createElement('style');
      s.id = 'claude-silent-switch-style';
      s.textContent = [
        'body[data-claude-silent-switch="1"] [class*="menuPopup_"],',
        'body[data-claude-silent-switch="1"] [class*="popupContent_"],',
        'body[data-claude-silent-switch="1"] [class*="popupRoot_"],',
        'body[data-claude-silent-switch="1"] [class*="popup_"],',
        'body[data-claude-silent-switch="1"] [class*="modelItem_"],',
        'body[data-claude-silent-switch="1"] [class*="commandItem_"],',
        'body[data-claude-silent-switch="1"] [class*="sectionHeader_"],',
        'body[data-claude-silent-switch="1"] [role="menu"],',
        'body[data-claude-silent-switch="1"] [role="listbox"]',
        '{ visibility: hidden !important; opacity: 0 !important; }',
      ].join('\n');
      document.head.appendChild(s);
    }
    function beginSilentSwitch() {
      ensureSilentStyleInjected();
      document.body.setAttribute('data-claude-silent-switch', '1');
    }
    function endSilentSwitch() {
      document.body.removeAttribute('data-claude-silent-switch');
    }

    // Главная функция переключения модели.
    // Сначала пробует прямой клик (если popup уже открыт).
    // Иначе — ищет прямую кнопку-триггер или идёт через command-menu.
    // По умолчанию silent=true: popup-контейнеры спрятаны на время операции.
    function switchModel(alias, letter, btn, silent) {
      if (silent !== false) silent = true;

      function finish(success) {
        if (silent) endSilentSwitch();
        btn.textContent = success ? '✓' : '✗';
        setTimeout(function () { btn.textContent = letter; }, 1200);
      }

      if (silent) beginSilentSwitch();

      // Popup уже открыт?
      if (tryClickModelItemByKey(alias)) {
        logInfo('switchModel: direct click on open popup →', alias);
        finish(true);
        return;
      }

      btn.textContent = '⏳';

      // Прямая кнопка-триггер модели?
      var directTrigger = findModelSelectorTrigger();
      if (directTrigger) {
        logInfo('switchModel: clicking direct trigger', directTrigger.className);
        directTrigger.click();
        waitForElement('[class*="modelItem_"]', 1500, function (found) {
          if (!found) {
            logWarn('switchModel: model popup did not appear after trigger');
            finish(false);
            return;
          }
          finish(tryClickModelItemByKey(alias));
        });
        return;
      }

      // Fallback: command menu → «Сменить модель…» → modelItem_
      var menuBtn = findCommandMenuButton();
      if (!menuBtn) {
        logWarn('switchModel: neither modelTrigger nor commandMenuBtn found');
        finish(false);
        return;
      }
      logInfo('switchModel: opening command menu…');
      menuBtn.click();
      waitForElement('[class*="commandItem_"]', 1500, function (menuFound) {
        if (!menuFound) {
          logWarn('switchModel: command menu did not open');
          finish(false);
          return;
        }
        var modelMenuItem = findMenuItemByText('Сменить модель') || findMenuItemByText('model');
        if (!modelMenuItem) {
          logWarn('switchModel: «Сменить модель» item not found');
          // Закрываем меню — Escape (даже под visibility:hidden оно остаётся открытым)
          document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
          finish(false);
          return;
        }
        modelMenuItem.click();
        waitForElement('[class*="modelItem_"]', 1500, function (popupFound) {
          if (!popupFound) {
            logWarn('switchModel: model popup did not open after menu item click');
            finish(false);
            return;
          }
          finish(tryClickModelItemByKey(alias));
        });
      });
    }

    function makeModelBtn(letter, alias, displayName) {
      var b = document.createElement('span');
      b.textContent = letter;
      b.title = 'Переключить на ' + displayName;
      b.style.cssText = btnStyle() +
        'font-weight:bold;font-family:-apple-system,sans-serif;' +
        'min-width:14px;text-align:center;';
      b.addEventListener('mouseenter', function () { hoverIn(b); });
      b.addEventListener('mouseleave', function () { hoverOut(b); });
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        switchModel(alias, letter, b);
      });
      return b;
    }
    var modelSBtn = makeModelBtn('S', 'default', 'Sonnet 4.6');
    var modelOBtn = makeModelBtn('O', 'opus',    'Opus 4.7');
    var modelHBtn = makeModelBtn('H', 'haiku',   'Haiku 4.5');

    iconsBar.appendChild(pingBtn);
    iconsBar.appendChild(saveBtn);
    iconsBar.appendChild(compactBtn);
    iconsBar.appendChild(modelSBtn);
    iconsBar.appendChild(modelOBtn);
    iconsBar.appendChild(modelHBtn);
    iconsBar.appendChild(copyBtn);
    iconsBar.appendChild(collapseBtn);
    overlay.appendChild(iconsBar);

    // Кнопка развернуть (в свёрнутом виде)
    var expandBtn = document.createElement('span');
    expandBtn.textContent = '▼';
    expandBtn.title = 'Развернуть';
    expandBtn.style.cssText = btnStyle() + 'font-size:20px;line-height:1;position:relative;top:-1px;';
    expandBtn.addEventListener('mouseenter', function () { hoverIn(expandBtn); });
    expandBtn.addEventListener('mouseleave', function () { hoverOut(expandBtn); });
    expandBtn.addEventListener('click', function () {
      isMinimized = false;
      // Пока панель была свёрнута, в текстовый блок не писали. Сбрасываем
      // память о последней записи, иначе ближайший тик решит, что писать
      // нечего, и развёрнутая панель покажет содержимое времён
      // сворачивания.
      lastOverlayText = null;
      textDiv.style.display = 'block';
      iconsBar.style.display = 'flex';
      miniBar.style.display = 'none';
      overlay.style.minWidth = '240px';
      overlay.style.maxWidth = '50vw';
      overlay.style.padding = '8px 14px';
      expandBtn.textContent = '▼';
    });

    // Кнопка копирования (в свёрнутом виде)
    var miniCopyBtn = document.createElement('span');
    miniCopyBtn.textContent = '📋';
    miniCopyBtn.title = 'Скопировать содержимое';
    miniCopyBtn.style.cssText = btnStyle();
    miniCopyBtn.addEventListener('mouseenter', function () { hoverIn(miniCopyBtn); });
    miniCopyBtn.addEventListener('mouseleave', function () { hoverOut(miniCopyBtn); });
    miniCopyBtn.addEventListener('click', function () { copyBtn.click(); });

    // Кнопка пинга (в свёрнутом виде)
    var miniPingBtn = document.createElement('span');
    miniPingBtn.textContent = '📡';
    miniPingBtn.title = 'Проверить интернет';
    miniPingBtn.style.cssText = btnStyle();
    miniPingBtn.addEventListener('mouseenter', function () { hoverIn(miniPingBtn); });
    miniPingBtn.addEventListener('mouseleave', function () { hoverOut(miniPingBtn); });
    miniPingBtn.addEventListener('click', function () { pingBtn.click(); });

    var miniSaveBtn = document.createElement('span');
    miniSaveBtn.textContent = '💾';
    miniSaveBtn.title = 'Сохранить лог';
    miniSaveBtn.style.cssText = btnStyle();
    miniSaveBtn.addEventListener('mouseenter', function () { hoverIn(miniSaveBtn); });
    miniSaveBtn.addEventListener('mouseleave', function () { hoverOut(miniSaveBtn); });
    miniSaveBtn.addEventListener('click', function () { saveBtn.click(); });

    miniBar.appendChild(miniPingBtn);
    miniBar.appendChild(miniSaveBtn);
    miniBar.appendChild(miniCopyBtn);
    miniBar.appendChild(expandBtn);
    overlay.appendChild(miniBar);

    if (document.body) {
      document.body.appendChild(overlay);
    } else {
      document.addEventListener('DOMContentLoaded', function () {
        document.body.appendChild(overlay);
      });
    }
    return overlay;
  }

  function fmtAgo(tsMs) {
    if (tsMs == null) return '—';
    var s = Math.round((Date.now() - tsMs) / 1000);
    return s + 's ago';
  }

  /**
   * Находит React root container (#root) и возвращает корневой fiber.
   * React 18+ хранит контейнер как свойство DOM-узла с ключом
   * вида `__reactContainer$<hash>` (новый рендерер) или
   * `_reactRootContainer` (legacy).
   */
  function findReactRootFiber() {
    var rootEl = document.getElementById('root');
    if (!rootEl) return null;
    var keys = Object.keys(rootEl);
    for (var i = 0; i < keys.length; i++) {
      if (keys[i].indexOf('__reactContainer$') === 0) {
        var container = rootEl[keys[i]];
        // .stateNode у container'а — FiberRootNode; .current — корневой фибер
        if (container && container.stateNode && container.stateNode.current) {
          return container.stateNode.current;
        }
        if (container && container.current) return container.current;
        return container;
      }
    }
    if (rootEl._reactRootContainer && rootEl._reactRootContainer._internalRoot) {
      return rootEl._reactRootContainer._internalRoot.current;
    }
    return null;
  }

  /**
   * Обходит fiber-дерево DFS и для каждого фибера передаёт visit(fiber).
   * Прерывается, если visit вернул `true`. Защита от циклов.
   */
  function walkFibers(rootFiber, visit) {
    if (!rootFiber) return;
    var stack = [rootFiber];
    var visited = new Set();
    while (stack.length) {
      var fiber = stack.pop();
      if (!fiber || visited.has(fiber)) continue;
      visited.add(fiber);
      if (visit(fiber) === true) return;
      if (fiber.child) stack.push(fiber.child);
      if (fiber.sibling) stack.push(fiber.sibling);
    }
  }

  /**
   * Проверяет, является ли объект экземпляром сессии (eX).
   * Признак: есть `busy` (с .value boolean), `connection`, `messages`,
   * `error` — основные Signals сессии.
   */
  function isSessionInstance(obj) {
    if (!obj || typeof obj !== 'object') return false;
    if (!('busy' in obj) || !('connection' in obj) || !('messages' in obj)) return false;
    var busy = obj.busy;
    if (!busy || typeof busy !== 'object' || !('value' in busy)) return false;
    return typeof busy.value === 'boolean';
  }

  /**
   * Ищет экземпляр сессии (eX) в fiber-дереве.
   * Стратегия:
   * 1. Проверяем props.context.viewSession — может быть session напрямую
   * 2. Ищем любой fiber, у которого props/state/stateNode содержит
   *    объект с busy+connection+messages Signals.
   */
  /**
   * Проверяет, является ли объект Wn sessionStore. Признак: есть
   * `activeSession` (Signal с .value) и `sessions` (Signal-массив).
   */
  function isSessionStore(obj) {
    if (!obj || typeof obj !== 'object') return false;
    if (!('activeSession' in obj) || !('sessions' in obj)) return false;
    var as = obj.activeSession;
    return as && typeof as === 'object' && 'value' in as;
  }

  function findSessionStore() {
    var rootFiber = findReactRootFiber();
    if (!rootFiber) return null;
    var found = null;
    walkFibers(rootFiber, function (fiber) {
      var sources = [fiber.memoizedProps, fiber.memoizedState, fiber.stateNode];
      for (var i = 0; i < sources.length; i++) {
        var c = sources[i];
        if (!c || typeof c !== 'object') continue;

        // Проверим props.sessions — может быть Wn store
        if ('sessions' in c) {
          var sessStore = c.sessions;
          if (isSessionStore(sessStore)) {
            var eX = sessStore.activeSession.value;
            if (isSessionInstance(eX)) { found = eX; return true; }
          }
        }

        // Проверим context.viewSession
        if ('context' in c && c.context && typeof c.context === 'object') {
          var vs = c.context.viewSession;
          if (isSessionInstance(vs)) { found = vs; return true; }
          if (vs && typeof vs === 'object' && 'value' in vs && isSessionInstance(vs.value)) {
            found = vs.value; return true;
          }
        }

        // Проверим session prop напрямую
        if ('session' in c && isSessionInstance(c.session)) {
          found = c.session; return true;
        }

        // Проверим сам объект
        if (isSessionInstance(c)) { found = c; return true; }
      }
    });
    return found;
  }

  function ensureSessionStore() {
    if (sessionStore) return sessionStore;
    var now = Date.now();
    if (now - lastSessionFindAttempt < 2000) return null; // throttle поиска
    lastSessionFindAttempt = now;
    sessionFindDiag = '';
    try {
      // Шаг 1: есть ли #root?
      var rootEl = document.getElementById('root');
      if (!rootEl) {
        sessionFindDiag = '#root not found';
        return null;
      }
      // Шаг 2: есть ли fiber-ключ?
      var keys = Object.keys(rootEl);
      var fiberKey = '';
      for (var i = 0; i < keys.length; i++) {
        if (keys[i].indexOf('__react') === 0 || keys[i].indexOf('_react') === 0) {
          fiberKey = keys[i];
          break;
        }
      }
      if (!fiberKey) {
        sessionFindDiag = '#root keys: ' + keys.filter(function(k){ return k.indexOf('_') === 0; }).join(', ');
        return null;
      }
      sessionFindDiag = 'key: ' + fiberKey.slice(0, 25);
      // Шаг 3: traversal
      sessionStore = findSessionStore();
      if (sessionStore) {
        sessionStoreFoundAt = now;
        sessionFindDiag += ' → FOUND';
      } else {
        // Подсчитаем сколько фиберов обошли и какие candidateProps видели
        var fiberCount = 0;
        var propsWithSession = 0;
        var firstCandidateKeys = '';
        var firstCandidateLocation = '';
        var rootFiber = findReactRootFiber();
        walkFibers(rootFiber, function(fiber) {
          fiberCount++;
          // Проверяем props, state, stateNode
          var sources = [
            ['props', fiber.memoizedProps],
            ['state', fiber.memoizedState],
            ['stateNode', fiber.stateNode],
          ];
          for (var s = 0; s < sources.length; s++) {
            var c = sources[s][1];
            if (c && typeof c === 'object' && ('session' in c || 'activeSession' in c || 'sessions' in c)) {
              propsWithSession++;
              if (!firstCandidateKeys) {
                firstCandidateLocation = sources[s][0];
                try {
                  var ks = Object.keys(c).slice(0, 15).join(',');
                  firstCandidateKeys = ks;
                  // Проверим activeSession
                  if ('activeSession' in c) {
                    var as = c.activeSession;
                    firstCandidateKeys += '\n  AS type=' + typeof as;
                    if (as && typeof as === 'object') {
                      firstCandidateKeys += ' keys=' + Object.keys(as).slice(0, 8).join(',');
                    }
                  }
                  // Если есть context — проверим его ключи (может быть Wn)
                  if ('context' in c && c.context && typeof c.context === 'object') {
                    var ctxKeys = Object.keys(c.context).slice(0, 15).join(',');
                    firstCandidateKeys += '\n  ctx: ' + ctxKeys;
                    // Если context — это Wn (имеет activeSession)?
                    if ('activeSession' in c.context) {
                      var as2 = c.context.activeSession;
                      firstCandidateKeys += '\n  ctx.AS type=' + typeof as2;
                      if (as2 && typeof as2 === 'object') {
                        firstCandidateKeys += ' keys=' + Object.keys(as2).slice(0, 8).join(',');
                      }
                    }
                  }
                  // Если sessions — проверим тип
                  if ('sessions' in c) {
                    var sess = c.sessions;
                    firstCandidateKeys += '\n  sessions type=' + typeof sess;
                    if (sess && typeof sess === 'object' && 'value' in sess) {
                      firstCandidateKeys += ' (signal, len=' + (Array.isArray(sess.value) ? sess.value.length : '?') + ')';
                    } else if (Array.isArray(sess)) {
                      firstCandidateKeys += ' (array, len=' + sess.length + ')';
                    }
                  }
                  // viewSession — ключевой кандидат
                  if ('context' in c && c.context && typeof c.context === 'object' && 'viewSession' in c.context) {
                    var vs = c.context.viewSession;
                    firstCandidateKeys += '\n  viewSession type=' + typeof vs;
                    if (vs && typeof vs === 'object') {
                      firstCandidateKeys += ' keys=' + Object.keys(vs).slice(0, 10).join(',');
                      if ('value' in vs) {
                        var vsv = vs.value;
                        firstCandidateKeys += '\n  viewSession.value type=' + typeof vsv;
                        if (vsv && typeof vsv === 'object') {
                          firstCandidateKeys += ' keys=' + Object.keys(vsv).slice(0, 10).join(',');
                        }
                      }
                      if ('busy' in vs) firstCandidateKeys += '\n  viewSession HAS busy!';
                    }
                  }
                } catch (e) { firstCandidateKeys = 'error: ' + e; }
              }
            }
          }
        });
        sessionFindDiag += ' → fibers:' + fiberCount + ' hits:' + propsWithSession;
        if (firstCandidateKeys) {
          sessionFindDiag += '\n  1st@' + firstCandidateLocation + ': ' + firstCandidateKeys;
        }
      }
    } catch (e) {
      sessionFindDiag = 'error: ' + (e && e.message ? e.message : e);
      logWarn('findSessionStore failed:', e);
    }
    return sessionStore;
  }

  // Последнее записанное в оверлей — чтобы не переписывать DOM тем же
  // самым (см. хвост updateDebugOverlay). null, а не '': пустая строка
  // тоже бывает значением, и её первая запись должна состояться.
  var lastOverlayText = null;
  var lastOverlayIcon = null;
  var lastOverlayTitle = null;

  function updateDebugOverlay() {
    var overlay = ensureDebugOverlay();
    updateDebugBuffer();
    var now = Date.now();

    // Текущее состояние фокуса (опрос — fallback, если событие focus не
    // приходит). Если значение поменялось — запишем как «событие».
    var currentFocus = document.hasFocus();
    if (currentFocus !== lastFocusState) {
      lastFocusState = currentFocus;
      lastFocusChangeAt = now;
      focusChangeCount++;
    }

    var lines = [];

    // Строка состояния соединения — в самом верху overlay
    var sess = ensureSessionStore();
    var connState = '?';
    busyState = false;
    var streamingState = false;
    var sendStarted = null;
    var errState = null;
    if (sess) {
      try {
        var conn = sess.connection && sess.connection.value;
        if (conn && conn.state && 'value' in conn.state) connState = conn.state.value;
        else if (conn && conn.state && typeof conn.state === 'string') connState = conn.state;
        busyState = !!(sess.busy && sess.busy.value);
        streamingState = !!sess.hasStreamingMessages;
        sendStarted = sess.sendStartedAt;
        errState = sess.error && sess.error.value;
      } catch (_) {}
    }

    var online = typeof navigator !== 'undefined' ? navigator.onLine : true;
    var domSilenceSec = Math.round((Date.now() - lastDomMutationAt) / 1000);

    // Отслеживание контента assistant-message (спиннер не влияет)
    var assistantMsgs = document.querySelectorAll('[data-testid="assistant-message"]');
    var lastMsg = assistantMsgs.length > 0 ? assistantMsgs[assistantMsgs.length - 1] : null;
    var currentContentLen = lastMsg ? lastMsg.textContent.length : 0;
    if (currentContentLen !== lastContentLen) {
      lastContentLen = currentContentLen;
      lastContentChangeAt = Date.now();
    }
    contentSilenceSec = Math.round((Date.now() - lastContentChangeAt) / 1000);

    // Timeout-детекция: busy=true и не стримит уже > N секунд →
    // возможная проблема с соединением до API.
    // Используем собственный _busyStartedAt, потому что sess.sendStartedAt
    // сбрасывается при получении system/init (одновременно с busy=true).
    busyNoStreamSec = 0;
    if (busyState && prevTrackedStates._busyStartedAt) {
      busyNoStreamSec = Math.round((Date.now() - prevTrackedStates._busyStartedAt) / 1000);
    }

    // Собственный трекинг стриминга — hasStreamingMessages в eX не
    // сбрасывается, поэтому отслеживаем по росту кол-ва messages.
    var nMsgsNow = 0;
    try {
      var m = sess && sess.messages && sess.messages.value;
      nMsgsNow = m ? m.length : 0;
    } catch (_) {}

    if (busyState && !prevTrackedStates._wasBusy) {
      // busy только что стал true → запоминаем кол-во messages и время
      prevTrackedStates._msgCountAtBusyStart = nMsgsNow;
      prevTrackedStates._busyStartedAt = Date.now();
      autoPingCount = 0;
      inlinePingClicked = false; // сброс для нового processing
      lastContentChangeAt = Date.now(); // сброс таймера контента
      lastContentLen = 0;
      onDemandPing();
      autoPingCount++;
    }
    if (!busyState && prevTrackedStates._wasBusy) {
      // busy завершился → чистим таймер
      prevTrackedStates._busyStartedAt = null;
    }
    prevTrackedStates._wasBusy = busyState;

    actuallyStreaming = busyState &&
      nMsgsNow > (prevTrackedStates._msgCountAtBusyStart || 0);

    var statusIcon = '⚪';
    var statusText = 'unknown';
    if (!sess) {
      statusIcon = '⚫'; statusText = 'session not found';
    } else if (errState) {
      statusIcon = '🔴'; statusText = 'error: ' + String(errState).slice(0, 25);
    } else if (!online) {
      statusIcon = '🔴'; statusText = 'OFFLINE (navigator.onLine=false)';
    } else if (connState !== 'connected') {
      statusIcon = '🔴'; statusText = connState;
    // Старый busyNoStreamSec-блок убран — заменён на domSilenceSec выше
    } else if (busyState && contentSilenceSec > AUTO_PING_AFTER_SILENCE_SEC) {
      // busy, но контент assistant-message не менялся > N секунд
      // Авто-пинг для диагностики
      var underLimit = MAX_PINGS === 0 || autoPingCount < MAX_PINGS;
      if (PING_INTERVAL_SEC > 0 && underLimit && onDemandPingState !== 'checking') {
        var sincePing = onDemandPingTs > 0 ? (Date.now() - onDemandPingTs) / 1000 : Infinity;
        if (sincePing >= PING_INTERVAL_SEC) {
          onDemandPing();
          autoPingCount++;
        }
      }
      if (onDemandPingState === 'offline') {
        statusIcon = '🔴'; statusText = 'no data ' + domSilenceSec + 's — INTERNET DOWN';
      } else if (onDemandPingState === 'online') {
        statusIcon = '🔵'; statusText = 'no data ' + domSilenceSec + 's — internet OK';
      } else if (onDemandPingState === 'checking') {
        statusIcon = '🟠'; statusText = 'no data ' + domSilenceSec + 's — checking…';
      } else {
        statusIcon = '🟣'; statusText = 'no data ' + domSilenceSec + 's';
      }
    } else if (busyState && actuallyStreaming) {
      statusIcon = '🟢'; statusText = 'streaming response…';
    } else if (busyState) {
      statusIcon = '🟡'; statusText = 'server processing…';
    } else {
      statusIcon = '⚪'; statusText = 'idle / connected';
    }
    lines.push(statusIcon + ' ' + statusText + (online ? '' : ' [OFFLINE]'));

    // Трекинг изменений ключевых состояний.
    // Из status убираем: секундный счётчик (processing Ns) и
    // ping-подстатусы (checking/INTERNET DOWN/server slow) —
    // они уже логируются через trackStateChange('ping').
    var statusForLog = statusText
      .replace(/\d+s/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    trackStateChange('status', statusForLog);
    trackStateChange('busy', busyState);
    trackStateChange('streaming', streamingState);
    trackStateChange('conn', connState);
    trackStateChange('online', online);
    // noData: логируем только переход receiving ↔ silent (без посекундного спама)
    var noDataState = (busyState && contentSilenceSec > AUTO_PING_AFTER_SILENCE_SEC) ? 'silent' : 'receiving';
    if (busyState) trackStateChange('noData', noDataState);
    // Логируем результат пинга напрямую (без trackStateChange, чтобы
    // не дублировать old→new при каждом изменении времени).
    if (onDemandPingState === 'online' || onDemandPingState === 'offline' || onDemandPingState === 'csp_blocked') {
      var pingIcon = onDemandPingState === 'online' ? '✅' : onDemandPingState === 'offline' ? '❌' : '⚠️';
      var pingVal = pingIcon + (onDemandPingState === 'online' && onDemandPingMs > 0 ? onDemandPingMs + 'ms' : onDemandPingState);
      // Записываем только если это новый результат (не тот же что уже последний в логе)
      var lastLog = stateLog.length > 0 ? stateLog[stateLog.length - 1] : '';
      if (lastLog.indexOf('ping: ' + pingVal) === -1) {
        var ts = new Date().toLocaleTimeString('ru-RU', {hour12: false});
        stateLog.push(ts + ' ping: ' + pingVal);
          }
    }

    if (overlayMode === 'visibility') {
      var remainingV = Math.max(0, visibilityResumeAt - now);
      lines.push('Refresh через ' + (remainingV / 1000).toFixed(1) + 's (resume)');
      if (remainingV <= 0) overlayMode = 'poll';
    } else {
      var elapsed = now - lastPollAt;
      var remainingP = Math.max(0, POLL_MS - elapsed);
      lines.push('Refresh через ' + (remainingP / 1000).toFixed(1) + 's');
    }

    lines.push('—— diag ——');
    lines.push('visState: ' + document.visibilityState);
    lines.push('hasFocus: ' + currentFocus);
    lines.push('init: ' + fmtAgo(initTimeMs));
    lines.push('visChanges: ' + visibilityChangeCount + (lastVisibilityChangeAt ? ' (last ' + fmtAgo(lastVisibilityChangeAt) + ' → ' + lastVisibilityChangeNewState + ')' : ''));
    lines.push('focusChanges: ' + focusChangeCount + (lastFocusChangeAt ? ' (last ' + fmtAgo(lastFocusChangeAt) + ' → ' + (lastFocusState ? 'focus' : 'blur') + ')' : ''));
    lines.push('—— refresh ——');
    lines.push('calls: ' + refreshCalls);
    lines.push('skip (notFocused): ' + refreshSkippedNotFocused);
    lines.push('skip (throttle): ' + refreshSkippedThrottled);
    lines.push('executed: ' + refreshExecuted);

    lines.push('—— session ——');
    // sess уже получен выше (в блоке status line)
    if (!sess) {
      lines.push('session: NOT FOUND');
      if (sessionFindDiag) lines.push('diag: ' + sessionFindDiag);
    } else {
      try {
        var sessId = (sess.sessionId && sess.sessionId.value) || sess.internalId || '?';
        var nMsgs = sess.messages && sess.messages.value;
        lines.push('id: ' + String(sessId).slice(0, 12) + '…');
        lines.push('busy:' + busyState + ' stream:' + actuallyStreaming + ' conn:' + connState);
        if (busyState && contentSilenceSec > 1) {
          lines.push('⚠️ no data: ' + contentSilenceSec + 's');
        }
        if (onDemandPingState !== 'idle') {
          var odAge = onDemandPingTs > 0 ? Math.round((Date.now() - onDemandPingTs) / 1000) + 's ago' : '';
          var odMs = onDemandPingState === 'online' && onDemandPingMs > 0 ? ' ' + onDemandPingMs + 'ms' : '';
          lines.push('📡 ping: ' + onDemandPingState + odMs + (odAge ? ' (' + odAge + ')' : ''));
        }
        lines.push('msgs: ' + (nMsgs ? nMsgs.length : '?'));
        if (sendStarted != null) {
          lines.push('sendStartedAt: ' + Math.round(performance.now() - sendStarted) + 'ms ago');
        }
      } catch (e) {
        lines.push('read error: ' + (e && e.message ? e.message : e));
      }
    }

    // Лог переходов — показываем последние MAX_STATE_LOG_DISPLAY
    if (stateLog.length > 0) {
      var logStart = Math.max(0, stateLog.length - MAX_STATE_LOG_DISPLAY);
      lines.push('—— state log (' + stateLog.length + ' total) ——');
      for (var l = logStart; l < stateLog.length; l++) {
        lines.push(stateLog[l]);
      }
    }

    /* Запись в DOM — единственное, что этот оверлей отдаёт наружу,
     * и одновременно единственное, чем он вредит.
     *
     * Тик идёт каждые 500 мс, а присваивание textContent — мутация
     * дерева независимо от того, изменился текст или нет. Раньше их
     * было ровно десять в секунду, и каждая будила все наши
     * MutationObserver'ы (базовый плюс по одному на модуль футера),
     * а те обходят документ целиком. При большой переписке это
     * постоянная фоновая работа, которой никто не заказывал:
     * в свёрнутом виде полотно вообще никому не видно.
     *
     * Отсюда два правила. Скрытому текстовому блоку не пишем вовсе —
     * его содержимое всё равно перечитается при разворачивании
     * ближайшим тиком. И ничего не пишем, если строка не изменилась:
     * значок статуса и подсказка меняются раз в секунды, а не десять
     * раз в секунду.
     *
     * Вычисления выше остаются нетронутыми: из них берутся busyState
     * и contentSilenceSec для авто-пинга и значка 📡, и пропуск
     * расчёта сломал бы их вместе с оверлеем. */
    var textEl = document.getElementById('claude-custom-debug-text');
    if (textEl && textEl.style.display !== 'none') {
      var text = lines.join('\n');
      if (text !== lastOverlayText) {
        lastOverlayText = text;
        textEl.textContent = text;
        perfBump('overlay-writes');
      }
    }

    // Обновляем миниатюрный статус-индикатор (видён в свёрнутом виде).
    var ms = document.getElementById('claude-custom-debug-mini-status');
    if (ms && statusIcon !== lastOverlayIcon) {
      lastOverlayIcon = statusIcon;
      ms.textContent = statusIcon;
      perfBump('overlay-writes');
    }
    var ov = document.getElementById('claude-custom-debug');
    var titleText = statusIcon + ' ' + statusText;
    if (ov && titleText !== lastOverlayTitle) {
      lastOverlayTitle = titleText;
      ov.title = titleText;
      perfBump('overlay-writes');
    }
  }

  /**
   * Показывает 📡 рядом со спиннером, когда DOM не получает новых
   * данных дольше autoPingAfterSilenceSec. Исчезает при появлении данных.
   */
  var pingIndicatorEl = null;

  function updateInlinePingIndicator() {
    var shouldShow = busyState && contentSilenceSec > AUTO_PING_AFTER_SILENCE_SEC;

    if (!shouldShow) {
      // Убираем индикатор
      if (pingIndicatorEl && pingIndicatorEl.parentNode) {
        pingIndicatorEl.parentNode.removeChild(pingIndicatorEl);
      }
      pingIndicatorEl = null;
      return;
    }

    // Ищем spinner row
    var spinnerRows = document.querySelectorAll('[class*="spinnerRow_"]');
    if (spinnerRows.length === 0) return;
    var spinnerRow = spinnerRows[spinnerRows.length - 1]; // последний

    // Ищем container внутри spinnerRow
    var container = spinnerRow.querySelector('[class*="container_"]');
    if (!container) container = spinnerRow;

    // Создаём или обновляем индикатор (inline, в той же строке)
    if (!pingIndicatorEl) {
      pingIndicatorEl = document.createElement('span');
      pingIndicatorEl.id = 'claude-ping-indicator';
      pingIndicatorEl.style.cssText =
        'margin-left:8px;font-size:12px;opacity:0.7;cursor:pointer;' +
        'font-family:monospace;pointer-events:auto;user-select:none;';
      pingIndicatorEl.title = 'Проверить интернет';
      pingIndicatorEl.addEventListener('click', function () {
        inlinePingClicked = true;
        onDemandPing();
      });
    }

    // До клика — только 📡, после клика — 📡 + результат
    if (!inlinePingClicked) {
      pingIndicatorEl.textContent = '📡';
    } else {
      var icon = onDemandPingState === 'online' ? '✅'
        : onDemandPingState === 'offline' ? '❌'
        : onDemandPingState === 'checking' ? '⏳'
        : '📡';
      var detail = '';
      if (onDemandPingState === 'online' && onDemandPingMs > 0) detail = ' ' + onDemandPingMs + 'ms';
      else if (onDemandPingState === 'offline') detail = ' offline';
      else if (onDemandPingState === 'checking') detail = ' checking…';
      pingIndicatorEl.textContent = '📡 ' + icon + detail;
    }

    // Вставляем внутрь container (после text-span), если ещё не вставлен
    if (!pingIndicatorEl.parentNode) {
      container.appendChild(pingIndicatorEl);
    }
  }

  /**
   * Пробегает по выпадашке меню `/` ([class*="menuPopup_"]) и возвращает
   * массив пунктов {section, label, title} в порядке появления в DOM.
   * Возвращает [] если меню не открыто или пустое (например, фильтр
   * ничего не нашёл).
   *
   * Структура DOM (на момент Claude Code 2.1.126):
   *   <div class="menuPopup_G_S7FQ">
   *     <input class="filterInput_..." placeholder="Фильтр действий…">
   *     <div class="commandList_G_S7FQ">
   *       <div>
   *         <div class="sectionHeader_G_S7FQ">Контекст</div>
   *         <div class="commandItem_G_S7FQ" title="DESCRIPTION">
   *           <div class="commandContent_..."><span class="commandLabel_...">LABEL</span></div>
   *         </div>
   *         ...
   *       </div>
   *       <div> ... следующая секция ... </div>
   *     </div>
   *   </div>
   *
   * Сопоставление section ↔ commandItem делается через порядок обхода
   * querySelectorAll: querySelectorAll возвращает узлы в depth-first
   * порядке, поэтому sectionHeader всегда встречается перед своими
   * commandItem-сёстрами и устанавливает текущую секцию.
   */
  function collectMenuItems() {
    var menus = document.querySelectorAll('[class*="menuPopup_"]');
    if (!menus.length) return [];
    var items = [];
    for (var i = 0; i < menus.length; i++) {
      var menu = menus[i];
      // Помимо `/`-меню (commandItem_) этот же контейнер используется
      // селектором модели (modelItem_ + modelLabel_ + modelDescription_).
      // Структуры разные: у command-меню title лежит в атрибуте title,
      // у model-меню «описание» — это отдельный span class*="modelDescription_".
      var nodes = menu.querySelectorAll(
        '[class*="sectionHeader_"], [class*="commandItem_"], [class*="modelItem_"]'
      );
      var section = null;
      for (var j = 0; j < nodes.length; j++) {
        var el = nodes[j];
        var cls = el.className || '';
        if (cls.indexOf('sectionHeader_') !== -1) {
          section = (el.textContent || '').trim() || null;
        } else if (cls.indexOf('commandItem_') !== -1) {
          var labelEl = el.querySelector('[class*="commandLabel_"]');
          // textContent может включать "(Max)"-suffix; берём только верхний
          // текст самого commandLabel, без вложенных span'ов с маркерами
          var label = '';
          if (labelEl) {
            // Собираем только прямые текстовые дочерние узлы
            for (var k = 0; k < labelEl.childNodes.length; k++) {
              var c = labelEl.childNodes[k];
              if (c.nodeType === Node.TEXT_NODE) label += c.textContent;
            }
            label = (label || labelEl.textContent || '').trim();
          }
          var title = el.getAttribute('title') || '';
          items.push({ section: section, label: label, title: title.trim() });
        } else if (cls.indexOf('modelItem_') !== -1) {
          var mLabelEl = el.querySelector('[class*="modelLabel_"]');
          var mDescEl = el.querySelector('[class*="modelDescription_"]');
          var mLabel = mLabelEl ? (mLabelEl.textContent || '').trim() : '';
          var mDesc = mDescEl ? (mDescEl.textContent || '').trim() : '';
          items.push({ section: section, label: mLabel, title: mDesc });
        }
      }
    }
    return items;
  }

  /**
   * Собирает ВСЕ тексты вокруг открытого меню `/`: текстовые узлы +
   * содержимое атрибутов title/aria-label/placeholder. Захватывает не
   * только сам menuPopup_, но и родительский inputFooter_ — там лежат
   * кнопки +, /, иконка автосжатия и попап «X% of context remaining».
   *
   * Возвращает плоский массив уникальных строк. Дальше анализатор в
   * localize.py фильтрует «английские без перевода» по эвристике
   * (см. _looks_english + ru_values).
   */
  // Селектор для всех popup-подобных элементов: выпадашки меню /,
  // меню кнопки + (Add), меню «Режимы» (permission selector),
  // popover'ы автосжатия, hover-tooltip'ы и т.д. Используется и в
  // collectMenuTexts (что собирать), и в isMenuRelatedMutation (на
  // что реагировать). [class*="enuPopup_"] / [class*="opup_"] —
  // частичные совпадения, чтобы покрыть menuPopup_/Popup_/popup_
  // независимо от регистра первой буквы и префикса.
  var POPUP_LIKE_SELECTOR = (
    '[class*="enuPopup_"],' +
    '[class*="opup_"],' +
    '[class*="opover_"],' +
    '[class*="ropdown_"],' +
    '[role="menu"],' +
    '[role="listbox"]'
  );

  function collectMenuTexts() {
    var roots = [];
    // 1) Если открыто меню / (menuPopup_), берём родителя ВЕРХНЕГО уровня,
    //    который содержит и menuPopup_, и его inputFooter_-сосед. Footer
    //    нужен чтобы захватить кнопки +, /, usage и hover-popup'ы рядом.
    var slashMenus = document.querySelectorAll('[class*="menuPopup_"]');
    for (var i = 0; i < slashMenus.length; i++) {
      var menu = slashMenus[i];
      var p = menu.parentElement;
      var inputFooter = null;
      while (p && p !== document.body) {
        var inFooter = p.querySelector('[class*="inputFooter_"]');
        if (inFooter) { inputFooter = inFooter; break; }
        p = p.parentElement;
      }
      roots.push(inputFooter && inputFooter.parentElement
        ? inputFooter.parentElement
        : menu);
    }
    // 2) Все остальные popup-like узлы (Add-меню, Режимы, popover'ы…),
    //    которые рендерятся в body отдельно от menuPopup_/footer.
    var others = document.querySelectorAll(POPUP_LIKE_SELECTOR);
    for (var ep = 0; ep < others.length; ep++) {
      var node = others[ep];
      var alreadyIn = false;
      for (var r = 0; r < roots.length; r++) {
        if (roots[r] === node || roots[r].contains(node)) { alreadyIn = true; break; }
      }
      if (!alreadyIn) roots.push(node);
    }
    if (!roots.length) return [];

    var seen = Object.create(null);
    var out = [];
    function add(text) {
      if (!text) return;
      var t = String(text).replace(/\s+/g, ' ').trim();
      if (!t) return;
      // descriptions некоторых slash-команд (/update-config, /claude-api)
      // и блоки tooltip'ов могут быть длиной ~1500–2500 символов — лимит
      // 5000 даёт запас, чтобы строки не обрезались и корректно
      // дедуплицировались с command_drift.title в localize.py.
      if (t.length > 5000) t = t.slice(0, 5000);
      if (seen[t]) return;
      seen[t] = true;
      out.push(t);
    }

    for (var ri = 0; ri < roots.length; ri++) {
      var root = roots[ri];
      // Все text-nodes
      var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false);
      var node;
      while ((node = walker.nextNode())) add(node.nodeValue);
      // Атрибуты title/aria-label/aria-description/placeholder
      var withAttrs = root.querySelectorAll('[title], [aria-label], [aria-description], [placeholder]');
      var attrs = ['title', 'aria-label', 'aria-description', 'placeholder'];
      for (var a = 0; a < withAttrs.length; a++) {
        for (var ai = 0; ai < attrs.length; ai++) {
          var v = withAttrs[a].getAttribute(attrs[ai]);
          if (v) add(v);
        }
      }
      // Корневой элемент тоже может иметь атрибуты
      for (var ai2 = 0; ai2 < attrs.length; ai2++) {
        if (root.getAttribute) {
          var rv = root.getAttribute(attrs[ai2]);
          if (rv) add(rv);
        }
      }
    }
    return out;
  }

  function sendDriftReport(items) {
    if (driftSendInFlight) return;
    driftSendInFlight = true;
    var texts = collectMenuTexts();
    fetch(LOCALE_DRIFT_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: items, texts: texts }),
    })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        driftSendInFlight = false;
        logInfo('locale-drift sent',
          items.length, 'items,', texts.length, 'texts →', d.path || d);
      })
      .catch(function (e) {
        driftSendInFlight = false;
        logWarn('locale-drift failed:', e && e.message ? e.message : e);
      });
  }

  /**
   * Собирает список моделей из popup'а селектора моделей.
   *
   * value (ID типа `claude-opus-4-7`) в DOM-тексте отсутствует — React
   * хранит его как `key` у элемента `<div key={V.value}>`. Достаём из
   * React-fiber: на каждом DOM-узле есть свойство `__reactFiber$xxx`
   * (имя суффикса — рандомный токен React), у fiber'а есть `.key`.
   *
   * Если popup не открыт — возвращает null. Дедуп — в maybeSaveModels.
   */
  function collectModelsList() {
    var items = document.querySelectorAll('[class*="modelItem_"]');
    if (!items.length) return null;
    var models = [];
    for (var i = 0; i < items.length; i++) {
      var el = items[i];
      var labelEl = el.querySelector('[class*="modelLabel_"]');
      var descEl = el.querySelector('[class*="modelDescription_"]');
      var displayName = labelEl ? (labelEl.textContent || '').trim() : '';
      var description = descEl ? (descEl.textContent || '').trim() : '';
      var cls = typeof el.className === 'string' ? el.className : '';
      var isActive = cls.indexOf('activeModelItem_') !== -1;

      var value = null;
      for (var k in el) {
        if (k.indexOf('__reactFiber') === 0) {
          var fiber = el[k];
          if (fiber && fiber.key) { value = fiber.key; }
          break;
        }
      }

      models.push({
        value: value,
        displayName: displayName,
        description: description,
        isActive: isActive,
      });
    }
    return models;
  }

  function sendModelsList(models) {
    if (modelsSendInFlight) return;
    modelsSendInFlight = true;
    fetch(MODELS_LIST_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ models: models }),
    })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        modelsSendInFlight = false;
        logInfo('models-list sent', models.length, 'models →', d.path || d);
      })
      .catch(function (e) {
        modelsSendInFlight = false;
        logWarn('models-list failed:', e && e.message ? e.message : e);
      });
  }

  /**
   * Debounced trigger для каталога моделей. Симметрично maybeCollectAndSend,
   * но смотрит только на modelItem_-popup и шлёт на /models-list.
   */
  function maybeSaveModels() {
    if (modelsListTimer) clearTimeout(modelsListTimer);
    modelsListTimer = setTimeout(function () {
      modelsListTimer = null;
      var models = collectModelsList();
      if (!models || !models.length) return; // popup моделей не открыт
      var hash = JSON.stringify(models);
      if (hash === lastModelsHash) return;
      lastModelsHash = hash;
      sendModelsList(models);
    }, MODELS_LIST_DEBOUNCE_MS);
  }

  /**
   * Debounced trigger: вызывается при любой DOM-мутации, ждёт
   * LOCALE_DRIFT_DEBOUNCE_MS тишины, затем собирает и шлёт snapshot.
   * Дедуп через lastDriftHash — повторные одинаковые наборы не уходят.
   */
  function maybeCollectAndSend() {
    if (!cfg.locale || cfg.locale === 'en') return;
    if (localeDriftTimer) clearTimeout(localeDriftTimer);
    localeDriftTimer = setTimeout(function () {
      localeDriftTimer = null;
      var items = collectMenuItems();
      if (!items.length) return; // меню не открыто — нечего слать
      var hash = JSON.stringify(items);
      if (hash === lastDriftHash) return; // не изменилось — пропустить
      lastDriftHash = hash;
      sendDriftReport(items);
    }, LOCALE_DRIFT_DEBOUNCE_MS);
  }

  /**
   * Фильтр мутаций — относится ли хоть одна к меню `/`?
   *
   * Старая логика дёргала maybeCollectAndSend на КАЖДУЮ мутацию body.
   * При включённом debug-overlay (setInterval каждые 500мс
   * обновляет содержимое #claude-custom-debug) общий MutationObserver
   * получал постоянный поток событий, и debounce-таймер 500мс
   * сбрасывался быстрее, чем успевал сработать. В результате snapshot
   * меню никогда не отправлялся, даже если меню было открыто 10 секунд.
   *
   * Теперь maybeCollectAndSend вызывается только когда мутация
   * фактически относится к меню — добавлен/изменён узел `menuPopup_`,
   * `commandItem_`, `sectionHeader_`, `filterInput_`, либо мутация
   * произошла внутри уже открытого `menuPopup_` (фильтрация по поиску).
   */
  function isMenuRelatedMutation(mutations) {
    for (var i = 0; i < mutations.length; i++) {
      var m = mutations[i];

      // Появление новых popup-like узлов (открытие любого меню/popover'а)
      var added = m.addedNodes;
      for (var j = 0; j < added.length; j++) {
        var n = added[j];
        if (n.nodeType !== 1) continue;
        var cls = typeof n.className === 'string' ? n.className : '';
        if (/menuPopup_|popup_|popover_|dropdown_|commandItem_|sectionHeader_|filterInput_/.test(cls)) {
          return true;
        }
        // ARIA-роли (на случай если меню без CSS-modules-классов)
        if (n.getAttribute) {
          var role = n.getAttribute('role');
          if (role === 'menu' || role === 'listbox' || role === 'menuitem') return true;
        }
        if (n.querySelector && n.querySelector(POPUP_LIKE_SELECTOR)) {
          return true;
        }
      }

      // Любая мутация ВНУТРИ уже открытого popup-like (фильтрация по
      // поиску в /-меню, выбор в Add, прочее). Для текстовых узлов
      // проверяем родителя.
      var target = m.target;
      if (target && target.nodeType === 3) target = target.parentElement;
      if (target && typeof target.closest === 'function') {
        if (target.closest(POPUP_LIKE_SELECTOR)) return true;
      }
    }
    return false;
  }

  /**
   * Помечает страницу для контекстного меню VSCode.
   *
   * Меню по правой кнопке (Cut/Copy/Paste) рисует оболочка VSCode, а не
   * страница: дописать в него пункт из нашего JS нельзя в принципе.
   * Штатный путь — атрибут `data-vscode-context`: VSCode при клике идёт
   * от узла под курсором вверх по дереву, собирает эти атрибуты и по
   * ним решает, какие вклады `webview/context` показать. Значение
   * `webviewSection` должно совпадать с `when` в манифесте расширения
   * (его вписывает patch-extension-settings.py).
   *
   * Ставим на <body>, потому что пункт нужен «в любом месте страницы».
   * `preventDefaultContextMenuItems` не трогаем: Cut/Copy/Paste должны
   * остаться, наш пункт к ним добавляется, а не заменяет их.
   *
   * body React не перерисовывает (он рендерит в #root), так что одной
   * установки хватает.
   */
  function markVscodeContext() {
    try {
      if (!document.body) return;
      document.body.setAttribute('data-vscode-context', JSON.stringify({
        webviewSection: 'claude-custom',
      }));
    } catch (e) {
      logWarn('не удалось пометить body для контекстного меню:', e);
    }
  }

  function init() {
    logInfo('init at', new Date().toISOString());
    var cspMeta = document.querySelector('meta[http-equiv="Content-Security-Policy"]');
    if (cspMeta) logInfo('CSP:', cspMeta.content);

    // Прибор запускается первым: всё, что происходит на загрузке
    // страницы, должно попасть в baseline-отчёт.
    perfInit();
    markVscodeContext();
    tagTimestampLines();
    refreshCustomCss();

    // Перехват click на иконке автосжатия (capture-фаза) — показывает
    // confirmation popup вместо мгновенного запуска /compact.
    document.addEventListener('click', compactClickInterceptor, true);
    // То же для пункта меню `/` «Очистить разговор» — спрашивает
    // подтверждение прежде, чем стирать текущий чат.
    document.addEventListener('click', clearClickInterceptor, true);

    /* Наблюдатель разделён на две части, и это разделение — суть
     * правки 59.3.
     *
     * СИНХРОННО, на каждую мутацию, остаётся только то, чему нужна
     * точность момента: отметка времени последней ЧУЖОЙ мутации.
     * На ней держится детектор тишины — 📡 и авто-пинг, — и загнать
     * её под throttle значило бы врать про возраст последних данных.
     * Никаких обращений к документу здесь нет: перебор записей стоит
     * O(числа записей) и не зависит от размера переписки.
     *
     * ПОД THROTTLE уходит всё, что обходит дерево: покраска меток 📬
     * (querySelectorAll по всем абзацам ответов) и разбор мутаций для
     * locale-drift. Именно они стоили дорого — а стриминг ответа даёт
     * тысячи мутаций в секунду, и делать этот обход на каждую из них
     * было бессмысленно: результат один и тот же. Задержка в четверть
     * секунды перед покраской метки времени незаметна глазу.
     *
     * `characterData` остаётся включённым. Соблазн убрать его велик —
     * это самый шумный источник, — но именно им виден стриминг текста
     * ответа: без него детектор тишины считал бы поток данных паузой
     * и 📡 загорался бы посреди работающего ответа.
     *
     * Свои мутации не считаются чужими. Оверлей живёт в том же body,
     * и его записи раньше и обновляли отметку времени, и запускали
     * обход дерева — то есть патч будил сам себя. */
    var BASE_THROTTLE_MS = 250;
    // Потолок буфера. MutationRecord держит ссылки на узлы, поэтому
    // расти без предела ему нельзя. Переполнение означает шторм
    // мутаций (стриминг), а не открытие меню `/` — снимок меню
    // соберётся при следующем его показе.
    var BASE_BUFFER_MAX = 1000;
    var baseBuffer = [];
    var baseTimer = null;

    var baseFlush = perfWrap('base-flush', function () {
      baseTimer = null;
      var batch = baseBuffer;
      baseBuffer = [];
      tagTimestampLines();
      // Locale-drift detector — собираем snapshot ТОЛЬКО когда мутация
      // относится к меню `/`. Иначе debug-overlay и стриминг ответов
      // в чате постоянно сбрасывают debounce-таймер, и snapshot
      // никогда не доходит до отправки.
      if (isMenuRelatedMutation(batch)) {
        maybeCollectAndSend();
        maybeSaveModels();
      }
    });

    new MutationObserver(perfWrap('base-observer', function (mutations) {
      perfBump('mutation-records', mutations.length);
      var foreign = false;
      for (var mi = 0; mi < mutations.length; mi++) {
        var target = mutations[mi].target;
        if (target && target.nodeType === 3) target = target.parentNode;
        if (target && target.__claudeOwnNode) continue;
        foreign = true;
        if (baseBuffer.length < BASE_BUFFER_MAX) baseBuffer.push(mutations[mi]);
      }
      if (!foreign) return;
      lastDomMutationAt = Date.now();
      if (baseTimer) return;
      baseTimer = setTimeout(baseFlush, BASE_THROTTLE_MS);
    })).observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
    });

    // Периодический пуллинг — для активных вкладок без DOM-активности.
    // refreshCustomCss сам выходит, если вкладка не visible.
    // lastPollAt тикается всегда, даже когда refresh — no-op (вкладка
    // скрыта), чтобы overlay-таймер был предсказуем.
    setInterval(perfWrap('css-poll', function () {
      refreshCustomCss();
      lastPollAt = Date.now();
    }), POLL_MS);

    // Когда вкладка становится активной — делаем refresh, чтобы догнать
    // изменения CSS, накопленные за время неактивности. Задержка
    // VISIBILITY_REFRESH_DELAY_MS позволяет увидеть, как именно цвет
    // меняется. 0 — мгновенно.
    // visibilitychange в Anthropic-webview не срабатывает (state всегда
    // visible). Оставляем подписку только для диагностики — счётчик
    // в overlay помогает увидеть, если в каком-то будущем релизе
    // расширение начнёт его эмитить.
    document.addEventListener('visibilitychange', function () {
      visibilityChangeCount++;
      lastVisibilityChangeAt = Date.now();
      lastVisibilityChangeNewState = document.visibilityState;
      lastVisibilityState = document.visibilityState;
    });

    // Реальный триггер «возврат на вкладку» в этом расширении —
    // window-focus после blur. Первый focus при init не должен
    // считаться возвратом, поэтому через флаг seenBlurSinceLastFocus.
    var seenBlurSinceLastFocus = false;
    window.addEventListener('focus', function () {
      if (lastFocusState !== true) {
        lastFocusState = true;
        lastFocusChangeAt = Date.now();
        focusChangeCount++;
      }
      if (!seenBlurSinceLastFocus) return; // первый focus после init
      seenBlurSinceLastFocus = false;

      var doRefresh = function () {
        lastCssRefresh = 0;
        refreshCustomCss();
        lastPollAt = Date.now();
      };
      if (VISIBILITY_REFRESH_DELAY_MS > 0) {
        if (DEBUG_OVERLAY_ENABLED) {
          overlayMode = 'visibility';
          visibilityResumeAt = Date.now() + VISIBILITY_REFRESH_DELAY_MS;
        }
        setTimeout(doRefresh, VISIBILITY_REFRESH_DELAY_MS);
      } else {
        doRefresh();
      }
    });
    window.addEventListener('blur', function () {
      if (lastFocusState !== false) {
        lastFocusState = false;
        lastFocusChangeAt = Date.now();
        focusChangeCount++;
      }
      seenBlurSinceLastFocus = true;
    });

    // Persistent debug-overlay тикает каждые 500мс на любой вкладке —
    // только если включён в конфиге (debugOverlay=true). Иначе вообще
    // никаких overlay-элементов не создаётся.
    if (DEBUG_OVERLAY_ENABLED) {
      ensureDebugOverlay();
      setInterval(perfWrap('overlay-tick', function () {
        updateDebugOverlay();
        updateInlinePingIndicator();
      }), 500);
      updateDebugOverlay();
    } else {
      // Даже без overlay, inline-индикаторы должны работать
      setInterval(perfWrap('ping-indicator', function () {
        updateInlinePingIndicator();
      }), 500);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * DOM WATCH — один наблюдатель на все модули
 *
 * Каждый модуль, которому нужно доставить свою кнопку в футер или
 * в строку сессии, заводил собственный MutationObserver на
 * document.body с `subtree: true` и вызывал из него полный скан
 * документа. К этапу 58 таких наблюдателей стало семь, и только
 * у одного (FIND IN PAGE) стоял throttle — там его поставили после
 * того, как скан на каждую мутацию подвесил webview.
 *
 * Чем это плохо, видно из арифметики. Стриминг ответа даёт тысячи
 * мутаций в секунду; браузер вызывает каждый из семи обработчиков
 * отдельно; каждый обработчик обходит документ целиком. Работа
 * растёт как «мутации × модули × размер переписки», причём почти вся
 * она бесполезна: между двумя соседними мутациями футер не меняется.
 *
 * Здесь один наблюдатель, один throttle и один периодический
 * обход-подстраховка на всех. Модуль вместо своего observer'а
 * регистрирует функцию скана:
 *
 *     window.__claudeDomWatch.register('mood', scan);
 *
 * Что даёт регистрация, кроме экономии:
 *
 * - **Чужие падения не мешают.** Скан каждого модуля вызывается
 *   в своём try/catch: исключение в одном раньше оборвало бы цикл
 *   и оставило остальных без вызова (тот же урок, что с обёрткой
 *   вокруг инлайн-JS в bootstrap).
 * - **Реентерабельности нет.** Сканы вставляют узлы, вставка рождает
 *   мутации, мутации будят наблюдателя — цикл «скан → мутация →
 *   скан» уже подвешивал окно однажды. Пока идёт проход, новый
 *   не начинается.
 * - **Свои мутации не считаются.** Оверлей и наши панели живут в том
 *   же body; без фильтра патч будил бы сам себя.
 * - **Есть предохранитель.** Если скан модуля съедает больше своего
 *   бюджета за минуту, он отключается насовсем и об этом уходит
 *   запись в журнал. Кнопка исчезнет при ближайшем ре-рендере —
 *   но это лучше подвешенного окна, а запись в журнале назовёт
 *   виновника без дознания.
 *
 * Время каждого скана идёт в прибор (`scan:<имя>` в отчёте perf) —
 * поэтому в сводке видно не только «наши обработчики съели столько-то»,
 * но и кто именно.
 * ============================================================ */
(function () {
  if (window.__claudeDomWatchInstalled) return;
  window.__claudeDomWatchInstalled = true;

  /* Регистратор публикуется ПЕРВЫМ делом, до всей настройки ниже.
   *
   * Модули обращаются к нему из своих init(), и если бы объекта не
   * оказалось, вызов бросил бы TypeError. Инлайн-JS обёрнут в общий
   * try/catch на уровне bootstrap, так что одно такое исключение
   * оборвало бы установку ВСЕХ последующих модулей — ровно та
   * поломка, ради которой этот этап и затевался.
   *
   * Функции ниже объявлены через `function`, поэтому уже видны;
   * переменные состояния получат значения строкой ниже, а методы
   * вызовут их сильно позже — из init() модулей. */
  window.__claudeDomWatch = {
    /**
     * Зарегистрировать скан модуля. Вызывается на мутациях (с общим
     * throttle) и раз в SWEEP_MS. Первый вызов — сразу, чтобы кнопка
     * появлялась без ожидания.
     */
    register: function (name, fn) {
      var wrapped = perf ? perf.wrap('scan:' + name, fn) : fn;
      subs.push({ name: name, fn: wrapped, spent: 0, disabled: false, failed: false });
      // Первый скан идёт через ту же обёртку, что и последующие: иначе
      // самый дорогой вызов — по неотрисованному ещё дереву — не попал
      // бы в отчёт прибора.
      try { wrapped(); } catch (e) {}
    },
    /** Внеочередной обход — например после действия, меняющего футер. */
    kick: function () { schedule(); },
  };

  // Пауза между обходами. Меньше — незаметно быстрее (кнопка и так
  // появляется в пределах кадра-двух), больше — заметно позже при
  // пересоздании футера React'ом.
  var THROTTLE_MS = 200;

  // Подстраховочный обход: observer пропускает узлы, отрисованные до
  // его подключения, а также случаи, когда мутация пришла в момент,
  // когда проход уже шёл.
  var SWEEP_MS = 3000;

  // Бюджет одного модуля — 4 секунды на минуту, то есть около 7%
  // главного потока. Столько скан кнопки не может стоить ни при
  // каком размере переписки; если стоит — он в цикле.
  var GUARD_WINDOW_MS = 60000;
  var GUARD_BUDGET_MS = 4000;

  var perf = window.__claudePerf || null;
  var subs = [];
  var timer = null;
  var running = false;

  function report(payload) {
    try {
      payload.href = location.href.slice(0, 200);
      payload.ts = Date.now();
      fetch('http://localhost:18923/webview-error', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        keepalive: true,
      }).catch(function () {});
    } catch (e) {}
  }

  /* Общий обход документа — один на проход вместо одного на модуль.
   *
   * Восемь сканов искали одни и те же узлы одним и тем же селектором,
   * каждый своим `querySelectorAll` по всему документу. При 11 700
   * узлах (список сообщений не виртуализирован) это была львиная доля
   * их стоимости: в замере 2026-09-03 сканы стоили 56–99 мс каждый,
   * и разброс между ними — шум, а не разница в работе.
   *
   * Контекст передаётся сканам аргументом. Модуль обязан принять его
   * как необязательный: скан вызывают и вне прохода (при регистрации,
   * из своих обработчиков), и тогда он ищет узлы сам. */
  function buildContext() {
    return {
      inputs: document.querySelectorAll('[class*="inputContainer_"]'),
      sessions: document.querySelectorAll('[class*="sessionItem_"]'),
      imageAttachments: document.querySelectorAll(
        '[class*="attachedFilesContainer_"] [class*="pill_"]'
      ),
      imagePreviews: document.querySelectorAll('[class*="previewContainer_"]'),
      userMessages: document.querySelectorAll('[data-transcript-message][class*="userMessageContainer_"]'),
    };
  }

  function runAll() {
    // Скан мутирует DOM, мутация будит наблюдателя. Без этого флага
    // получается тот самый цикл «скан → мутация → скан».
    if (running) return;
    running = true;
    try {
      var ctx = buildContext();
      for (var i = 0; i < subs.length; i++) {
        var s = subs[i];
        if (s.disabled) continue;
        var t0 = performance.now();
        try {
          s.fn(ctx);
        } catch (e) {
          // Падение одного скана не должно лишать вызова остальных.
          // Сообщаем один раз: если модуль падает, он падает на каждой
          // мутации, и журнал заполнился бы одной строкой.
          if (!s.failed) {
            s.failed = true;
            report({
              kind: 'scan-error',
              message: 'скан модуля «' + s.name + '» упал: '
                + String(e && e.message || e),
              module: s.name,
              stack: String(e && e.stack || '').slice(0, 1500),
            });
          }
        }
        s.spent += performance.now() - t0;
      }
    } finally {
      running = false;
    }
  }

  function guard() {
    for (var i = 0; i < subs.length; i++) {
      var s = subs[i];
      if (s.disabled) continue;
      if (s.spent > GUARD_BUDGET_MS) {
        s.disabled = true;
        report({
          kind: 'scan-guard',
          message: 'скан модуля «' + s.name + '» съел '
            + Math.round(s.spent) + ' мс за минуту — модуль отключён',
          module: s.name,
          spent_ms: Math.round(s.spent),
        });
      }
      s.spent = 0;
    }
  }

  function schedule() {
    if (timer) return;
    timer = setTimeout(function () {
      timer = null;
      runAll();
    }, THROTTLE_MS);
  }

  /* Узлы, ради которых вообще существуют сканы: поле ввода с футером
   * (шесть модулей) и строка списка сессий (SESSION MOVER). Мутация
   * вне этих поддеревьев ничего для нас не меняет.
   *
   * Замер 2026-09-03 показал, зачем это нужно. В покое приложение
   * мутирует DOM непрерывно — 20–30 записей в секунду, — и throttle
   * честно пропускал по пять проходов в секунду. Каждый проход это
   * восемь обходов документа, а документ здесь не виртуализирован:
   * 11 700 узлов на 190 сообщений. Выходило 5–7% главного потока
   * ради футера, который всё это время не менялся.
   *
   * Проверка стоит `closest` на запись — десятки шагов вверх по
   * дереву против восьми обходов всего документа. */
  var RELEVANT = '[class*="inputContainer_"], [class*="inputFooter_"], [class*="sessionItem_"], [class*="attachedFilesContainer_"], [class*="pill_"], [class*="previewOverlay_"], [class*="previewContainer_"], [data-transcript-message][class*="userMessageContainer_"]';

  function isRelevant(m) {
    var target = m.target;
    if (target && target.nodeType === 3) target = target.parentNode;
    // Наши собственные узлы (оверлей, панели) — не повод для скана.
    if (!target || target.__claudeOwnNode) return false;
    if (target.closest && target.closest(RELEVANT)) return true;

    /* Монтирование самого контейнера: React вставляет поле ввода
     * целиком, и тогда цель мутации — его будущий родитель, а сам
     * контейнер лежит в addedNodes. Без этой ветки кнопка появлялась
     * бы только со следующим обходом-подстраховкой, то есть через
     * секунды после открытия вкладки. */
    var added = m.addedNodes;
    if (!added) return false;
    for (var i = 0; i < added.length; i++) {
      var node = added[i];
      // Текстовые узлы — самый частый гость при стриминге ответа,
      // и они заведомо ничего не монтируют.
      if (node.nodeType !== 1) continue;
      if (node.matches && node.matches(RELEVANT)) return true;
      if (node.querySelector && node.querySelector(RELEVANT)) return true;
    }
    return false;
  }

  function onMutations(mutations) {
    for (var i = 0; i < mutations.length; i++) {
      if (!isRelevant(mutations[i])) continue;
      if (perf) perf.bump('batches-relevant');
      schedule();
      return;
    }
    // Ни одна мутация нас не касается — прохода не будет вовсе.
    // Промах фильтра не страшен: раз в SWEEP_MS идёт полный обход,
    // и кнопка встанет с задержкой, а не потеряется.
    if (perf) perf.bump('batches-skipped');
  }

  function observeBody() {
    try {
      // characterData здесь не нужен: модули следят за появлением и
      // порядком узлов, а не за текстом внутри них. Это заодно снимает
      // самый шумный источник — стриминг ответа.
      new MutationObserver(
        perf ? perf.wrap('dom-watch', onMutations) : onMutations
      ).observe(document.body, { childList: true, subtree: true });
    } catch (e) {}
  }

  // Этот блок — не модуль, а инфраструктура: он исполняется сразу при
  // загрузке файла, а не по DOMContentLoaded, потому что модули ниже
  // регистрируются у него. На этот момент body может ещё не
  // существовать, и observe(null) бросил бы исключение — молча, внутри
  // catch, оставив всех подписчиков без наблюдателя вообще.
  if (document.body) observeBody();
  else document.addEventListener('DOMContentLoaded', observeBody);

  setInterval(runAll, SWEEP_MS);
  setInterval(guard, GUARD_WINDOW_MS);
})();

/* ============================================================
 * USER MESSAGE TIMES — persisted send time, never the time of rendering.
 * ============================================================ */
(function () {
  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  if (window.__claudeUserMessageTimesInstalled) return;
  window.__claudeUserMessageTimesInstalled = true;
  var dateFormat = typeof cfg.userMessageTimestampFormat === 'string'
    && cfg.userMessageTimestampFormat.trim()
    ? cfg.userMessageTimestampFormat : 'YYYY-MM-DD HH:mm:ss';
  var completionFormat = typeof cfg.userMessageCompletionTimeFormat === 'string'
    && cfg.userMessageCompletionTimeFormat.trim() ? cfg.userMessageCompletionTimeFormat : 'HH:mm:ss';
  var selector = '[data-transcript-message][class*="userMessageContainer_"]';
  var sessions = new Map();
  var revealedMessage = null;
  var revealTimer = null;
  var uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  function messageInfo(el) {
    var key = Object.keys(el).find(function (k) { return k.indexOf('__reactFiber') === 0; });
    var fiber = key && el[key];
    if (!fiber) return null;
    // DOM nodes may keep the alternate from an earlier React commit.
    var root = fiber;
    for (var i = 0; root.return && i < 100; i++) root = root.return;
    if (root.stateNode && root.stateNode.current && root.stateNode.current !== root && fiber.alternate) {
      fiber = fiber.alternate;
    }
    for (var hop = 0; fiber && hop < 30; hop++, fiber = fiber.return) {
      var props = fiber.memoizedProps;
      var message = props && props.message;
      if (!message) continue;
      if (message.type !== 'user' || message.isSynthetic || message.parentToolUseId
          || typeof message.uuid !== 'string') return null;
      var session = props.session;
      var sid = session && session.sessionId;
      if (sid && typeof sid === 'object') sid = sid.value;
      return typeof sid === 'string' && uuid.test(sid)
        ? { session: sid, id: message.uuid, holder: session } : null;
    }
    return null;
  }

  function kick() { window.__claudeDomWatch.kick(); }

  function sessionIsRunning(entry) {
    var busy = entry && entry.holder && entry.holder.busy;
    return (busy && typeof busy === 'object' ? busy.value : busy) === true;
  }

  function requestTimes(sid, entry) {
    if (entry.loading || entry.retry) return;
    var wait = entry.nextFetch - Date.now();
    if (wait > 0) {
      entry.retry = setTimeout(function () { entry.retry = null; kick(); }, wait);
      return;
    }
    entry.loading = true;
    entry.nextFetch = Date.now() + 1000;
    fetch('http://127.0.0.1:18923/message-times?session=' + encodeURIComponent(sid)
      + (sessionIsRunning(entry) ? '&running=1' : ''), { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d && d.ok && d.times && typeof d.times === 'object') {
          entry.times = d.times;
          entry.tasks = d.tasks || {};
          syncAccountUsage(entry.tasks);
          entry.activeIds = d.active_ids || [];
        }
      })
      .catch(function () { entry.nextFetch = Date.now() + 5000; })
      .then(function () { entry.loading = false; kick(); });
  }

  function syncAccountUsage(tasks) {
    if (typeof window.__claudeSyncAccountUsage !== 'function') return;
    Object.keys(tasks).forEach(function (id) {
      if (tasks[id].account_usage) window.__claudeSyncAccountUsage(tasks[id].account_usage);
    });
  }

  function formatMessageTime(date, format) {
    var parts = {
      YYYY: String(date.getFullYear()).padStart(4, '0'),
      MM: String(date.getMonth() + 1).padStart(2, '0'),
      DD: String(date.getDate()).padStart(2, '0'),
      HH: String(date.getHours()).padStart(2, '0'),
      mm: String(date.getMinutes()).padStart(2, '0'),
      ss: String(date.getSeconds()).padStart(2, '0'),
    };
    return (format || dateFormat).replace(/YYYY|MM|DD|HH|mm|ss/g, function (token) { return parts[token]; });
  }

  function renderSentTime(stamp, date) {
    stamp.textContent = '';
    // Keep custom date formats, including DD.MM.YYYY and a time-first format.
    var datePart = /(?:YYYY|MM|DD)(?:[^A-Za-z]*(?:YYYY|MM|DD))*/.exec(dateFormat);
    var parts = datePart ? [
      [dateFormat.slice(0, datePart.index), false],
      [datePart[0], true],
      [dateFormat.slice(datePart.index + datePart[0].length), false],
    ] : [[dateFormat, false]];
    parts.forEach(function (part) {
      if (!part[0]) return;
      var span = document.createElement('span');
      if (part[1]) span.className = 'claude-user-message-date';
      span.textContent = formatMessageTime(date, part[0]);
      stamp.appendChild(span);
    });
  }

  function durationText(milliseconds) {
    var seconds = Math.max(0, Math.floor(milliseconds / 1000));
    var hours = Math.floor(seconds / 3600);
    var minutes = Math.floor(seconds % 3600 / 60);
    return (hours ? hours + ' ч ' : '') + (hours || minutes ? minutes + ' м ' : '') + seconds % 60 + ' с';
  }

  function messageCost(cost) {
    if (!cost) return { text: '', title: '' };
    if (cost.kind === 'api' && typeof cost.usd === 'number' && isFinite(cost.usd)) {
      var amount = cost.usd > 0 && cost.usd < 0.0001 ? '<$0.0001' : '≈ $' + cost.usd.toFixed(4);
      return { text: ' · ' + amount,
        title: 'Оценка по записанным API-запросам и сохранённым тарифам, с учётом кэша и доступных журналов связанных субагентов. '
          + 'Это не выписка провайдера. При уточнениях во время выполнения каждый запрос относится к последнему сообщению.' };
    }
    if (cost.kind === 'subscription' && Array.isArray(cost.windows) && cost.windows.length) {
      var windows = cost.windows.filter(function (w) { return typeof w.percent === 'number' && isFinite(w.percent); });
      var parts = windows.map(function (w) { return '≈ ' + Number(w.percent.toFixed(2)) + '%'; });
      if (parts.length) return { text: ' · ' + parts.join(' / '),
        title: windows.map(function (w, i) { return w.label + ': ' + parts[i]; }).join('\n') + '\n'
          + 'Изменение общего счётчика подписки в процентных пунктах за время задачи. '
          + 'Включает расход параллельных чатов; замеры могут пересекаться у сообщений-уточнений. '
          + '≈0% означает, что счётчик не изменился: списание может быть меньше его точности или ещё не учтено.' };
    }
    var reasons = {
      no_baseline: 'Для этого сообщения не сохранён начальный замер и способ оплаты. Учёт начинается с новых сообщений после установки.',
      pending: 'Ожидается промежуточный или итоговый замер. Интервал обновления задаётся в .claude/patches/claude-custom-config.toml.',
      account_changed: 'Во время задачи изменился аккаунт или способ оплаты; корректно вычислить расход нельзя.',
      reset: 'За время задачи произошло обновление окна лимита; корректно вычислить разницу нельзя.',
      stale: 'Провайдер не обновил счётчик лимита достаточно близко к началу или окончанию задачи.',
      no_limits: 'Провайдер не предоставил счётчик лимита для сравнения.',
      unknown_rate: 'Для части запросов нет тарифа или достаточных данных о кэше/Fast. Тарифы: .claude/message-costs.toml.',
      no_usage: 'В журнале пока нет данных о расходе API для этого сообщения.',
    };
    return { text: ' · ' + (cost.reason === 'pending' ? '…' : '—'),
      title: reasons[cost.reason] || 'Данные о расходе недоступны.' };
  }

  function saveStop(sid, entry) {
    if (!entry.pendingStop || entry.saving || Date.now() < entry.nextSave) return;
    entry.saving = true;
    entry.nextSave = Date.now() + 5000;
    var pending = entry.pendingStop;
    fetch('http://127.0.0.1:18923/message-times?session=' + encodeURIComponent(sid), {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(pending), keepalive: true,
    }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d || !d.ok) return;
      entry.tasks = d.tasks || entry.tasks;
      syncAccountUsage(entry.tasks);
      if (entry.pendingStop === pending) entry.pendingStop = null;
    }).catch(function () {}).then(function () { entry.saving = false; kick(); });
  }

  function updateTask(sid, entry) {
    var busy = entry.holder && entry.holder.busy;
    if (busy && typeof busy === 'object') busy = busy.value;
    if (busy === false && entry.wasBusy === true && typeof window.__claudeFinishMarkdownSession === 'function') {
      window.__claudeFinishMarkdownSession(entry.holder);
    }
    if (busy === true) {
      if (entry.wasBusy === false) entry.busySince = Date.now();
      entry.activeIds.forEach(function (id) {
        var task = entry.tasks[id] || {};
        // Include server completion while the UI still renders this turn.
        // A previous turn must not restart before the new prompt is indexed.
        if (!task.completed_at || Date.parse(task.completed_at) >= entry.busySince) entry.runningIds.add(id);
      });
      requestTimes(sid, entry);
    } else if (busy === false && entry.wasBusy === true && entry.runningIds.size) {
      entry.pendingStop = { message_ids: Array.from(entry.runningIds), completed_at: new Date().toISOString() };
      entry.pendingStop.message_ids.forEach(function (id) {
        entry.localStops[id] = { completed_at: entry.pendingStop.completed_at, source: 'ui_stop' };
      });
      entry.runningIds.clear();
      entry.refreshUntil = Date.now() + 5000;
    }
    if (typeof busy === 'boolean') entry.wasBusy = busy;
    if (entry.pendingStop) saveStop(sid, entry);
    if (Date.now() < entry.refreshUntil) requestTimes(sid, entry);
  }

  function renderTime(el, info, timestamp, task, running) {
    var stamp = el.querySelector('.claude-user-message-time');
    var date = typeof timestamp === 'string' ? new Date(timestamp) : null;
    if (!info || !date || isNaN(date.getTime())) {
      if (stamp) stamp.remove();
      return;
    }
    var identity = info.session + '/' + info.id;
    var end = !running && task && task.completed_at ? new Date(task.completed_at) : null;
    if (end && (isNaN(end.getTime()) || end < date)) end = null;
    var sentText = formatMessageTime(date);
    var endText = '';
    var elapsedText = '';
    if (end) {
      var format = completionFormat;
      if (end.toDateString() !== date.toDateString() && !/YYYY|MM|DD/.test(format)) format = 'YYYY-MM-DD ' + format;
      endText = ' (' + formatMessageTime(end, format) + ')';
    }
    if (end || running) elapsedText = ' · ' + durationText((end ? end.getTime() : Date.now()) - date.getTime());
    var cost = messageCost(task && task.cost);
    var refresh = running && task && task.cost_refresh;
    var refreshText = '';
    if (refresh && typeof refresh.next_at === 'number' && isFinite(refresh.next_at)) {
      var remaining = Math.max(0, Math.ceil(refresh.next_at - Date.now() / 1000));
      refreshText = ' · ↻ ' + (refresh.updating || !remaining ? '…'
        : String(Math.floor(remaining / 60)).padStart(2, '0') + ':' + String(remaining % 60).padStart(2, '0'));
    }
    var text = sentText + endText + elapsedText + cost.text + refreshText;
    if (stamp && stamp.getAttribute('data-message-key') === identity
        && stamp.textContent === text && stamp.getAttribute('data-cost-title') === cost.title) return;
    if (!stamp) {
      stamp = document.createElement('time');
      stamp.className = 'claude-user-message-time';
      stamp.__claudeOwnNode = true;
      el.appendChild(stamp);
    }
    stamp.setAttribute('data-message-key', identity);
    stamp.setAttribute('data-cost-title', cost.title);
    stamp.dateTime = date.toISOString();
    renderSentTime(stamp, date);
    if (endText) {
      var endSpan = document.createElement('span');
      endSpan.className = 'claude-user-message-completion';
      endSpan.textContent = endText;
      stamp.appendChild(endSpan);
    }
    if (elapsedText) {
      var elapsedSpan = document.createElement('span');
      elapsedSpan.className = 'claude-user-message-duration';
      elapsedSpan.textContent = elapsedText;
      stamp.appendChild(elapsedSpan);
    }
    if (cost.text) {
      var separator = document.createElement('span');
      separator.className = 'claude-user-message-duration';
      separator.textContent = cost.text.slice(0, 3);
      stamp.appendChild(separator);
      var costSpan = document.createElement('span');
      costSpan.className = 'claude-user-message-cost';
      costSpan.textContent = cost.text.slice(3);
      costSpan.title = cost.title;
      stamp.appendChild(costSpan);
    }
    if (refreshText) {
      var refreshSpan = document.createElement('span');
      refreshSpan.className = 'claude-user-message-duration';
      refreshSpan.textContent = refreshText;
      refreshSpan.title = 'До следующего фонового обновления расхода лимита. … — ожидается свежий замер.';
      stamp.appendChild(refreshSpan);
    }
    stamp.title = date.toLocaleString('ru-RU');
    if (end) stamp.title += '\nЗавершено ' + end.toLocaleString('ru-RU')
      + (task.source === 'transcript' ? ' (по финальному ответу в журнале)'
        : task.source === 'ui_stop' ? ' (по остановке обработки в интерфейсе)' : ' (по Stop-хуку)');
    if (end && task.server_completed_at && task.source === 'ui_stop') {
      stamp.title += '\nStop-хук: ' + new Date(task.server_completed_at).toLocaleString('ru-RU');
    }
    if (cost.title) stamp.title += '\n' + cost.title;
    stamp.setAttribute('aria-label', stamp.title);
  }

  function scan(ctx) {
    sessions.forEach(function (entry) { entry.views = []; });
    var rows = ctx && ctx.userMessages || document.querySelectorAll(selector);
    for (var i = 0; i < rows.length; i++) {
      var info = messageInfo(rows[i]);
      if (!info) { renderTime(rows[i], null, null); continue; }
      var entry = sessions.get(info.session);
      if (!entry) {
        entry = { times: {}, tasks: {}, localStops: {}, activeIds: [], views: [], runningIds: new Set(),
          wasBusy: null, busySince: 0, pendingStop: null, saving: false, nextSave: 0, refreshUntil: 0,
          loading: false, retry: null, nextFetch: 0 };
        sessions.set(info.session, entry);
        if (sessions.size > 16) sessions.delete(sessions.keys().next().value);
      }
      entry.holder = info.holder;
      entry.views.push({ el: rows[i], info: info });
      var timestamp = entry.times[info.id];
      if (!timestamp) requestTimes(info.session, entry);
    }
    tick();
  }

  function tick() {
    sessions.forEach(function (entry, sid) {
      updateTask(sid, entry);
      entry.views.forEach(function (view) {
        var id = view.info.id;
        var task = entry.tasks[id];
        task = withLocalStop(task, entry.localStops[id]);
        renderTime(view.el, view.info, entry.times[id], task, entry.runningIds.has(id));
      });
    });
  }

  function withLocalStop(task, local) {
    return local && (!task || !task.completed_at || Date.parse(local.completed_at) > Date.parse(task.completed_at))
      ? Object.assign({}, task, local) : task;
  }

  function revealMessage(sid, id) {
    var rows = document.querySelectorAll(selector);
    for (var i = 0; i < rows.length; i++) {
      var info = messageInfo(rows[i]);
      if (!info || info.session !== sid || info.id !== id) continue;
      if (revealTimer) clearTimeout(revealTimer);
      if (revealedMessage) revealedMessage.classList.remove('claude-message-jump-highlight');
      revealedMessage = rows[i];
      revealedMessage.classList.add('claude-message-jump-highlight');
      revealedMessage.scrollIntoView({ block: 'center', behavior: 'smooth' });
      revealTimer = setTimeout(function () {
        if (revealedMessage) revealedMessage.classList.remove('claude-message-jump-highlight');
        revealedMessage = null;
        revealTimer = null;
      }, 2500);
      return true;
    }
    return false;
  }

  window.__claudeMessageTiming = {
    render: renderTime,
    reveal: revealMessage,
    isRunning: function (sid) { return sessionIsRunning(sessions.get(sid)); },
    status: function (sid, id) {
      var entry = sessions.get(sid);
      if (!entry) return null;
      var task = entry.tasks[id];
      task = withLocalStop(task, entry.localStops[id]);
      return { task: task, running: entry.runningIds.has(id) };
    },
  };
  function init() {
    if (cfg.userMessageTimestamps !== true) return;
    window.__claudeDomWatch.register('user-message-times', scan);
    setInterval(tick, 1000);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();

// === CHAT AUTO SCROLL ===
function claudeFollowChatEnd(container) {
  var frame = null;
  var top = container.scrollTop;
  var height = container.scrollHeight;
  var following = height - container.clientHeight - top <= 48;
  function schedule() {
    if (!following || frame !== null) return;
    frame = requestAnimationFrame(function () {
      frame = null;
      if (!following || !container.isConnected) return;
      // Instant movement: smooth scrolling would lag behind a continuous stream.
      container.scrollTop = container.scrollHeight;
      top = container.scrollTop;
      height = container.scrollHeight;
    });
  }
  function onScroll() {
    var next = container.scrollTop;
    // Growth alone must not turn following off: the bottom has moved, not the user.
    if (next < top - 1 && container.scrollHeight >= height) following = false;
    else if (container.scrollHeight - container.clientHeight - next <= 48) following = true;
    top = next;
    height = container.scrollHeight;
  }
  function onWheel(event) { if (event.deltaY < 0) following = false; }
  var resize = new ResizeObserver(schedule);
  function watchTail() {
    resize.disconnect();
    resize.observe(container);
    // The active turn, spinner and composer spacer are at the tail. Observe a
    // bounded number of boxes, not every message or every streamed DOM mutation.
    var children = container.children;
    for (var i = Math.max(0, children.length - 4); i < children.length; i++) resize.observe(children[i]);
    schedule();
  }
  var structure = new MutationObserver(watchTail);
  structure.observe(container, { childList: true });
  container.addEventListener('scroll', onScroll, { passive: true });
  container.addEventListener('wheel', onWheel, { passive: true });
  watchTail();
  return {
    resume: function () { following = true; schedule(); },
    destroy: function () {
      resize.disconnect(); structure.disconnect();
      container.removeEventListener('scroll', onScroll);
      container.removeEventListener('wheel', onWheel);
      if (frame !== null) cancelAnimationFrame(frame);
    },
  };
}
(function () {
  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  if (cfg.chatAutoScroll !== true || cfg.safeMode === true || window.__claudeChatAutoScrollInstalled ||
      typeof ResizeObserver !== 'function' || typeof MutationObserver !== 'function') return;
  window.__claudeChatAutoScrollInstalled = true;
  var current = new Map();
  window.__claudeResumeChatScroll = function (container) {
    var follow = current.get(container);
    if (follow) follow.resume();
  };
  window.__claudeDomWatch.register('chat-auto-scroll', function (ctx) {
    var inputs = ctx && ctx.inputs || document.querySelectorAll('[class*="inputContainer_"]');
    var found = new Set();
    for (var i = 0; i < inputs.length; i++) {
      var chat = inputs[i].closest('[class*="chatContainer_"]');
      var container = chat && chat.querySelector('[role="region"][class*="messagesContainer_"]');
      if (container) found.add(container);
    }
    current.forEach(function (follow, container) {
      if (!found.has(container) || !container.isConnected) { follow.destroy(); current.delete(container); }
    });
    found.forEach(function (container) {
      if (!current.has(container)) current.set(container, claudeFollowChatEnd(container));
    });
  });
})();
// === END CHAT AUTO SCROLL ===

/* ============================================================
 * CHAT SCROLL BOTTOM — jump to the end beside the active composer.
 * ============================================================ */
(function () {
  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  if (cfg.chatScrollBottomButton !== true || window.__claudeChatScrollBottomInstalled) return;
  window.__claudeChatScrollBottomInstalled = true;
  var button = null;
  var host = null;
  var chat = null;
  var frame = null;
  var resize = typeof ResizeObserver === 'function' ? new ResizeObserver(schedulePosition) : null;

  function position() {
    if (!button || !host || !host.isConnected || !chat || !chat.isConnected) {
      if (button) button.hidden = true;
      return;
    }
    var input = host.getBoundingClientRect();
    var bounds = chat.getBoundingClientRect();
    if (!input.width || !input.height || !bounds.width || !bounds.height) {
      button.hidden = true;
      return;
    }
    var size = 36;
    var right = Math.min(bounds.right, window.innerWidth);
    var room = right - input.right;
    // Wide editor: center in the free space on the right, as beside Usage.
    // Sidebar: move above the composer instead of covering Send or its text.
    var left = room >= size + 16 ? input.right + (room - size) / 2 : right - size - 12;
    var top = room >= size + 16 ? input.top + (input.height - size) / 2 : input.top - size - 10;
    button.style.left = Math.max(8, Math.min(left, window.innerWidth - size - 8)) + 'px';
    button.style.top = Math.max(8, Math.min(top, window.innerHeight - size - 8)) + 'px';
    button.hidden = false;
  }

  function schedulePosition() {
    if (frame !== null) return;
    frame = requestAnimationFrame(function () { frame = null; position(); });
  }

  function jumpToEnd() {
    if (!chat || !chat.isConnected) return;
    var transcript = chat.querySelector('[role="region"][class*="messagesContainer_"]')
      || chat.querySelector('[class*="messagesContainer_"]');
    if (!transcript) return;
    if (window.__claudeResumeChatScroll) window.__claudeResumeChatScroll(transcript);
    var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    transcript.scrollTo({ top: transcript.scrollHeight, behavior: reduced ? 'auto' : 'smooth' });
  }

  function scan(ctx) {
    var inputs = ctx && ctx.inputs || document.querySelectorAll('[class*="inputContainer_"]');
    var next = null;
    var nextChat = null;
    var bottom = 0;
    for (var i = 0; i < inputs.length; i++) {
      if (!inputs[i].querySelector('[role="textbox"][contenteditable]')) continue;
      var root = inputs[i].closest('[class*="chatContainer_"]');
      if (!root) continue;
      var rect = inputs[i].getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0 && rect.bottom > bottom) {
        next = inputs[i]; nextChat = root; bottom = rect.bottom;
      }
    }
    if (host !== next || chat !== nextChat) {
      host = next; chat = nextChat;
      if (resize) {
        resize.disconnect();
        if (host) resize.observe(host);
        if (chat) resize.observe(chat);
      }
    }
    if (!host) { if (button) button.hidden = true; return; }
    if (!button || !button.isConnected) {
      button = document.createElement('button');
      button.type = 'button';
      button.className = 'claude-chat-scroll-bottom';
      button.__claudeOwnNode = true;
      button.title = 'В конец чата';
      button.setAttribute('aria-label', button.title);
      button.textContent = '↓';
      button.addEventListener('mousedown', function (event) { event.preventDefault(); });
      button.addEventListener('click', function (event) {
        event.preventDefault(); event.stopPropagation(); jumpToEnd();
      });
      document.body.appendChild(button);
    }
    position();
  }

  window.addEventListener('resize', schedulePosition);
  window.__claudeDomWatch.register('chat-scroll-bottom', scan);
})();

/* ============================================================
 * COMPOSER TEXT — чтение и вставка текста в поле ввода
 *
 * Поле ввода — `div[contenteditable="plaintext-only"]`, React-
 * controlled. С ним связаны две ловушки, на каждую из которых уже
 * наступали, и обе стоят отдельной функции.
 *
 * ЧТЕНИЕ. `textContent` склеивает строки: он конкатенирует текст
 * узлов и о разрывах не знает. `innerText` учитывает раскладку и
 * отдаёт ровно то, что видит пользователь, — с `\n` на каждом
 * переносе, независимо от того, хранит их поле символами или <br>.
 *
 * ВСТАВКА. Один `insertText` со всей строкой не годится: перенос
 * внутри неё Chromium разрывом не делает. Снаружи это выглядит
 * особенно обманчиво — каретка встаёт куда надо, выделение показывает
 * несколько строк, а видимый текст склеен в одну. Так и есть: поле
 * рисует текст прозрачным, а видимое рисует зеркало `.mentionMirror_*`
 * (см. заметку про EMOJI PICKER), и до зеркала переносы не доезжают.
 * Поэтому вставляем построчно, а между строками просим редактор
 * сделать разрыв — тем же действием, что и Shift+Enter.
 *
 * Пойманы обе ловушки порознь: чтение — на возврате черновика
 * keepalive, вставка — там же, а потом ещё раз на цитировании.
 * Отсюда общий блок: третьей копии быть не должно.
 * ============================================================ */
(function () {
  if (window.__claudeComposerTextInstalled) return;
  window.__claudeComposerTextInstalled = true;

  window.__claudeComposer = {
    /** Содержимое поля с сохранением переносов. */
    read: function (el) {
      if (!el) return '';
      return (typeof el.innerText === 'string' ? el.innerText : el.textContent) || '';
    },

    /**
     * Вставляет текст в фокусированное поле, воспроизводя переносы.
     * Возвращает false, если редактор отказал, — вызывающий решает,
     * что делать дальше.
     */
    insertMultiline: function (text) {
      var lines = String(text).split('\n');
      for (var i = 0; i < lines.length; i++) {
        if (i > 0) {
          var broke = false;
          try {
            broke = document.execCommand('insertLineBreak');
          } catch (e) {
            broke = false;
          }
          if (!broke) {
            try { document.execCommand('insertText', false, '\n'); } catch (e) {}
          }
        }
        // Пустая строка — это сам разрыв, вставлять сверх него нечего.
        if (!lines[i]) continue;
        try {
          if (!document.execCommand('insertText', false, lines[i])) return false;
        } catch (e) {
          return false;
        }
      }
      return true;
    },
  };
})();

/* ============================================================
 * SESSION MOVER — перенос сессий чата между проектами Claude Code
 * ============================================================
 *
 * Добавляет кнопку 📁 «Переместить в проект» в `.sessionActions_*`
 * каждой строки списка локальных сессий. По клику открывает модалку
 * со списком существующих проектов (GET /list-projects) и полем для
 * создания нового проекта (POST /create-project + /move-session).
 *
 * Извлечение session_id: через React-fiber.key sessionItem-кнопки
 * (Claude Code хранит туда `session.sessionId.value`).
 *
 * Бэкенд: http-server.py в .claude/hooks/, endpoints:
 *   - GET  /list-projects
 *   - POST /move-session   (auto-detect source если не указан)
 *   - POST /create-project
 *
 * Изолировано от основной IIFE — отдельный модуль с защитой
 * от двойной установки через window.__claudeSessionMoverInstalled.
 */
(function () {
  if (window.__claudeSessionMoverInstalled) return;
  window.__claudeSessionMoverInstalled = true;

  // Единственный модуль, у которого выключателя не было: без него
  // безопасный режим не мог погасить всё и поиск виновника поломки
  // упирался бы в неснимаемую кнопку в списке сессий.
  if ((window.__CLAUDE_CUSTOM_CONFIG__ || {}).sessionMover === false) return;

  var API_BASE = 'http://localhost:18923';
  var MOVE_BTN_CLASS = 'claude-move-session-btn';
  var INSTALLED_ATTR = 'data-claude-move-installed';

  function logInfo() {
    var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
    if (!cfg.logs) return;
    try { console.log.apply(console, ['[session-mover]'].concat([].slice.call(arguments))); } catch (e) {}
  }

  /** Отправляет диагностику на http-server (логирует в файл). */
  function sendDiag(tag, data) {
    try {
      fetch(API_BASE + '/diag', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tag: tag, data: data || {} }),
        keepalive: true,
      }).catch(function () {});
    } catch (e) {}
  }

  sendDiag('install', { ua: navigator.userAgent, ts: Date.now() });

  /** Извлекает sessionId из React-fiber sessionItem.
   *
   * DOM-fiber кнопки (<button class="sessionItem_*">) имеет key=null,
   * потому что `key` в React передаётся не на DOM-элемент, а на
   * fiber родительского компонента (SessionItem forwardRef). Поднимаемся
   * по `.return` пока не найдём fiber с непустым строковым ключом —
   * это и есть `session.sessionId.value` (UUID).
   *
   * Fallback: если key — число (порядковый индекс из `??o1`), значит
   * sessionId.value отсутствовал; такие сессии пропускаем.
   */
  function getSessionIdFromElement(el) {
    if (!el) return null;
    var keys = Object.keys(el);
    var fiber = null;
    for (var i = 0; i < keys.length; i++) {
      if (keys[i].indexOf('__reactFiber') === 0) {
        fiber = el[keys[i]];
        break;
      }
    }
    if (!fiber) return null;
    var hops = 0;
    while (fiber && hops < 10) {
      if (typeof fiber.key === 'string' && fiber.key.length > 0) {
        return fiber.key;
      }
      fiber = fiber.return;
      hops++;
    }
    return null;
  }

  function getSessionName(sessionItem) {
    var nameEl = sessionItem.querySelector('[class*="sessionName_"]');
    if (!nameEl) return '(unnamed)';
    return (nameEl.textContent || '').trim() || '(unnamed)';
  }

  function createMoveButton(sessionId, sessionName) {
    var btn = document.createElement('button');
    btn.className = MOVE_BTN_CLASS;
    btn.title = 'Переместить в другой проект';
    btn.setAttribute('aria-label', 'Переместить сессию в другой проект');
    btn.setAttribute('type', 'button');
    btn.textContent = '📁';
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      e.preventDefault();
      openMoveDialog(sessionId, sessionName);
    });
    // sessionItem-кнопка реагирует на mousedown — глушим оба события
    btn.addEventListener('mousedown', function (e) { e.stopPropagation(); });
    return btn;
  }

  function processSessionItem(sessionItem) {
    if (sessionItem.getAttribute(INSTALLED_ATTR) === '1') return;
    var actionsEl = sessionItem.querySelector('[class*="sessionActions_"]');
    if (!actionsEl) return;
    var sessionId = getSessionIdFromElement(sessionItem);
    if (!sessionId) return;
    var sessionName = getSessionName(sessionItem);
    var btn = createMoveButton(sessionId, sessionName);
    var deleteBtn = actionsEl.querySelector('[class*="deleteButton_"]');
    if (deleteBtn) {
      actionsEl.insertBefore(btn, deleteBtn);
    } else {
      actionsEl.appendChild(btn);
    }
    sessionItem.setAttribute(INSTALLED_ATTR, '1');
  }

  function scanSessionItems(ctx) {
    // Узлы даёт общий обход (см. DOM WATCH) — один на все модули.
    // Свой поиск остаётся для вызовов вне прохода: при регистрации
    // и из обработчиков самого модуля.
    var items = (ctx && ctx.sessions)
      || document.querySelectorAll('[class*="sessionItem_"]');
    if (!window.__claudeMoverScanLogged && items.length > 0) {
      window.__claudeMoverScanLogged = true;
      var first = items[0];
      var reactKeys = Object.keys(first).filter(function (k) {
        return k.indexOf('__react') === 0 || k.indexOf('_react') === 0;
      });
      var fiberKey = reactKeys.filter(function (k) { return k.indexOf('Fiber') >= 0; })[0];
      var fiber = fiberKey ? first[fiberKey] : null;
      // Собираем цепочку .return и их keys (до 6 уровней вверх),
      // чтобы видеть, на каком предке хранится sessionId.value.
      var chain = [];
      var f = fiber;
      for (var h = 0; h < 6 && f; h++) {
        chain.push({
          type: f.type && (f.type.displayName || f.type.name || (typeof f.type === 'string' ? f.type : '<anon>')),
          key: typeof f.key === 'string' ? f.key : (f.key == null ? null : String(f.key)),
        });
        f = f.return;
      }
      sendDiag('first-scan', {
        itemCount: items.length,
        firstClassName: (first.className || '').slice(0, 200),
        reactKeys: reactKeys,
        fiberKey: fiberKey || null,
        fiberKeyOnFiber: fiber && typeof fiber.key !== 'undefined' ? String(fiber.key) : 'NO-KEY',
        returnChain: chain,
        hasSessionActions: !!first.querySelector('[class*="sessionActions_"]'),
        hasDeleteBtn: !!first.querySelector('[class*="deleteButton_"]'),
      });
    }
    var inserted = 0;
    for (var i = 0; i < items.length; i++) {
      try {
        var before = items[i].getAttribute(INSTALLED_ATTR) === '1';
        processSessionItem(items[i]);
        if (!before && items[i].getAttribute(INSTALLED_ATTR) === '1') inserted++;
      } catch (e) {
        sendDiag('process-error', { err: String(e) });
      }
    }
    if (inserted > 0) sendDiag('btn-inserted', { count: inserted });
  }

  function pluralize(n, forms) {
    var mod10 = n % 10, mod100 = n % 100;
    if (mod100 >= 11 && mod100 <= 14) return forms[2];
    if (mod10 === 1) return forms[0];
    if (mod10 >= 2 && mod10 <= 4) return forms[1];
    return forms[2];
  }

  /** Возвращает имя последней папки пути.
   * '/home/vladimir/Документы/Projects/Flying_Player' → 'Flying_Player'
   * '/home/vladimir' → 'vladimir'
   * '/'             → '/'
   */
  function basenameOfPath(p) {
    if (!p) return p;
    var s = String(p);
    // Убираем trailing slashes (кроме самого корня)
    while (s.length > 1 && s.charAt(s.length - 1) === '/') {
      s = s.slice(0, -1);
    }
    var idx = s.lastIndexOf('/');
    if (idx < 0) return s;
    if (idx === 0 && s.length === 1) return '/';
    return s.slice(idx + 1) || s;
  }

  /** Открывает модалку переноса сессии. */
  function openMoveDialog(sessionId, sessionName) {
    closeMoveDialog();

    var overlay = document.createElement('div');
    overlay.id = 'claude-move-overlay';
    overlay.className = 'claude-move-overlay';

    var modal = document.createElement('div');
    modal.className = 'claude-move-modal';
    overlay.appendChild(modal);

    var header = document.createElement('div');
    header.className = 'claude-move-header';
    header.textContent = 'Переместить сессию';
    modal.appendChild(header);

    var sub = document.createElement('div');
    sub.className = 'claude-move-subheader';
    sub.textContent = sessionName;
    modal.appendChild(sub);

    var sid = document.createElement('div');
    sid.className = 'claude-move-sid';
    sid.textContent = 'ID: ' + sessionId;
    modal.appendChild(sid);

    var loading = document.createElement('div');
    loading.className = 'claude-move-loading';
    loading.textContent = 'Загрузка списка проектов...';
    modal.appendChild(loading);

    var listLabel = document.createElement('div');
    listLabel.className = 'claude-move-section-label';
    listLabel.textContent = 'Выбрать существующий проект:';
    listLabel.style.display = 'none';
    modal.appendChild(listLabel);

    var listEl = document.createElement('div');
    listEl.className = 'claude-move-list';
    listEl.style.display = 'none';
    modal.appendChild(listEl);

    var newLabel = document.createElement('div');
    newLabel.className = 'claude-move-section-label';
    newLabel.textContent = 'Создать новый проект:';
    newLabel.style.display = 'none';
    modal.appendChild(newLabel);

    var newRow = document.createElement('div');
    newRow.className = 'claude-move-new-row';
    newRow.style.display = 'none';
    modal.appendChild(newRow);

    var newInput = document.createElement('input');
    newInput.type = 'text';
    newInput.className = 'claude-move-new-input';
    newInput.placeholder = '/абсолютный/путь/к/проекту';
    newRow.appendChild(newInput);

    var newBtn = document.createElement('button');
    newBtn.className = 'claude-move-new-btn';
    newBtn.textContent = 'Создать и переместить';
    newBtn.setAttribute('type', 'button');
    newBtn.addEventListener('click', function () {
      var p = (newInput.value || '').trim();
      if (!p) { newInput.focus(); return; }
      createProjectAndMove(sessionId, p);
    });
    newRow.appendChild(newBtn);

    var footer = document.createElement('div');
    footer.className = 'claude-move-footer';
    modal.appendChild(footer);

    var cancelBtn = document.createElement('button');
    cancelBtn.className = 'claude-move-cancel';
    cancelBtn.textContent = 'Отмена';
    cancelBtn.setAttribute('type', 'button');
    cancelBtn.addEventListener('click', closeMoveDialog);
    footer.appendChild(cancelBtn);

    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) closeMoveDialog();
    });
    var escHandler = function (e) {
      if (e.key === 'Escape') closeMoveDialog();
    };
    document.addEventListener('keydown', escHandler);
    overlay._escHandler = escHandler;

    document.body.appendChild(overlay);

    loadProjectList(sessionId, sessionName, loading, listLabel, listEl, newLabel, newRow);
  }

  /** Делает fetch GET /list-projects с авто-ретраями: до 10 попыток
   * с интервалом 1 сек. Каждая попытка попадает строкой в лог
   * (внутри блока `loading`). При успехе лог сворачивается до одной
   * строки. При финальном фейле — кнопка «Повторить» под логом. */
  function loadProjectList(sessionId, sessionName, loading, listLabel, listEl, newLabel, newRow) {
    var MAX_ATTEMPTS = 10;
    var RETRY_DELAY_MS = 1000;

    // Перестраиваем содержимое loading: заголовок + контейнер с логом.
    while (loading.firstChild) loading.removeChild(loading.firstChild);
    loading.style.display = '';

    var logTitle = document.createElement('div');
    logTitle.textContent = 'Загрузка списка проектов...';
    loading.appendChild(logTitle);

    var logBox = document.createElement('div');
    logBox.className = 'claude-move-log';
    loading.appendChild(logBox);

    listLabel.style.display = 'none';
    listEl.style.display = 'none';
    newLabel.style.display = 'none';
    newRow.style.display = 'none';
    while (listEl.firstChild) listEl.removeChild(listEl.firstChild);

    function nowStr() {
      var d = new Date();
      function pad(n) { return n < 10 ? '0' + n : '' + n; }
      return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
    }
    function appendLogLine(text, kind) {
      var line = document.createElement('div');
      line.className = 'claude-move-log-line ' +
        (kind ? ('claude-move-log-' + kind) : '');
      line.textContent = '[' + nowStr() + '] ' + text;
      logBox.appendChild(line);
      logBox.scrollTop = logBox.scrollHeight;
    }

    function attempt(n) {
      appendLogLine('Попытка ' + n + '/' + MAX_ATTEMPTS + ': GET /list-projects ...');
      fetch(API_BASE + '/list-projects')
        .then(function (r) {
          if (!r.ok) throw new Error('HTTP ' + r.status);
          return r.json();
        })
        .then(function (data) {
          var count = (data && data.projects) ? data.projects.length : 0;
          appendLogLine('✓ Получено ' + count + ' проект(ов)', 'ok');
          onSuccess(data);
        })
        .catch(function (err) {
          var emsg = (err && err.message) || String(err);
          appendLogLine('✗ Ошибка: ' + emsg, 'err');
          if (n < MAX_ATTEMPTS) {
            setTimeout(function () { attempt(n + 1); }, RETRY_DELAY_MS);
          } else {
            onFinalError(err);
          }
        });
    }

    function onSuccess(data) {
      loading.style.display = 'none';
      listLabel.style.display = '';
      listEl.style.display = '';
      newLabel.style.display = '';
      newRow.style.display = '';

      var projects = (data && data.projects) || [];
      if (!projects.length) {
        var empty = document.createElement('div');
        empty.className = 'claude-move-empty';
        empty.textContent = 'Нет существующих проектов';
        listEl.appendChild(empty);
        return;
      }
      projects.forEach(function (p) {
        var fullPath = p.display_name || p.encoded_name;
        var shortName = basenameOfPath(fullPath);

        var item = document.createElement('button');
        item.className = 'claude-move-item';
        item.setAttribute('type', 'button');
        // Полный путь — в нативном tooltip (browser показывает его
        // после ~500мс удержания курсора).
        item.setAttribute('title', fullPath);

        var name = document.createElement('div');
        name.className = 'claude-move-item-name';
        name.textContent = shortName;
        item.appendChild(name);

        var meta = document.createElement('div');
        meta.className = 'claude-move-item-meta';
        var count = (typeof p.session_count === 'number') ? p.session_count : 0;
        meta.textContent = count + ' ' + pluralize(count, ['сессия', 'сессии', 'сессий']);
        item.appendChild(meta);

        item.addEventListener('click', function () {
          showConfirmMove(sessionId, sessionName,
                          p.encoded_name, fullPath, shortName);
        });
        listEl.appendChild(item);
      });
    }

    function onFinalError(err) {
      logTitle.textContent = 'Все ' + MAX_ATTEMPTS + ' попыток провалились — сервер недоступен.';
      var retryBtn = document.createElement('button');
      retryBtn.className = 'claude-move-new-btn';
      retryBtn.textContent = 'Повторить';
      retryBtn.setAttribute('type', 'button');
      retryBtn.style.marginTop = '8px';
      retryBtn.addEventListener('click', function () {
        loadProjectList(sessionId, sessionName, loading, listLabel, listEl, newLabel, newRow);
      });
      loading.appendChild(retryBtn);
    }

    attempt(1);
  }

  function closeMoveDialog() {
    var overlay = document.getElementById('claude-move-overlay');
    if (!overlay) return;
    if (overlay._escHandler) {
      document.removeEventListener('keydown', overlay._escHandler);
    }
    overlay.remove();
  }

  function setBusy(busy) {
    var overlay = document.getElementById('claude-move-overlay');
    if (!overlay) return;
    if (busy) overlay.classList.add('claude-move-busy');
    else overlay.classList.remove('claude-move-busy');
  }

  /** Показывает диалог подтверждения переноса в текущей модалке.
   *
   * @param {string} sessionId    UUID переносимой сессии.
   * @param {string} sessionName  Имя сессии для отображения.
   * @param {string} targetEncoded Имя папки в ~/.claude/projects/.
   * @param {string} targetFullPath Полный путь проекта (для tooltip/info).
   * @param {string} targetShortName Basename проекта.
   *
   * При «Перенести» — moveSession + переход в success-тост.
   * При «Назад» — возврат к списку проектов через loadProjectList.
   */
  function showConfirmMove(sessionId, sessionName, targetEncoded,
                           targetFullPath, targetShortName) {
    var overlay = document.getElementById('claude-move-overlay');
    if (!overlay) return;
    var modal = overlay.querySelector('.claude-move-modal');
    if (!modal) return;
    modal.innerHTML = '';
    modal.classList.remove('claude-move-success');

    var h = document.createElement('div');
    h.className = 'claude-move-header';
    h.textContent = 'Подтвердите перенос';
    modal.appendChild(h);

    var question = document.createElement('div');
    question.className = 'claude-move-confirm-question';
    question.textContent = 'Вы действительно хотите перенести сессию';
    modal.appendChild(question);

    var sessionBox = document.createElement('div');
    sessionBox.className = 'claude-move-confirm-box';
    var sessionLabel = document.createElement('div');
    sessionLabel.className = 'claude-move-confirm-label';
    sessionLabel.textContent = 'Сессия';
    sessionBox.appendChild(sessionLabel);
    var sessionValue = document.createElement('div');
    sessionValue.className = 'claude-move-confirm-value';
    sessionValue.textContent = sessionName || '(без названия)';
    sessionValue.setAttribute('title', 'ID: ' + sessionId);
    sessionBox.appendChild(sessionValue);
    modal.appendChild(sessionBox);

    var arrow = document.createElement('div');
    arrow.className = 'claude-move-confirm-arrow';
    arrow.textContent = '↓';
    modal.appendChild(arrow);

    var targetBox = document.createElement('div');
    targetBox.className = 'claude-move-confirm-box';
    var targetLabel = document.createElement('div');
    targetLabel.className = 'claude-move-confirm-label';
    targetLabel.textContent = 'В проект';
    targetBox.appendChild(targetLabel);
    var targetValue = document.createElement('div');
    targetValue.className = 'claude-move-confirm-value';
    targetValue.textContent = targetShortName;
    targetBox.appendChild(targetValue);
    var targetPath = document.createElement('div');
    targetPath.className = 'claude-move-confirm-path';
    targetPath.textContent = targetFullPath;
    targetBox.appendChild(targetPath);
    modal.appendChild(targetBox);

    var footer = document.createElement('div');
    footer.className = 'claude-move-footer';
    modal.appendChild(footer);

    // Порядок: [Скопировать] (зелёная) — [Перенести] (синяя) —
    // [Отмена] (ghost). Увеличенный gap между ними через
    // .claude-move-footer-spaced (см. claude-custom.css).
    footer.classList.add('claude-move-footer-spaced');

    var copyBtn = document.createElement('button');
    copyBtn.className = 'claude-move-new-btn claude-move-copy';
    copyBtn.textContent = 'Скопировать';
    copyBtn.setAttribute('type', 'button');
    copyBtn.setAttribute('title',
      'Создать копию сессии в выбранном проекте (с новым UUID); исходная остаётся на месте');
    copyBtn.addEventListener('click', function () {
      copySession(sessionId, targetEncoded);
    });
    footer.appendChild(copyBtn);

    var confirmBtn = document.createElement('button');
    confirmBtn.className = 'claude-move-new-btn';
    confirmBtn.textContent = 'Перенести';
    confirmBtn.setAttribute('type', 'button');
    confirmBtn.addEventListener('click', function () {
      moveSession(sessionId, targetEncoded);
    });
    footer.appendChild(confirmBtn);

    var backBtn = document.createElement('button');
    backBtn.className = 'claude-move-cancel claude-move-ghost';
    backBtn.textContent = 'Отмена';
    backBtn.setAttribute('type', 'button');
    backBtn.addEventListener('click', function () {
      // Возвращаемся к списку проектов — перерисовываем модалку заново
      // через openMoveDialog. Это удалит overlay и создаст новый,
      // что приведёт к повторной загрузке списка.
      closeMoveDialog();
      openMoveDialog(sessionId, sessionName);
    });
    footer.appendChild(backBtn);
  }

  /** Копирует сессию в другой проект через POST /copy-session.
   * В отличие от moveSession, исходная сессия остаётся на месте,
   * а у копии новый UUID. */
  function copySession(sessionId, targetEncoded) {
    setBusy(true);
    fetch(API_BASE + '/copy-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: sessionId, target_project: targetEncoded }),
    })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) {
          alert('Ошибка копирования: ' + ((res.body && res.body.error) || 'unknown'));
          setBusy(false);
          return;
        }
        logInfo('copied', res.body);
        sendDiag('copy-success', {
          sessionId: sessionId,
          newSessionId: res.body && res.body.new_session_id,
        });
        // Список текущего проекта не меняется (исходная сессия осталась),
        // поэтому signal-refresh не нужен. Показываем success-тост,
        // refreshMethod='signal' чтобы не предлагать Reload Window.
        showCopySuccessToast(targetEncoded, res.body && res.body.new_session_id);
      })
      .catch(function (err) {
        alert('Сетевая ошибка: ' + ((err && err.message) || err));
        setBusy(false);
      });
  }

  function showCopySuccessToast(targetEncoded, newSessionId) {
    var overlay = document.getElementById('claude-move-overlay');
    if (!overlay) return;
    var modal = overlay.querySelector('.claude-move-modal');
    if (!modal) return;
    modal.innerHTML = '';
    modal.classList.add('claude-move-success');

    var h = document.createElement('div');
    h.className = 'claude-move-header';
    h.textContent = '✓ Сессия скопирована';
    modal.appendChild(h);

    var sub = document.createElement('div');
    sub.className = 'claude-move-subheader';
    sub.textContent = 'В проект: ' + targetEncoded;
    modal.appendChild(sub);

    if (newSessionId) {
      var sid = document.createElement('div');
      sid.className = 'claude-move-sid';
      sid.textContent = 'Новый ID: ' + newSessionId;
      modal.appendChild(sid);
    }

    var hint = document.createElement('div');
    hint.className = 'claude-move-hint';
    hint.textContent = 'Исходная сессия осталась на месте. ' +
      'Чтобы открыть копию в её проекте — переключитесь туда (откройте папку в VSCode).';
    modal.appendChild(hint);

    var footer = document.createElement('div');
    footer.className = 'claude-move-footer';
    modal.appendChild(footer);

    var okBtn = document.createElement('button');
    okBtn.className = 'claude-move-cancel';
    okBtn.textContent = 'Закрыть';
    okBtn.setAttribute('type', 'button');
    okBtn.addEventListener('click', closeMoveDialog);
    footer.appendChild(okBtn);

    overlay.classList.remove('claude-move-busy');
  }

  function moveSession(sessionId, targetEncoded) {
    setBusy(true);
    fetch(API_BASE + '/move-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: sessionId, target_project: targetEncoded }),
    })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) {
          alert('Ошибка переноса: ' + ((res.body && res.body.error) || 'unknown'));
          setBusy(false);
          return;
        }
        logInfo('moved', res.body);
        // Пытаемся обновить список сразу: убрать перенесённую сессию
        // из React signal-store, минуя reload window (он ломает webview).
        var refreshed = tryRefreshList(sessionId);
        sendDiag('move-success', { sessionId: sessionId, refreshed: refreshed });
        var sourceProject = res.body && res.body.source_project;
        showSuccessToast(targetEncoded, refreshed, sessionId, sourceProject);
      })
      .catch(function (err) {
        alert('Сетевая ошибка: ' + ((err && err.message) || err));
        setBusy(false);
      });
  }

  // ---- Авто-обновление списка сессий после переноса ----
  //
  // Самый чистый способ — попросить React signal-store удалить
  // перенесённую сессию из массива `sessions.value`. Если по какой-то
  // причине обнаружить store не удалось, fallback — программный клик
  // по табу Web → Local, который заставляет панель перерисоваться.

  function findReactRootFiberLocal() {
    var rootEl = document.getElementById('root');
    if (!rootEl) return null;
    var keys = Object.keys(rootEl);
    for (var i = 0; i < keys.length; i++) {
      if (keys[i].indexOf('__reactContainer$') === 0) {
        var container = rootEl[keys[i]];
        if (container && container.stateNode && container.stateNode.current) {
          return container.stateNode.current;
        }
        if (container && container.current) return container.current;
        return container;
      }
    }
    return null;
  }

  function walkFibersLocal(rootFiber, visit) {
    if (!rootFiber) return;
    var stack = [rootFiber];
    var visited = new Set();
    while (stack.length) {
      var fiber = stack.pop();
      if (!fiber || visited.has(fiber)) continue;
      visited.add(fiber);
      if (visit(fiber) === true) return;
      if (fiber.child) stack.push(fiber.child);
      if (fiber.sibling) stack.push(fiber.sibling);
    }
  }

  /** Ищет signal `sessions` со списком сессий проекта. Признак —
   * объект-родитель имеет и `sessions`, и `activeSession`, где
   * `sessions.value` — массив, а в каждом элементе массива есть
   * `sessionId.value` (UUID). */
  function findSessionsSignal() {
    var rootFiber = findReactRootFiberLocal();
    if (!rootFiber) return null;
    var found = null;
    walkFibersLocal(rootFiber, function (fiber) {
      var sources = [fiber.memoizedProps, fiber.memoizedState, fiber.stateNode];
      for (var i = 0; i < sources.length; i++) {
        var c = sources[i];
        if (!c || typeof c !== 'object') continue;
        var container = null;
        if ('sessions' in c && 'activeSession' in c) container = c;
        else if (c.context && typeof c.context === 'object' &&
                 'sessions' in c.context && 'activeSession' in c.context) {
          container = c.context;
        }
        if (!container) continue;
        var sig = container.sessions;
        if (sig && typeof sig === 'object' && 'value' in sig &&
            Array.isArray(sig.value)) {
          // Доп. валидация: элементы массива должны выглядеть как сессии
          var v = sig.value;
          if (v.length === 0 ||
              (v[0] && v[0].sessionId && 'value' in v[0].sessionId)) {
            found = sig;
            return true;
          }
        }
      }
    });
    return found;
  }

  /** Программный клик Web → Local — fallback если signal не найден. */
  function tabTrick() {
    var segmented = document.querySelector('[class*="segmented_"]');
    if (!segmented) return false;
    var tabs = segmented.querySelectorAll('button, [role="tab"]');
    if (tabs.length < 2) return false;
    var activeIdx = -1, otherIdx = -1;
    for (var i = 0; i < tabs.length; i++) {
      var cn = tabs[i].className || '';
      if (cn.indexOf('tabActive_') >= 0 || cn.indexOf('active_') >= 0) activeIdx = i;
      else if (otherIdx < 0) otherIdx = i;
    }
    if (activeIdx < 0 || otherIdx < 0) return false;
    try {
      tabs[otherIdx].click();
      setTimeout(function () { try { tabs[activeIdx].click(); } catch (e) {} }, 80);
      return true;
    } catch (e) { return false; }
  }

  /** Главный обработчик авто-обновления. Возвращает строку с
   * описанием способа: 'signal' | 'tab' | 'none'. */
  function tryRefreshList(removedSessionId) {
    try {
      var sig = findSessionsSignal();
      if (sig) {
        var filtered = sig.value.filter(function (s) {
          return !(s && s.sessionId && s.sessionId.value === removedSessionId);
        });
        if (filtered.length !== sig.value.length) {
          sig.value = filtered; // signal setter — триггер ре-рендера
          return 'signal';
        }
      }
    } catch (e) {
      sendDiag('refresh-signal-error', { err: String(e) });
    }
    try {
      if (tabTrick()) return 'tab';
    } catch (e) {
      sendDiag('refresh-tab-error', { err: String(e) });
    }
    return 'none';
  }

  /** Показывает экран успеха в той же модалке.
   *
   * Раньше после переноса вызывали window.location.reload() — это ломало
   * webview Claude Code (после reload панель оставалась пустой, потому
   * что webview теряет связь с extension host).
   *
   * Теперь модалка превращается в success-сообщение с просьбой
   * закрыть/открыть панель Claude Code (или сделать Reload Window),
   * чтобы расширение перечитало список сессий из ~/.claude/projects/.
   */
  function showSuccessToast(targetEncoded, refreshMethod, sessionId, sourceProject) {
    // sourceProject больше не используется в этом тосте — отмена
    // переноса теперь происходит через confirmation-диалог *до* фактического
    // переноса (см. showConfirmMove), а не после.
    void sourceProject;

    var overlay = document.getElementById('claude-move-overlay');
    if (!overlay) return;
    var modal = overlay.querySelector('.claude-move-modal');
    if (!modal) return;
    modal.innerHTML = '';
    modal.classList.add('claude-move-success');

    var h = document.createElement('div');
    h.className = 'claude-move-header';
    h.textContent = '✓ Сессия перенесена';
    modal.appendChild(h);

    var sub = document.createElement('div');
    sub.className = 'claude-move-subheader';
    sub.textContent = 'В проект: ' + targetEncoded;
    modal.appendChild(sub);

    var hint = document.createElement('div');
    hint.className = 'claude-move-hint';
    if (refreshMethod === 'signal' || refreshMethod === 'tab') {
      hint.textContent = 'Список сессий обновлён автоматически.';
    } else {
      hint.textContent = 'Не удалось автоматически обновить список. ' +
        'Сделайте Developer: Reload Window — сессия точно перенесена ' +
        'на диск, после reload список перечитается.';
    }
    modal.appendChild(hint);

    var footer = document.createElement('div');
    footer.className = 'claude-move-footer';
    modal.appendChild(footer);

    if (refreshMethod !== 'signal' && refreshMethod !== 'tab') {
      var reloadBtn = document.createElement('button');
      reloadBtn.className = 'claude-move-new-btn';
      reloadBtn.textContent = 'Reload Window';
      reloadBtn.setAttribute('type', 'button');
      reloadBtn.addEventListener('click', function () {
        try { window.location.reload(); } catch (e) {}
      });
      footer.appendChild(reloadBtn);
    }

    var okBtn = document.createElement('button');
    okBtn.className = 'claude-move-cancel';
    okBtn.textContent = 'Закрыть';
    okBtn.setAttribute('type', 'button');
    okBtn.addEventListener('click', closeMoveDialog);
    footer.appendChild(okBtn);

    overlay.classList.remove('claude-move-busy');
  }

  /** Обратный перенос: возвращает сессию в исходный проект.
   * Используется кнопкой «Отменить» в success-тосте. */
  function undoMove(sessionId, sourceProject, btn) {
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Возврат...';
    }
    setBusy(true);
    fetch(API_BASE + '/move-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: sessionId, target_project: sourceProject }),
    })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) {
          alert('Не удалось отменить: ' + ((res.body && res.body.error) || 'unknown'));
          if (btn) { btn.disabled = false; btn.textContent = 'Отменить'; }
          setBusy(false);
          return;
        }
        logInfo('undo done', res.body);
        sendDiag('undo-success', { sessionId: sessionId });
        // Перерисуем тост: показываем что вернули, без дальнейшего undo
        showUndoneToast(sourceProject);
      })
      .catch(function (err) {
        alert('Сетевая ошибка при отмене: ' + ((err && err.message) || err));
        if (btn) { btn.disabled = false; btn.textContent = 'Отменить'; }
        setBusy(false);
      });
  }

  function showUndoneToast(returnedTo) {
    var overlay = document.getElementById('claude-move-overlay');
    if (!overlay) return;
    var modal = overlay.querySelector('.claude-move-modal');
    if (!modal) return;
    modal.innerHTML = '';
    // Без класса 'claude-move-success' — нейтральный вид

    var h = document.createElement('div');
    h.className = 'claude-move-header';
    h.textContent = '↶ Перенос отменён';
    modal.appendChild(h);

    var sub = document.createElement('div');
    sub.className = 'claude-move-subheader';
    sub.textContent = 'Сессия возвращена в: ' + returnedTo;
    modal.appendChild(sub);

    var footer = document.createElement('div');
    footer.className = 'claude-move-footer';
    modal.appendChild(footer);

    var reloadBtn = document.createElement('button');
    reloadBtn.className = 'claude-move-new-btn';
    reloadBtn.textContent = 'Reload Window';
    reloadBtn.setAttribute('type', 'button');
    reloadBtn.setAttribute('title',
      'Чтобы вернувшаяся сессия снова появилась в списке этого проекта');
    reloadBtn.addEventListener('click', function () {
      try { window.location.reload(); } catch (e) {}
    });
    footer.appendChild(reloadBtn);

    var okBtn = document.createElement('button');
    okBtn.className = 'claude-move-cancel';
    okBtn.textContent = 'Закрыть';
    okBtn.setAttribute('type', 'button');
    okBtn.addEventListener('click', closeMoveDialog);
    footer.appendChild(okBtn);

    overlay.classList.remove('claude-move-busy');
  }

  function createProjectAndMove(sessionId, absPath) {
    setBusy(true);
    fetch(API_BASE + '/create-project', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: absPath }),
    })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) {
          alert('Не удалось создать проект: ' + ((res.body && res.body.error) || 'unknown'));
          setBusy(false);
          return;
        }
        logInfo('project created', res.body);
        // Серверу target_path передавать не нужно: при /create-project
        // он уже записал .cwd в новую папку, /move-session прочитает.
        moveSession(sessionId, res.body.encoded_name);
      })
      .catch(function (err) {
        alert('Сетевая ошибка: ' + ((err && err.message) || err));
        setBusy(false);
      });
  }

  function init() {
    sendDiag('init', { readyState: document.readyState, hasBody: !!document.body });
    // Свой наблюдатель и свой таймер-подстраховка заменены общими —
    // см. DOM WATCH. Первый скан делает сама регистрация.
    window.__claudeDomWatch.register('session-mover', scanSessionItems);
    logInfo('installed');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * EMOJI CATALOG — данные смайликов для picker'а и автозамены
 * ============================================================
 *
 * Компактный формат хранения: одна строка на категорию, элементы
 * разделены `|`, внутри элемента поля разделены пробелом:
 *
 *     <символ> <shortcode> <ключевое слово> <ключевое слово> ...
 *
 * Первое поле — сам эмодзи, второе — латинский shortcode (по нему
 * работает автозамена вида `:rocket:`), остальные — ключевые слова
 * для поиска (русские и английские). Все поля участвуют в поиске.
 *
 * Каталог регистрируется в `window.__claudeEmojiCatalog` независимо
 * от флагов конфига: им пользуются и EMOJI PICKER, и EMOJI AUTOREPLACE,
 * каждый из которых включается своим параметром.
 * ============================================================ */
(function () {
  if (window.__claudeEmojiCatalog) return;

  var RAW = [
    { id: 'smileys', name: 'Смайлы', icon: '😀', data:
      '😀 grinning улыбка радость smile happy|' +
      '😃 smiley улыбка радость open|' +
      '😄 laughing смех радость joy|' +
      '😁 beaming ухмылка зубы grin|' +
      '😆 grin_squint смех хохот laugh|' +
      '😅 sweat_smile нервный смех пот|' +
      '🤣 rofl хохот смех rolling|' +
      '😂 joy слёзы смех плачу tears|' +
      '🙂 slight_smile улыбка лёгкая|' +
      '🙃 upside_down перевёрнутый ирония|' +
      '😉 wink подмигивание флирт|' +
      '😊 blush смущение улыбка|' +
      '😇 innocent ангел нимб|' +
      '🥰 smiling_hearts влюблён сердечки love|' +
      '😍 heart_eyes влюблён восторг love|' +
      '🤩 star_struck звёзды восторг wow|' +
      '😘 kiss поцелуй воздушный|' +
      '😗 kissing поцелуй губы|' +
      '🥲 smile_tear улыбка слеза|' +
      '😋 yum вкусно язык tasty|' +
      '😛 tongue язык дразнить|' +
      '😜 winky_tongue язык подмигивание|' +
      '🤪 zany безумие дурачусь crazy|' +
      '😝 squint_tongue язык зажмурился|' +
      '🤑 money_mouth деньги доллар богатство|' +
      '🤗 hug обнимаю объятия hugs|' +
      '🤭 hand_over_mouth ой упс oops|' +
      '🤫 shush тише секрет quiet|' +
      '🤔 thinking думаю размышляю hmm|' +
      '🤐 zipper молчу рот закрыт|' +
      '🤨 raised_eyebrow бровь скепсис|' +
      '😐 neutral нейтрально безразлично|' +
      '😑 expressionless без эмоций|' +
      '😶 no_mouth без рта молчание|' +
      '😏 smirk ухмылка хитрость|' +
      '😒 unamused недовольство скука|' +
      '🙄 roll_eyes закатываю глаза|' +
      '😬 grimace неловко гримаса|' +
      '🤥 lying врёт нос ложь|' +
      '😌 relieved облегчение спокойствие|' +
      '😔 pensive грусть печаль sad|' +
      '😪 sleepy сонный устал|' +
      '🤤 drooling слюни|' +
      '😴 sleeping сплю сон zzz|' +
      '😷 mask маска болезнь|' +
      '🤒 thermometer температура болен|' +
      '🤕 head_bandage травма бинт|' +
      '🤢 nauseated тошнит|' +
      '🤮 vomiting рвота|' +
      '🤧 sneezing чихаю|' +
      '🥵 hot_face жарко жара|' +
      '🥶 cold_face холодно мороз|' +
      '🥴 woozy пьяный головокружение|' +
      '😵 dizzy_face без сознания|' +
      '🤯 exploding_head взрыв мозга шок|' +
      '🤠 cowboy ковбой шляпа|' +
      '🥳 partying праздник вечеринка party|' +
      '😎 sunglasses крутой очки cool|' +
      '🤓 nerd ботаник очки|' +
      '🧐 monocle монокль изучаю|' +
      '😕 confused растерянность|' +
      '😟 worried беспокойство|' +
      '🙁 slight_frown грусть|' +
      '😮 open_mouth удивление wow|' +
      '😯 hushed удивление|' +
      '😲 astonished шок изумление|' +
      '😳 flushed смущение краснею|' +
      '🥺 pleading умоляю прошу|' +
      '😦 frowning хмурюсь|' +
      '😨 fearful страх испуг|' +
      '😰 anxious тревога пот|' +
      '😢 cry плачу слеза sad|' +
      '😭 sob рыдаю плач|' +
      '😱 scream крик ужас|' +
      '😖 confounded мучение|' +
      '😣 persevere терплю|' +
      '😞 disappointed разочарование|' +
      '😩 weary устал|' +
      '😫 tired измотан|' +
      '🥱 yawning зевота скука|' +
      '😤 triumph злость пар|' +
      '😡 rage ярость злой angry|' +
      '😠 angry злой сердитый|' +
      '🤬 cursing ругань мат|' +
      '😈 smiling_imp чертёнок озорство|' +
      '👿 imp чёрт злой|' +
      '💀 skull череп смерть dead|' +
      '💩 poop какашка|' +
      '🤡 clown клоун|' +
      '👻 ghost привидение|' +
      '👽 alien пришелец|' +
      '🤖 robot робот бот|' +
      '😺 smiley_cat кот улыбка|' +
      '😻 heart_eyes_cat кот влюблён'
    },
    { id: 'gestures', name: 'Жесты', icon: '👍', data:
      '👍 thumbsup лайк класс отлично like|' +
      '👎 thumbsdown дизлайк плохо|' +
      '👌 ok_hand окей отлично|' +
      '🤌 pinched щепотка|' +
      '✌️ victory виктория мир|' +
      '🤞 crossed_fingers удача скрещенные|' +
      '🤟 love_you люблю жест|' +
      '🤘 horns рок коза|' +
      '🤙 call_me звони|' +
      '👈 point_left влево|' +
      '👉 point_right вправо|' +
      '👆 point_up вверх|' +
      '👇 point_down вниз|' +
      '☝️ index_up вверх один|' +
      '✋ raised_hand ладонь стоп|' +
      '🤚 back_hand ладонь|' +
      '🖐️ hand_splayed ладонь пальцы|' +
      '🖖 vulcan вулкан спок|' +
      '👋 wave привет пока hello|' +
      '🤝 handshake рукопожатие договор deal|' +
      '🙏 pray спасибо молитва пожалуйста thanks|' +
      '✍️ writing пишу рука|' +
      '💪 muscle сила бицепс мощь|' +
      '🦾 mechanical_arm протез сила|' +
      '👏 clap аплодисменты браво|' +
      '🙌 raising_hands ура руки победа|' +
      '👐 open_hands ладони|' +
      '🤲 palms_up прошу|' +
      '🫶 heart_hands сердечко руками|' +
      '🤦 facepalm рукалицо фейспалм|' +
      '🤷 shrug пожимаю плечами не знаю|' +
      '🙋 raising_hand поднял руку вопрос|' +
      '🙆 ok_person окей жест|' +
      '🙅 no_good нельзя нет|' +
      '💁 tipping_hand информация|' +
      '🫡 salute отдаю честь|' +
      '🧑‍💻 technologist программист разработчик coder|' +
      '👨‍💻 man_technologist программист разработчик|' +
      '👩‍💻 woman_technologist программистка разработчица|' +
      '🕵️ detective детектив расследование|' +
      '👀 eyes глаза смотрю внимание look|' +
      '👁️ eye глаз|' +
      '🧠 brain мозг ум'
    },
    { id: 'nature', name: 'Природа', icon: '🌿', data:
      '🐶 dog собака пёс|' +
      '🐱 cat кот кошка|' +
      '🐭 mouse мышь|' +
      '🐹 hamster хомяк|' +
      '🐰 rabbit кролик заяц|' +
      '🦊 fox лиса|' +
      '🐻 bear медведь|' +
      '🐼 panda панда|' +
      '🐨 koala коала|' +
      '🐯 tiger тигр|' +
      '🦁 lion лев|' +
      '🐮 cow корова|' +
      '🐷 pig свинья|' +
      '🐸 frog лягушка|' +
      '🐵 monkey обезьяна|' +
      '🙈 see_no_evil обезьяна не вижу|' +
      '🙉 hear_no_evil обезьяна не слышу|' +
      '🙊 speak_no_evil обезьяна молчу|' +
      '🐔 chicken курица|' +
      '🐧 penguin пингвин|' +
      '🐦 bird птица|' +
      '🦆 duck утка|' +
      '🦉 owl сова|' +
      '🐺 wolf волк|' +
      '🐴 horse лошадь|' +
      '🦄 unicorn единорог|' +
      '🐝 bee пчела|' +
      '🐛 caterpillar гусеница червяк|' +
      '🦋 butterfly бабочка|' +
      '🐌 snail улитка|' +
      '🐞 lady_beetle божья коровка|' +
      '🐜 ant муравей|' +
      '🕷️ spider паук|' +
      '🐢 turtle черепаха|' +
      '🐍 snake змея питон python|' +
      '🦎 lizard ящерица|' +
      '🐙 octopus осьминог|' +
      '🦐 shrimp креветка|' +
      '🐬 dolphin дельфин|' +
      '🐳 whale кит|' +
      '🐟 fish рыба|' +
      '🦈 shark акула|' +
      '🐊 crocodile крокодил|' +
      '🐘 elephant слон|' +
      '🦒 giraffe жираф|' +
      '🌵 cactus кактус|' +
      '🌲 evergreen ёлка дерево|' +
      '🌳 tree дерево|' +
      '🌴 palm пальма|' +
      '🌱 seedling росток|' +
      '🌿 herb трава зелень|' +
      '🍀 clover клевер удача|' +
      '🍁 maple_leaf лист клён|' +
      '🍂 fallen_leaves листья осень|' +
      '🌷 tulip тюльпан|' +
      '🌹 rose роза|' +
      '🌺 hibiscus цветок|' +
      '🌻 sunflower подсолнух|' +
      '💐 bouquet букет|' +
      '🌸 cherry_blossom сакура цветение|' +
      '☀️ sunny солнце ясно|' +
      '🌤️ sun_small_cloud солнце облака|' +
      '⛅ partly_cloudy облачно|' +
      '☁️ cloud облако|' +
      '🌧️ rain дождь|' +
      '⛈️ thunderstorm гроза|' +
      '❄️ snowflake снежинка снег|' +
      '⛄ snowman снеговик|' +
      '🔥 fire огонь пожар горит|' +
      '💧 droplet капля вода|' +
      '🌊 ocean волна море|' +
      '🌈 rainbow радуга|' +
      '⭐ star звезда|' +
      '🌟 glowing_star звезда сияние|' +
      '✨ sparkles искры блеск магия|' +
      '⚡ zap молния энергия быстро|' +
      '🌙 crescent_moon луна ночь|' +
      '🌍 earth земля планета мир|' +
      '🪐 planet планета сатурн'
    },
    { id: 'food', name: 'Еда', icon: '🍎', data:
      '🍎 apple яблоко|' +
      '🍐 pear груша|' +
      '🍊 tangerine мандарин апельсин|' +
      '🍋 lemon лимон|' +
      '🍌 banana банан|' +
      '🍉 watermelon арбуз|' +
      '🍇 grapes виноград|' +
      '🍓 strawberry клубника|' +
      '🫐 blueberries черника|' +
      '🍒 cherries вишня черешня|' +
      '🍑 peach персик|' +
      '🥭 mango манго|' +
      '🍍 pineapple ананас|' +
      '🥥 coconut кокос|' +
      '🥝 kiwi киви|' +
      '🍅 tomato помидор|' +
      '🥑 avocado авокадо|' +
      '🍆 eggplant баклажан|' +
      '🥔 potato картошка|' +
      '🥕 carrot морковь|' +
      '🌽 corn кукуруза|' +
      '🌶️ hot_pepper перец острый|' +
      '🥒 cucumber огурец|' +
      '🥬 leafy_green салат|' +
      '🥦 broccoli брокколи|' +
      '🧄 garlic чеснок|' +
      '🧅 onion лук|' +
      '🍄 mushroom гриб|' +
      '🥜 peanuts арахис орехи|' +
      '🍞 bread хлеб|' +
      '🥐 croissant круассан|' +
      '🥖 baguette багет|' +
      '🥨 pretzel крендель|' +
      '🧀 cheese сыр|' +
      '🥚 egg яйцо|' +
      '🍳 cooking яичница готовка|' +
      '🥞 pancakes блины|' +
      '🧇 waffle вафля|' +
      '🥓 bacon бекон|' +
      '🍔 hamburger бургер|' +
      '🍟 fries картошка фри|' +
      '🍕 pizza пицца|' +
      '🌭 hotdog хотдог|' +
      '🥪 sandwich сэндвич|' +
      '🌮 taco тако|' +
      '🌯 burrito буррито|' +
      '🥗 salad салат|' +
      '🍝 spaghetti паста макароны|' +
      '🍜 ramen рамен лапша|' +
      '🍲 stew суп|' +
      '🍣 sushi суши|' +
      '🍤 fried_shrimp креветка|' +
      '🍚 rice рис|' +
      '🍦 ice_cream мороженое|' +
      '🍩 doughnut пончик|' +
      '🍪 cookie печенье|' +
      '🎂 birthday торт день рождения|' +
      '🍰 cake пирожное торт|' +
      '🍫 chocolate шоколад|' +
      '🍬 candy конфета|' +
      '🍭 lollipop леденец|' +
      '🍯 honey мёд|' +
      '🥛 milk молоко|' +
      '☕ coffee кофе|' +
      '🍵 tea чай|' +
      '🧃 juice сок|' +
      '🥤 cup_straw напиток|' +
      '🍺 beer пиво|' +
      '🍻 beers пиво тост|' +
      '🍷 wine вино|' +
      '🥂 champagne шампанское тост|' +
      '🍾 bottle_pop шампанское праздник|' +
      '🥃 whisky виски|' +
      '🧊 ice лёд'
    },
    { id: 'activity', name: 'Активность', icon: '⚽', data:
      '⚽ soccer футбол мяч|' +
      '🏀 basketball баскетбол|' +
      '🏈 football американский футбол|' +
      '⚾ baseball бейсбол|' +
      '🎾 tennis теннис|' +
      '🏐 volleyball волейбол|' +
      '🎱 pool бильярд|' +
      '🏓 ping_pong пинг понг|' +
      '🏸 badminton бадминтон|' +
      '🥊 boxing бокс|' +
      '🥋 martial_arts кимоно|' +
      '⛳ golf гольф|' +
      '🏹 bow_arrow лук стрела|' +
      '🎣 fishing рыбалка|' +
      '🏂 snowboard сноуборд|' +
      '⛷️ ski лыжи|' +
      '🏄 surfing сёрфинг|' +
      '🏊 swimming плавание|' +
      '🚴 cycling велосипед|' +
      '🏃 running бег|' +
      '🧗 climbing скалолазание|' +
      '🏆 trophy кубок победа|' +
      '🥇 gold_medal медаль первое место|' +
      '🥈 silver_medal медаль второе|' +
      '🥉 bronze_medal медаль третье|' +
      '🎖️ medal награда|' +
      '🎯 dart цель дартс точно|' +
      '🎮 video_game игра геймпад|' +
      '🕹️ joystick джойстик|' +
      '🎲 dice кубик игра|' +
      '🧩 puzzle пазл головоломка|' +
      '🎨 art искусство палитра|' +
      '🎭 performing театр маски|' +
      '🎤 microphone микрофон караоке|' +
      '🎧 headphones наушники музыка|' +
      '🎵 note нота музыка|' +
      '🎶 notes музыка ноты|' +
      '🎸 guitar гитара|' +
      '🎹 piano пианино|' +
      '🥁 drum барабан|' +
      '🎺 trumpet труба|' +
      '🎻 violin скрипка|' +
      '🎬 clapper кино хлопушка|' +
      '🎉 tada праздник ура поздравляю party|' +
      '🎊 confetti конфетти праздник|' +
      '🎈 balloon шарик|' +
      '🎁 gift подарок|' +
      '🎃 jack_o_lantern тыква хэллоуин|' +
      '🎄 christmas_tree ёлка новый год'
    },
    { id: 'travel', name: 'Транспорт', icon: '🚗', data:
      '🚗 car машина авто|' +
      '🚕 taxi такси|' +
      '🚙 suv внедорожник|' +
      '🚌 bus автобус|' +
      '🏎️ racing_car гонка болид|' +
      '🚓 police_car полиция|' +
      '🚑 ambulance скорая|' +
      '🚒 fire_engine пожарная|' +
      '🚚 truck грузовик|' +
      '🚜 tractor трактор|' +
      '🛴 scooter самокат|' +
      '🚲 bike велосипед|' +
      '🏍️ motorcycle мотоцикл|' +
      '✈️ airplane самолёт полёт|' +
      '🚀 rocket ракета запуск релиз|' +
      '🛸 ufo нло|' +
      '🚁 helicopter вертолёт|' +
      '⛵ sailboat парусник|' +
      '🚤 speedboat катер|' +
      '🛳️ ship корабль|' +
      '🚂 locomotive поезд паровоз|' +
      '🚆 train электричка|' +
      '🚇 metro метро|' +
      '🗺️ map карта|' +
      '🧭 compass компас|' +
      '🏔️ mountain гора|' +
      '🌋 volcano вулкан|' +
      '🏕️ camping кемпинг палатка|' +
      '🏖️ beach пляж|' +
      '🏝️ island остров|' +
      '🏠 house дом|' +
      '🏡 house_garden дом сад|' +
      '🏢 office офис здание|' +
      '🏥 hospital больница|' +
      '🏦 bank банк|' +
      '🏨 hotel отель|' +
      '🏫 school школа|' +
      '🗼 tower башня|' +
      '🏰 castle замок|' +
      '🌃 night_city ночь город|' +
      '🌉 bridge мост|' +
      '🎡 ferris_wheel колесо обозрения'
    },
    { id: 'objects', name: 'Объекты', icon: '💻', data:
      '💻 laptop ноутбук компьютер computer|' +
      '🖥️ desktop монитор компьютер|' +
      '⌨️ keyboard клавиатура|' +
      '🖱️ computer_mouse мышь|' +
      '🖨️ printer принтер|' +
      '💾 floppy дискета сохранить save|' +
      '💿 cd диск|' +
      '🔌 plug розетка питание|' +
      '🔋 battery батарея заряд|' +
      '📱 mobile телефон смартфон|' +
      '☎️ telephone телефон|' +
      '📞 receiver трубка звонок|' +
      '📷 camera фото камера|' +
      '📹 video_camera видеокамера|' +
      '🎥 movie_camera камера кино|' +
      '📺 tv телевизор|' +
      '📻 radio радио|' +
      '🎙️ studio_mic микрофон подкаст|' +
      '⏱️ stopwatch секундомер время|' +
      '⏰ alarm_clock будильник время|' +
      '⌛ hourglass песочные часы ожидание|' +
      '🔦 flashlight фонарь|' +
      '💡 bulb идея лампочка idea|' +
      '🕯️ candle свеча|' +
      '🧯 extinguisher огнетушитель|' +
      '💸 money_wings деньги улетели расход|' +
      '💵 dollar доллар деньги|' +
      '💰 moneybag мешок денег|' +
      '💳 credit_card карта оплата|' +
      '🧾 receipt чек счёт|' +
      '⚖️ balance весы баланс|' +
      '🔧 wrench ключ инструмент фикс fix|' +
      '🔨 hammer молоток|' +
      '🛠️ tools инструменты настройка|' +
      '⚙️ gear шестерня настройки config|' +
      '🧰 toolbox ящик инструментов|' +
      '🧲 magnet магнит|' +
      '🔩 nut_bolt болт гайка|' +
      '⛓️ chains цепи|' +
      '🔒 lock замок закрыто secure|' +
      '🔓 unlock открыто замок|' +
      '🔑 key ключ|' +
      '🚪 door дверь|' +
      '🛏️ bed кровать|' +
      '🚿 shower душ|' +
      '🧹 broom метла уборка cleanup|' +
      '🧼 soap мыло|' +
      '🪣 bucket ведро|' +
      '📦 package пакет коробка сборка build|' +
      '📫 mailbox почта ящик|' +
      '📧 email почта письмо|' +
      '📤 outbox исходящие|' +
      '📥 inbox входящие|' +
      '📜 scroll свиток документ|' +
      '📄 page документ файл file|' +
      '📊 bar_chart график диаграмма статистика|' +
      '📈 chart_up рост график вверх|' +
      '📉 chart_down падение график вниз|' +
      '📋 clipboard буфер планшет|' +
      '📌 pushpin кнопка закрепить|' +
      '📍 round_pushpin метка место|' +
      '📎 paperclip скрепка вложение|' +
      '📏 ruler линейка|' +
      '✂️ scissors ножницы вырезать|' +
      '🗄️ file_cabinet шкаф архив|' +
      '🗑️ wastebasket корзина удалить delete|' +
      '📁 folder папка каталог|' +
      '📂 open_folder папка открыта|' +
      '📅 calendar календарь дата|' +
      '📓 notebook блокнот тетрадь|' +
      '📕 closed_book книга|' +
      '📖 open_book книга чтение документация docs|' +
      '📚 books книги библиотека|' +
      '🔖 bookmark закладка|' +
      '🏷️ label ярлык тег tag|' +
      '🔍 mag лупа поиск search|' +
      '🔬 microscope микроскоп исследование|' +
      '🔭 telescope телескоп|' +
      '📡 satellite антенна спутник связь|' +
      '💊 pill таблетка|' +
      '🩺 stethoscope стетоскоп|' +
      '🧪 test_tube пробирка тест test|' +
      '🧬 dna днк|' +
      '🩹 bandage пластырь патч patch|' +
      '✏️ pencil карандаш|' +
      '🖊️ pen ручка|' +
      '🖌️ paintbrush кисть|' +
      '📝 memo заметка написать note'
    },
    { id: 'symbols', name: 'Символы', icon: '❤️', data:
      '❤️ heart сердце любовь красное|' +
      '🧡 orange_heart сердце оранжевое|' +
      '💛 yellow_heart сердце жёлтое|' +
      '💚 green_heart сердце зелёное|' +
      '💙 blue_heart сердце синее|' +
      '💜 purple_heart сердце фиолетовое|' +
      '🖤 black_heart сердце чёрное|' +
      '🤍 white_heart сердце белое|' +
      '💔 broken_heart разбитое сердце|' +
      '💕 two_hearts сердечки|' +
      '💖 sparkling_heart сердце блеск|' +
      '💘 heart_arrow стрела амур|' +
      '💝 heart_ribbon подарок сердце|' +
      '💯 hundred сто отлично точно|' +
      '💢 anger злость|' +
      '💥 boom взрыв бум|' +
      '💫 dizzy_star звёзды|' +
      '💦 sweat_drops капли|' +
      '💨 dash дым скорость|' +
      '✅ white_check_mark готово выполнено ок done|' +
      '☑️ ballot_check галочка чек|' +
      '✔️ check_mark галочка|' +
      '❌ x ошибка нет крест error fail|' +
      '⭕ o круг|' +
      '🚫 no_entry_sign запрет нельзя|' +
      '⛔ no_entry стоп запрет|' +
      '❗ exclamation восклицательный важно|' +
      '❓ question вопрос|' +
      '‼️ bangbang двойной восклицательный|' +
      '⚠️ warning внимание предупреждение осторожно|' +
      '☢️ radioactive радиация|' +
      '♻️ recycle переработка рефакторинг|' +
      '🔄 arrows_counterclockwise обновить синхронизация refresh|' +
      '▶️ play плей воспроизвести|' +
      '⏸️ pause пауза|' +
      '⏹️ stop стоп|' +
      '⏭️ next следующий|' +
      '⏮️ previous предыдущий|' +
      '⏩ fast_forward перемотка|' +
      '🔀 shuffle перемешать|' +
      '🔁 repeat повтор цикл|' +
      '⬆️ arrow_up вверх|' +
      '⬇️ arrow_down вниз|' +
      '⬅️ arrow_left влево|' +
      '➡️ arrow_right вправо|' +
      '↩️ arrow_back назад откат|' +
      '🔝 top наверх|' +
      '🆕 new новое|' +
      '🆗 ok_button окей|' +
      '🆘 sos помощь|' +
      '🔔 bell колокольчик уведомление|' +
      '🔕 no_bell без звука|' +
      '🔊 loud_sound звук громко|' +
      '🔇 mute без звука|' +
      '📢 loudspeaker объявление|' +
      '💬 speech_balloon сообщение чат комментарий|' +
      '💭 thought_balloon мысль|' +
      '♾️ infinity бесконечность|' +
      '⚛️ atom атом|' +
      '©️ copyright копирайт|' +
      '™️ tm торговая марка|' +
      '🔢 numbers цифры номера|' +
      '🔤 abc алфавит буквы'
    },
    { id: 'dev', name: 'Код', icon: '🚀', data:
      '🚀 deploy деплой релиз запуск|' +
      '🐛 bug баг ошибка дефект|' +
      '✅ done готово выполнено|' +
      '❌ fail провал ошибка|' +
      '⚠️ warn предупреждение|' +
      '🔧 fix фикс починка|' +
      '🔨 build сборка|' +
      '📦 release пакет релиз|' +
      '🧪 tests тесты|' +
      '🔍 review ревью поиск|' +
      '💡 idea идея|' +
      '📝 docs документация заметка|' +
      '🔥 hotfix горит срочно|' +
      '🎯 goal цель задача|' +
      '⏱️ perf производительность|' +
      '🧹 cleanup рефакторинг уборка|' +
      '🩹 hotpatch патч заплатка|' +
      '📈 metrics метрики рост|' +
      '💻 code код разработка|' +
      '⚙️ config конфиг настройки|' +
      '🔒 security безопасность|' +
      '🗑️ remove удалить|' +
      '🚧 wip в работе стройка|' +
      '🤖 automation бот автоматизация|' +
      '🎉 merged влито готово'
    }
  ];

  var categories = [];
  var byCode = {};
  var all = [];

  for (var i = 0; i < RAW.length; i++) {
    var raw = RAW[i];
    var parts = raw.data.split('|');
    var items = [];
    for (var j = 0; j < parts.length; j++) {
      var fields = parts[j].split(/\s+/).filter(function (s) { return s.length > 0; });
      if (fields.length < 2) continue;
      var kw = fields.slice(1).join(' ').toLowerCase();
      var item = {
        ch: fields[0],
        code: fields[1],
        // Строка для поиска: shortcode + все ключевые слова, нижним
        // регистром, чтобы search() не приводил регистр на каждый вызов.
        kw: kw,
        words: kw.split(' '),
      };
      items.push(item);
      all.push(item);
      // Первый встреченный shortcode выигрывает — категория `dev`
      // идёт последней и не перетирает канонические коды.
      if (!byCode[item.code]) byCode[item.code] = item.ch;
    }
    categories.push({ id: raw.id, name: raw.name, icon: raw.icon, items: items });
  }

  window.__claudeEmojiCatalog = {
    categories: categories,
    all: all,
    byCode: byCode,
    /**
     * Поиск по подстроке в shortcode и ключевых словах. Результат
     * ранжируется четырьмя корзинами, иначе запрос «баг» выдаёт
     * 🥖 (ба-гет) раньше 🐛:
     *   1. точное совпадение shortcode;
     *   2. точное совпадение любого ключевого слова;
     *   3. совпадение с начала слова;
     *   4. совпадение в середине слова.
     */
    search: function (query) {
      var q = String(query || '').trim().toLowerCase();
      if (!q) return [];
      var byShortcode = [];
      var byWord = [];
      var byPrefix = [];
      var rest = [];
      for (var k = 0; k < all.length; k++) {
        var it = all[k];
        if (it.code === q) { byShortcode.push(it); continue; }
        var pos = it.kw.indexOf(q);
        if (pos < 0) continue;
        if (it.words.indexOf(q) >= 0) byWord.push(it);
        else if (pos === 0 || it.kw.charAt(pos - 1) === ' ') byPrefix.push(it);
        else rest.push(it);
      }
      // Категория `dev` намеренно дублирует символы из других разделов
      // (🔧 wrench и 🔧 fix), поэтому в выдаче схлопываем по символу.
      var seen = {};
      return byShortcode.concat(byWord, byPrefix, rest).filter(function (it) {
        if (seen[it.ch]) return false;
        seen[it.ch] = true;
        return true;
      });
    },
  };
})();

/* ============================================================
 * EMOJI PICKER — кнопка 😀 в футере поля ввода чата
 * ============================================================
 *
 * Добавляет кнопку 😀 слева от кнопки микрофона, в правом верхнем
 * углу поля ввода (`.micButtonWrapper_*`); если диктовка отключена
 * и микрофона нет — в футер `.inputFooter_*` рядом с меню `/`.
 * Расположение выбирается в VSCode Settings UI пунктом
 * `claudeCode.emojiButtonPlacement` (mic | footer): значение приходит
 * в конфиг bootstrap, а смена подхватывается на лету опросом
 * http-server.py, без Reload Window.
 * По клику открывается панель: строка поиска, табы категорий,
 * сетка смайликов и блок «Недавние» (localStorage). Выбранный
 * смайлик вставляется в позицию каретки composer'а; сообщение при
 * этом НЕ отправляется — панель остаётся открытой, можно вставить
 * несколько подряд.
 *
 * Composer в Claude Code 2.x — `div[contenteditable="plaintext-only"]
 * [role="textbox"]`, а не textarea, и он React-controlled. Поэтому:
 *   - вставка идёт через document.execCommand('insertText'), который
 *     эмитит native input-event с корректным inputType (тот же приём,
 *     что в triggerSlashCommandViaInput);
 *   - на mousedown внутри панели вызывается preventDefault, чтобы
 *     фокус (и выделение) не уходили из composer'а;
 *   - позиция каретки дополнительно запоминается через
 *     selectionchange — на случай, когда фокус всё же ушёл
 *     (например, в поле поиска панели).
 *
 * React перерисовывает поле ввода, поэтому кнопка переустанавливается
 * по мутациям DOM и периодическим обходом — оба даёт общий
 * наблюдатель (см. DOM WATCH), у модуля своего больше нет.
 *
 * Управление: `emojiPicker` и `emojiRecentLimit` в
 * .claude/patches/claude-custom-config.toml, расположение кнопки —
 * `claudeCode.emojiButtonPlacement` в настройках VSCode.
 * ============================================================ */
(function () {
  if (window.__claudeEmojiPickerInstalled) return;
  window.__claudeEmojiPickerInstalled = true;

  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  if (cfg.emojiPicker !== true) return;

  var catalog = window.__claudeEmojiCatalog;
  if (!catalog) return;

  var RECENT_LIMIT =
    typeof cfg.emojiRecentLimit === 'number' && cfg.emojiRecentLimit >= 0
      ? cfg.emojiRecentLimit
      : 24;
  var RECENT_KEY = 'claudeCustomEmojiRecent';
  var BTN_CLASS = 'claude-emoji-btn';
  var PANEL_ID = 'claude-emoji-panel';

  // Расположение кнопки: 'mic' | 'footer'. Значение приходит из
  // VSCode Settings UI (claudeCode.emojiButtonPlacement) — хук
  // patch-claude-webview.py кладёт его в конфиг bootstrap. Но
  // bootstrap перечитывается только при Reload Window, поэтому
  // текущее значение дополнительно опрашивается у http-server.py:
  // так смена настройки применяется почти сразу, как и правки CSS.
  var PLACEMENT_URL = 'http://localhost:18923/vscode-settings';
  var PLACEMENT_POLL_MS = 5000;
  var placement = cfg.emojiButtonPlacement === 'footer' ? 'footer' : 'mic';

  var panel = null;          // корневой элемент панели (или null)
  var anchorBtn = null;      // кнопка 😀, относительно которой открыта панель
  var searchInput = null;
  var gridEl = null;
  var previewEl = null;
  var tabsEl = null;
  var activeCategory = null; // id категории или '__recent__'
  var activeIndex = -1;      // индекс подсвеченной ячейки в сетке
  var renderedItems = [];    // элементы, показанные в сетке сейчас
  var savedRange = null;     // последняя позиция каретки в composer'е

  function logInfo() {
    if (!cfg.logs) return;
    try {
      console.log.apply(console, ['[emoji-picker]'].concat([].slice.call(arguments)));
    } catch (e) {}
  }

  /* ---------- composer и каретка ---------- */

  function getComposer() {
    return (
      document.querySelector('[role="textbox"][contenteditable][aria-label*="essage" i]') ||
      document.querySelector('[role="textbox"][contenteditable]') ||
      document.querySelector('div[contenteditable]')
    );
  }

  /** Запоминает каретку, пока она находится внутри composer'а. */
  function rememberCaret() {
    var composer = getComposer();
    if (!composer) return;
    var sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    var range = sel.getRangeAt(0);
    if (!composer.contains(range.startContainer)) return;
    savedRange = range.cloneRange();
  }

  /** Ставит каретку в composer: сохранённая позиция или конец текста. */
  function restoreCaret(composer) {
    var sel = window.getSelection();
    if (!sel) return;
    if (savedRange && composer.contains(savedRange.startContainer)) {
      sel.removeAllRanges();
      sel.addRange(savedRange);
      return;
    }
    if (sel.rangeCount > 0 && composer.contains(sel.getRangeAt(0).startContainer)) {
      return; // каретка уже в composer'е — не двигаем
    }
    var range = document.createRange();
    range.selectNodeContents(composer);
    range.collapse(false); // в конец
    sel.removeAllRanges();
    sel.addRange(range);
  }

  /**
   * Вставляет символ в позицию каретки composer'а. Возвращает true,
   * если вставка удалась.
   */
  function insertEmoji(ch) {
    var composer = getComposer();
    if (!composer) {
      logInfo('composer не найден, вставка отменена');
      return false;
    }
    var searchWasFocused = !!searchInput && document.activeElement === searchInput;
    try {
      composer.focus();
      restoreCaret(composer);
      var inserted = document.execCommand('insertText', false, ch);
      if (!inserted) {
        // Fallback: ручная вставка текстового узла + синтетический
        // InputEvent, чтобы React-обработчик onInput увидел изменение.
        var sel = window.getSelection();
        if (sel && sel.rangeCount > 0) {
          var range = sel.getRangeAt(0);
          range.deleteContents();
          var node = document.createTextNode(ch);
          range.insertNode(node);
          range.setStartAfter(node);
          range.collapse(true);
          sel.removeAllRanges();
          sel.addRange(range);
        } else {
          composer.textContent = (composer.textContent || '') + ch;
        }
        composer.dispatchEvent(new InputEvent('input', {
          bubbles: true, cancelable: true, inputType: 'insertText', data: ch,
        }));
      }
      rememberCaret();
      pushRecent(ch);
      if (searchWasFocused) {
        // Клик мышью по ячейке при активном поиске: фокус возвращаем
        // в поле, чтобы можно было продолжить набирать запрос.
        searchInput.focus();
      }
      return true;
    } catch (e) {
      logInfo('вставка не удалась:', (e && e.message) || e);
      return false;
    }
  }

  /* ---------- недавние ---------- */

  function loadRecent() {
    if (RECENT_LIMIT === 0) return [];
    try {
      var raw = window.localStorage.getItem(RECENT_KEY);
      if (!raw) return [];
      var arr = JSON.parse(raw);
      if (!Array.isArray(arr)) return [];
      return arr.filter(function (s) { return typeof s === 'string' && s; })
        .slice(0, RECENT_LIMIT);
    } catch (e) {
      return [];
    }
  }

  function pushRecent(ch) {
    if (RECENT_LIMIT === 0) return;
    var recent = loadRecent().filter(function (s) { return s !== ch; });
    recent.unshift(ch);
    recent = recent.slice(0, RECENT_LIMIT);
    try {
      window.localStorage.setItem(RECENT_KEY, JSON.stringify(recent));
    } catch (e) {}
    // Если сейчас открыт таб «Недавние» — не перерисовываем сетку
    // прямо под курсором, иначе ячейки прыгают при серии вставок.
  }

  /** Находит описание смайлика по символу (для tooltip'а «недавних»). */
  function findByChar(ch) {
    for (var i = 0; i < catalog.all.length; i++) {
      if (catalog.all[i].ch === ch) return catalog.all[i];
    }
    return { ch: ch, code: '', kw: '' };
  }

  /* ---------- панель ---------- */

  function itemTitle(item) {
    return item.code ? ':' + item.code + ':  ' + item.kw : item.ch;
  }

  function renderGrid(items) {
    renderedItems = items;
    activeIndex = -1;
    gridEl.textContent = '';
    if (!items.length) {
      var empty = document.createElement('div');
      empty.className = 'claude-emoji-empty';
      empty.textContent = 'Ничего не найдено';
      gridEl.appendChild(empty);
      setPreview(null);
      return;
    }
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var cell = document.createElement('button');
      cell.type = 'button';
      cell.className = 'claude-emoji-cell';
      cell.textContent = item.ch;
      cell.title = itemTitle(item);
      cell.setAttribute('data-index', String(i));
      gridEl.appendChild(cell);
    }
    setPreview(items[0]);
  }

  function setPreview(item) {
    if (!previewEl) return;
    if (!item) {
      previewEl.textContent = '';
      return;
    }
    previewEl.textContent = '';
    var ch = document.createElement('span');
    ch.className = 'claude-emoji-preview-ch';
    ch.textContent = item.ch;
    var name = document.createElement('span');
    name.className = 'claude-emoji-preview-name';
    name.textContent = item.code ? ':' + item.code + ':' : '';
    previewEl.appendChild(ch);
    previewEl.appendChild(name);
  }

  function showCategory(id) {
    activeCategory = id;
    var tabs = tabsEl.querySelectorAll('.claude-emoji-tab');
    for (var i = 0; i < tabs.length; i++) {
      var isActive = tabs[i].getAttribute('data-cat') === id;
      tabs[i].classList.toggle('claude-emoji-tab-active', isActive);
    }
    if (id === '__recent__') {
      renderGrid(loadRecent().map(findByChar));
      return;
    }
    for (var j = 0; j < catalog.categories.length; j++) {
      if (catalog.categories[j].id === id) {
        renderGrid(catalog.categories[j].items);
        return;
      }
    }
  }

  function setActiveIndex(index) {
    var cells = gridEl.querySelectorAll('.claude-emoji-cell');
    if (!cells.length) return;
    if (index < 0) index = 0;
    if (index > cells.length - 1) index = cells.length - 1;
    for (var i = 0; i < cells.length; i++) {
      cells[i].classList.toggle('claude-emoji-cell-active', i === index);
    }
    activeIndex = index;
    cells[index].scrollIntoView({ block: 'nearest' });
    setPreview(renderedItems[index]);
  }

  /** Сколько ячеек помещается в строку — для навигации стрелками.
   * Считаем по фактическому переносу (offsetTop), а не делением
   * ширин: с учётом gap деление даёт погрешность в одну колонку. */
  function columnCount() {
    var cells = gridEl.querySelectorAll('.claude-emoji-cell');
    if (!cells.length) return 1;
    var firstTop = cells[0].offsetTop;
    var count = 0;
    for (var i = 0; i < cells.length; i++) {
      if (cells[i].offsetTop !== firstTop) break;
      count++;
    }
    return Math.max(1, count);
  }

  function buildPanel() {
    var root = document.createElement('div');
    root.id = PANEL_ID;
    root.className = 'claude-emoji-panel';

    var searchRow = document.createElement('div');
    searchRow.className = 'claude-emoji-search-row';
    searchInput = document.createElement('input');
    searchInput.type = 'text';
    searchInput.className = 'claude-emoji-search';
    searchInput.placeholder = 'Поиск: улыбка, rocket, баг…';
    searchInput.setAttribute('aria-label', 'Поиск смайлика');
    searchRow.appendChild(searchInput);
    root.appendChild(searchRow);

    tabsEl = document.createElement('div');
    tabsEl.className = 'claude-emoji-tabs';
    var tabDefs = [];
    if (RECENT_LIMIT > 0) {
      tabDefs.push({ id: '__recent__', icon: '🕘', name: 'Недавние' });
    }
    for (var i = 0; i < catalog.categories.length; i++) {
      tabDefs.push({
        id: catalog.categories[i].id,
        icon: catalog.categories[i].icon,
        name: catalog.categories[i].name,
      });
    }
    for (var j = 0; j < tabDefs.length; j++) {
      var tab = document.createElement('button');
      tab.type = 'button';
      tab.className = 'claude-emoji-tab';
      tab.textContent = tabDefs[j].icon;
      tab.title = tabDefs[j].name;
      tab.setAttribute('data-cat', tabDefs[j].id);
      tabsEl.appendChild(tab);
    }
    root.appendChild(tabsEl);

    gridEl = document.createElement('div');
    gridEl.className = 'claude-emoji-grid';
    root.appendChild(gridEl);

    previewEl = document.createElement('div');
    previewEl.className = 'claude-emoji-preview';
    root.appendChild(previewEl);

    // Фокус не должен уходить из composer'а при кликах по панели —
    // иначе теряется выделение и вставка уедет не туда. Исключение —
    // поле поиска, которому фокус как раз нужен.
    root.addEventListener('mousedown', function (e) {
      if (e.target === searchInput) return;
      e.preventDefault();
    });

    root.addEventListener('click', function (e) {
      var tabBtn = e.target.closest && e.target.closest('.claude-emoji-tab');
      if (tabBtn) {
        searchInput.value = '';
        showCategory(tabBtn.getAttribute('data-cat'));
        return;
      }
      var cell = e.target.closest && e.target.closest('.claude-emoji-cell');
      if (cell) {
        var idx = parseInt(cell.getAttribute('data-index'), 10);
        var item = renderedItems[idx];
        if (item) insertEmoji(item.ch);
      }
    });

    root.addEventListener('mouseover', function (e) {
      var cell = e.target.closest && e.target.closest('.claude-emoji-cell');
      if (!cell) return;
      var idx = parseInt(cell.getAttribute('data-index'), 10);
      if (renderedItems[idx]) setPreview(renderedItems[idx]);
    });

    searchInput.addEventListener('input', function () {
      var q = searchInput.value.trim();
      if (!q) {
        showCategory(activeCategory || tabDefs[0].id);
        return;
      }
      var tabs = tabsEl.querySelectorAll('.claude-emoji-tab');
      for (var k = 0; k < tabs.length; k++) {
        tabs[k].classList.remove('claude-emoji-tab-active');
      }
      renderGrid(catalog.search(q));
    });

    root.addEventListener('keydown', onPanelKeydown);
    document.body.appendChild(root);
    return root;
  }

  function onPanelKeydown(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      closePanel(true);
      return;
    }
    var cols = columnCount();
    if (e.key === 'ArrowRight') {
      e.preventDefault();
      setActiveIndex(activeIndex < 0 ? 0 : activeIndex + 1);
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      setActiveIndex(activeIndex <= 0 ? 0 : activeIndex - 1);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex(activeIndex < 0 ? 0 : activeIndex + cols);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex(activeIndex < 0 ? 0 : activeIndex - cols);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      var item = renderedItems[activeIndex < 0 ? 0 : activeIndex];
      if (item) {
        insertEmoji(item.ch);
        // Enter вставляет, но фокус оставляем в поиске — так можно
        // набрать следующий запрос без мыши.
        if (searchInput) searchInput.focus();
      }
    }
  }

  function positionPanel() {
    if (!panel || !anchorBtn) return;
    var rect = anchorBtn.getBoundingClientRect();
    var pRect = panel.getBoundingClientRect();
    var top = rect.top - pRect.height - 6;
    if (top < 6) top = Math.min(rect.bottom + 6, window.innerHeight - pRect.height - 6);
    if (top < 6) top = 6;
    var left = rect.left + rect.width / 2 - pRect.width / 2;
    if (left + pRect.width > window.innerWidth - 6) {
      left = window.innerWidth - pRect.width - 6;
    }
    if (left < 6) left = 6;
    panel.style.top = top + 'px';
    panel.style.left = left + 'px';
  }

  function openPanel(btn) {
    rememberCaret();
    anchorBtn = btn;
    panel = buildPanel();
    var firstTab = RECENT_LIMIT > 0 && loadRecent().length
      ? '__recent__'
      : catalog.categories[0].id;
    showCategory(firstTab);
    positionPanel();
    searchInput.focus();
    setTimeout(function () {
      document.addEventListener('mousedown', onOutsideMouseDown, true);
      document.addEventListener('keydown', onDocumentKeydown, true);
      window.addEventListener('resize', positionPanel);
    }, 0);
    logInfo('панель открыта');
  }

  function closePanel(focusComposer) {
    if (!panel) return;
    panel.remove();
    panel = null;
    anchorBtn = null;
    searchInput = null;
    gridEl = null;
    previewEl = null;
    tabsEl = null;
    renderedItems = [];
    activeIndex = -1;
    document.removeEventListener('mousedown', onOutsideMouseDown, true);
    document.removeEventListener('keydown', onDocumentKeydown, true);
    window.removeEventListener('resize', positionPanel);
    if (focusComposer) {
      var composer = getComposer();
      if (composer) {
        composer.focus();
        restoreCaret(composer);
      }
    }
    logInfo('панель закрыта');
  }

  function onOutsideMouseDown(e) {
    if (!panel) return;
    if (panel.contains(e.target)) return;
    if (e.target.closest && e.target.closest('.' + BTN_CLASS)) return; // toggle сам себя
    closePanel(false);
  }

  function onDocumentKeydown(e) {
    if (e.key === 'Escape' && panel) {
      e.preventDefault();
      e.stopPropagation();
      closePanel(true);
    }
  }

  /* ---------- кнопка рядом с микрофоном ----------
   *
   * Основное место — `[class*="micButtonWrapper_"]`: absolute-контейнер
   * в правом верхнем углу поля ввода (top:5px; right:0), где живёт
   * кнопка диктовки. Кнопка 😀 встаёт слева от микрофона, для чего
   * wrapper переводится в flex классом `claude-emoji-mic-host`
   * (по умолчанию элементы внутри блочные и встали бы друг под друга).
   *
   * Микрофон рендерится только при `speechToTextEnabled`, поэтому
   * остаётся запасное место — футер `[class*="inputFooter_"]` рядом
   * с кнопкой меню `/`.
   */

  function createButton(host) {
    var btn = document.createElement('button');
    btn.type = 'button'; // важно: поле ввода внутри <form>, submit нам не нужен
    btn.className = BTN_CLASS;
    btn.title = 'Вставить смайлик';
    btn.setAttribute('aria-label', 'Вставить смайлик');
    btn.textContent = '😀';
    // Наследуем нативные классы соседней кнопки — так наша получает те
    // же размеры, радиус и hover, что и штатные, без привязки к хэшу
    // в имени класса.
    var sibling = host.querySelector('button[class*="micButton_"]') ||
      host.querySelector('button[class*="menuButton_"]');
    if (sibling && sibling.className) {
      // У микрофона класс состояния `recording_*` появляется во время
      // записи — забирать его себе нельзя.
      var inherited = sibling.className.split(/\s+/).filter(function (c) {
        return c && c.indexOf('recording') !== 0 && c.indexOf('claude-') !== 0;
      });
      inherited.push(BTN_CLASS);
      btn.className = inherited.join(' ');
    }
    btn.addEventListener('mousedown', function (e) {
      // Не отдаём фокус кнопке: каретка должна остаться в composer'е.
      e.preventDefault();
      e.stopPropagation();
    });
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (panel) closePanel(true);
      else openPanel(btn);
    });
    return btn;
  }

  /** Вставка в контейнер микрофона. Возвращает true, если удалось. */
  function mountNearMic(container, existing) {
    var wrapper = container.querySelector('[class*="micButtonWrapper_"]');
    if (!wrapper) return false;
    var micBtn = wrapper.querySelector('button[class*="micButton_"]:not(.' + BTN_CLASS + ')');
    if (!micBtn) return false;
    if (existing && existing.parentNode === wrapper && existing.nextSibling === micBtn) return true;
    var btn = existing || createButton(wrapper);
    wrapper.classList.add('claude-emoji-mic-host');
    var oldHost = btn.parentNode;
    wrapper.insertBefore(btn, micBtn);
    if (oldHost && oldHost.classList && oldHost.classList.contains('claude-emoji-standalone')) {
      oldHost.parentNode.classList.remove('claude-emoji-input-host');
      oldHost.remove();
    }
    // Полю ввода нужен правый отступ под вторую иконку, иначе текст
    // уезжает под неё. Ставим маркер на контейнер, а не правим
    // `messageInput_*` глобально: без нашей кнопки отступ не нужен.
    var inputWrap = micBtn.closest('[class*="messageInputContainer_"]') || wrapper.parentNode;
    if (inputWrap && inputWrap.classList) inputWrap.classList.add('claude-emoji-inline');
    logInfo('кнопка встроена рядом с микрофоном');
    return true;
  }

  /** Keep the requested input position even when voice is unavailable. */
  function mountInInput(container, existing) {
    var inputWrap = container.querySelector('[class*="messageInputContainer_"]');
    if (!inputWrap) return false;
    var host = inputWrap.querySelector('.claude-emoji-standalone');
    if (host && existing && existing.parentNode === host) return true;
    if (!host) {
      host = document.createElement('div');
      host.className = 'claude-emoji-standalone';
      inputWrap.classList.add('claude-emoji-input-host');
      inputWrap.appendChild(host);
    }
    host.appendChild(existing || createButton(container));
    return true;
  }

  /** Explicit footer placement, next to the slash menu. */
  function mountInFooter(container) {
    var footer = container.querySelector('[class*="inputFooter_"]');
    if (!footer) return false;
    var btn = createButton(footer);
    var menuBtn = footer.querySelector('button[class*="menuButton_"]');
    if (menuBtn && menuBtn.parentNode === footer) {
      footer.insertBefore(btn, menuBtn.nextSibling);
    } else {
      var spacer = footer.querySelector('[class*="spacer_"]');
      if (spacer && spacer.parentNode === footer) footer.insertBefore(btn, spacer);
      else footer.appendChild(btn);
    }
    logInfo('кнопка встроена в футер (микрофон недоступен)');
    return true;
  }

  function scanInputs(ctx) {
    // Узлы даёт общий обход (см. DOM WATCH) — один на все модули.
    // Свой поиск остаётся для вызовов вне прохода: при регистрации
    // и из обработчиков самого модуля.
    var containers = (ctx && ctx.inputs)
      || document.querySelectorAll('[class*="inputContainer_"]');
    for (var i = 0; i < containers.length; i++) {
      var container = containers[i];
      // Футер и поле ввода лежат в одном fieldset.inputContainer_*,
      // поэтому одной проверки хватает на оба варианта размещения.
      var existing = container.querySelector('.' + BTN_CLASS);
      if (existing) {
        // Dictation can mount after the composer. Promote the fallback button
        // once, without recreating it or moving it on every observer callback.
        if (placement === 'mic' && !mountNearMic(container, existing)) mountInInput(container, existing);
        continue;
      }
      if (!container.querySelector('[role="textbox"][contenteditable]')) continue;
      // Keep the button inside the input when dictation is unavailable.
      if (placement === 'footer') mountInFooter(container);
      else if (!mountNearMic(container)) mountInInput(container);
    }
    // Панель без своей кнопки (React перерисовал поле ввода) —
    // закрываем, чтобы не висела оторванной от анкера.
    if (panel && anchorBtn && !document.body.contains(anchorBtn)) {
      closePanel(false);
    }
  }

  /** Снимает кнопку и следы её размещения — перед переносом. */
  function unmountButtons() {
    var buttons = document.querySelectorAll('.' + BTN_CLASS);
    for (var i = 0; i < buttons.length; i++) {
      var host = buttons[i].parentNode;
      buttons[i].remove();
      // Класс на контейнере микрофона нужен только пока кнопка в нём.
      if (host && host.classList) host.classList.remove('claude-emoji-mic-host');
    }
    var marked = document.querySelectorAll('.claude-emoji-inline');
    for (var j = 0; j < marked.length; j++) {
      marked[j].classList.remove('claude-emoji-inline');
    }
    var standalone = document.querySelectorAll('.claude-emoji-standalone');
    for (var k = 0; k < standalone.length; k++) {
      standalone[k].parentNode.classList.remove('claude-emoji-input-host');
      standalone[k].remove();
    }
  }

  /**
   * Опрашивает http-server.py на предмет смены
   * claudeCode.emojiButtonPlacement в VSCode Settings UI.
   * Сервер может быть не запущен — тогда молча остаёмся на значении
   * из bootstrap.
   */
  function pollPlacement() {
    fetch(PLACEMENT_URL, { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        if (!data) return;
        var next = data.emojiButtonPlacement === 'footer' ? 'footer' : 'mic';
        if (next === placement) return;
        logInfo('расположение кнопки сменилось:', placement, '→', next);
        placement = next;
        if (panel) closePanel(false);
        unmountButtons();
        scanInputs();
      })
      .catch(function () {});
  }

  function init() {
    // Наблюдатель и подстраховочный таймер — общие (см. DOM WATCH).
    window.__claudeDomWatch.register('emoji-picker', scanInputs);
    pollPlacement();
    setInterval(pollPlacement, PLACEMENT_POLL_MS);
    // Каретку запоминаем всегда, а не только при открытой панели:
    // к моменту клика по 😀 фокус уже может быть в другом месте.
    document.addEventListener('selectionchange', rememberCaret);
    logInfo('installed, смайликов в каталоге:', catalog.all.length);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * EMOJI AUTOREPLACE — текстовые смайлики → эмодзи прямо при наборе
 * ============================================================
 *
 * Слушает input-события composer'а и, когда перед кареткой оказалась
 * распознаваемая последовательность, заменяет её на эмодзи:
 *
 *   :)  :-)  =)  ;)  :(  <3      → 🙂 🙂 🙂 😉 🙁 ❤️
 *   :D  :P  :o  xD  :3           → 😃 😛 😮 😆 😺
 *   :rocket:  :bug:  :done:      → 🚀 🐛 ✅
 *
 * Shortcode-форма `:name:` резолвится по индексу EMOJI CATALOG,
 * то есть покрывает все смайлики каталога.
 *
 * Два режима срабатывания — из-за конфликтов с обычным текстом:
 *
 * 1. МГНОВЕННЫЕ — паттерны, у которых не бывает продолжения
 *    (`:)`, `<3`, `:/`, `\o/`, а также `:name:`). Заменяются сразу
 *    по вводу последнего символа.
 *
 * 2. ОТЛОЖЕННЫЕ — паттерны, которые могут оказаться началом чего-то
 *    длиннее (`:D`, `:o`, `:3`, `xD`). Заменяются только когда следом
 *    введён пробел или перевод строки. Иначе `:o` схлопывался бы
 *    в 😮 прямо посреди набора `:ok_hand:`, а `xD` — посреди слова.
 *
 * Ложные срабатывания дополнительно отсекаются требованием границы
 * слева: перед последовательностью должен быть пробел, перевод строки
 * или начало текста. Поэтому `http://`, `C:/Users` и `10:00` остаются
 * как есть.
 *
 * Замена выполняется через execCommand('insertText') по выделенному
 * Range — так React видит штатный input-event, а пользователь может
 * откатить замену обычным Ctrl+Z.
 *
 * Известное ограничение: отложенный паттерн в самом конце сообщения
 * (`ок :D` + сразу Enter) уходит текстом — разделитель после него
 * ввести уже не успевают. Мгновенные паттерны этим не страдают.
 *
 * Управление: `emojiAutoReplace` в claude-custom-config.toml.
 * ============================================================ */
(function () {
  if (window.__claudeEmojiAutoReplaceInstalled) return;
  window.__claudeEmojiAutoReplaceInstalled = true;

  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  if (cfg.emojiAutoReplace !== true) return;

  // Мгновенные паттерны. Внутри таблицы порядок важен: более длинные
  // варианты проверяются первыми, иначе `:-)` схлопнется по хвосту
  // `-)`, а `</3` — по хвосту `<3`.
  // Голые `8)` и `B)` намеренно не включены — они превращали бы
  // нумерацию списка («8) сделать») в 😎; оставлены формы с дефисом.
  var INSTANT = [
    ['>:(', '😠'],
    ['</3', '💔'],
    [":'(", '😢'],
    ['\\o/', '🙌'],
    ['8-)', '😎'],
    ['B-)', '😎'],
    [':-)', '🙂'],
    [':-(', '🙁'],
    [':-D', '😃'],
    [':-P', '😛'],
    [':-p', '😛'],
    [':-O', '😮'],
    [':-o', '😮'],
    [':-|', '😐'],
    [':-/', '😕'],
    [';-)', '😉'],
    [':)', '🙂'],
    ['=)', '🙂'],
    [':(', '🙁'],
    [';)', '😉'],
    [':|', '😐'],
    [':/', '😕'],
    [':*', '😘'],
    ['<3', '❤️'],
  ];

  // Отложенные: `<двоеточие><буква/цифра>` — потенциальное начало
  // shortcode (`:o` в `:ok_hand:`), а `xD` — потенциальное начало
  // слова. Такие заменяются только после ввода пробела.
  var DEFERRED = [
    [':D', '😃'],
    [':P', '😛'],
    [':p', '😛'],
    [':O', '😮'],
    [':o', '😮'],
    [':3', '😺'],
    ['xD', '😆'],
    ['XD', '😆'],
  ];

  var SHORTCODE_RE = /:([a-z0-9_]{2,24}):$/i;
  var MAX_LOOKBEHIND = 32;
  var BOUNDARY_RE = /[\s\u00A0]/;

  var catalog = window.__claudeEmojiCatalog;
  var replacing = false; // защита от реакции на собственную вставку

  function logInfo() {
    if (!cfg.logs) return;
    try {
      console.log.apply(console, ['[emoji-autoreplace]'].concat([].slice.call(arguments)));
    } catch (e) {}
  }

  function getComposer() {
    return (
      document.querySelector('[role="textbox"][contenteditable][aria-label*="essage" i]') ||
      document.querySelector('[role="textbox"][contenteditable]') ||
      document.querySelector('div[contenteditable]')
    );
  }

  /**
   * Слева от найденной последовательности должен быть пробел или
   * начало текста — иначе `http:/` превратилось бы в `http😕`.
   */
  function hasBoundary(text, startIndex) {
    if (startIndex <= 0) return true;
    return BOUNDARY_RE.test(text.charAt(startIndex - 1));
  }

  function matchTable(table, text) {
    for (var k = 0; k < table.length; k++) {
      var pattern = table[k][0];
      if (text.length < pattern.length) continue;
      if (text.slice(text.length - pattern.length) !== pattern) continue;
      if (!hasBoundary(text, text.length - pattern.length)) continue;
      return { len: pattern.length, ch: table[k][1] };
    }
    return null;
  }

  /**
   * Ищет, что заменить в тексте перед кареткой.
   * Возвращает {len, text} — сколько символов снять и что вставить,
   * либо null.
   */
  function findReplacement(before) {
    var hit = matchTable(INSTANT, before);
    if (hit) return { len: hit.len, text: hit.ch };

    if (catalog) {
      var m = SHORTCODE_RE.exec(before);
      if (m && hasBoundary(before, m.index)) {
        var ch = catalog.byCode[m[1].toLowerCase()];
        if (ch) return { len: m[0].length, text: ch };
      }
    }

    // Отложенные срабатывают по только что введённому разделителю.
    // Снимаем паттерн вместе с разделителем и возвращаем его обратно
    // после эмодзи — тогда каретка остаётся в конце, а не перед пробелом.
    var last = before.charAt(before.length - 1);
    if (last && BOUNDARY_RE.test(last)) {
      var deferredHit = matchTable(DEFERRED, before.slice(0, before.length - 1));
      if (deferredHit) {
        return { len: deferredHit.len + 1, text: deferredHit.ch + last };
      }
    }
    return null;
  }

  /** Заменяет `len` символов перед кареткой на `text`. */
  function replaceBeforeCaret(node, offset, len, text) {
    var sel = window.getSelection();
    if (!sel) return;
    var range = document.createRange();
    try {
      range.setStart(node, offset - len);
      range.setEnd(node, offset);
    } catch (e) {
      return; // узел успел измениться под нами
    }
    sel.removeAllRanges();
    sel.addRange(range);

    replacing = true;
    try {
      if (!document.execCommand('insertText', false, text)) {
        // Fallback, если execCommand недоступен: правим данные узла
        // напрямую и сообщаем React о вводе синтетическим событием.
        node.deleteData(offset - len, len);
        node.insertData(offset - len, text);
        var after = document.createRange();
        after.setStart(node, offset - len + text.length);
        after.collapse(true);
        sel.removeAllRanges();
        sel.addRange(after);
        var composer = getComposer();
        if (composer) {
          composer.dispatchEvent(new InputEvent('input', {
            bubbles: true, cancelable: true, inputType: 'insertText', data: text,
          }));
        }
      }
      logInfo('заменено на', JSON.stringify(text));
    } catch (e) {
      logInfo('замена не удалась:', (e && e.message) || e);
    } finally {
      // Снимаем флаг после того, как отработают обработчики нашего
      // же input-события, иначе замена вызовет сама себя.
      setTimeout(function () { replacing = false; }, 0);
    }
  }

  function onInput(e) {
    if (replacing) return;
    var composer = getComposer();
    if (!composer || e.target !== composer) return;
    // Реагируем только на набор текста: удаления и вставки из буфера
    // (insertFromPaste) не трогаем — пользователь их не набирал.
    var type = e.inputType || '';
    if (type !== 'insertText' && type !== 'insertCompositionText' &&
        type !== 'insertLineBreak' && type !== 'insertParagraph' && type !== '') {
      return;
    }

    var sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    var range = sel.getRangeAt(0);
    if (!range.collapsed) return;
    var node = range.startContainer;
    if (node.nodeType !== 3) return; // ждём текстовый узел
    if (!composer.contains(node)) return;

    var offset = range.startOffset;
    var before = node.data.slice(Math.max(0, offset - MAX_LOOKBEHIND), offset);
    var found = findReplacement(before);
    if (!found) return;
    replaceBeforeCaret(node, offset, found.len, found.text);
  }

  function init() {
    // Слушаем на document: composer пересоздаётся React'ом, вешать
    // обработчик на сам элемент пришлось бы после каждого ре-рендера.
    document.addEventListener('input', onInput, true);
    logInfo('installed | мгновенных:', INSTANT.length,
      '| отложенных:', DEFERRED.length,
      '| shortcodes:', catalog ? Object.keys(catalog.byCode).length : 0);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * SETTINGS MENU FIX — чиним пункт меню `/` «Общие настройки…»
 * ============================================================
 *
 * Симптом: выбор пункта «Настройки → Общие настройки…» не открывает
 * настройки расширения, а отправляет в чат слэш-команду `/config`
 * (та печатает usage вида `key=value`). Оба пункта при этом
 * подсвечиваются в меню одновременно.
 *
 * Причина — коллизия идентификаторов в самом расширении (2.1.220).
 * Пункт меню регистрируется так:
 *
 *     k6 = { config: "slash-command-config", ... }
 *     registerAction({ id: k6.config, label: "General config…" },
 *                    "Settings", () => t.openConfig())
 *
 * а слэш-команды CLI — так:
 *
 *     let l = `slash-command-${invocation}`;      // /config → "slash-command-config"
 *     registerAction({ id: l, label: `/${invocation}` },
 *                    "Slash Commands", () => send(`/${invocation}`))
 *
 * Пока в CLI не было команды `/config`, конфликта не возникало.
 * Теперь она есть, id совпадают буквально, и обработчик пункта меню
 * перекрывается обработчиком слэш-команды.
 *
 * Что делает патч: перехватывает click в capture-фазе (тот же приём,
 * что в compactClickInterceptor), опознаёт пункт по лейблу и вызывает
 * `openConfig()` — метод контекста приложения, который достаётся
 * через React-fiber. Если контекст найти не удалось, событие
 * не блокируется: пусть отработает штатное (пусть и неверное)
 * поведение, это лучше мёртвой кнопки.
 *
 * Управление: `fixSettingsMenuItem` в claude-custom-config.toml.
 * ============================================================ */
(function () {
  if (window.__claudeSettingsMenuFixInstalled) return;
  window.__claudeSettingsMenuFixInstalled = true;

  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  if (cfg.fixSettingsMenuItem !== true) return;

  // Лейбл зависит от локали (localize.py переводит меню) и от того,
  // каким символом расширение набрало многоточие.
  var LABELS = [
    'общие настройки…',
    'общие настройки...',
    'general config…',
    'general config...',
  ];

  var cachedContext = null;

  function logInfo() {
    if (!cfg.logs) return;
    try {
      console.log.apply(console, ['[settings-menu-fix]'].concat([].slice.call(arguments)));
    } catch (e) {}
  }

  function getFiber(el) {
    var keys = Object.keys(el);
    for (var i = 0; i < keys.length; i++) {
      if (keys[i].indexOf('__reactFiber') === 0) return el[keys[i]];
    }
    return null;
  }

  /** Контекст приложения — объект с методами openConfig/openHelp. */
  function looksLikeContext(obj) {
    return !!obj && typeof obj === 'object' &&
      typeof obj.openConfig === 'function' &&
      typeof obj.openHelp === 'function';
  }

  /** Ищет контекст среди значений props (и в самом props). */
  function contextFromProps(props) {
    if (!props || typeof props !== 'object') return null;
    if (looksLikeContext(props)) return props;
    if (looksLikeContext(props.context)) return props.context;
    var keys = Object.keys(props);
    for (var i = 0; i < keys.length; i++) {
      if (looksLikeContext(props[keys[i]])) return props[keys[i]];
    }
    return null;
  }

  /** Ищет контекст в цепочке хуков компонента. */
  function contextFromState(fiber) {
    var state = fiber.memoizedState;
    var hops = 0;
    while (state && hops < 40) {
      if (looksLikeContext(state.memoizedState)) return state.memoizedState;
      // Signals/стейт часто лежат ещё на уровень глубже, в .value.
      if (state.memoizedState && looksLikeContext(state.memoizedState.value)) {
        return state.memoizedState.value;
      }
      state = state.next;
      hops++;
    }
    return null;
  }

  /**
   * Поднимается от кликнутого пункта вверх по дереву фиберов —
   * контекст почти наверняка прокинут в один из родительских
   * компонентов меню, так что до полного обхода дело не доходит.
   */
  function findContextUpwards(el) {
    var fiber = getFiber(el);
    var hops = 0;
    while (fiber && hops < 40) {
      var found = contextFromProps(fiber.memoizedProps) || contextFromState(fiber);
      if (found) return found;
      fiber = fiber.return;
      hops++;
    }
    return null;
  }

  /** Запасной путь: обход дерева от корня React. */
  function findContextFromRoot() {
    var root = document.getElementById('root');
    if (!root) return null;
    var keys = Object.keys(root);
    var containerKey = null;
    for (var i = 0; i < keys.length; i++) {
      if (keys[i].indexOf('__reactContainer') === 0) { containerKey = keys[i]; break; }
    }
    if (!containerKey) return null;

    var stack = [root[containerKey]];
    var seen = new Set();
    var visited = 0;
    while (stack.length && visited < 6000) {
      var fiber = stack.pop();
      if (!fiber || seen.has(fiber)) continue;
      seen.add(fiber);
      visited++;
      var found = contextFromProps(fiber.memoizedProps) || contextFromState(fiber);
      if (found) return found;
      if (fiber.child) stack.push(fiber.child);
      if (fiber.sibling) stack.push(fiber.sibling);
    }
    return null;
  }

  function getContext(el) {
    if (looksLikeContext(cachedContext)) return cachedContext;
    cachedContext = findContextUpwards(el) || findContextFromRoot();
    logInfo('контекст приложения', cachedContext ? 'найден' : 'НЕ найден');
    return cachedContext;
  }

  /** Закрывает выпадашку меню — React слушает Escape на document. */
  function closeMenu() {
    var escape = { key: 'Escape', code: 'Escape', keyCode: 27, which: 27,
      bubbles: true, cancelable: true };
    document.dispatchEvent(new KeyboardEvent('keydown', escape));
    var input = document.querySelector('[role="textbox"][contenteditable]');
    if (input) input.dispatchEvent(new KeyboardEvent('keydown', escape));
  }

  function isTargetItem(item) {
    var labelEl = item.querySelector('[class*="commandLabel_"]');
    var text = ((labelEl ? labelEl.textContent : item.textContent) || '')
      .trim().toLowerCase();
    if (!text) return false;
    // Слэш-команда `/config` живёт в том же меню и лейбл у неё
    // начинается со слэша — её трогать нельзя.
    if (text.charAt(0) === '/') return false;
    return LABELS.indexOf(text) >= 0;
  }

  function onClickCapture(e) {
    if (!e.target.closest) return;
    var item = e.target.closest('[class*="commandItem_"]');
    if (!item || !isTargetItem(item)) return;

    var context = getContext(item);
    if (!context) {
      // Чинить нечем — пропускаем событие дальше, чтобы поведение
      // осталось хотя бы прежним, а не исчезло совсем.
      logInfo('контекст не найден, отдаём событие React-обработчику');
      return;
    }

    e.preventDefault();
    e.stopPropagation();
    try {
      context.openConfig();
      logInfo('openConfig() вызван');
    } catch (err) {
      logInfo('openConfig() упал:', (err && err.message) || err);
    }
    closeMenu();
  }

  function init() {
    document.addEventListener('click', onClickCapture, true);
    logInfo('installed');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * CACHE USAGE BUTTON
 *
 * Кнопка «Usage» в футере поля ввода, слева от «Править
 * автоматически». По клику открывается панель со статистикой
 * prompt-кэша текущей сессии: размер контекста, вердикт последнего
 * хода (попадание/промах и пауза до него), суммы чтений и записей,
 * оценка стоимости против варианта без кэша и список последних
 * промахов с длиной паузы.
 *
 * Не путать с соседней кнопкой «Cache» (модуль CACHE KEEPALIVE):
 * эта показывает статистику, та поддерживает кэш живым.
 *
 * Данные берёт GET http://localhost:18923/cache-usage — там
 * http-server.py разбирает JSONL-транскрипт сессии (модуль
 * .claude/hooks/cache_usage.py). Ничего не считается в webview:
 * транскрипты бывают по 70 МБ, разбор инкрементальный и живёт
 * на стороне сервера.
 *
 * Почему кнопка, а не инжект в каждое сообщение: статистика нужна
 * изредка, а строка в шапке каждого ответа быстро превращается в шум.
 *
 * Управление: `usageButton` в claude-custom-config.toml.
 * ============================================================ */
(function () {
  if (window.__claudeCacheButtonInstalled) return;
  window.__claudeCacheButtonInstalled = true;

  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};

  var API_URL = 'http://127.0.0.1:18923/cache-usage';
  var BTN_CLASS = 'claude-usage-btn';
  var BARE_CLASS = 'claude-usage-btn-bare';  // без донора стиля
  var PANEL_ID = 'claude-cache-panel';

  // Соседний контрол, слева от которого встаём. Лейбл локализуется,
  // поэтому ищем оба варианта; при промахе есть запасные якоря.
  var AUTO_EDIT_RE = /Править автоматически|Edit automatically/i;

  var UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  // Во сколько ставок input обходится промах сверх попадания:
  // заплачено по записи (2x) вместо чтения (0.1x).
  var MISS_LOSS_MULT = 1.9;

  var panel = null;
  var anchorBtn = null;

  var historyTab = 'cache';
  var historyCleanup = null;
  var usageSessions = new Map();
  var panelState = null;
  var usageViewReady = false;

  function usageSession(sid) {
    var state = usageSessions.get(sid);
    if (!state) state = { tab: 'cache', scroll: 0, expanded: {}, stats: null, chat: null };
    usageSessions.delete(sid);
    usageSessions.set(sid, state);
    if (usageSessions.size > 8) usageSessions.delete(usageSessions.keys().next().value);
    return state;
  }

  function captureUsageView() {
    if (!panel || !panelState || !usageViewReady) return;
    panelState.tab = historyTab;
    panelState.scroll = panel.scrollTop;
    panelState.anchor = null;
    var top = panel.getBoundingClientRect().top;
    panel.querySelectorAll('[data-usage-key]').forEach(function (el) {
      var key = el.getAttribute('data-usage-key');
      var details = el.querySelector('details');
      var toggle = el.querySelector('[aria-expanded]');
      panelState.expanded[key] = details ? details.open : !!toggle && toggle.getAttribute('aria-expanded') === 'true';
      var rect = el.getBoundingClientRect();
      if (!panelState.anchor && rect.height && rect.bottom > top && rect.top < panel.getBoundingClientRect().bottom) {
        panelState.anchor = { key: key, offset: rect.top - top };
      }
    });
  }

  function restoreUsageView() {
    if (!panel || !panelState) return;
    var anchor = null;
    panel.querySelectorAll('[data-usage-key]').forEach(function (el) {
      var key = el.getAttribute('data-usage-key');
      if (panelState.expanded[key]) {
        var details = el.querySelector('details');
        var toggle = el.querySelector('[aria-expanded="false"]');
        if (details) {
          details.open = true;
          if (el.__usageExpand) el.__usageExpand();
        }
        else if (toggle) toggle.click();
      }
      if (panelState.anchor && panelState.anchor.key === key) anchor = el;
    });
    panel.scrollTop = panelState.scroll;
    if (anchor && anchor.getBoundingClientRect().height) {
      panel.scrollTop += anchor.getBoundingClientRect().top - panel.getBoundingClientRect().top - panelState.anchor.offset;
    }
  }

  function logInfo() {
    if (!cfg.logs) return;
    try {
      console.log.apply(console, ['[cache-usage]'].concat([].slice.call(arguments)));
    } catch (e) {}
  }

  /* ---------- какая сессия открыта в этой вкладке ---------- */

  /**
   * Без session id сервер отдаёт самый свежий .jsonl в папке проекта —
   * то есть все вкладки показывают одну и ту же сессию, и она ещё
   * и перескакивает, когда в соседней вкладке появляется новое
   * сообщение. Поэтому id берём из React-fiber и передаём явно.
   *
   * Идём вверх по `.return` от поля ввода: sessionId лежит в пропсах
   * или состоянии одного из родительских компонентов чата. Значение
   * бывает и голой строкой, и Preact-сигналом — в бандле поля вида
   * `session.sessionId.value` встречаются наравне с обычными.
   *
   * Существующий getSessionIdFromElement из SESSION MOVER здесь не
   * годится: он читает React-key элемента списка сессий, а у открытой
   * вкладки такого элемента нет.
   */
  function fiberOf(el) {
    if (!el) return null;
    var keys = Object.keys(el);
    for (var i = 0; i < keys.length; i++) {
      if (keys[i].indexOf('__reactFiber') === 0) return el[keys[i]];
    }
    return null;
  }

  // Имена пропсов, под которыми лежит объект сессии. В бандле это
  // экземпляр класса с полями-сигналами (`sessionId`, `summary`,
  // `busy`), а вкладки живут внутри одного webview — какая активна,
  // знает `activeSession`.
  var HOLDER_KEYS = ['session', 'activeSession', 'currentSession', 'conversation'];

  /** Достаёт UUID из объекта-держателя сессии (поле или сигнал). */
  function idFromHolder(h) {
    if (!h || typeof h !== 'object') return null;
    var v;
    try { v = h.sessionId; } catch (e) { return null; }
    if (typeof v === 'string' && UUID_RE.test(v)) return v;
    if (v && typeof v === 'object' && typeof v.value === 'string'
        && UUID_RE.test(v.value)) {
      return v.value;
    }
    return null;
  }

  /** Разворачивает сигнал: у Preact значение лежит в `.value`. */
  function unwrap(v) {
    if (v && typeof v === 'object' && v.value && typeof v.value === 'object') {
      return v.value;
    }
    return v;
  }

  /**
   * Ищет id в объекте пропсов/состояния.
   *
   * Плоской проверки `obj.sessionId` не хватает: в пропсы приходит
   * не id, а сам объект сессии (`props.session.sessionId.value`) или
   * стор с активной вкладкой (`props.activeSession.value.sessionId.value`).
   * Поэтому смотрим на уровень глубже — сперва по известным именам,
   * потом общим перебором, на случай другого имени пропса.
   */
  function pickSessionId(obj) {
    if (!obj || typeof obj !== 'object') return null;
    var direct = idFromHolder(obj);
    if (direct) return direct;

    var i, got;
    for (i = 0; i < HOLDER_KEYS.length; i++) {
      var h = obj[HOLDER_KEYS[i]];
      if (!h || typeof h !== 'object') continue;
      got = idFromHolder(h) || idFromHolder(unwrap(h));
      if (got) return got;
    }

    var keys;
    try { keys = Object.keys(obj); } catch (e) { return null; }
    for (i = 0; i < keys.length && i < 30; i++) {
      var c;
      try { c = obj[keys[i]]; } catch (e) { continue; }
      if (!c || typeof c !== 'object') continue;
      got = idFromHolder(c) || idFromHolder(unwrap(c));
      if (got) return got;
    }
    return null;
  }

  /**
   * Состояние функционального компонента — не объект, а связный список
   * хуков: значение каждого лежит в `.memoizedState`, следующий в
   * `.next`. Прямая проверка fiber.memoizedState видит только первый
   * хук (а чаще вообще служебную структуру), поэтому идём по цепочке.
   */
  function pickFromHooks(state) {
    var hook = state;
    var n = 0;
    while (hook && typeof hook === 'object' && n < 40) {
      var got = pickSessionId(hook.memoizedState);
      if (got) return got;
      hook = hook.next;
      n++;
    }
    return null;
  }

  function pickFromFiber(f) {
    if (!f) return null;
    return pickSessionId(f.memoizedProps)
      || pickSessionId(f.memoizedState)
      || pickFromHooks(f.memoizedState);
  }

  function findSessionId() {
    var anchor = document.querySelector('[class*="inputContainer_"]')
      || document.getElementById('root')
      || document.body;
    var fiber = fiberOf(anchor);
    var hops = 0;
    while (fiber && hops < 80) {
      var id = pickFromFiber(fiber);
      if (id) {
        logInfo('id найден подъёмом, шагов:', hops);
        return id;
      }
      fiber = fiber.return;
      hops++;
    }
    // Подъём не помог — обходим вниз от корня. Очередь ограничена:
    // панель открывается по клику, но подвесить webview обходом
    // на десятки тысяч узлов всё равно нельзя.
    var root = fiberOf(document.getElementById('root') || document.body);
    var queue = root ? [root] : [];
    var seen = 0;
    while (queue.length && seen < 12000) {
      var f = queue.shift();
      seen++;
      if (!f) continue;
      var found = pickFromFiber(f);
      if (found) {
        logInfo('id найден обходом вниз, узлов просмотрено:', seen);
        return found;
      }
      if (f.child) queue.push(f.child);
      if (f.sibling) queue.push(f.sibling);
    }
    logInfo('id не найден: подъём', hops, 'шагов, обход', seen, 'узлов');
    return null;
  }

  // Резолвер — общая зависимость: им же пользуются кнопки ByPass
  // и Cache, чтобы работать именно со своей вкладкой. Регистрируем ДО
  // проверки флага, иначе выключенный usageButton утащил бы за собой
  // и соседние модули (тот же приём, что с __claudeEmojiCatalog).
  window.__claudeSessionId = findSessionId;

  if (cfg.usageButton !== true) return;

  /* ---------- форматирование ---------- */

  function human(n) {
    if (typeof n !== 'number' || !isFinite(n)) return '—';
    if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
    return String(Math.round(n));
  }

  function money(v) {
    return typeof v === 'number' ? '$' + v.toFixed(2) : '—';
  }

  function hhmm(iso) {
    if (typeof iso !== 'string' || iso.length < 16) return '—';
    // Транскрипт пишет UTC; показываем в локальной зоне пользователя.
    var d = new Date(iso);
    if (isNaN(d.getTime())) return iso.slice(11, 16);
    return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
  }

  function gapText(gap) {
    if (typeof gap !== 'number' || !isFinite(gap) || gap < 0) return '';
    var seconds = Math.round(gap * 60);
    var hours = Math.floor(seconds / 3600);
    var minutes = Math.floor(seconds % 3600 / 60);
    return (hours ? hours + ' ч ' : '')
      + (hours || minutes ? minutes + ' м ' : '') + seconds % 60 + ' с';
  }

  /* ---------- панель ---------- */

  function closePanel() {
    captureUsageView();
    if (historyCleanup) { historyCleanup(); historyCleanup = null; }
    if (panel) panel.remove();
    panel = null;
    panelState = null;
    usageViewReady = false;
    anchorBtn = null;
    document.removeEventListener('mousedown', onOutside, true);
    document.removeEventListener('keydown', onKeydown, true);
  }

  function onOutside(e) {
    if (!panel) return;
    if (panel.contains(e.target)) return;
    if (anchorBtn && anchorBtn.contains(e.target)) return;
    closePanel();
  }

  function onKeydown(e) {
    if (e.key === 'Escape') closePanel();
  }

  function row(label, value, cls, title) {
    var el = document.createElement('div');
    el.className = 'claude-cache-row' + (cls ? ' ' + cls : '');
    if (title) el.title = title;
    var l = document.createElement('span');
    l.className = 'claude-cache-label';
    l.textContent = label;
    var v = document.createElement('span');
    v.className = 'claude-cache-value';
    v.textContent = value;
    el.appendChild(l);
    el.appendChild(v);
    return el;
  }

  function renderError(body, text) {
    var p = document.createElement('div');
    p.className = 'claude-cache-empty';
    p.textContent = text;
    body.appendChild(p);
  }

  /** Короткое имя модели: claude-opus-5 → opus-5, glm-5.3 → glm-5.3. */
  function shortModel(name) {
    return String(name || '').replace(/^claude-/, '') || '—';
  }

  /**
   * История сессии: промахи вперемешку с переключениями модели
   * и аккаунта, по времени.
   *
   * Раньше здесь были «последние промахи», и они выглядели
   * беспричинными: «переписано 900k» без намёка, что минутой раньше
   * сменили аккаунт. Теперь причина стоит рядом со следствием.
   *
   * Ленту готовит сервер (`history`). Запасной путь по `miss_log`
   * нужен, пока в окне работает webview, загруженный до обновления
   * сервера: список промахов без событий — это ровно прежнее
   * поведение, и оно лучше пустого раздела.
   */
  function renderHistory(body, d, ttl, rate, hideTitle) {
    var items = d.history;
    if (!items) {
      items = (d.miss_log || []).filter(function (m) {
        return m.written > 0 || m.verdict === 'промах' || m.verdict === 'частичное';
      }).map(function (m) {
        return {
          kind: 'miss', ts: m.ts, gap: m.gap, written: m.written,
          fresh: m.fresh, verdict: m.verdict,
        };
      });
    }
    // Новые события сверху; исходный ответ нужен и другим индикаторам.
    items = items.slice().sort(function (a, b) {
      return (Date.parse(b.ts) || 0) - (Date.parse(a.ts) || 0);
    });
    if (!items.length) return;

    if (!hideTitle) {
      var title = document.createElement('div');
      title.className = 'claude-cache-head claude-cache-head-sub';
      title.textContent = 'история';
      body.appendChild(title);
    }

    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var el = it.kind === 'miss' ? missRow(it, ttl, rate)
        : it.kind === 'hit' ? hitRow(it) : eventRow(it);
      if (it.count > 1) {
        el.children[0].textContent += ' × ' + it.count;
        el.title += '\nПодряд ' + it.count + ' событий: '
          + hhmm(it.started_ts) + ' — ' + hhmm(it.ts);
        el.title += it.kind === 'hit' || it.kind === 'miss'
          ? '\nТокены суммированы за серию'
          : '\nПоказаны данные последнего события серии';
        if (it.kind === 'miss') el.title += '; пауза указана для последнего промаха';
      }
      var historyRow = usageHistoryGroup(el, it, ttl, rate);
      historyRow.setAttribute('data-usage-key', 'cache:' + it.kind + ':' + (it.started_ts || it.ts));
      body.appendChild(historyRow);
    }
  }

  function renderHistoryTabs(body, d, ttl, rate) {
    var owner = panel;
    var saved = usageSession(d.session);
    var stopped = false;
    var loading = false;
    var nextLoad = 0;
    var views = new Map();
    var heading = document.createElement('div');
    heading.className = 'claude-cache-head claude-cache-head-sub';
    heading.textContent = 'история';
    body.appendChild(heading);
    var tabs = document.createElement('div');
    tabs.className = 'claude-usage-history-tabs';
    tabs.setAttribute('role', 'tablist');
    tabs.setAttribute('aria-label', 'История Usage');
    body.appendChild(tabs);
    var panes = {};
    var buttons = {};
    ['cache', 'chat'].forEach(function (name) {
      var button = document.createElement('button');
      button.type = 'button';
      button.id = 'claude-usage-tab-' + name;
      button.textContent = name === 'cache' ? 'Кэш' : 'Чат';
      button.setAttribute('role', 'tab');
      button.setAttribute('aria-controls', 'claude-usage-history-' + name);
      tabs.appendChild(button);
      buttons[name] = button;
      var pane = document.createElement('div');
      pane.id = 'claude-usage-history-' + name;
      pane.className = 'claude-usage-history-pane';
      pane.setAttribute('role', 'tabpanel');
      pane.setAttribute('aria-labelledby', button.id);
      panes[name] = pane;
      body.appendChild(pane);
      button.addEventListener('click', function () { select(name); });
      button.addEventListener('keydown', function (event) {
        var target = event.key === 'Home' ? 'cache' : event.key === 'End' ? 'chat'
          : event.key === 'ArrowLeft' || event.key === 'ArrowRight' ? (name === 'cache' ? 'chat' : 'cache') : null;
        if (!target) return;
        event.preventDefault();
        select(target);
        buttons[target].focus();
      });
    });
    renderHistory(panes.cache, d, ttl, rate, true);
    if (!panes.cache.children.length) renderError(panes.cache, 'Событий кэша пока нет');
    var status = document.createElement('div');
    status.className = 'claude-cache-foot';
    panes.chat.appendChild(status);
    var list = document.createElement('div');
    list.className = 'claude-usage-chat-list';
    panes.chat.appendChild(list);

    function updateTimes() {
      var timing = window.__claudeMessageTiming;
      views.forEach(function (view, id) {
        var live = timing && timing.status(d.session, id);
        var task = live && live.task ? Object.assign({}, view.message, live.task) : view.message;
        var running = !!(live && live.running);
        if (timing) timing.render(view.meta, { session: d.session, id: id }, view.message.sent_at, task, running);
        else view.meta.textContent = view.message.sent_at;
        view.state.textContent = view.navigationError || (running ? 'выполняется' : task.completed_at ? '' : 'нет отметки завершения');
      });
    }

    function renderChat(data) {
      if (views.size) captureUsageView();
      var messages = (data.messages || []).slice().sort(function (a, b) { return Date.parse(b.sent_at) - Date.parse(a.sent_at); });
      var seen = new Set();
      messages.forEach(function (message, index) {
        seen.add(message.id);
        var view = views.get(message.id);
        if (!view) {
          var el = document.createElement('div');
          el.className = 'claude-usage-chat-entry';
          el.setAttribute('data-usage-key', 'chat:' + message.id);
          var details = document.createElement('details');
          var summary = document.createElement('summary');
          details.appendChild(summary);
          el.appendChild(details);
          var footer = document.createElement('div');
          footer.className = 'claude-usage-chat-meta';
          el.appendChild(footer);
          var meta = document.createElement('div');
          footer.appendChild(meta);
          var jump = document.createElement('button');
          jump.type = 'button';
          jump.className = 'claude-usage-chat-jump';
          jump.textContent = '↗';
          jump.title = 'Перейти к сообщению в чате';
          jump.setAttribute('aria-label', jump.title);
          footer.appendChild(jump);
          var state = document.createElement('div');
          state.className = 'claude-cache-foot';
          el.appendChild(state);
          view = { el: el, details: details, summary: summary, meta: meta, state: state };
          el.__usageExpand = function () { view.summary.textContent = view.fullText; };
          jump.addEventListener('click', function () {
            var timing = window.__claudeMessageTiming;
            if (timing && timing.reveal(d.session, view.message.id)) {
              closePanel();
            } else {
              view.navigationError = 'Сообщение не загружено в основном чате';
              updateTimes();
            }
          });
          details.addEventListener('toggle', function () {
            view.summary.textContent = view.details.open ? view.fullText : view.previewText;
          });
          views.set(message.id, view);
        }
        var text = message.text || '';
        var attachments = message.attachments ? 'Вложений: ' + message.attachments : '';
        var preview = text.replace(/\s+/g, ' ').trim();
        view.previewText = (preview.length > 120 ? preview.slice(0, 120) + '…' : preview) || attachments || 'Сообщение без текста';
        view.fullText = (text + (attachments ? (text ? '\n' : '') + attachments : '')) || 'Сообщение без текста';
        view.summary.textContent = view.details.open ? view.fullText : view.previewText;
        view.message = message;
        if (list.children[index] !== view.el) list.insertBefore(view.el, list.children[index] || null);
      });
      views.forEach(function (view, id) { if (!seen.has(id)) { view.el.remove(); views.delete(id); } });
      status.textContent = messages.length ? 'Сообщений: ' + messages.length + ' · новые сверху' : 'Сообщений пользователя пока нет';
      updateTimes();
      restoreUsageView();
    }

    function loadChat() {
      if (!d.session) { status.textContent = 'Не удалось определить сессию'; return; }
      if (loading || Date.now() < nextLoad) return;
      loading = true;
      nextLoad = Date.now() + 5000;
      if (!views.size) status.textContent = 'Загрузка сообщений…';
      var timing = window.__claudeMessageTiming;
      var running = timing && timing.isRunning && timing.isRunning(d.session);
      fetch('http://127.0.0.1:18923/message-times?session=' + encodeURIComponent(d.session) + '&include_messages=1'
        + (running ? '&running=1' : ''), { cache: 'no-store' })
        .then(function (res) { return res.json(); })
        .then(function (data) {
          if (stopped || panel !== owner) return;
          if (!data || !data.ok) throw new Error('history unavailable');
          saved.chat = data;
          renderChat(data);
        }).catch(function () {
          if (!stopped && panel === owner) status.textContent = 'Не удалось обновить историю. Повторяю…';
        }).then(function () { loading = false; });
    }

    function select(name) {
      historyTab = name;
      Object.keys(panes).forEach(function (key) {
        panes[key].hidden = key !== name;
        buttons[key].setAttribute('aria-selected', String(key === name));
        buttons[key].setAttribute('tabindex', key === name ? '0' : '-1');
      });
      if (name === 'chat') { loadChat(); updateTimes(); }
    }
    if (saved.chat) renderChat(saved.chat);
    select(historyTab);
    var timer = setInterval(function () {
      if (!stopped && panel === owner && historyTab === 'chat') { updateTimes(); loadChat(); }
    }, 1000);
    historyCleanup = function () { stopped = true; clearInterval(timer); };
  }

  /** Раскрытие серии тем же способом, что у прежней сводки попаданий. */
  function usageHistoryGroup(summary, item, ttl, rate) {
    var details = item.details || [];
    if (!(item.count > 1) || !details.length) return summary;

    var group = document.createElement('div');
    group.className = 'claude-cache-hit-group';
    summary.classList.add('claude-cache-expandable');
    summary.setAttribute('role', 'button');
    summary.setAttribute('tabindex', '0');
    summary.setAttribute('aria-expanded', 'false');
    summary.title += '\nНажмите, чтобы показать отдельные события';
    var label = summary.children[0].textContent;
    summary.children[0].textContent = '▸ ' + label;

    var detailBox = document.createElement('div');
    detailBox.className = 'claude-cache-hit-details';
    detailBox.hidden = true;
    var rendered = false;
    function toggle() {
      if (!rendered) {
        details.slice().sort(function (a, b) {
          return (Date.parse(b.ts) || 0) - (Date.parse(a.ts) || 0);
        }).forEach(function (ev) {
          var el = ev.kind === 'miss' ? missRow(ev, ttl, rate)
            : ev.kind === 'hit' ? hitRow(ev) : eventRow(ev);
          el.classList.add('claude-cache-hit-detail');
          detailBox.appendChild(el);
        });
        rendered = true;
      }
      var expanded = summary.getAttribute('aria-expanded') === 'true';
      summary.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      detailBox.hidden = expanded;
      summary.children[0].textContent = (expanded ? '▸ ' : '▾ ') + label;
    }
    summary.addEventListener('click', toggle);
    summary.addEventListener('keydown', function (event) {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      event.preventDefault();
      toggle();
    });
    group.appendChild(summary);
    group.appendChild(detailBox);
    return group;
  }

  /** Успешное чтение или непрерывная серия на своём месте в общей ленте. */
  function hitRow(hit) {
    return row(
      hhmm(hit.ts) + '  ·  попадание в кэш',
      'прочитано ' + human(hit.read),
      'claude-cache-hit',
      'Успешное чтение prompt-кэша'
        + (hit.model ? ' · ' + shortModel(hit.model) : '')
    );
  }

  /** Строка промаха. */
  function missRow(m, ttl, rate) {
    if (typeof m.ttl_minutes === 'number' && m.ttl_minutes > 0) ttl = m.ttl_minutes;
    // Причину показываем отдельно: объяснённый промах виден в Usage,
    // но по-прежнему не считается потерей живого кэша для Mood.
    var known = typeof m.gap === 'number';
    var cls = '';
    var hint = '';
    if (m.explain === 'model' || m.explain === 'account') {
      cls = 'claude-cache-miss';
      hint = m.explain === 'model' ? 'промах после смены модели' : 'промах после смены аккаунта';
    } else if (!known) {
      cls = '';
      hint = '';
    } else if (m.gap < ttl) {
      cls = 'claude-cache-unexpected';
      hint = 'ранний промах: интервал короче заданного TTL (' + ttl
        + ' мин); точная причина неизвестна';
    } else {
      cls = 'claude-cache-expired';
      hint = 'интервал не меньше заданного TTL (' + ttl
        + ' мин); срок хранения мог истечь, точная причина неизвестна';
    }
    // Потеря — разница между тем, что заплачено (запись, 2x),
    // и тем, что стоило бы попадание (чтение, 0.1x). Не полная
    // стоимость записи: даже при попадании префикс не бесплатен.
    var lost = m.written * MISS_LOSS_MULT * rate / 1e6;
    var value = m.written > 0
      ? 'переписано ' + human(m.written) + '  (-' + money(lost) + ')'
      : typeof m.fresh === 'number' && m.fresh > 0
        ? 'свежий ввод ' + human(m.fresh) : 'запись кэша не сообщается';
    var label = m.verdict === 'частичное' ? 'частичный промах' : 'промах кэша';
    var gap = gapText(m.gap);
    return row(
      hhmm(m.ts) + '  ·  ' + label + ' - ' + (gap || '—'),
      value,
      cls, hint + '\nИнтервал между записями запросов в журнале: ' + (gap || '—')
    );
  }

  /** Строка переключения: смена модели или аккаунта. */
  function eventRow(ev) {
    if (ev.kind === 'compact') {
      var before = typeof ev.context_before === 'number' && ev.context_before > 0
        ? human(ev.context_before) : '';
      var after = typeof ev.context_after === 'number' && ev.context_after > 0
        ? human(ev.context_after) : '';
      var size = before && after ? before + ' → ' + after
        : before ? 'до ' + before : after ? 'после ' + after : 'размер н/д';
      return row(
        hhmm(ev.ts) + '  ·  сжатие контекста',
        size + (ev.model ? '  ·  ' + shortModel(ev.model) : ''),
        'claude-cache-event',
        'Codex App Server завершил сжатие контекста; число справа — '
          + 'размер контекста перед событием'
      );
    }
    var isAccount = ev.kind === 'account';
    var from = isAccount ? (ev.from || '—') : shortModel(ev.from);
    var to = isAccount ? (ev.to || '—') : shortModel(ev.to);
    var el = row(
      hhmm(ev.ts) + '  ·  ' + (isAccount ? 'аккаунт' : 'модель'),
      from + ' → ' + to,
      'claude-cache-event' + (isAccount ? ' claude-cache-event-account' : ''),
      isAccount
        ? 'Переключение аккаунта. Кэш нового провайдера пуст, поэтому '
          + 'первый ход после переключения промахивается закономерно'
        : 'Смена модели. Префикс кэша у каждой модели свой, поэтому '
          + 'первый ход после смены промахивается закономерно'
    );
    if (ev.pending) {
      // Ход после переключения ещё не сделан — кэш не проверялся.
      // Без пометки событие читалось бы как обошедшееся без промаха.
      el.classList.add('claude-cache-event-pending');
      el.title += '. Ход после него ещё не сделан';
    }
    return el;
  }

  function renderStats(body, d, guessed) {
    var last = d.last || {};
    // TTL приходит с сервера (он читает конфиг по mtime), поэтому
    // правка cacheKeepaliveTtlMinutes видна сразу, без Reload Window.
    var ttl = typeof d.ttl_minutes === 'number' && d.ttl_minutes > 0
      ? d.ttl_minutes : 60;
    var rate = (d.rates && d.rates.input) || 5.0;
    var verdict = last.verdict || '—';
    var gap = gapText(last.gap);

    var head = document.createElement('div');
    head.className = 'claude-cache-head';
    head.textContent = 'контекст ' + human(d.context)
      + (typeof d.context_window === 'number' && d.context_window > 0
        ? ' / ' + human(d.context_window) : '');
    var sub = document.createElement('span');
    sub.className = 'claude-cache-sub';
    sub.textContent = (d.model || '')
      + (d.effort ? ' · ' + d.effort : '');
    head.appendChild(sub);
    body.appendChild(head);

    var verdictCls =
      verdict === 'попадание' ? 'claude-cache-hit' :
      verdict === 'старт' ? '' : 'claude-cache-miss';
    body.appendChild(row(
      'последний ход',
      verdict + (gap ? ' · пауза ' + gap : ''),
      verdictCls
    ));
    var openaiLive = d.live_provider === 'openai';
    body.appendChild(row(
      'чтение / запись' + (openaiLive ? ' (API)' : ''),
      human(last.read) + ' / ' + human(last.write),
      '',
      openaiLive
        ? 'Сырые cachedInputTokens / cacheWriteInputTokens, полученные '
          + 'от Codex App Server для последнего хода'
        : ''
    ));
    if (openaiLive && last.cache_status) {
      var cacheStatusClass = last.cache_status === 'попадание'
        ? 'claude-cache-hit'
        : last.cache_status === 'холодный старт'
          ? 'claude-cache-explained' : 'claude-cache-miss';
      body.appendChild(row(
        'кэш OpenAI', last.cache_status, cacheStatusClass,
        last.cache_status === 'холодный старт'
          ? 'Первый запрос нового Codex-thread: читать ещё нечего. '
            + 'Следующий запрос покажет попадание либо промах'
          : 'Состояние prompt-кэша по cachedInputTokens последнего хода'
      ));
    }
    if (typeof d.context_window === 'number' && d.context_window > 0) {
      body.appendChild(row('окно модели', human(d.context_window)));
    }

    body.appendChild(document.createElement('hr'));

    body.appendChild(row('запросов', String(d.requests)));
    body.appendChild(row('прочитано из кэша', human(d.read)));
    body.appendChild(row('записано в кэш', human(d.write)));
    body.appendChild(row('свежий input', human(d.fresh)));
    body.appendChild(row('output', human(d.output)));
    var earlyMisses = typeof d.early_misses === 'number' ? d.early_misses : null;
    var missesRow = row(
      'промахов', earlyMisses === null ? '—' : String(earlyMisses),
      'claude-cache-miss',
      'Красным — ранние промахи: интервал короче TTL провайдера, '
        + 'кроме ходов после смены модели или аккаунта. '
        + 'В скобках — остальные промахи. '
        + 'Оба числа пересчитываются при изменении TTL'
    );
    if (earlyMisses !== null && typeof d.misses === 'number') {
      var otherCount = document.createElement('span');
      otherCount.className = 'claude-cache-other-count';
      otherCount.textContent = ' (' + Math.max(0, d.misses - earlyMisses) + ')';
      missesRow.children[1].appendChild(otherCount);
    }
    if (d.rewritten) missesRow.children[1].appendChild(
      document.createTextNode(' · переписано ' + human(d.rewritten))
    );
    body.appendChild(missesRow);

    body.appendChild(document.createElement('hr'));

    body.appendChild(row('с кэшем', money(d.cost)));
    body.appendChild(row('без кэша было бы', money(d.cost_naive)));
    body.appendChild(row('экономия', d.ratio + '×', 'claude-cache-hit'));
    if (d.wasted) {
      // Минус — это расход, а не поступление; знак снимает двусмысленность.
      body.appendChild(row(
        'потеряно на промахах', '-' + money(d.wasted), 'claude-cache-miss'
      ));
    }

    // Промахи, у которых нашлась причина, показываем отдельной строкой:
    // это разница между «кэш течёт» и «я много переключался».
    if (d.explained_misses) {
      body.appendChild(row(
        'из них после переключений', String(d.explained_misses),
        'claude-cache-explained',
        'Промахи сразу после смены модели или аккаунта. Кэш в этот '
        + 'момент холодный по определению, поэтому в потери они не идут'
      ));
    }

    renderHistoryTabs(body, d, ttl, rate);

    // Показываем, чью статистику видим. Без этого нельзя отличить
    // «данные моей вкладки» от «данные соседней, попавшей под
    // автоопределение по свежести файла».
    var foot = document.createElement('div');
    foot.className = 'claude-cache-foot';
    foot.textContent = 'сессия ' + String(d.session || '—').slice(0, 8)
      + (guessed ? ' · выбрана по свежести файла' : '');
    body.appendChild(foot);
  }

  function openPanel(btn) {
    closePanel();
    anchorBtn = btn;

    panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.className = 'claude-cache-panel';
    var openedPanel = panel;

    var body = document.createElement('div');
    body.className = 'claude-cache-body';
    body.textContent = 'загрузка…';
    panel.appendChild(body);
    document.body.appendChild(panel);

    // Футер прижат к низу окна, поэтому раскрываемся вверх от кнопки.
    var r = btn.getBoundingClientRect();
    panel.style.bottom = Math.max(8, window.innerHeight - r.top + 6) + 'px';
    panel.style.right = Math.max(8, window.innerWidth - r.right) + 'px';

    document.addEventListener('mousedown', onOutside, true);
    document.addEventListener('keydown', onKeydown, true);

    var sid = findSessionId();
    // Keep data and reading position separate for each chat. Render the last
    // snapshot synchronously; network requests only refresh an already open UI.
    panelState = sid ? usageSession(sid) : { tab: 'cache', scroll: 0, expanded: {} };
    historyTab = panelState.tab;
    var saved = panelState;
    if (saved.stats) {
      body.textContent = '';
      renderStats(body, saved.stats, false);
      usageViewReady = true;
      restoreUsageView();
    }
    logInfo(sid ? 'session id: ' + sid : 'session id не найден, спрашиваем свежую');
    var url = sid ? API_URL + '?session=' + encodeURIComponent(sid) : API_URL;

    fetch(url, { cache: 'no-store' })
      .then(function (res) { return res.json(); })
      .then(function (d) {
        if (panel !== openedPanel) return;
        if (!(d && d.ok) && saved.stats) {
          logInfo('refresh failed; keeping previous Usage snapshot');
          return;
        }
        captureUsageView();
        if (historyCleanup) { historyCleanup(); historyCleanup = null; }
        body.textContent = '';
        if (d && d.ok) {
          saved.stats = d;
          renderStats(body, d, !sid);
        }
        else {
          renderError(body, (d && d.error) || 'нет данных');
          if (sid) renderHistoryTabs(body, { session: sid, history: [] }, 60, 5);
        }
        // Высота стала известна только сейчас — переставляем, чтобы
        // панель не уезжала за верхний край на длинном списке промахов.
        var rr = btn.getBoundingClientRect();
        panel.style.bottom = Math.max(8, window.innerHeight - rr.top + 6) + 'px';
        usageViewReady = true;
        restoreUsageView();
      })
      .catch(function (err) {
        if (panel !== openedPanel) return;
        if (!saved.stats) {
          body.textContent = '';
          renderError(body, 'http-server.py недоступен (порт 18923)');
        }
        logInfo('fetch failed', err);
      });
  }

  /* ---------- кнопка ---------- */

  /**
   * Ищет точку вставки и донора стиля.
   *
   * Донор — обязательно сама `<button>`, а не обёртка вокруг неё:
   * футер собран из CSS-модулей (`footerButton_<hash>`), и весь вид —
   * размеры, шрифт, hover — висит на кнопке. Копирование класса
   * с внешнего div'а даёт пустой контейнерный класс, после чего
   * проступает UA-оформление <button> — серая плашка с рамкой.
   *
   * Точка вставки — предок найденной кнопки, лежащий прямо в футере:
   * контрол режима обёрнут в свой контейнер, и вставлять надо рядом
   * с обёрткой, иначе кнопка окажется внутри чужого поповера.
   */
  function findAnchor(footer) {
    var buttons = footer.querySelectorAll('button');
    var match = null;
    for (var i = 0; i < buttons.length; i++) {
      if (AUTO_EDIT_RE.test(buttons[i].textContent || '')) {
        match = buttons[i];
        break;
      }
    }
    if (match) {
      var node = match;
      while (node.parentNode && node.parentNode !== footer) node = node.parentNode;
      return {
        before: node.parentNode === footer ? node : null,
        donor: match,
      };
    }
    // Режим переключён на другой (лейбл иной) — донора берём с любой
    // штатной кнопки футера, чтобы вид всё равно совпал.
    return {
      before: null,
      donor: footer.querySelector('[class*="footerButton_"]')
        || footer.querySelector('button'),
    };
  }

  /**
   * Иконка-цилиндр БД перед подписью.
   *
   * Штатные кнопки футера собраны как `<svg 20×20 fill="none">` плюс
   * голый `<span>` с текстом; размер иконки задаёт сам класс
   * `footerButton_`, поэтому важно повторить именно эту разметку —
   * тогда наша иконка отмасштабируется вместе с родными.
   *
   * Строим через createElementNS, а не innerHTML: SVG живёт в своём
   * namespace, а innerHTML в webview может упереться в Trusted Types.
   */
  function cacheIcon() {
    var NS = 'http://www.w3.org/2000/svg';
    function el(name, attrs) {
      var node = document.createElementNS(NS, name);
      for (var k in attrs) {
        if (Object.prototype.hasOwnProperty.call(attrs, k)) {
          node.setAttribute(k, attrs[k]);
        }
      }
      return node;
    }
    var svg = el('svg', {
      width: '20', height: '20', viewBox: '0 0 20 20', fill: 'none',
    });
    var stroke = {
      stroke: 'currentColor',
      'stroke-width': '1.2',
      'stroke-linecap': 'round',
    };
    // Верхний эллипс + бока цилиндра + средняя перемычка.
    svg.appendChild(el('ellipse', {
      cx: '10', cy: '5.75', rx: '5.25', ry: '2.25',
      stroke: 'currentColor', 'stroke-width': '1.2',
    }));
    svg.appendChild(el('path', Object.assign({
      d: 'M4.75 5.75V14.25C4.75 15.49 7.1 16.5 10 16.5C12.9 16.5 15.25 15.49 15.25 14.25V5.75',
    }, stroke)));
    svg.appendChild(el('path', Object.assign({
      d: 'M4.75 10C4.75 11.24 7.1 12.25 10 12.25C12.9 12.25 15.25 11.24 15.25 10',
    }, stroke)));
    return svg;
  }

  function createButton(donor) {
    var btn = document.createElement('button');
    btn.type = 'button';
    if (donor && typeof donor.className === 'string' && donor.className) {
      btn.className = claudeNativeButtonClasses(donor) + ' ' + BTN_CLASS;
    } else {
      // Донора не нашли — гасим UA-оформление своими руками.
      btn.className = BTN_CLASS + ' ' + BARE_CLASS;
    }
    btn.title = 'Статистика prompt-кэша сессии';
    btn.appendChild(cacheIcon());
    var label = document.createElement('span');
    label.textContent = 'Usage';
    btn.appendChild(label);
    // Без preventDefault фокус уходит из composer'а: пользователь
    // теряет позицию каретки просто посмотрев статистику.
    btn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (panel) closePanel();
      else openPanel(btn);
    });
    return btn;
  }

  function mount(container) {
    var footer = container.querySelector('[class*="inputFooter_"]');
    if (!footer) return false;
    var anchor = findAnchor(footer);
    var btn = createButton(anchor.donor);
    // Порядок в футере: Usage · Cache · ByPass · автоправки. Ищем
    // самого левого из уже вставленных соседей — так позиция не зависит
    // от того, какой модуль смонтировался первым.
    var neighbour = footer.querySelector('.claude-keepalive-btn')
      || footer.querySelector('.claude-bypass-btn');
    if (neighbour && neighbour.parentNode === footer) {
      footer.insertBefore(btn, neighbour);
    } else if (anchor.before) {
      footer.insertBefore(btn, anchor.before);
    } else {
      // Лейбл не найден — цепляемся за spacer, он разделяет левую
      // и правую группы футера.
      var spacer = footer.querySelector('[class*="spacer_"]');
      if (spacer && spacer.parentNode === footer) {
        footer.insertBefore(btn, spacer.nextSibling);
      } else {
        footer.appendChild(btn);
      }
    }
    logInfo(
      'кнопка встроена',
      anchor.before ? 'рядом с автоправками' : 'по запасному якорю',
      anchor.donor ? 'стиль от ' + anchor.donor.className : 'без донора стиля'
    );
    return true;
  }

  /**
   * Держит порядок Usage · Cache · ByPass даже если кнопки появились
   * не в том порядке. Вставка при монтировании этого не гарантирует:
   * React пересоздаёт футер, модули домонтируются по своим таймерам,
   * и кто окажется первым — как повезёт.
   */
  function ensureOrder(footer) {
    var me = footer.querySelector('.' + BTN_CLASS);
    if (!me || me.parentNode !== footer) return;
    var right = footer.querySelector('.claude-keepalive-btn')
      || footer.querySelector('.claude-bypass-btn');
    if (!right || right.parentNode !== footer) return;
    // DOCUMENT_POSITION_FOLLOWING — сосед идёт ПОСЛЕ нас, всё верно.
    if (me !== right && !(me.compareDocumentPosition(right) & 4)) {
      footer.insertBefore(me, right);
      logInfo('порядок восстановлен: Usage перед соседями');
    }
  }

  function scan(ctx) {
    // Узлы даёт общий обход (см. DOM WATCH) — один на все модули.
    // Свой поиск остаётся для вызовов вне прохода: при регистрации
    // и из обработчиков самого модуля.
    var containers = (ctx && ctx.inputs)
      || document.querySelectorAll('[class*="inputContainer_"]');
    for (var i = 0; i < containers.length; i++) {
      var footer = containers[i].querySelector('[class*="inputFooter_"]');
      // Проверяем по наличию элемента, а не по флагу-атрибуту: React
      // пересоздаёт поле ввода вместе с нашими атрибутами.
      if (containers[i].querySelector('.' + BTN_CLASS)) {
        if (footer) ensureOrder(footer);
        continue;
      }
      if (!containers[i].querySelector('[role="textbox"][contenteditable]')) continue;
      mount(containers[i]);
    }
    // Панель пережила пересоздание своей кнопки — закрываем, иначе
    // она повиснет непривязанной.
    if (panel && anchorBtn && !document.body.contains(anchorBtn)) closePanel();
  }

  function init() {
    // Наблюдатель и подстраховочный таймер — общие (см. DOM WATCH).
    window.__claudeDomWatch.register('usage', scan);
    logInfo('installed');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * BYPASS BUTTON
 *
 * Кнопка «ByPass» в футере, между Cache и «Править автоматически».
 * Ручной вход в тот же режим, который включает слово `да!`: пока он
 * активен, PreToolUse хук bypass-check.sh отвечает harness'у
 * permissionDecision=allow, и окна подтверждения не появляются.
 *
 * Механизм один и тот же — marker-файл .claude/hooks-runtime/<session_id>.
 * bypass-magic-word.py ставит его по слову, эта кнопка — через
 * POST /bypass. Поэтому состояние общее: включив режим словом, увидишь
 * кнопку активной, и наоборот. Выключить кнопкой можно, словом — нет
 * (магическое слово только включает).
 *
 * В отличие от слова, кнопка умеет и снимать marker, так что это ещё
 * и единственный способ выйти из режима, не закрывая сессию.
 *
 * Состояние опрашивается раз в BYPASS_POLL_MS: режим могли включить
 * словом в этой же вкладке, и кнопка обязана это отразить.
 *
 * Управление: `bypassButton` в claude-custom-config.toml.
 * ============================================================ */
(function () {
  if (window.__claudeBypassButtonInstalled) return;
  window.__claudeBypassButtonInstalled = true;

  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  if (cfg.bypassButton !== true) return;

  var API_URL = 'http://localhost:18923/bypass';
  var BTN_CLASS = 'claude-bypass-btn';
  var BARE_CLASS = 'claude-bypass-btn-bare';
  var ON_CLASS = 'claude-bypass-on';
  var BYPASS_POLL_MS = 5000;
  var AUTO_EDIT_RE = /Править автоматически|Edit automatically/i;
  var STORAGE_KEY = 'claudeCustomBypass';
  var CARRY_MS = (typeof cfg.buttonStateCarrySec === 'number'
    && cfg.buttonStateCarrySec >= 0 ? cfg.buttonStateCarrySec : 600) * 1000;

  var active = false;
  var carryChecked = false;  // перенос состояния пробовали делать

  function logInfo() {
    if (!cfg.logs) return;
    try {
      console.log.apply(console, ['[bypass-btn]'].concat([].slice.call(arguments)));
    } catch (e) {}
  }

  function sessionId() {
    var fn = window.__claudeSessionId;
    return typeof fn === 'function' ? fn() : null;
  }

  /* ---------- иконка ---------- */

  function boltIcon() {
    var NS = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('width', '20');
    svg.setAttribute('height', '20');
    svg.setAttribute('viewBox', '0 0 20 20');
    svg.setAttribute('fill', 'none');
    var path = document.createElementNS(NS, 'path');
    path.setAttribute('d', 'M11.5 2.5L5 11h3.5L8 17.5L15 9h-3.5z');
    path.setAttribute('fill', 'currentColor');
    svg.appendChild(path);
    return svg;
  }

  /* ---------- состояние ---------- */

  /**
   * Штатный «выключенный» вид берём у самого расширения: в CSS-модуле
   * футера рядом с footerButton_<hash> лежит footerButtonInactive_<hash>
   * с тем же хешем. Достраиваем имя из класса донора — так приглушённая
   * кнопка выглядит ровно как неактивная штатная.
   */
  function inactiveClassFrom(donorClass) {
    var m = /(?:^|\s)footerButton_(\w+)(?:\s|$)/.exec(donorClass || '');
    return m ? 'footerButtonInactive_' + m[1] : '';
  }

  function applyState(btn) {
    var inactive = btn.getAttribute('data-inactive-class') || '';
    if (inactive) {
      if (active) btn.classList.remove(inactive);
      else btn.classList.add(inactive);
    }
    if (active) btn.classList.add(ON_CLASS);
    else btn.classList.remove(ON_CLASS);
    btn.title = active
      ? 'Bypass включён: tool-вызовы идут без подтверждения. Клик — выключить.'
      : 'Bypass выключен. Клик — пропускать tool-вызовы без подтверждения '
        + 'до конца сессии (то же, что слово «да!»).';
  }

  function applyStateAll() {
    var nodes = document.querySelectorAll('.' + BTN_CLASS);
    for (var i = 0; i < nodes.length; i++) applyState(nodes[i]);
  }

  /* ---------- перенос состояния между сессиями ---------- */

  /**
   * Состояние bypass живёт в marker-файле на стороне сервера и привязано
   * к session id, а перезагрузка окна создаёт новую сессию — плюс
   * SessionEnd-хук маркер удаляет. Поэтому после перезагрузки режим
   * честно выключен, и восстановить его можно только поставив маркер
   * заново.
   *
   * Запоминаем последний явный выбор в localStorage и переносим его,
   * если он свежее CARRY_MS. Окно намеренно короткое: авто-снятие
   * подтверждений при закрытии сессии — защитное свойство механизма,
   * и превращать его в бессрочное включение нельзя. Перезагрузка
   * занимает секунды, так что нескольких минут достаточно.
   */
  function readLast() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      var obj = raw ? JSON.parse(raw) : null;
      return obj && typeof obj === 'object' ? obj : null;
    } catch (e) {
      return null;
    }
  }

  function writeLast(on) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        on: !!on, at: Date.now(),
      }));
    } catch (e) {}
  }

  function shouldCarry() {
    var last = readLast();
    return !!(last && last.on === true && typeof last.at === 'number'
      && Date.now() - last.at <= CARRY_MS);
  }

  function refresh() {
    var sid = sessionId();
    if (!sid) return;
    fetch(API_URL + '?session=' + encodeURIComponent(sid), { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.ok) return;

        // Первый ответ после загрузки страницы: сервер говорит
        // «выключен», но пользователь включал режим только что —
        // значит это последствие перезагрузки, а не его решение.
        if (!carryChecked) {
          carryChecked = true;
          if (!d.active && shouldCarry()) {
            logInfo('переношу включённый режим на новую сессию');
            send(sid, true);
            return;
          }
        }

        if (d.active !== active) {
          active = !!d.active;
          applyStateAll();
          logInfo('состояние обновлено:', active ? 'включён' : 'выключен');
        }
      })
      .catch(function () {});
  }

  /** Ставит или снимает маркер на сервере. */
  function send(sid, want) {
    return fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sid, active: want }),
    })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.ok) throw new Error((d && d.error) || 'отказ сервера');
        active = !!d.active;
        applyStateAll();
        return active;
      });
  }

  function toggle(btn) {
    var sid = sessionId();
    if (!sid) {
      logInfo('session id не определён — переключать нечего');
      btn.title = 'Не удалось определить сессию вкладки';
      return;
    }
    var want = !active;
    send(sid, want)
      .then(function (state) {
        // Запоминаем именно явный выбор пользователя — на него потом
        // опирается перенос после перезагрузки.
        writeLast(state);
        logInfo(state ? 'включён' : 'выключен');
      })
      .catch(function (err) {
        logInfo('переключение не удалось', err);
        btn.title = 'http-server.py недоступен (порт 18923)';
      });
  }

  /* ---------- встраивание ---------- */

  function findAnchor(footer) {
    var buttons = footer.querySelectorAll('button');
    var match = null;
    for (var i = 0; i < buttons.length; i++) {
      if (AUTO_EDIT_RE.test(buttons[i].textContent || '')) {
        match = buttons[i];
        break;
      }
    }
    if (match) {
      var node = match;
      while (node.parentNode && node.parentNode !== footer) node = node.parentNode;
      return {
        before: node.parentNode === footer ? node : null,
        donor: match,
      };
    }
    return {
      before: null,
      donor: footer.querySelector('[class*="footerButton_"]')
        || footer.querySelector('button'),
    };
  }

  function createButton(donor) {
    var btn = document.createElement('button');
    btn.type = 'button';
    var donorClass = claudeNativeButtonClasses(donor);
    if (donorClass) {
      btn.className = donorClass + ' ' + BTN_CLASS;
      var inactive = inactiveClassFrom(donorClass);
      if (inactive) btn.setAttribute('data-inactive-class', inactive);
    } else {
      btn.className = BTN_CLASS + ' ' + BARE_CLASS;
    }
    btn.appendChild(boltIcon());
    var label = document.createElement('span');
    label.textContent = 'ByPass';
    btn.appendChild(label);
    applyState(btn);
    btn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      toggle(btn);
    });
    return btn;
  }

  function mount(container) {
    var footer = container.querySelector('[class*="inputFooter_"]');
    if (!footer) return false;
    var anchor = findAnchor(footer);
    var btn = createButton(anchor.donor);
    // Порядок в футере: Usage · Cache · ByPass · автоправки. ByPass —
    // самый правый из наших, поэтому просто встаёт перед обёрткой
    // автоправок; соседи слева ориентируются уже на него.
    if (anchor.before) {
      footer.insertBefore(btn, anchor.before);
    } else {
      var spacer = footer.querySelector('[class*="spacer_"]');
      if (spacer && spacer.parentNode === footer) {
        footer.insertBefore(btn, spacer.nextSibling);
      } else {
        footer.appendChild(btn);
      }
    }
    return true;
  }

  function scan(ctx) {
    // Узлы даёт общий обход (см. DOM WATCH) — один на все модули.
    // Свой поиск остаётся для вызовов вне прохода: при регистрации
    // и из обработчиков самого модуля.
    var containers = (ctx && ctx.inputs)
      || document.querySelectorAll('[class*="inputContainer_"]');
    for (var i = 0; i < containers.length; i++) {
      if (containers[i].querySelector('.' + BTN_CLASS)) continue;
      if (!containers[i].querySelector('[role="textbox"][contenteditable]')) continue;
      mount(containers[i]);
    }
  }

  function init() {
    refresh();
    // Наблюдатель и подстраховочный таймер — общие (см. DOM WATCH).
    window.__claudeDomWatch.register('bypass', scan);
    setInterval(refresh, BYPASS_POLL_MS);
    logInfo('installed');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * FIND IN PAGE
 *
 * Кнопка 🔍 рядом с иконкой автосжатия (`usageButtonV2_*`) в футере.
 * По клику (или Ctrl+F) открывается строка поиска: подсветка всех
 * совпадений в переписке, переход по ним, счётчик «текущее/всего».
 *
 * Подсветка сделана через CSS Custom Highlight API
 * (`CSS.highlights` + `::highlight()`), а НЕ обёрткой в <mark>.
 * Это принципиально: переписка React-управляемая, любая вставка
 * элементов в неё слетает на ближайшем ре-рендере, а во время
 * стриминга ответа он происходит непрерывно. Highlight API работает
 * поверх Range и DOM вообще не трогает — совпадения переживают
 * перерисовку, пока живы текстовые узлы.
 *
 * Область поиска — `messagesContainer_*`; поле ввода исключено
 * намеренно: там текст прозрачный, а видимую копию рисует зеркало
 * (см. правило про .mentionMirror_ в claude-custom.css), и подсветка
 * в нём выглядела бы как совпадение в пустоте.
 *
 * Управление: `findInPage` в claude-custom-config.toml.
 * ============================================================ */
(function () {
  if (window.__claudeFindInPageInstalled) return;
  window.__claudeFindInPageInstalled = true;

  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  if (cfg.findInPage !== true) return;
  // Без Highlight API подсветить нечем, а ломать DOM ради этого нельзя.
  if (typeof CSS === 'undefined' || !CSS.highlights || typeof Highlight === 'undefined') {
    return;
  }

  var BTN_CLASS = 'claude-find-btn';
  var BARE_CLASS = 'claude-find-btn-bare';  // без донора стиля
  var BAR_ID = 'claude-find-bar';

  var scanning = false;      // защита от повторного входа
  var disabled = false;      // выключено предохранителем
  var mounts = 0;            // вставок с прошлой проверки
  var HL_ALL = 'claude-find';
  var HL_ACTIVE = 'claude-find-active';
  var DEBOUNCE_MS = 150;

  var bar = null;
  var input = null;
  var counter = null;
  var ranges = [];
  var index = -1;
  var debounceTimer = null;

  function logInfo() {
    if (!cfg.logs) return;
    try {
      console.log.apply(console, ['[find]'].concat([].slice.call(arguments)));
    } catch (e) {}
  }

  function searchRoot() {
    return document.querySelector('[class*="messagesContainer_"]') || document.body;
  }

  /* ---------- поиск ---------- */

  function collectRanges(query) {
    var found = [];
    if (!query) return found;
    var root = searchRoot();
    var needle = query.toLowerCase();

    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function (node) {
        if (!node.nodeValue) return NodeFilter.FILTER_REJECT;
        var el = node.parentElement;
        if (!el) return NodeFilter.FILTER_REJECT;
        // Своя строка поиска и поле ввода из выдачи исключены.
        if (el.closest('#' + BAR_ID)) return NodeFilter.FILTER_REJECT;
        if (el.closest('[class*="inputContainer_"]')) return NodeFilter.FILTER_REJECT;
        // <script>/<style> попадают в обход TreeWalker'а как текст.
        var tag = el.tagName;
        if (tag === 'SCRIPT' || tag === 'STYLE') return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      },
    });

    var node;
    while ((node = walker.nextNode())) {
      var text = node.nodeValue.toLowerCase();
      var from = 0;
      for (;;) {
        var at = text.indexOf(needle, from);
        if (at === -1) break;
        var r = document.createRange();
        r.setStart(node, at);
        r.setEnd(node, at + needle.length);
        found.push(r);
        from = at + needle.length;
        if (found.length > 5000) return found;  // защита от «а» на длинной переписке
      }
    }
    return found;
  }

  function paint() {
    try {
      if (!ranges.length) {
        CSS.highlights.delete(HL_ALL);
        CSS.highlights.delete(HL_ACTIVE);
        return;
      }
      // Highlight — Set-подобный объект; добавляем по одному, а не
      // через spread: совпадений бывают тысячи, и раскладывать их
      // в аргументы вызова незачем.
      var all = new Highlight();
      for (var i = 0; i < ranges.length; i++) all.add(ranges[i]);
      CSS.highlights.set(HL_ALL, all);
      var current = ranges[index];
      if (current) CSS.highlights.set(HL_ACTIVE, new Highlight(current));
      else CSS.highlights.delete(HL_ACTIVE);
    } catch (e) {
      logInfo('подсветка не удалась', e);
    }
  }

  function updateCounter() {
    if (!counter) return;
    if (!input || !input.value) counter.textContent = '';
    else if (!ranges.length) counter.textContent = 'нет совпадений';
    else counter.textContent = (index + 1) + '/' + ranges.length;
  }

  function scrollToCurrent() {
    var r = ranges[index];
    if (!r) return;
    var el = r.startContainer.parentElement;
    if (el && el.scrollIntoView) {
      el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }
  }

  function runSearch(keepIndex) {
    var query = input ? input.value : '';
    var previous = index;
    ranges = collectRanges(query);
    if (!ranges.length) index = -1;
    else if (keepIndex && previous >= 0) index = Math.min(previous, ranges.length - 1);
    else index = 0;
    paint();
    updateCounter();
    if (index >= 0 && !keepIndex) scrollToCurrent();
    logInfo('совпадений:', ranges.length);
  }

  function step(delta) {
    if (!ranges.length) return;
    // Узлы могли исчезнуть при ре-рендере — тогда пересчитываем.
    var alive = ranges[index] && ranges[index].startContainer.isConnected;
    if (!alive) {
      runSearch(true);
      if (!ranges.length) return;
    }
    index = (index + delta + ranges.length) % ranges.length;
    paint();
    updateCounter();
    scrollToCurrent();
  }

  /* ---------- строка поиска ---------- */

  function closeBar() {
    if (debounceTimer) { clearTimeout(debounceTimer); debounceTimer = null; }
    if (bar) bar.remove();
    bar = null;
    input = null;
    counter = null;
    ranges = [];
    index = -1;
    try {
      CSS.highlights.delete(HL_ALL);
      CSS.highlights.delete(HL_ACTIVE);
    } catch (e) {}
  }

  function navButton(label, title, onClick) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'claude-find-nav';
    b.textContent = label;
    b.title = title;
    b.addEventListener('mousedown', function (e) { e.preventDefault(); });
    b.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    return b;
  }

  function openBar(anchor) {
    if (bar) { input.focus(); input.select(); return; }

    bar = document.createElement('div');
    bar.id = BAR_ID;
    bar.className = 'claude-find-bar';

    input = document.createElement('input');
    input.type = 'text';
    input.className = 'claude-find-input';
    input.placeholder = 'Поиск по переписке';
    input.addEventListener('input', function () {
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(function () { runSearch(false); }, DEBOUNCE_MS);
    });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        if (!ranges.length) runSearch(false);
        else step(e.shiftKey ? -1 : 1);
      } else if (e.key === 'Escape') {
        e.preventDefault();
        closeBar();
      }
    });

    counter = document.createElement('span');
    counter.className = 'claude-find-count';

    bar.appendChild(input);
    bar.appendChild(counter);
    bar.appendChild(navButton('↑', 'Предыдущее (Shift+Enter)', function () { step(-1); }));
    bar.appendChild(navButton('↓', 'Следующее (Enter)', function () { step(1); }));
    bar.appendChild(navButton('✕', 'Закрыть (Esc)', closeBar));
    document.body.appendChild(bar);

    placeBar();
    input.focus();
  }

  /**
   * Ставит строку над всей формой ввода, а не над кнопкой.
   *
   * Футер — часть той же рамки, что и поле: при многострочном тексте
   * форма растёт вверх и накрывает панель, привязанную к кнопке.
   * Якорь по `inputContainer_` держит строку выше рамки целиком.
   */
  /**
   * Контейнер ВИДИМОГО поля ввода.
   *
   * Просто `querySelector('[class*="inputContainer_"]')` брал первый
   * попавшийся узел — а он не обязательно тот, в котором лежит
   * композер (свои inputContainer_ есть и у скрытых, и у поповерных
   * форм). Панель из-за этого уезжала к левому краю окна, а не к краю
   * формы. Идём от самого поля ввода вверх — тот же приём, из-за
   * отсутствия которого модуль вчера подвесил webview.
   */
  function hostElement() {
    var composer = document.querySelector('[role="textbox"][contenteditable]');
    if (composer) {
      var host = composer.closest('[class*="inputContainer_"]');
      if (host) return host;
    }
    return document.querySelector('[class*="inputContainer_"]');
  }

  function placeBar() {
    if (!bar) return;
    var host = hostElement();
    if (!host) return;
    var r = host.getBoundingClientRect();
    bar.style.bottom = Math.max(8, window.innerHeight - r.top + 8) + 'px';
    // Левый край панели совпадает с левым краем формы — кнопка тоже
    // слева, и строка раскрывается прямо над ней. Если панель шире
    // остатка окна, поджимаем, чтобы не уехала за правый край.
    var width = bar.offsetWidth || 0;
    var left = Math.max(8, Math.min(r.left, window.innerWidth - width - 8));
    bar.style.left = left + 'px';
    bar.style.right = 'auto';
  }

  /* ---------- кнопка ---------- */

  function lensIcon() {
    var NS = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('width', '20');
    svg.setAttribute('height', '20');
    svg.setAttribute('viewBox', '0 0 20 20');
    svg.setAttribute('fill', 'none');
    var circle = document.createElementNS(NS, 'circle');
    circle.setAttribute('cx', '9');
    circle.setAttribute('cy', '9');
    circle.setAttribute('r', '4.75');
    circle.setAttribute('stroke', 'currentColor');
    circle.setAttribute('stroke-width', '1.3');
    var handle = document.createElementNS(NS, 'path');
    handle.setAttribute('d', 'M12.6 12.6L16 16');
    handle.setAttribute('stroke', 'currentColor');
    handle.setAttribute('stroke-width', '1.3');
    handle.setAttribute('stroke-linecap', 'round');
    svg.appendChild(circle);
    svg.appendChild(handle);
    return svg;
  }

  function createButton(donor) {
    var btn = document.createElement('button');
    btn.type = 'button';
    var donorClass = claudeNativeButtonClasses(donor);
    // Без класса штатной кнопки проступает UA-оформление <button> —
    // серая плашка с рамкой, чужеродная в футере.
    btn.className = donorClass
      ? donorClass + ' ' + BTN_CLASS
      : BTN_CLASS + ' ' + BARE_CLASS;
    btn.title = 'Поиск по переписке (Ctrl+F)';
    btn.appendChild(lensIcon());
    btn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (bar) closeBar();
      else openBar(btn);
    });
    return btn;
  }

  /**
   * Место — в левой группе футера, сразу за кнопкой меню `/`.
   *
   * Донора стиля берём у неё же, а не у `footerButton_`: меню —
   * иконка без подписи, той же формы и размера, что наша лупа.
   * `footerButton_` рассчитан на «иконка + текст» и даёт лишний
   * отступ справа.
   */
  function findSlot(footer) {
    var menu = footer.querySelector('[class*="menuButton_"]');
    if (menu && menu.parentNode === footer) {
      return { before: menu.nextSibling, donor: menu };
    }
    var donor = footer.querySelector('[class*="footerButton_"]')
      || footer.querySelector('button');
    return { before: footer.firstChild, donor: donor };
  }

  function mount(footer) {
    var slot = findSlot(footer);
    var btn = createButton(slot.donor);
    if (slot.before) footer.insertBefore(btn, slot.before);
    else footer.appendChild(btn);
    mounts++;
    return true;
  }

  /**
   * Сканирует ТОЛЬКО настоящее поле ввода.
   *
   * Раньше здесь был `querySelectorAll('[class*="inputFooter_"]')`,
   * и это подвесило webview: свой `inputFooter_` есть у поповера меню
   * `/` (см. SETTINGS MENU FIX). Кнопка вставлялась и туда, React сносил
   * её при перерисовке, MutationObserver звал скан заново — цикл
   * mount → мутация → mount, главный поток вставал, окно переставало
   * отвечать. Остальные модули не страдали именно потому, что идут
   * от `inputContainer_` и требуют внутри поле ввода; здесь тот же
   * фильтр.
   */
  function scan(ctx) {
    if (scanning || disabled) return;
    scanning = true;
    try {
      // Узлы даёт общий обход (см. DOM WATCH) — один на все модули.
      // Свой поиск остаётся для вызовов вне прохода: при регистрации
      // и из обработчиков самого модуля.
      var containers = (ctx && ctx.inputs)
        || document.querySelectorAll('[class*="inputContainer_"]');
      for (var i = 0; i < containers.length; i++) {
        if (!containers[i].querySelector('[role="textbox"][contenteditable]')) continue;
        var footer = containers[i].querySelector('[class*="inputFooter_"]');
        if (!footer) continue;
        if (footer.querySelector('.' + BTN_CLASS)) {
          ensureOrder(footer);
          continue;
        }
        mount(footer);
      }
      if (bar) placeBar();
    } finally {
      scanning = false;
    }
  }

  /** Держит кнопку сразу за меню `/`, если ре-рендер её сдвинул. */
  function ensureOrder(footer) {
    var me = footer.querySelector('.' + BTN_CLASS);
    var menu = footer.querySelector('[class*="menuButton_"]');
    if (!me || !menu) return;
    if (me.parentNode !== footer || menu.parentNode !== footer) return;
    if (menu.nextSibling !== me) footer.insertBefore(me, menu.nextSibling);
  }

  /**
   * Предохранитель. Если вставок за минуту оказалось неправдоподобно
   * много — значит кнопку кто-то сносит и мы попали в цикл. Лучше
   * выключить поиск, чем подвесить окно: цену такой ошибки я уже
   * заплатил чужим временем.
   */
  function guard() {
    if (mounts > 200) {
      disabled = true;
      logInfo('слишком много вставок за минуту — модуль отключён');
    }
    mounts = 0;
  }

  function onHotkey(e) {
    if (!(e.ctrlKey || e.metaKey) || e.key !== 'f') return;
    var anchor = document.querySelector('.' + BTN_CLASS);
    if (!anchor) return;
    e.preventDefault();
    e.stopPropagation();
    openBar(anchor);
  }

  function init() {
    // Наблюдатель, его throttle и подстраховочный таймер — общие
    // (см. DOM WATCH). Свой throttle этот модуль завёл первым, после
    // того как скан на каждую мутацию подвесил webview; теперь он
    // распространён на всех, а здесь остаётся только счётчик вставок:
    // он ловит не дороговизну скана, а цикл «вставили — снесли».
    window.__claudeDomWatch.register('find-in-page', scan);
    setInterval(guard, 60000);
    document.addEventListener('keydown', onHotkey, true);
    window.addEventListener('resize', placeBar);
    logInfo('installed');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * QUOTE FROM SELECTION — контекстная кнопка цитирования
 * ============================================================
 *
 * Когда выделение текста ЗАВЕРШЕНО, у его конца появляется значок
 * цитаты (❝). По клику текст преобразуется в цитату (`> ` перед
 * каждой строкой) и вставляется в composer с новой строки.
 *
 * Работает с выделением в:
 *   - переписке Claude (сообщения, промеки)
 *   - коде и форматированном тексте
 *
 * Примеры вставки (composer не пуст):
 *   "hello\nworld"       → "\n> hello\n> world\n"
 *   "one"                → "\n> one\n"
 *   "абзац\n\nабзац"     → "\n> абзац\n> абзац\n"
 *
 * Последний пример — не описка: соседние абзацы Selection API отдаёт
 * разделёнными пустой строкой, и в цитате она не нужна (см. toQuote).
 *
 * Перевод строки в конце обязателен: он оставляет каретку в начале
 * следующей строки, сразу под цитатой. Иначе набор ответа начинался
 * бы с нажатия Enter, чтобы не дописывать свой текст к чужой цитате.
 *
 * Момент появления. Кнопка ждёт конца выделения — отпускания мыши,
 * а для клавиатурного выделения паузы в изменениях. Показывать её
 * по `selectionchange` нельзя: событие приходит на каждый сдвиг
 * границы, и кнопка прыгала бы за курсором через весь фрагмент,
 * мешая целиться, — а нажать её во время протаскивания всё равно
 * невозможно.
 *
 * Кнопка исчезает, когда:
 *   - началось новое выделение или был клик мимо (mousedown)
 *   - выделение снято
 *   - был выполнен клик по ней (вставка произошла)
 *
 * Управление: `quoteFromSelection` в claude-custom-config.toml.
 * ============================================================ */
(function () {
  if (window.__claudeQuoteFromSelectionInstalled) return;
  window.__claudeQuoteFromSelectionInstalled = true;

  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  if (cfg.quoteFromSelection !== true) return;

  var quoteButton = null;    // текущая кнопка (или null)
  var currentSelection = null; // сохранённое выделение

  // Идёт ли выделение прямо сейчас (зажата кнопка мыши). Пока идёт,
  // кнопки быть не должно: `selectionchange` прилетает на каждый
  // сдвиг курсора, и кнопка прыгала бы за ним, мешая целиться в конец
  // фрагмента — а попасть по ней в этот момент всё равно нельзя.
  var selecting = false;

  // У выделения с клавиатуры (Shift+стрелки) нет момента «отпустили
  // кнопку», поэтому концом считаем паузу в изменениях. Полсекунды —
  // заметно дольше интервала автоповтора клавиши, так что при
  // удержании Shift+→ кнопка не мигает на каждом символе.
  var KEYBOARD_SETTLE_MS = 500;
  var settleTimer = null;

  function logInfo() {
    if (!cfg.logs) return;
    try {
      console.log.apply(console, ['[quote-from-selection]'].concat([].slice.call(arguments)));
    } catch (e) {}
  }

  function getComposer() {
    return (
      document.querySelector('[role="textbox"][contenteditable][aria-label*="essage" i]') ||
      document.querySelector('[role="textbox"][contenteditable]') ||
      document.querySelector('div[contenteditable]')
    );
  }

  /**
   * Получает выделённый текст из Selection API.
   * Возвращает {text, range} или null, если ничего не выделено.
   */
  function getSelection() {
    var sel = window.getSelection();
    if (!sel || sel.toString().length === 0) return null;
    return {
      text: sel.toString(),
      range: sel.rangeCount > 0 ? sel.getRangeAt(0).cloneRange() : null
    };
  }

  /**
   * Преобразует текст в цитату: `> ` перед каждой строкой.
   *
   * Пустые строки выбрасываются. Это не косметика: соседние абзацы
   * страницы Selection API отдаёт разделёнными пустой строкой
   * (`абзац\n\nабзац`) — так сериализуются блочные элементы. Для
   * пользователя же это две строки подряд, он их такими и видел,
   * выделяя. Оставлять разделитель значило бы вставлять цитату
   * разреженнее оригинала, да ещё и с осиротевшим `> ` посередине.
   *
   * Обратная сторона: пустая строка внутри выделенного кода тоже
   * исчезнет. Отличить её от разделителя абзацев нечем — в тексте
   * выделения это один и тот же `\n\n`, — а плотная цитата ближе
   * к тому, что видел глаз.
   */
  function toQuote(text) {
    var lines = text.split('\n');
    var quoted = [];
    for (var i = 0; i < lines.length; i++) {
      if (!lines[i].trim()) continue;
      quoted.push('> ' + lines[i]);
    }
    return quoted.join('\n');
  }

  /**
   * Вставляет цитату в composer как новую строку.
   * Если в composer уже есть текст, добавляет \n перед цитатой.
   */
  function insertQuoteIntoComposer(text) {
    var composer = getComposer();
    if (!composer) {
      logInfo('composer не найден');
      return false;
    }

    try {
      var quote = toQuote(text);
      if (!quote) {
        // После отсева пустых строк цитировать нечего — выделены были
        // одни пробелы. Вставлять при этом пару переводов строки
        // значило бы мусорить в поле по нажатию, которое пользователь
        // считает безрезультатным.
        logInfo('в выделении нет текста');
        return false;
      }

      composer.focus();

      // Ставим каретку в конец
      var sel = window.getSelection();
      var range = document.createRange();
      range.selectNodeContents(composer);
      range.collapse(false); // в конец
      sel.removeAllRanges();
      sel.addRange(range);

      // Проверяем, есть ли уже текст в composer. Читаем через общий
      // помощник: textContent склеил бы строки и пустым полем счёл бы
      // только по-настоящему пустое.
      var currentText = window.__claudeComposer.read(composer);
      var hasText = currentText.trim().length > 0;
      // Перевод строки в конце ставит каретку в начало следующей
      // строки — сразу под цитатой, готовой к набору ответа. Без него
      // каретка оставалась в конце последней процитированной строки,
      // и первое, что приходилось делать, — жать Enter, дописывая
      // свой текст к чужой цитате.
      var textToInsert = (hasText ? '\n' : '') + quote + '\n';

      // Построчно, через общий помощник: один insertText со всем
      // текстом склеил бы цитату из нескольких строк в одну — Chromium
      // не делает разрыва из `\n` внутри вставляемой строки.
      var inserted = window.__claudeComposer.insertMultiline(textToInsert);

      if (!inserted) {
        // Fallback: вставляем вручную. Каретку ставим сами — присвоение
        // textContent пересоздаёт узлы и позицию не сохраняет.
        composer.textContent = currentText + textToInsert;
        var endRange = document.createRange();
        endRange.selectNodeContents(composer);
        endRange.collapse(false);
        sel.removeAllRanges();
        sel.addRange(endRange);
        composer.dispatchEvent(new InputEvent('input', {
          bubbles: true, cancelable: true, inputType: 'insertText', data: textToInsert,
        }));
      }

      logInfo('цитата вставлена (' + quote.length + ' символов)');
      return true;
    } catch (e) {
      logInfo('ошибка при вставке:', (e && e.message) || e);
      return false;
    }
  }

  /**
   * Создаёт и показывает кнопку цитирования рядом с выделением.
   */
  function showQuoteButton() {
    var sel = getSelection();
    if (!sel || !sel.range) {
      hideQuoteButton();
      return;
    }

    currentSelection = sel;

    // Создаём кнопку, если её нет
    if (!quoteButton) {
      quoteButton = document.createElement('button');
      quoteButton.type = 'button';
      quoteButton.className = 'claude-quote-btn';
      quoteButton.textContent = '❝';
      quoteButton.title = 'Процитировать';
      quoteButton.style.cssText =
        'position:fixed;width:36px;height:36px;padding:3px 0 0;margin:0;border:none;' +
        'border-radius:6px;background:#8B5A2B;color:#fff;font-size:34px;line-height:1;' +
        'display:flex;align-items:center;justify-content:center;overflow:hidden;' +
        'cursor:pointer;z-index:10000;';

      quoteButton.addEventListener('mousedown', function (e) {
        e.preventDefault();
        e.stopPropagation();
      });

      quoteButton.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        if (currentSelection && currentSelection.text) {
          insertQuoteIntoComposer(currentSelection.text);
          hideQuoteButton();
        }
      });

      document.body.appendChild(quoteButton);
    }

    // Позиционируем кнопку выше выделения, справа
    try {
      var rect = sel.range.getBoundingClientRect();
      // Кнопка выше выделения, справа от конца. Низ кнопки — с зазором
      // над верхней границей выделения, полностью над строкой.
      var btnH = quoteButton.offsetHeight || 36;
      var x = rect.right + 4;
      var y = rect.top - btnH - 6;  // зазор 6px над выделением

      quoteButton.style.left = x + 'px';
      quoteButton.style.top = y + 'px';
      quoteButton.style.display = 'block';
    } catch (e) {
      logInfo('ошибка при позиционировании:', (e && e.message) || e);
      hideQuoteButton();
    }
  }

  /**
   * Скрывает кнопку цитирования.
   */
  function hideQuoteButton() {
    if (quoteButton) {
      quoteButton.style.display = 'none';
    }
    currentSelection = null;
  }

  function cancelSettle() {
    if (settleTimer) {
      clearTimeout(settleTimer);
      settleTimer = null;
    }
  }

  /** Показ после паузы — для выделения с клавиатуры. */
  function scheduleSettledShow() {
    cancelSettle();
    settleTimer = setTimeout(function () {
      settleTimer = null;
      if (selecting) return;  // мышь снова в деле, ждём mouseup
      if (window.getSelection().toString().length > 0) showQuoteButton();
    }, KEYBOARD_SETTLE_MS);
  }

  /** Показывает кнопку немедленно, если есть что цитировать. */
  function showIfSelected() {
    cancelSettle();
    if (window.getSelection().toString().length > 0) showQuoteButton();
    else hideQuoteButton();
  }

  /**
   * Изменение выделения. Само по себе поводом показать кнопку не
   * является: событие прилетает на каждый сдвиг границы, то есть
   * десятки раз за одно протаскивание мышью. Здесь только гасим
   * кнопку и, для клавиатурного выделения, заводим таймер паузы.
   */
  function handleSelectionChange() {
    if (window.getSelection().toString().length === 0) {
      cancelSettle();
      hideQuoteButton();
      return;
    }
    // Выделение мышью ещё идёт — момент показа наступит на mouseup.
    if (selecting) {
      cancelSettle();
      hideQuoteButton();
      return;
    }
    scheduleSettledShow();
  }

  /** Начало выделения мышью; клик по самой кнопке им не считается. */
  function handleMouseDown(e) {
    if (quoteButton && (e.target === quoteButton || quoteButton.contains(e.target))) {
      return;
    }
    selecting = true;
    cancelSettle();
    hideQuoteButton();
  }

  /** Конец выделения мышью — единственный момент, когда кнопка нужна. */
  function handleMouseUp(e) {
    // Отпускание на самой кнопке — это её нажатие, а не конец
    // выделения: показывать нечего, клик сейчас всё уберёт сам.
    if (quoteButton && e && (e.target === quoteButton || quoteButton.contains(e.target))) {
      return;
    }
    selecting = false;
    showIfSelected();
  }

  function init() {
    // Показ — только по завершению выделения: отпустили мышь либо
    // клавиатурное выделение перестало меняться.
    document.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('touchend', handleMouseUp);
    document.addEventListener('selectionchange', handleSelectionChange);

    // Начало протаскивания и клик мимо — оба гасят кнопку.
    document.addEventListener('mousedown', handleMouseDown);

    logInfo('контекстная кнопка цитирования активирована');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * CACHE KEEPALIVE
 *
 * Кнопка «Cache» между Usage и ByPass. Включённая — не даёт истечь
 * prompt-кэшу сессии: при простое дольше cacheKeepaliveMinutes
 * отправляет в чат короткое сообщение, и попадание в кэш продлевает
 * его TTL ещё на час (TTL обновляется при каждом использовании).
 *
 * Почему это модуль webview, а не хук. Хуки Claude Code реактивны:
 * они отвечают на события, но сами инициировать сообщение не могут.
 * Отправить его способен только тот, у кого есть поле ввода, то есть
 * webview. Серверная часть при этом всё равно нужна — именно она
 * знает, когда был последний ход (GET /cache-usage → last.ts).
 *
 * Отправляем не по таймеру вслепую, а по факту простоя: пока идёт
 * обычная работа, кэш продлевается сам, и лишние сообщения — это
 * потраченная квота и мусор в истории. Проверка раз в минуту, отправка
 * только когда простой реально дошёл до порога.
 *
 * Три случая, когда ход пропускается:
 *   - в поле ввода есть черновик — затирать его недопустимо;
 *   - модель отвечает прямо сейчас (в футере кнопка «стоп»);
 *   - session id не определился.
 *
 * Состояние тоггла хранится в localStorage по session id: у каждой
 * вкладки своё, и переживает Reload Window.
 *
 * Управление: `cacheKeepalive`, `cacheKeepaliveMinutes`,
 * `cacheKeepaliveMessage` в claude-custom-config.toml.
 * ============================================================ */
(function () {
  if (window.__claudeCacheKeepaliveInstalled) return;
  window.__claudeCacheKeepaliveInstalled = true;

  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  if (cfg.cacheKeepalive !== true) return;

  var USAGE_URL = 'http://localhost:18923/cache-usage';
  var BTN_CLASS = 'claude-keepalive-btn';
  var BARE_CLASS = 'claude-keepalive-btn-bare';
  var ON_CLASS = 'claude-keepalive-on';
  var STORAGE_KEY = 'claudeCustomCacheKeepalive';
  var LAST_KEY = '__last';
  var TICK_MS = 60000;
  var CARRY_MS = (typeof cfg.buttonStateCarrySec === 'number'
    && cfg.buttonStateCarrySec >= 0 ? cfg.buttonStateCarrySec : 600) * 1000;
  var AUTO_EDIT_RE = /Править автоматически|Edit automatically/i;

  // Стартовые значения — из bootstrap; дальше их обновляет pollConfig().
  var IDLE_MINUTES = typeof cfg.cacheKeepaliveMinutes === 'number'
    && cfg.cacheKeepaliveMinutes > 0 ? cfg.cacheKeepaliveMinutes : 55;
  var MESSAGE = typeof cfg.cacheKeepaliveMessage === 'string'
    && cfg.cacheKeepaliveMessage ? cfg.cacheKeepaliveMessage : 'keepalive';
  var MIN_CONTEXT = typeof cfg.cacheKeepaliveMinContext === 'number'
    && cfg.cacheKeepaliveMinContext >= 0 ? cfg.cacheKeepaliveMinContext : 50000;
  // Верхняя граница поддержания; фактическое истечение кэша неизвестно.
  var TTL_MINUTES = typeof cfg.cacheKeepaliveTtlMinutes === 'number'
    && cfg.cacheKeepaliveTtlMinutes > 0 ? cfg.cacheKeepaliveTtlMinutes : 60;

  var CONFIG_URL = 'http://localhost:18923/custom-config';
  var CONFIG_POLL_MS = 5000;

  var NOTE_ID = 'claude-keepalive-note';
  var NOTE_TIMEOUT_MS = 12000;

  var enabled = false;
  var stateLoaded = false;   // состояние из localStorage уже прочитано
  var pendingDraft = null;   // черновик, снятый на время отправки
  var lastIdleMin = null;
  var cacheLost = false;     // простой перевалил за TTL, поддерживать нечего
  var noteEl = null;
  var noteTimer = null;

  function human(n) {
    if (typeof n !== 'number' || !isFinite(n)) return '—';
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
    return String(Math.round(n));
  }

  function logInfo() {
    if (!cfg.logs) return;
    try {
      console.log.apply(console, ['[keepalive]'].concat([].slice.call(arguments)));
    } catch (e) {}
  }

  function sessionId() {
    var fn = window.__claudeSessionId;
    return typeof fn === 'function' ? fn() : null;
  }

  /* ---------- хранилище состояния ---------- */

  function readStore() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      var obj = raw ? JSON.parse(raw) : null;
      return obj && typeof obj === 'object' ? obj : {};
    } catch (e) {
      return {};
    }
  }

  function writeStore(store) {
    // Записей накапливается по одной на сессию, а сессия создаётся
    // на каждую перезагрузку окна. Оставляем только свежие, иначе
    // localStorage растёт без предела.
    var keys = Object.keys(store).filter(function (k) { return k !== LAST_KEY; });
    if (keys.length > 30) {
      keys.slice(0, keys.length - 30).forEach(function (k) { delete store[k]; });
    }
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
    } catch (e) {}
  }

  /**
   * Возвращает состояние для текущей сессии или null, если session id
   * ещё не определился (React-дерево не отрисовано).
   *
   * Перезагрузка окна создаёт НОВУЮ сессию, поэтому записи под старым
   * id для неё бесполезны. Чтобы выбор не сбрасывался, переносим его
   * из последнего явного включения — но только если оно свежее
   * CARRY_MS. Перезагрузка занимает секунды, так что короткого окна
   * достаточно; без ограничения включение недельной давности молча
   * оживало бы в новом разговоре.
   */
  function loadEnabled() {
    var sid = sessionId();
    if (!sid) return null;
    var store = readStore();
    if (typeof store[sid] === 'boolean') return store[sid];

    var last = store[LAST_KEY];
    if (last && last.on === true && typeof last.at === 'number'
        && Date.now() - last.at <= CARRY_MS) {
      // Переносим в новую сессию и фиксируем, чтобы дальше читалось
      // напрямую. __last намеренно не трогаем: иначе окно давности
      // продлевалось бы каждой перезагрузкой и стало бы бессрочным.
      store[sid] = true;
      writeStore(store);
      logInfo('состояние перенесено с прошлой сессии');
      return true;
    }
    return false;
  }

  function saveEnabled(on) {
    var sid = sessionId();
    if (!sid) return;
    var store = readStore();
    // Пишем явный false, а не удаляем: иначе выключение выглядело бы
    // как «выбора не было» и перенос включил бы кнопку обратно.
    store[sid] = !!on;
    store[LAST_KEY] = { on: !!on, at: Date.now() };
    writeStore(store);
  }

  /* ---------- иконка ---------- */

  function clockIcon() {
    var NS = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('width', '20');
    svg.setAttribute('height', '20');
    svg.setAttribute('viewBox', '0 0 20 20');
    svg.setAttribute('fill', 'none');
    var circle = document.createElementNS(NS, 'circle');
    circle.setAttribute('cx', '10');
    circle.setAttribute('cy', '10');
    circle.setAttribute('r', '6.25');
    circle.setAttribute('stroke', 'currentColor');
    circle.setAttribute('stroke-width', '1.2');
    var hands = document.createElementNS(NS, 'path');
    hands.setAttribute('d', 'M10 6.25V10l2.75 1.6');
    hands.setAttribute('stroke', 'currentColor');
    hands.setAttribute('stroke-width', '1.2');
    hands.setAttribute('stroke-linecap', 'round');
    hands.setAttribute('stroke-linejoin', 'round');
    svg.appendChild(circle);
    svg.appendChild(hands);
    return svg;
  }

  /* ---------- состояние кнопки ---------- */

  function inactiveClassFrom(donorClass) {
    var m = /(?:^|\s)footerButton_(\w+)(?:\s|$)/.exec(donorClass || '');
    return m ? 'footerButtonInactive_' + m[1] : '';
  }

  /* ---------- уведомление при слишком малом контексте ---------- */

  function hideNote() {
    if (noteTimer) {
      clearTimeout(noteTimer);
      noteTimer = null;
    }
    if (noteEl) noteEl.remove();
    noteEl = null;
    document.removeEventListener('mousedown', onNoteOutside, true);
    document.removeEventListener('keydown', onNoteKeydown, true);
  }

  function onNoteOutside(e) {
    if (noteEl && !noteEl.contains(e.target)) hideNote();
  }

  function onNoteKeydown(e) {
    if (e.key === 'Escape') hideNote();
  }

  function showNote(btn, lines) {
    hideNote();
    noteEl = document.createElement('div');
    noteEl.id = NOTE_ID;
    noteEl.className = 'claude-keepalive-note';
    for (var i = 0; i < lines.length; i++) {
      var p = document.createElement('div');
      p.className = i === 0
        ? 'claude-keepalive-note-head'
        : 'claude-keepalive-note-line';
      p.textContent = lines[i];
      noteEl.appendChild(p);
    }
    document.body.appendChild(noteEl);

    var r = btn.getBoundingClientRect();
    noteEl.style.bottom = Math.max(8, window.innerHeight - r.top + 6) + 'px';
    noteEl.style.right = Math.max(8, window.innerWidth - r.right) + 'px';

    document.addEventListener('mousedown', onNoteOutside, true);
    document.addEventListener('keydown', onNoteKeydown, true);
    noteTimer = setTimeout(hideNote, NOTE_TIMEOUT_MS);
  }

  /**
   * Текст отказа. Считаем то, что реально предотвращается: холодный
   * старт переписывает весь префикс по ставке записи (2x) вместо
   * чтения (0.1x), то есть стоит T × 1.9 × ставка_input.
   *
   * Отношение цены прогрева к цене холодного старта — ровно 19 и от
   * размера контекста не зависит (T сокращается). Поэтому порог здесь
   * не про окупаемость, а про абсолютную величину ставки: на мелком
   * контексте предотвращать нечего, а сообщение в истории и расход
   * квоты остаются те же.
   */
  function tooSmallLines(d) {
    var rate = (d.rates && d.rates.input) || 5.0;
    var avoided = d.context * 1.9 * rate / 1e6;
    return [
      'Контекст сессии — ' + human(d.context) + ' токенов.',
      'Поддержание включается от ' + human(MIN_CONTEXT) + '.',
      '',
      'Пока холодный старт обойдётся примерно в $' + avoided.toFixed(2)
        + ' — дешевле, чем сообщение поддержания в истории и расход квоты '
        + 'на него. Вернись к кнопке, когда контекст подрастёт.',
    ];
  }

  /**
   * Подсказка описывает три состояния: выключено, сторожит, кэш уже
   * потерян. Третье важно показывать явно — иначе включённая кнопка,
   * которая сознательно ничего не делает, выглядит как сломанная.
   *
   * Порог и простой подписаны отдельными словами: формулировка
   * «Простой сейчас: 3 мин из 55» читалась двусмысленно, первое число
   * принимали за настройку.
   */
  function titleFor() {
    if (!enabled) {
      return 'Поддержание кэша выключено. Клик — включить: при простое '
        + 'от ' + IDLE_MINUTES + ' до ' + TTL_MINUTES + ' мин будет '
        + 'отправлено короткое сообщение, чтобы кэш не истёк. Доступно '
        + 'от ' + human(MIN_CONTEXT) + ' токенов контекста.';
    }
    var head = 'Поддержание кэша включено, окно ' + IDLE_MINUTES + '–'
      + TTL_MINUTES + ' мин.';
    if (cacheLost) {
      return head + ' Простой ' + lastIdleMin.toFixed(0) + ' мин — заданный TTL '
        + 'достигнут. Возобновлю поддержание после твоего '
        + 'следующего сообщения. Клик — выключить.';
    }
    if (lastIdleMin !== null) {
      var left = IDLE_MINUTES - lastIdleMin;
      head += left > 0
        ? ' Простой ' + lastIdleMin.toFixed(0) + ' мин, до отправки около '
          + Math.round(left) + ' мин.'
        : ' Простой ' + lastIdleMin.toFixed(0) + ' мин — сообщение уйдёт '
          + 'при ближайшей проверке.';
    }
    return head + ' Клик — выключить.';
  }

  function applyState(btn) {
    var inactive = btn.getAttribute('data-inactive-class') || '';
    if (inactive) {
      if (enabled) btn.classList.remove(inactive);
      else btn.classList.add(inactive);
    }
    if (enabled) btn.classList.add(ON_CLASS);
    else btn.classList.remove(ON_CLASS);
    btn.title = titleFor();
  }

  function applyStateAll() {
    var nodes = document.querySelectorAll('.' + BTN_CLASS);
    for (var i = 0; i < nodes.length; i++) applyState(nodes[i]);
  }

  /* ---------- отправка ---------- */

  function composerOf(container) {
    return container.querySelector('[role="textbox"][contenteditable]');
  }

  /* Чтение и многострочная вставка — общие (см. COMPOSER TEXT).
   * Обе функции жили здесь и были написаны по следам поломок с этим
   * полем; цитирование наступило на ту же вставку повторно, поэтому
   * они переехали в общий блок. */
  function readComposer(el) {
    return window.__claudeComposer.read(el);
  }

  function insertMultiline(text) {
    return window.__claudeComposer.insertMultiline(text);
  }

  /**
   * Отправляет сообщение через штатное поле ввода.
   *
   * Текст вставляем execCommand'ом: поле React-controlled, прямая
   * запись в textContent теряется на ближайшем ре-рендере (тот же
   * приём, что в EMOJI PICKER).
   *
   * Отправляем кликом по штатной кнопке, а не синтетическим Enter:
   * обработчик Enter живёт в React и может меняться между версиями,
   * а кнопка — стабильная точка входа.
   */
  function trySend() {
    var containers = document.querySelectorAll('[class*="inputContainer_"]');
    for (var i = 0; i < containers.length; i++) {
      var container = containers[i];
      var el = composerOf(container);
      if (!el) continue;

      // Кнопка отправки во время генерации превращается в «стоп»:
      // отличаем по иконке из того же CSS-модуля футера.
      if (container.querySelector('[class*="stopIcon_"]')) {
        logInfo('пропуск: модель отвечает');
        return false;
      }
      if (!container.querySelector('[class*="sendButton_"]')) continue;

      // Черновик не мешает отправке: убираем его, шлём keepalive
      // и возвращаем обратно. Текст держим в pendingDraft до успешного
      // возврата — если что-то пойдёт не так, его подберёт scan().
      var draft = readComposer(el);
      el.focus();
      if (draft) {
        pendingDraft = draft;
        try {
          document.execCommand('selectAll', false, null);
          document.execCommand('delete', false, null);
        } catch (e) {
          logInfo('не удалось очистить поле — отправку пропускаю');
          pendingDraft = null;
          return false;
        }
      }

      var ok = insertMultiline(MESSAGE);
      if (!ok) {
        logInfo('вставка текста не удалась');
        restoreDraft(container, 0);
        return false;
      }
      clickSendWhenReady(container, 0);
      return true;
    }
    return false;
  }

  /**
   * Возвращает черновик в поле, когда оно освободится.
   *
   * Ждём именно пустого поля: сразу после клика там ещё лежит наш
   * keepalive, а если пользователь начал печатать — затирать его
   * нельзя. Поэтому при непустом поле просто ждём дальше, а по
   * истечении попыток оставляем pendingDraft висеть: его подберёт
   * ближайший scan(), когда поле освободится. Так черновик не теряется
   * даже при неудачной отправке.
   *
   * Позиция каретки внутри черновика не сохраняется — текст
   * возвращается целиком, каретка встаёт в конец.
   */
  function restoreDraft(container, attempt) {
    if (!pendingDraft) return;
    var el = composerOf(container);
    if (!el) return;
    if ((el.textContent || '') === '') {
      var text = pendingDraft;
      pendingDraft = null;
      el.focus();
      if (insertMultiline(text)) {
        logInfo('черновик возвращён,', text.length, 'символов,',
          text.split('\n').length, 'строк');
      } else {
        pendingDraft = text;  // не вышло — пусть попробует scan()
      }
      return;
    }
    if (attempt >= 40) return;  // 40 × 50 мс = 2 с
    setTimeout(function () { restoreDraft(container, attempt + 1); }, 50);
  }

  /**
   * Жмёт кнопку отправки, дождавшись, когда она разблокируется.
   *
   * В бандле она `disabled: !busy && !hasContent`, то есть при пустом
   * поле заблокирована. React обновляет состояние асинхронно: клик
   * сразу после execCommand приходится на ещё выключенную кнопку и
   * молча пропадает, а текст остаётся висеть в поле. Вдобавок React
   * может заменить сам узел, поэтому кнопку каждый раз ищем заново,
   * а не держим ссылку.
   *
   * Если за отведённое время кнопка так и не ожила, убираем свой текст:
   * оставлять его в поле хуже, чем не отправить — пользователь потом
   * наткнётся на чужую строку в композере.
   */
  function clickSendWhenReady(container, attempt) {
    var send = container.querySelector('[class*="sendButton_"]');
    if (send && !send.disabled) {
      send.click();
      logInfo('отправлено сообщение поддержания, попыток:', attempt);
      restoreDraft(container, 0);
      return;
    }
    if (attempt >= 30) {  // 30 × 50 мс = 1.5 с
      logInfo('кнопка отправки не разблокировалась — убираем текст');
      var el = composerOf(container);
      if (el && (el.textContent || '').trim() === MESSAGE.trim()) {
        el.focus();
        try {
          document.execCommand('selectAll', false, null);
          document.execCommand('delete', false, null);
        } catch (e) {}
      }
      restoreDraft(container, 0);
      return;
    }
    setTimeout(function () {
      clickSendWhenReady(container, attempt + 1);
    }, 50);
  }

  /**
   * Подтягивает настройки с сервера.
   *
   * Значения из bootstrap фиксируются на момент загрузки окна, поэтому
   * правка TOML не действовала до Reload Window — и порог показывался
   * старый, хотя в файле стоял новый. Опрос снимает это: тот же приём
   * уже используется для emojiButtonPlacement.
   *
   * Сам флаг cacheKeepalive намеренно не обновляем: модуль либо
   * установлен со всеми обработчиками, либо нет, и включить его на лету
   * всё равно нельзя — для этого нужен Reload Window.
   */
  function applyLiveConfig(c, providerTtl) {
    if (!c || typeof c !== 'object') return;
    var changed = [];

    if (typeof c.cacheKeepaliveMinutes === 'number'
        && c.cacheKeepaliveMinutes > 0
        && c.cacheKeepaliveMinutes !== IDLE_MINUTES) {
      IDLE_MINUTES = c.cacheKeepaliveMinutes;
      changed.push('порог ' + IDLE_MINUTES + ' мин');
    }
    if (typeof c.cacheKeepaliveMessage === 'string'
        && c.cacheKeepaliveMessage
        && c.cacheKeepaliveMessage !== MESSAGE) {
      MESSAGE = c.cacheKeepaliveMessage;
      changed.push('текст сообщения');
    }
    if (typeof c.cacheKeepaliveMinContext === 'number'
        && c.cacheKeepaliveMinContext >= 0
        && c.cacheKeepaliveMinContext !== MIN_CONTEXT) {
      MIN_CONTEXT = c.cacheKeepaliveMinContext;
      changed.push('порог контекста ' + human(MIN_CONTEXT));
    }
    var ttl = typeof providerTtl === 'number' && providerTtl > 0
      ? providerTtl : c.cacheKeepaliveTtlMinutes;
    if (typeof ttl === 'number' && ttl > 0 && ttl !== TTL_MINUTES) {
      TTL_MINUTES = ttl;
      changed.push('TTL ' + TTL_MINUTES + ' мин');
    }

    if (changed.length) {
      normalizeWindow();
      applyStateAll();  // подсказки пересобираются с новыми значениями
      logInfo('конфиг обновлён:', changed.join(', '));
    }
  }

  /**
   * Порог обязан быть строго меньше TTL, иначе окно срабатывания пусто
   * и кнопка молча не делает ничего. Чинить это отказом было бы хуже:
   * пользователь увидел бы включённую кнопку без эффекта. Поджимаем
   * порог и говорим об этом в консоль.
   */
  function normalizeWindow() {
    if (IDLE_MINUTES < TTL_MINUTES) return;
    var fixed = Math.max(TTL_MINUTES / 2, TTL_MINUTES - 5);
    logInfo('порог', IDLE_MINUTES, 'мин не меньше TTL', TTL_MINUTES,
      '— окно пусто, поджимаю порог до', fixed);
    IDLE_MINUTES = fixed;
  }

  function pollConfig() {
    fetch(CONFIG_URL, { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (d) { if (d && d.ok) applyLiveConfig(d.config, d.cache_ttl_minutes); })
      .catch(function () {});
  }

  function tick() {
    if (!enabled) return;
    var sid = sessionId();
    if (!sid) return;
    fetch(USAGE_URL + '?session=' + encodeURIComponent(sid), { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.ok || !d.last || !d.last.ts) return;
        // Проверяем TTL текущего провайдера перед отправкой, даже если
        // опрос /custom-config ещё не увидел переключение аккаунта.
        applyLiveConfig({}, d.ttl_minutes);
        var ts = Date.parse(d.last.ts);
        if (isNaN(ts)) return;
        lastIdleMin = (Date.now() - ts) / 60000;

        // После настроенного порога пропускаем автоматическое сообщение:
        // дальнейшее хранение кэша не предполагаем, но истечение не доказано.
        cacheLost = lastIdleMin >= TTL_MINUTES;
        applyStateAll();
        if (cacheLost) {
          logInfo('простой', lastIdleMin.toFixed(0), 'мин — заданный TTL достигнут, не отправляю');
          return;
        }
        if (lastIdleMin >= IDLE_MINUTES) trySend();
      })
      .catch(function () {});
  }

  /* ---------- встраивание ---------- */

  function findAnchor(footer) {
    var buttons = footer.querySelectorAll('button');
    var match = null;
    for (var i = 0; i < buttons.length; i++) {
      if (AUTO_EDIT_RE.test(buttons[i].textContent || '')) {
        match = buttons[i];
        break;
      }
    }
    if (match) {
      var node = match;
      while (node.parentNode && node.parentNode !== footer) node = node.parentNode;
      return { before: node.parentNode === footer ? node : null, donor: match };
    }
    return {
      before: null,
      donor: footer.querySelector('[class*="footerButton_"]')
        || footer.querySelector('button'),
    };
  }

  function createButton(donor) {
    var btn = document.createElement('button');
    btn.type = 'button';
    var donorClass = claudeNativeButtonClasses(donor);
    if (donorClass) {
      btn.className = donorClass + ' ' + BTN_CLASS;
      var inactive = inactiveClassFrom(donorClass);
      if (inactive) btn.setAttribute('data-inactive-class', inactive);
    } else {
      btn.className = BTN_CLASS + ' ' + BARE_CLASS;
    }
    btn.appendChild(clockIcon());
    var label = document.createElement('span');
    label.textContent = 'Cache';
    btn.appendChild(label);
    applyState(btn);
    btn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      hideNote();
      if (enabled) {
        setEnabled(false);
      } else {
        requestEnable(btn);
      }
    });
    return btn;
  }

  function setEnabled(on) {
    enabled = on;
    saveEnabled(on);
    applyStateAll();
    logInfo(on ? 'включено' : 'выключено');
    if (on) tick();
  }

  /**
   * Включение — только после проверки размера контекста у сервера.
   * Синхронно решить нельзя: пока тоггл выключен, тики не идут и
   * свежих данных на руках нет.
   */
  function requestEnable(btn) {
    var sid = sessionId();
    if (!sid) {
      showNote(btn, ['Не удалось определить сессию вкладки.']);
      return;
    }
    fetch(USAGE_URL + '?session=' + encodeURIComponent(sid), { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.ok) {
          showNote(btn, ['Статистика недоступна: '
            + ((d && d.error) || 'нет данных') + '.']);
          return;
        }
        if (typeof d.context === 'number' && d.context < MIN_CONTEXT) {
          logInfo('отказ: контекст', d.context, '<', MIN_CONTEXT);
          showNote(btn, tooSmallLines(d));
          return;
        }
        setEnabled(true);
      })
      .catch(function () {
        showNote(btn, ['http-server.py недоступен (порт 18923).']);
      });
  }

  function mount(container) {
    var footer = container.querySelector('[class*="inputFooter_"]');
    if (!footer) return false;
    var anchor = findAnchor(footer);
    var btn = createButton(anchor.donor);
    // Порядок в футере: Usage · Cache · ByPass · автоправки. Опираемся
    // на соседа, а не на порядок инициализации модулей: React
    // пересоздаёт футер, и кто смонтируется первым — не гарантировано.
    // Встаём перед ByPass, если он уже есть, иначе перед автоправками
    // (тогда ByPass позже встанет справа от нас сам).
    var neighbour = footer.querySelector('.claude-bypass-btn');
    if (neighbour && neighbour.parentNode === footer) {
      footer.insertBefore(btn, neighbour);
    } else if (anchor.before) {
      footer.insertBefore(btn, anchor.before);
    } else {
      var spacer = footer.querySelector('[class*="spacer_"]');
      if (spacer && spacer.parentNode === footer) {
        footer.insertBefore(btn, spacer.nextSibling);
      } else {
        footer.appendChild(btn);
      }
    }
    return true;
  }

  /**
   * Держит порядок Usage · Cache · ByPass даже если кнопки появились
   * не в том порядке. Вставка при монтировании этого не гарантирует:
   * React пересоздаёт футер, модули домонтируются по своим таймерам,
   * и кто окажется первым — как повезёт.
   */
  function ensureOrder(footer) {
    var me = footer.querySelector('.' + BTN_CLASS);
    var right = footer.querySelector('.claude-bypass-btn');
    if (!me || !right) return;
    if (me.parentNode !== footer || right.parentNode !== footer) return;
    // DOCUMENT_POSITION_FOLLOWING — сосед идёт ПОСЛЕ нас, всё верно.
    if (me !== right && !(me.compareDocumentPosition(right) & 4)) {
      footer.insertBefore(me, right);
      logInfo('порядок восстановлен: Cache перед ByPass');
    }
  }

  /**
   * Дочитывает сохранённое состояние, когда session id наконец
   * определился. При init() его ещё нет: резолвер работает по
   * React-fiber, а дерево на тот момент не отрисовано — раньше из-за
   * этого кнопка всегда стартовала выключенной, даже если сохранённое
   * состояние было.
   */
  function loadStateWhenReady() {
    if (stateLoaded) return;
    var value = loadEnabled();
    if (value === null) return;  // session id ещё не резолвится
    stateLoaded = true;
    if (value !== enabled) {
      enabled = value;
      applyStateAll();
    }
    logInfo('состояние восстановлено:', enabled ? 'включено' : 'выключено');
    if (enabled) tick();
  }

  function scan(ctx) {
    loadStateWhenReady();
    // Узлы даёт общий обход (см. DOM WATCH) — один на все модули.
    // Свой поиск остаётся для вызовов вне прохода: при регистрации
    // и из обработчиков самого модуля.
    var containers = (ctx && ctx.inputs)
      || document.querySelectorAll('[class*="inputContainer_"]');
    for (var i = 0; i < containers.length; i++) {
      // Страховка: если возврат черновика не удался с первого раза
      // (поле было занято, отправка сорвалась), подбираем его здесь.
      if (pendingDraft) restoreDraft(containers[i], 39);
      var footer = containers[i].querySelector('[class*="inputFooter_"]');
      if (containers[i].querySelector('.' + BTN_CLASS)) {
        if (footer) ensureOrder(footer);
        continue;
      }
      if (!containers[i].querySelector('[role="textbox"][contenteditable]')) continue;
      mount(containers[i]);
    }
  }

  function init() {
    // Состояние не читаем здесь: резолвер session id работает по
    // React-fiber, а дерево на этот момент ещё не отрисовано.
    // Этим занимается loadStateWhenReady() из scan(), как только
    // id станет доступен.
    normalizeWindow();
    // Наблюдатель и подстраховочный таймер — общие (см. DOM WATCH).
    // Регистрация делает первый скан сама, до applyStateAll: порядок
    // здесь тот же, что был у явного вызова.
    window.__claudeDomWatch.register('keepalive', scan);
    applyStateAll();
    pollConfig();
    setInterval(tick, TICK_MS);
    setInterval(pollConfig, CONFIG_POLL_MS);
    logInfo('installed, порог', IDLE_MINUTES, 'мин');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * ACCOUNT SWITCHER BUTTON
 *
 * Кнопка «Accs» в футере, слева от Usage. По клику открывается панель
 * со списком settings-файлов из ~/.claude/ — каждый такой файл это
 * аккаунт своего провайдера (Anthropic, Z.AI, ...). После подтверждения
 * активный ~/.claude/settings.json заменяется копией выбранного.
 *
 * Вся работа с файлами — на стороне сервера (account_switcher.py),
 * здесь только список и клик: webview не имеет доступа к ФС.
 *
 * ВАЖНО про применение. `env` из settings.json процесс Claude Code
 * читает при старте, а стартует он один раз на активацию extension
 * host — поэтому смена провайдера НЕ действует на текущее окно сама
 * по себе. Панель не притворяется, что переключение уже подействовало:
 * молчаливая подмена под работающей сессией — худший из вариантов,
 * пользователь считал бы, что говорит с другой моделью.
 *
 * Перед сменой открывается предупреждение (см. openModal). Подтверждение
 * выполняет смену и затем перезапуск extension host; окно, редакторы
 * и терминалы остаются на месте.
 *
 * Управление: `accountsButton` в claude-custom-config.toml;
 * смена аккаунта всегда требует подтверждения.
 * ============================================================ */
(function () {
  if (window.__claudeAccountsButtonInstalled) return;
  window.__claudeAccountsButtonInstalled = true;

  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  if (cfg.accountsButton !== true) return;

  var API_URL = 'http://127.0.0.1:18923/accounts';
  var RESTART_URL = 'http://localhost:18923/restart-exthost';
  var ENV_URL = 'http://localhost:18923/account-env';
  var BTN_CLASS = 'claude-accs-btn';
  var BARE_CLASS = 'claude-accs-btn-bare';
  var PANEL_ID = 'claude-accs-panel';
  var MODAL_ID = 'claude-accs-modal';
  // Список известных имён настроек для автодополнения в форме.
  // Панель открыта одна на окно, поэтому id фиксированный.
  var SET_LIST_ID = 'claude-accs-setting-names';
  var AUTO_EDIT_RE = /Править автоматически|Edit automatically/i;

  // Сколько ждём подтверждения от расширения. Наблюдатель в extension.js
  // опрашивает заявку раз в секунду, поэтому запас в четыре секунды
  // покрывает и медленный диск, и попадание в середину его цикла.
  var ACK_TIMEOUT_MS = 4000;
  var ACK_POLL_MS = 400;
  // Сколько ждать переоткрытия вкладки, прежде чем убрать модалку самим.
  // Рестарт хоста занимает ~3 с, оживление вкладки — ещё ~1.5 с; запас
  // взят на медленный старт расширения.
  var ACK_CLOSE_MS = 20000;

  // Раздел «подписка» в настройках аккаунта и строка срока в списке.
  // Отсутствие ключа означает «включено»: данные
  // о сроке приходит с сервера, а сам раздел формы рисуем только
  // когда сервер о нём знает — см. renderConfigForm.
  var showSub = cfg.accountsSubscription !== false;

  var panel = null;
  var modal = null;
  var switching = false;   // защита от двойного клика по пункту
  var restarting = false;  // заявка на перезапуск отправлена, ждём хост

  // Аккаунт, который был активен на момент отрисовки списка, — то есть
  // тот, на котором реально работает текущий процесс Claude Code.
  // Нужен для отката: отказ от перезапуска возвращает settings.json
  // к нему, иначе на диске остался бы один провайдер, а в работающей
  // сессии — другой.
  var activeFile = null;
  var accountsSnapshot = null;
  var messageUsageByFile = Object.create(null);
  var accountsRevision = 0;
  var accountDetailsCache = Object.create(null);

  function rememberAccounts(accounts) {
    accountsSnapshot = Array.isArray(accounts) ? accounts : [];
    if (Object.keys(messageUsageByFile).length) accountsSnapshot = accountsSnapshot.map(withMessageUsage);
  }

  function withMessageUsage(acc) {
    var usage = messageUsageByFile[acc.file];
    return usage && (!acc.usage || usage.observedAt > (acc.usage.observedAt || 0))
      ? Object.assign({}, acc, { usage: usage }) : acc;
  }

  function receiveMessageUsage(update) {
    if (!update || typeof update.file !== 'string' || !update.usage
        || !Number.isFinite(update.usage.observedAt) || !Array.isArray(update.usage.windows)) return;
    var previous = messageUsageByFile[update.file];
    if (previous && previous.observedAt >= update.usage.observedAt) return;
    messageUsageByFile[update.file] = update.usage;
    if (accountsSnapshot) accountsSnapshot = accountsSnapshot.map(withMessageUsage);
    if (!panel || !showUsage) return;
    var account = accountsSnapshot && accountsSnapshot.find(function (acc) { return acc.file === update.file; });
    if (!account) return;
    var hosts = panel.querySelectorAll('[data-claude-account-usage-file]');
    for (var i = 0; i < hosts.length; i++) {
      if (hosts[i].getAttribute('data-claude-account-usage-file') !== update.file) continue;
      var old = hosts[i].querySelector('.claude-accs-usage');
      var fresh = usageBlock(account.usage);
      if (fresh && old) hosts[i].replaceChild(fresh, old);
      else if (fresh) hosts[i].appendChild(fresh);
    }
  }
  window.__claudeSyncAccountUsage = receiveMessageUsage;

  // Замыкание «отказаться», выставляемое openModal. Обработчик Escape
  // живёт на уровне модуля и о содержимом модалки не знает.
  var modalDecline = null;

  function logInfo() {
    if (!cfg.logs) return;
    try {
      console.log.apply(console, ['[accs-btn]'].concat([].slice.call(arguments)));
    } catch (e) {}
  }

  /* ---------- иконка ---------- */

  /**
   * Две фигурки — «аккаунты». Разметка повторяет штатные кнопки футера:
   * `<svg 20×20 fill="none">` + голый `<span>`, размер задаёт класс
   * footerButton_. Через createElementNS, а не innerHTML: SVG живёт
   * в своём namespace, а innerHTML упирается в Trusted Types.
   */
  function accsIcon() {
    var NS = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('width', '20');
    svg.setAttribute('height', '20');
    svg.setAttribute('viewBox', '0 0 20 20');
    svg.setAttribute('fill', 'none');
    function path(d) {
      var p = document.createElementNS(NS, 'path');
      p.setAttribute('d', d);
      p.setAttribute('fill', 'currentColor');
      svg.appendChild(p);
    }
    // Передняя фигура (голова + плечи) и приглушённый силуэт за ней.
    path('M8 10a2.6 2.6 0 100-5.2A2.6 2.6 0 008 10zm0 1.2c-2.4 0-4.4 1.3-4.4 2.9V16h8.8v-1.9c0-1.6-2-2.9-4.4-2.9z');
    var back = document.createElementNS(NS, 'path');
    back.setAttribute('d', 'M13.4 9.4a2.2 2.2 0 100-4.4 2.2 2.2 0 000 4.4zm.4 1.3c-.5 0-1 .06-1.45.17 1.1.72 1.8 1.78 1.8 2.99V16h3.05v-1.7c0-1.45-1.6-2.6-3.4-2.6z');
    back.setAttribute('fill', 'currentColor');
    back.setAttribute('opacity', '0.55');
    svg.appendChild(back);
    return svg;
  }

  /* ---------- панель ---------- */

  function closePanel() {
    if (!panel) return;
    if (panel.parentNode) panel.parentNode.removeChild(panel);
    panel = null;
    document.removeEventListener('mousedown', onOutside, true);
    document.removeEventListener('keydown', onKeydown, true);
  }

  function onOutside(e) {
    if (!panel) return;
    if (panel.contains(e.target)) return;
    // Клик по самой кнопке обрабатывает её собственный listener —
    // иначе панель закрылась бы здесь и тут же открылась заново.
    if (e.target.closest && e.target.closest('.' + BTN_CLASS)) return;
    closePanel();
  }

  function onKeydown(e) {
    if (e.key !== 'Escape') return;
    e.preventDefault();
    // Escape при открытой форме env закрывает сначала её: набирая
    // значение, промахнуться мимо клавиши легко, а закрытая панель
    // унесла бы с собой всю правку.
    var form = panel && panel.querySelector('.claude-accs-env');
    if (form && form.contains(document.activeElement)) {
      form.parentNode.removeChild(form);
      return;
    }
    closePanel();
  }

  function positionPanel(btn) {
    if (!panel) return;
    // Футер прижат к низу окна — раскрываемся вверх от кнопки.
    var r = btn.getBoundingClientRect();
    panel.style.bottom = Math.max(8, window.innerHeight - r.top + 6) + 'px';
    panel.style.left = Math.max(8, r.left) + 'px';
  }

  function renderError(body, text) {
    var div = document.createElement('div');
    div.className = 'claude-accs-empty';
    div.textContent = text;
    body.appendChild(div);
  }

  /** Строка аккаунта: имя + endpoint, активный помечен галкой. */
  function gearIcon() {
    var NS = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('width', '14');
    svg.setAttribute('height', '14');
    svg.setAttribute('viewBox', '0 0 16 16');
    svg.setAttribute('fill', 'none');
    var p = document.createElementNS(NS, 'path');
    // Зубцы (восемь выступов по кругу) и ось отверстия — вторым
    // контуром: fill-rule="evenodd" делает его дыркой, а не накладкой.
    p.setAttribute('d',
      'M9.1 1.5l.3 1.7c.4.14.78.34 1.12.58l1.6-.62 1.4 2.42-1.3 1.13c.03.2.05.4.05.61'
      + 's-.02.41-.05.61l1.3 1.13-1.4 2.42-1.6-.62c-.34.24-.72.44-1.12.58l-.3 1.7h-2.8'
      + 'l-.3-1.7a4.6 4.6 0 01-1.12-.58l-1.6.62-1.4-2.42 1.3-1.13a4.7 4.7 0 010-1.22'
      + 'L1.88 5.58l1.4-2.42 1.6.62c.34-.24.72-.44 1.12-.58l.3-1.7h2.8zM8 5.9'
      + 'a2.1 2.1 0 100 4.2 2.1 2.1 0 000-4.2z');
    p.setAttribute('fill', 'currentColor');
    p.setAttribute('fill-rule', 'evenodd');
    svg.appendChild(p);
    return svg;
  }

  /** Значок «?» с описанием ключа, стоящий перед крестиком удаления.
   *
   * Показывается только у знакомых ключей: у незнакомого он обещал бы
   * объяснение, которого у нас нет. Место под него держим всегда —
   * иначе крестики в соседних строках встали бы в разные колонки.
   * Текст берётся с сервера (`hints` в ответе /account-env), а не из
   * этого файла: правка описания там применяется перезапуском сервера,
   * а здесь потребовала бы Reload Window. */
  function hintMark(text) {
    var mark = document.createElement('span');
    mark.className = 'claude-accs-env-hint';
    mark.textContent = '?';
    setHint(mark, text);
    return mark;
  }

  function setHint(mark, text) {
    mark.title = text || '';
    mark.style.visibility = text ? 'visible' : 'hidden';
  }

  function delButton(row, title) {
    var del = document.createElement('button');
    del.type = 'button';
    del.className = 'claude-accs-env-del';
    del.textContent = '✕';
    del.title = title;
    del.addEventListener('mousedown', function (e) { e.preventDefault(); });
    del.addEventListener('click', function () {
      if (row.parentNode) row.parentNode.removeChild(row);
    });
    return del;
  }

  function envRow(list, key, value, hints) {
    var row = document.createElement('div');
    row.className = 'claude-accs-env-row';

    var keyInput = document.createElement('input');
    keyInput.type = 'text';
    keyInput.className = 'claude-accs-env-key';
    keyInput.value = key || '';
    keyInput.placeholder = 'ПЕРЕМЕННАЯ';
    keyInput.spellcheck = false;
    row.appendChild(keyInput);

    var valInput = document.createElement('input');
    valInput.type = 'text';
    valInput.className = 'claude-accs-env-val';
    valInput.value = value == null ? '' : String(value);
    valInput.placeholder = 'значение';
    valInput.spellcheck = false;
    row.appendChild(valInput);

    var mark = hintMark(hints && hints[key]);
    keyInput.addEventListener('input', function () {
      setHint(mark, hints && hints[keyInput.value.trim()]);
    });
    row.appendChild(mark);
    row.appendChild(delButton(row, 'Удалить переменную'));

    list.appendChild(row);
    return row;
  }

  /** Поле значения настройки — по типу из справочника.
   *
   * Переключатель и список вместо текстового поля не украшательство:
   * `switchModelsOnFlag` должен остаться булевым, а значение вне
   * enum'а расширение молча игнорирует, и настройка выглядит заданной,
   * не действуя. Текущее значение добавляется в список, даже если его
   * там нет: показать «max» как «low» значило бы соврать про файл. */
  function settingField(spec, value) {
    var kind = (spec && spec.type) || 'text';
    if (kind !== 'bool' && kind !== 'enum') {
      var input = document.createElement('input');
      input.type = 'text';
      input.className = 'claude-accs-env-val';
      input.value = value == null ? '' : String(value);
      input.placeholder = 'значение';
      input.spellcheck = false;
      return input;
    }

    var sel = document.createElement('select');
    sel.className = 'claude-accs-env-val claude-accs-env-sel';
    var options = kind === 'bool'
      ? [['true', 'да'], ['false', 'нет']]
      : (spec.options || []).map(function (o) { return [o, o]; });
    var current = kind === 'bool'
      ? (value === true || value === 'true' ? 'true' : 'false')
      : (value == null ? '' : String(value));
    var known = options.some(function (o) { return o[0] === current; });
    if (!known) options.unshift([current, current || '(не задано)']);
    for (var i = 0; i < options.length; i++) {
      var opt = document.createElement('option');
      opt.value = options[i][0];
      opt.textContent = options[i][1];
      sel.appendChild(opt);
    }
    sel.value = current;
    sel.dataset.kind = kind;
    return sel;
  }

  function settingRow(list, key, value, specs) {
    var row = document.createElement('div');
    row.className = 'claude-accs-env-row';

    var keyInput = document.createElement('input');
    keyInput.type = 'text';
    keyInput.className = 'claude-accs-env-key';
    keyInput.value = key || '';
    keyInput.placeholder = 'настройка';
    keyInput.spellcheck = false;
    keyInput.setAttribute('list', SET_LIST_ID);
    row.appendChild(keyInput);

    var wrap = document.createElement('span');
    wrap.className = 'claude-accs-env-field';
    wrap.appendChild(settingField(specs && specs[key], value));
    row.appendChild(wrap);

    var mark = hintMark(specs && specs[key] && specs[key].hint);
    keyInput.addEventListener('input', function () {
      var spec = specs && specs[keyInput.value.trim()];
      setHint(mark, spec && spec.hint);
      // Тип поля зависит от имени настройки, а его правят прямо здесь:
      // переименовали `model` в `verbose` — поле обязано стать
      // переключателем, иначе в файл уйдёт строка вместо булева.
      var kind = (spec && spec.type) || 'text';
      if (wrap.firstChild && (wrap.firstChild.dataset.kind || 'text') === kind) return;
      var old = wrap.firstChild ? wrap.firstChild.value : '';
      wrap.textContent = '';
      wrap.appendChild(settingField(spec, old));
    });
    row.appendChild(mark);
    row.appendChild(delButton(row, 'Удалить настройку'));

    list.appendChild(row);
    return row;
  }

  /** Собирает раздел из полей формы. Пустые имена пропускаем: строка,
   * добавленная кнопкой «+» и оставленная незаполненной, — это не ключ
   * с пустым именем, а просто передумали. */
  function collectRows(list, typed) {
    var out = {};
    var rows = list.querySelectorAll('.claude-accs-env-row');
    for (var i = 0; i < rows.length; i++) {
      var key = rows[i].querySelector('.claude-accs-env-key').value.trim();
      if (!key) continue;
      var field = rows[i].querySelector('.claude-accs-env-val');
      // Булево отправляем булевым, а не строкой «true»: сервер по
      // справочнику привёл бы и строку, но в файле аккаунта с чужой
      // настройкой гадать о типе было бы не по чему.
      out[key] = (typed && field.dataset.kind === 'bool')
        ? field.value === 'true'
        : field.value;
    }
    return out;
  }

  /** Форма правки настроек аккаунта под его строкой. */
  function openConfigEditor(item, acc, btn, body) {
    var open = item.querySelector('.claude-accs-env');
    if (open) {
      // Повторный клик по шестерёнке — закрыть. Правки при этом
      // теряются: они не сохранены, и делать вид, что сохранены, хуже.
      item.removeChild(open);
      positionPanel(btn);
      return;
    }

    var form = document.createElement('div');
    form.className = 'claude-accs-env';
    item.appendChild(form);

    var loading = document.createElement('div');
    loading.className = 'claude-accs-env-note';
    loading.textContent = 'загрузка…';
    form.appendChild(loading);
    positionPanel(btn);

    fetch(ENV_URL + '?file=' + encodeURIComponent(acc.file), { cache: 'no-store' })
      .then(function (res) { return res.json(); })
      .then(function (d) {
        if (!panel || !form.parentNode) return;
        if (!d || !d.ok) throw new Error((d && d.error) || 'нет данных');
        form.textContent = '';
        renderConfigForm(form, acc, d, btn, body);
        positionPanel(btn);
      })
      .catch(function (err) {
        if (!panel || !form.parentNode) return;
        form.textContent = '';
        var e = document.createElement('div');
        e.className = 'claude-accs-env-note claude-accs-env-err';
        e.textContent = 'Не удалось прочитать файл: ' + ((err && err.message) || err);
        form.appendChild(e);
        positionPanel(btn);
      });
  }

  /** Заголовок раздела формы. */
  function sectionHead(form, text) {
    var head = document.createElement('div');
    head.className = 'claude-accs-env-sec';
    head.textContent = text;
    form.appendChild(head);
  }

  /** «05» из 5 — для селектов времени и ячеек календаря. */
  function pad2(n) {
    return (n < 10 ? '0' : '') + n;
  }

  /**
   * Раздел «подписка»: дата и время оплаты и срок в днях.
   *
   * Нативный input[type=datetime-local] в webview расширения свой
   * пикер не открывает — окно VSCode не даёт всплывающим панелям
   * Chromium показаться, — поэтому календарь и время свои: клик
   * по полю разворачивает сетку месяца и селекты часов/минут прямо
   * в форме. Поле только для чтения: набрать дату руками нельзя,
   * и сломать ISO-формат, который ждёт сервер, — тоже.
   *
   * ISO-значение живёт в data-атрибуте поля; в самом поле —
   * человеческая запись «06.09.2026 12:00».
   */
  function subscriptionBox(sub, btn, fields) {
    var box = document.createElement('div');
    box.className = 'claude-accs-env-list';

    // Сервер знает источник каждого значения. Отсутствующая маска —
    // старый http-server.py: ради совместимости показываем все поля.
    fields = fields && typeof fields === 'object' ? fields : {};

    var paidIso = (sub && sub.paidAt) || '';
    var hours = 12;
    var minutes = 0;

    // Почта: у сторонних провайдеров её не спросить ни у CLI, ни
    // по API — вводят руками и хранят с подпиской. Тарифа в форме
    // нет: Z.AI и OpenAI сообщают его сами, а для остальных он
    // не стоил отдельного поля.
    var emailRow = document.createElement('div');
    emailRow.className = 'claude-accs-env-row';
    var emailLabel = document.createElement('span');
    emailLabel.className = 'claude-accs-env-label';
    emailLabel.textContent = 'email';
    var emailInput = document.createElement('input');
    emailInput.type = 'text';
    emailInput.className = 'claude-accs-env-val claude-accs-sub-email';
    emailInput.value = (sub && sub.email) || '';
    emailInput.placeholder = 'почта аккаунта';
    emailInput.spellcheck = false;
    emailInput.title = 'Показывается в строке имени аккаунта';
    emailRow.appendChild(emailLabel);
    emailRow.appendChild(emailInput);
    if (fields.email === false) emailRow.style.display = 'none';
    box.appendChild(emailRow);

    var paidRow = document.createElement('div');
    paidRow.className = 'claude-accs-env-row';
    var paidLabel = document.createElement('span');
    paidLabel.className = 'claude-accs-env-label';
    paidLabel.textContent = 'оплачена';
    var paidInput = document.createElement('input');
    paidInput.type = 'text';
    paidInput.readOnly = true;
    paidInput.className = 'claude-accs-env-val claude-accs-sub-paid';
    paidInput.placeholder = 'выбрать дату и время';
    paidInput.title = 'Клик — календарь и время; кнопка «очистить» '
      + 'внутри убирает дату вовсе';
    paidRow.appendChild(paidLabel);
    paidRow.appendChild(paidInput);
    if (fields.paidAt === false) paidRow.style.display = 'none';
    box.appendChild(paidRow);

    var cal = document.createElement('div');
    cal.className = 'claude-accs-cal';
    cal.style.display = 'none';
    box.appendChild(cal);

    var MONTHS = ['январь', 'февраль', 'март', 'апрель', 'май', 'июнь',
      'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь'];
    var WEEKDAYS = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];

    // Какой месяц показываем: от уже заданной даты, иначе текущий.
    var start = paidIso ? Date.parse(paidIso) : Date.now();
    var view = isNaN(start) ? new Date() : new Date(start);
    if (paidIso) {
      hours = view.getHours();
      minutes = view.getMinutes();
    }

    /** Пересобирает ISO из даты в поле и выбранных часов/минут. */
    function recombine(dayIso) {
      var day = dayIso || (paidIso ? paidIso.slice(0, 10) : '');
      return day + 'T' + pad2(hours) + ':' + pad2(minutes);
    }

    function sync() {
      paidInput.dataset.iso = paidIso;
      paidInput.value = paidIso ? subDate(paidIso, true) : '';
    }

    // --- каркас календаря ---

    var calHead = document.createElement('div');
    calHead.className = 'claude-accs-cal-head';

    var prevBtn = document.createElement('button');
    prevBtn.type = 'button';
    prevBtn.className = 'claude-accs-cal-nav';
    prevBtn.textContent = '‹';
    prevBtn.title = 'Предыдущий месяц';
    var calTitle = document.createElement('span');
    calTitle.className = 'claude-accs-cal-title';
    var nextBtn = document.createElement('button');
    nextBtn.type = 'button';
    nextBtn.className = 'claude-accs-cal-nav';
    nextBtn.textContent = '›';
    nextBtn.title = 'Следующий месяц';
    calHead.appendChild(prevBtn);
    calHead.appendChild(calTitle);
    calHead.appendChild(nextBtn);
    cal.appendChild(calHead);

    var grid = document.createElement('div');
    grid.className = 'claude-accs-cal-grid';
    cal.appendChild(grid);

    var timeRow = document.createElement('div');
    timeRow.className = 'claude-accs-cal-time';
    var timeLabel = document.createElement('span');
    timeLabel.className = 'claude-accs-env-label';
    timeLabel.textContent = 'время';
    var hourSel = document.createElement('select');
    hourSel.className = 'claude-accs-env-val claude-accs-env-sel';
    var minuteSel = document.createElement('select');
    minuteSel.className = 'claude-accs-env-val claude-accs-env-sel';
    var i, opt;
    for (i = 0; i < 24; i++) {
      opt = document.createElement('option');
      opt.value = String(i);
      opt.textContent = pad2(i);
      hourSel.appendChild(opt);
    }
    for (i = 0; i < 60; i++) {
      opt = document.createElement('option');
      opt.value = String(i);
      opt.textContent = pad2(i);
      minuteSel.appendChild(opt);
    }
    hourSel.value = String(hours);
    minuteSel.value = String(minutes);
    var colon = document.createElement('span');
    colon.className = 'claude-accs-cal-colon';
    colon.textContent = ':';
    timeRow.appendChild(timeLabel);
    timeRow.appendChild(hourSel);
    timeRow.appendChild(colon);
    timeRow.appendChild(minuteSel);
    cal.appendChild(timeRow);

    var calFoot = document.createElement('div');
    calFoot.className = 'claude-accs-cal-foot';
    var clearBtn = document.createElement('button');
    clearBtn.type = 'button';
    clearBtn.className = 'claude-accs-env-btn';
    clearBtn.textContent = 'очистить';
    clearBtn.title = 'Убрать дату оплаты — строка срока уйдёт из списка';
    var doneBtn = document.createElement('button');
    doneBtn.type = 'button';
    doneBtn.className = 'claude-accs-env-btn claude-accs-env-save';
    doneBtn.textContent = 'готово';
    calFoot.appendChild(clearBtn);
    calFoot.appendChild(doneBtn);
    cal.appendChild(calFoot);

    // --- поведение ---

    function shiftMonth(delta) {
      view = new Date(view.getFullYear(), view.getMonth() + delta, 1);
      renderCal();
    }

    function renderCal() {
      var y = view.getFullYear();
      var m = view.getMonth();
      calTitle.textContent = MONTHS[m] + ' ' + y;

      grid.textContent = '';
      var d;
      for (d = 0; d < WEEKDAYS.length; d++) {
        var wd = document.createElement('span');
        wd.className = 'claude-accs-cal-wd';
        wd.textContent = WEEKDAYS[d];
        grid.appendChild(wd);
      }

      var picked = paidIso ? paidIso.slice(0, 10) : '';
      var today = new Date();
      var todayIso = today.getFullYear() + '-' + pad2(today.getMonth() + 1)
        + '-' + pad2(today.getDate());
      // Пустые ячейки до понедельника: без них первый день месяца
      // встал бы не в свою колонку, а дни соседних месяцев в сетке —
      // обещание клика, которого здесь нет.
      var lead = (new Date(y, m, 1).getDay() + 6) % 7;
      var total = new Date(y, m + 1, 0).getDate();
      var day;
      for (day = 0; day < lead; day++) {
        var blank = document.createElement('span');
        blank.className = 'claude-accs-cal-day claude-accs-cal-blank';
        grid.appendChild(blank);
      }
      for (day = 1; day <= total; day++) {
        var iso = y + '-' + pad2(m + 1) + '-' + pad2(day);
        var cell = document.createElement('button');
        cell.type = 'button';
        cell.className = 'claude-accs-cal-day';
        if (iso === picked) cell.className += ' claude-accs-cal-sel';
        if (iso === todayIso) cell.className += ' claude-accs-cal-today';
        cell.textContent = String(day);
        cell.addEventListener('mousedown', function (e) { e.preventDefault(); });
        cell.addEventListener('click', (function (dayIso) {
          return function () {
            paidIso = recombine(dayIso);
            sync();
            renderCal();
          };
        })(iso));
        grid.appendChild(cell);
      }
    }

    function toggleCal() {
      var open = cal.style.display !== 'none';
      cal.style.display = open ? 'none' : '';
      if (!open) renderCal();
      positionPanel(btn);
    }

    prevBtn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    nextBtn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    prevBtn.addEventListener('click', function () { shiftMonth(-1); });
    nextBtn.addEventListener('click', function () { shiftMonth(1); });

    hourSel.addEventListener('change', function () {
      hours = parseInt(hourSel.value, 10) || 0;
      if (paidIso) {
        paidIso = recombine();
        sync();
      }
    });
    minuteSel.addEventListener('change', function () {
      minutes = parseInt(minuteSel.value, 10) || 0;
      if (paidIso) {
        paidIso = recombine();
        sync();
      }
    });

    clearBtn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    clearBtn.addEventListener('click', function () {
      paidIso = '';
      sync();
      renderCal();
    });
    doneBtn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    doneBtn.addEventListener('click', toggleCal);

    paidInput.addEventListener('mousedown', function (e) { e.preventDefault(); });
    paidInput.addEventListener('click', toggleCal);

    var daysRow = document.createElement('div');
    daysRow.className = 'claude-accs-env-row';
    var daysLabel = document.createElement('span');
    daysLabel.className = 'claude-accs-env-label';
    daysLabel.textContent = 'срок, дн';
    var daysInput = document.createElement('input');
    daysInput.type = 'number';
    daysInput.min = '1';
    daysInput.step = '1';
    daysInput.className = 'claude-accs-env-val claude-accs-sub-days';
    daysInput.value = sub && sub.days ? String(sub.days) : '';
    daysInput.placeholder = '30';
    daysInput.title = 'На сколько дней оплачено. Пусто — месяц';
    daysRow.appendChild(daysLabel);
    daysRow.appendChild(daysInput);
    if (fields.days === false) daysRow.style.display = 'none';
    box.appendChild(daysRow);

    sync();
    return box;
  }

  /**
   * Данные раздела подписки для сохранения. Пусто всё — null: это
   * явное «удалить запись», а не «не трогать» (отсутствие ключа),
   * иначе очистить поля и сохранить не получилось бы вовсе.
   */
  function collectSubscription(box) {
    var input = box.querySelector('.claude-accs-sub-paid');
    var paid = ((input && input.dataset.iso) || '').trim();
    var email = box.querySelector('.claude-accs-sub-email').value.trim();
    var days = parseInt(box.querySelector('.claude-accs-sub-days').value, 10);
    if (!paid && !email) return null;
    return {
      paidAt: paid,
      days: isNaN(days) ? null : days,
      email: email,
    };
  }

  function renderConfigForm(form, acc, data, btn, body) {
    var hints = data.hints || {};
    var envHints = hints.env || {};
    var setHints = hints.settings || {};
    var env = data.env || {};
    // Раздел настроек рисуем, только если сервер его прислал: webview
    // может работать с сервером, поднятым до этой правки, и пустая
    // секция означала бы «настроек нет», а не «сервер о них не знает».
    var settings = data.settings && typeof data.settings === 'object'
      ? data.settings : null;

    var head = document.createElement('div');
    head.className = 'claude-accs-env-head';
    head.textContent = acc.file;
    form.appendChild(head);

    var names, i;
    var setList = null;

    // Подписка — первый раздел формы: у каждого провайдера своё
    // знание о ней (Z.AI отдаёт тариф и срок сам, Anthropic — почту,
    // OpenAI — все доступные данные). Рисуем ручную часть,
    // лишь когда сервер прислал ключ (undefined — старый
    // http-server.py о разделе не знает; null — подписки у аккаунта
    // нет, и поля просто пустые).
    var subBox = null;
    if (showSub && data.subscription !== undefined) {
      sectionHead(form, 'подписка · срок действия');
      subBox = subscriptionBox(
        data.subscription, btn, data.subscriptionFields);
      form.appendChild(subBox);
    }

    if (settings) {
      var datalist = document.createElement('datalist');
      datalist.id = SET_LIST_ID;
      names = Object.keys(setHints);
      for (i = 0; i < names.length; i++) {
        var opt = document.createElement('option');
        opt.value = names[i];
        datalist.appendChild(opt);
      }
      form.appendChild(datalist);

      sectionHead(form, 'настройки');
      setList = document.createElement('div');
      setList.className = 'claude-accs-env-list';
      form.appendChild(setList);

      names = Object.keys(settings);
      for (i = 0; i < names.length; i++) {
        settingRow(setList, names[i], settings[names[i]], setHints);
      }
      if (!names.length) settingRow(setList, '', '', setHints);
    }

    sectionHead(form, 'env · переменные окружения');
    var list = document.createElement('div');
    list.className = 'claude-accs-env-list';
    form.appendChild(list);

    names = Object.keys(env);
    for (i = 0; i < names.length; i++) {
      envRow(list, names[i], env[names[i]], envHints);
    }
    if (!names.length) envRow(list, '', '', envHints);

    var status = document.createElement('div');
    status.className = 'claude-accs-env-note';
    form.appendChild(status);

    var foot = document.createElement('div');
    foot.className = 'claude-accs-env-foot';
    form.appendChild(foot);

    var addSet = null;
    if (setList) {
      addSet = document.createElement('button');
      addSet.type = 'button';
      addSet.className = 'claude-accs-env-btn';
      addSet.textContent = '+ настройка';
      addSet.addEventListener('mousedown', function (e) { e.preventDefault(); });
      addSet.addEventListener('click', function () {
        var row = settingRow(setList, '', '', setHints);
        positionPanel(btn);
        try { row.querySelector('.claude-accs-env-key').focus(); } catch (e) {}
      });
      foot.appendChild(addSet);
    }

    var add = document.createElement('button');
    add.type = 'button';
    add.className = 'claude-accs-env-btn';
    add.textContent = '+ переменная';
    add.addEventListener('mousedown', function (e) { e.preventDefault(); });
    add.addEventListener('click', function () {
      var row = envRow(list, '', '', envHints);
      positionPanel(btn);
      try { row.querySelector('.claude-accs-env-key').focus(); } catch (e) {}
    });
    foot.appendChild(add);

    var save = document.createElement('button');
    save.type = 'button';
    save.className = 'claude-accs-env-btn claude-accs-env-save';
    save.textContent = 'Сохранить';
    save.addEventListener('mousedown', function (e) { e.preventDefault(); });
    save.addEventListener('click', function () {
      save.disabled = true;
      cancel.disabled = true;
      add.disabled = true;
      if (addSet) addSet.disabled = true;
      status.className = 'claude-accs-env-note';
      status.textContent = 'сохранение…';

      var payload = { file: acc.file, env: collectRows(list, false) };
      // Раздела нет — не отправляем его вовсе: пустой объект сервер
      // понял бы как «удалить все настройки». Для подписки null,
      // наоборот, легитимен — см. collectSubscription.
      if (setList) payload.settings = collectRows(setList, true);
      if (subBox) payload.subscription = collectSubscription(subBox);

      accountsRevision++;
      fetch(ENV_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
        .then(function (res) { return res.json(); })
        .then(function (d) {
          if (d && d.ok) rememberAccounts(d.accounts);
          if (!panel || !form.parentNode) return;
          save.disabled = false;
          cancel.disabled = false;
          add.disabled = false;
          if (addSet) addSet.disabled = false;
          if (!d || !d.ok) {
            throw new Error((d && (d.message || d.error)) || 'сервер отказал');
          }
          logInfo('настройки сохранены:', acc.file);
          // Перерисовываем весь список: подпись endpoint могла только
          // что измениться, и оставлять старую нельзя.
          // Форма при этом закрывается вместе со старой разметкой,
          // поэтому итог показываем в подвале панели.
          renderAccounts(body, d.accounts, btn);
          var note = document.createElement('div');
          note.className = 'claude-accs-env-note';
          note.textContent = '✓ ' + (d.message || 'сохранено');
          body.appendChild(note);
          positionPanel(btn);
        })
        .catch(function (err) {
          if (!panel || !form.parentNode) return;
          save.disabled = false;
          cancel.disabled = false;
          add.disabled = false;
          if (addSet) addSet.disabled = false;
          status.className = 'claude-accs-env-note claude-accs-env-err';
          status.textContent = 'Не сохранено: ' + ((err && err.message) || err);
          positionPanel(btn);
        });
    });
    foot.appendChild(save);

    var cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.className = 'claude-accs-env-btn claude-accs-env-cancel';
    cancel.textContent = 'Отмена';
    cancel.addEventListener('mousedown', function (e) { e.preventDefault(); });
    cancel.addEventListener('click', function () {
      if (!form.parentNode) return;
      form.parentNode.removeChild(form);
      positionPanel(btn);
    });
    foot.appendChild(cancel);
  }

  /* ---------- лимиты подписки ---------- */

  /**
   * Полоски расхода лимитов claude.ai в строке аккаунта: пятичасовое
   * окно и недельное (у Max к ним добавляются окна по моделям).
   *
   * Данные приходят полем `usage` в самом аккаунте — сервер читает их
   * из кэша Claude Code (`cachedUsageUtilization` в ~/.claude.json).
   * Свежесть поэтому не наша: CLI обновляет кэш, пока работает на
   * OAuth-логине, и если сессия давно идёт через стороннего провайдера,
   * числа успевают состариться. Возраст записи есть в подсказке, а
   * после USAGE_STALE_SEC полоски ещё и приглушаются — молча показывать
   * вчерашние проценты как сегодняшние нельзя.
   *
   * Полоски лежат внутри строки-кнопки и клик не перехватывают:
   * строка целиком означает «переключиться на этот аккаунт», и
   * мёртвая зона в её правой половине была бы неожиданностью.
   */
  var showUsage = cfg.accountsUsageBars !== false;

  // Возраст данных, после которого блок считается устаревшим.
  // Полчаса: CLI обновляет кэш в каждой сессии, и запись старше
  // получаса означает, что на этом логине давно никто не работал.
  var USAGE_STALE_SEC = 1800;

  /** «1 ч 51 мин», «6 д», «меньше минуты» — сколько осталось. */
  function formatLeft(sec, compact) {
    if (typeof sec !== 'number' || !isFinite(sec) || sec < 0) return '';
    if (sec < 60) return 'меньше минуты';
    var min = Math.floor(sec / 60) % 60;
    var hours = Math.floor(sec / 3600) % 24;
    var days = Math.floor(sec / 86400);
    // Компакт («19д 22ч») — для строки подписки в имени аккаунта;
    // с пробелами («19 д 22 ч») — лимиты и метки свежести.
    if (days > 0) return days + (compact ? 'д' : ' д')
      + (hours ? ' ' + hours + (compact ? 'ч' : ' ч') : '');
    if (hours > 0) return hours + (compact ? 'ч' : ' ч')
      + (min ? ' ' + min + (compact ? 'мин' : ' мин') : '');
    return min + (compact ? 'мин' : ' мин');
  }

  /** «обновлены 4 мин назад» — насколько данным можно верить. */
  function formatAge(sec) {
    if (typeof sec !== 'number' || !isFinite(sec) || sec < 0) {
      return 'время обновления неизвестно';
    }
    if (sec < 90) return 'обновлены только что';
    return 'обновлены ' + formatLeft(sec) + ' назад';
  }

  // Атрибут-метка строки, которой полагаются полоски. Ставится по
  // acc.oauth, поэтому свежие числа есть куда положить даже тогда,
  // когда кэш пуст и при первой отрисовке полосок не было.
  var USAGE_HOST_ATTR = 'data-claude-usage-host';

  /**
   * Окна лимитов: ключ в ответе API, подпись полоски, полное название.
   *
   * Таблица повторяет USAGE_WINDOWS из account_switcher.py — числа
   * приходят двумя путями (кэш через сервер и живой ответ отсюда), и
   * одно и то же окно не должно называться в них по-разному. Меняете
   * здесь — правьте и там.
   */
  var USAGE_WINDOWS = [
    ['five_hour', '5 ч', 'Сессия (5 часов)'],
    ['seven_day', '7 дн', 'Неделя (7 дней)'],
    ['seven_day_opus', 'Opus', 'Неделя, Opus'],
    ['seven_day_sonnet', 'Sonnet', 'Неделя, Sonnet'],
  ];

  /**
   * Приводит `rate_limits` из ответа расширения к тому же виду, в
   * котором лимиты присылает сервер, — чтобы отрисовка была одна.
   */
  function windowsFromRateLimits(limits) {
    if (!limits || typeof limits !== 'object') return null;
    var windows = [];
    for (var i = 0; i < USAGE_WINDOWS.length; i++) {
      var key = USAGE_WINDOWS[i][0];
      var w = limits[key];
      if (!w || typeof w !== 'object') continue;
      var pct = w.utilization;
      if (typeof pct !== 'number' || !isFinite(pct)) continue;
      var left = null;
      if (typeof w.resets_at === 'string' && w.resets_at) {
        var at = Date.parse(w.resets_at);
        if (!isNaN(at)) left = Math.round((at - Date.now()) / 1000);
      }
      // То же правило, что на сервере: окно с прошедшим временем сброса
      // уже началось заново, и прежние проценты к нему не относятся
      // (см. anthropic_usage в account_switcher.py).
      var expired = left !== null && left <= 0;
      windows.push({
        key: key,
        label: USAGE_WINDOWS[i][1],
        title: USAGE_WINDOWS[i][2],
        percent: expired ? 0 : pct,
        resetsInSec: expired ? null : left,
        expired: expired,
      });
    }
    return windows.length ? { windows: windows, ageSec: 0, observedAt: Date.now() / 1000 } : null;
  }

  /* ---------- свежие лимиты у самого расширения ---------- */

  /**
   * Сервер отдаёт лимиты из кэша, который ведёт CLI (`~/.claude.json`),
   * и обновляет он его, только когда его об этом просят: пока никто не
   * открывал «Аккаунт и расход», числа стареют. Прецедент (2026-09-01):
   * пятичасовое окно успело сброситься, штатное окно показывало 2%,
   * а панель — 33% из вчерашнего кэша.
   *
   * Поэтому при открытии панели мы просим свежие числа у самого
   * расширения — тем же вызовом `session.getUsage()`, которым их берёт
   * штатное окно «Account & Usage». Побочный эффект тут главный: CLI
   * при этом перезаписывает свой кэш, так что свежие числа достаются и
   * серверу, и всем остальным потребителям.
   *
   * Объект сессии достаём из React-fiber — тем же приёмом, что
   * `findSessionId` в CACHE USAGE BUTTON и `openConfig` в SETTINGS MENU
   * FIX. Признак нужного объекта — метод `getUsage`.
   */
  function fiberOfEl(el) {
    if (!el) return null;
    var keys = Object.keys(el);
    for (var i = 0; i < keys.length; i++) {
      if (keys[i].indexOf('__reactFiber') === 0) return el[keys[i]];
    }
    return null;
  }

  function hasUsageApi(o) {
    return !!o && typeof o === 'object' && typeof o.getUsage === 'function';
  }

  /** Ищет объект сессии в пропсах/состоянии одного fiber'а. */
  function usageHolderIn(obj) {
    if (!obj || typeof obj !== 'object') return null;
    if (hasUsageApi(obj)) return obj;
    var keys;
    try { keys = Object.keys(obj); } catch (e) { return null; }
    for (var i = 0; i < keys.length && i < 30; i++) {
      var c;
      try { c = obj[keys[i]]; } catch (e) { continue; }
      if (hasUsageApi(c)) return c;
      // Сессия бывает завёрнута в сигнал: значение лежит в `.value`.
      if (c && typeof c === 'object' && hasUsageApi(c.value)) return c.value;
    }
    return null;
  }

  function findUsageHolder() {
    var anchor = document.querySelector('[class*="inputContainer_"]')
      || document.getElementById('root')
      || document.body;
    var fiber = fiberOfEl(anchor);
    var hops = 0;
    while (fiber && hops < 80) {
      var found = usageHolderIn(fiber.memoizedProps)
        || usageHolderIn(fiber.memoizedState);
      if (found) return found;
      // Состояние функционального компонента — связный список хуков.
      var hook = fiber.memoizedState;
      var n = 0;
      while (hook && typeof hook === 'object' && n < 40) {
        var got = usageHolderIn(hook.memoizedState);
        if (got) return got;
        hook = hook.next;
        n++;
      }
      fiber = fiber.return;
      hops++;
    }
    return null;
  }

  /** Перерисовывает полоски во всех строках, которым они положены. */
  function applyUsage(body, usage) {
    var hosts = body.querySelectorAll('[' + USAGE_HOST_ATTR + ']');
    for (var i = 0; i < hosts.length; i++) {
      var host = hosts[i];
      var fresh = usageBlock(usage);
      var old = host.querySelector('.claude-accs-usage');
      if (!fresh) {
        if (old) host.removeChild(old);
        continue;
      }
      if (old) host.replaceChild(fresh, old);
      else host.appendChild(fresh);
    }
  }

  function markUsageBusy(body, busy) {
    var blocks = body.querySelectorAll('.claude-accs-usage');
    for (var i = 0; i < blocks.length; i++) {
      blocks[i].classList.toggle('claude-accs-usage-busy', !!busy);
    }
  }

  /**
   * Просит у расширения свежие лимиты и заменяет ими показанные из кэша.
   * Молчаливая: не вышло — остаются кэшированные числа, и подсказка
   * честно называет их возраст.
   */
  function refreshUsage(body) {
    if (!showUsage) return;
    if (!body.querySelector('[' + USAGE_HOST_ATTR + ']')) return;
    var holder = findUsageHolder();
    if (!holder) {
      logInfo('объект сессии с getUsage не найден — остаёмся на кэше');
      return;
    }
    var promise;
    try { promise = holder.getUsage(); } catch (e) { return; }
    if (!promise || typeof promise.then !== 'function') return;

    markUsageBusy(body, true);
    var revision = accountsRevision;
    promise.then(function (res) {
      // Панель могли закрыть или перерисовать, пока шёл запрос.
      if (!panel || !body.isConnected || revision !== accountsRevision) return;
      markUsageBusy(body, false);
      var usage = res && res.usage;
      var fresh = usage && windowsFromRateLimits(usage.rate_limits);
      if (!fresh) {
        logInfo('расширение не отдало лимиты — остаёмся на кэше');
        return;
      }
      applyUsage(body, fresh);
      if (accountsSnapshot) accountsSnapshot = accountsSnapshot.map(function (acc) {
        return acc.oauth ? Object.assign({}, acc, { usage: fresh }) : acc;
      });
      logInfo('лимиты обновлены у расширения');
    }, function (err) {
      if (!panel || !body.isConnected) return;
      markUsageBusy(body, false);
      logInfo('getUsage отказал', err);
    });
  }

  function usageBlock(usage) {
    var wins = usage && usage.windows;
    if (!wins || !wins.length) return null;

    var box = document.createElement('span');
    box.className = 'claude-accs-usage';
    if (typeof usage.ageSec === 'number' && usage.ageSec > USAGE_STALE_SEC) {
      box.className += ' claude-accs-usage-stale';
    }

    var lines = [];
    for (var i = 0; i < wins.length; i++) {
      var w = wins[i] || {};
      var pct = typeof w.percent === 'number' && isFinite(w.percent) ? w.percent : 0;
      var shown = Math.max(0, Math.min(100, pct));

      var line = document.createElement('span');
      line.className = 'claude-accs-usage-row';
      // Уровень расхода четвертями: 0 — меньше четверти лимита,
      // 3 — больше трёх четвертей. Цвет шкалы и процента берётся из
      // него, поэтому строка красится целиком одним атрибутом.
      line.setAttribute('data-level',
        String(Math.min(3, Math.floor(shown / 25))));

      var label = document.createElement('span');
      // Подпись всегда белая: цветом говорит шкала, а подпись только
      // называет окно. Ключ окна в разметке остаётся — по нему видно,
      // какая шкала перед тобой, и на него можно опереться, если
      // палитру снова захочется сделать по-оконной.
      label.className = 'claude-accs-usage-label';
      if (w.key) label.setAttribute('data-window', w.key);
      label.textContent = w.label || '';
      line.appendChild(label);

      // У сброшенного окна отсчитывать нечего: время прошло, а нового
      // рубежа кэш не знает — его назовёт только следующий ответ API.
      var left = formatLeft(w.resetsInSec);
      var barText = w.expired ? 'сброшен' : left;
      var hint = w.expired
        ? ' · окно сброшено, свежих данных нет'
        : (left ? ' · сброс через ' + left : '');

      var track = document.createElement('span');
      track.className = 'claude-accs-usage-track';
      var fill = document.createElement('span');
      fill.className = 'claude-accs-usage-fill';
      // Цвет полоски задаёт CSS по ключу окна: держать палитру в JS
      // значило бы требовать Reload Window на каждый подбор оттенка.
      if (w.key) fill.setAttribute('data-window', w.key);
      fill.style.width = shown + '%';
      track.appendChild(fill);

      // Время до сброса — внутри шкалы, одним слоем и всегда одним
      // цветом (подобран на стенде usage-text-picker.html вместе с
      // цветом подложки). Менять цвет по границе заливки двумя слоями
      // нельзя: сглаживание глифов смешивается с нижним текстом, а не
      // с фоном, и буквы получают светлую кайму (прецедент 55.2).
      if (barText) {
        var when = document.createElement('span');
        when.className = 'claude-accs-usage-when';
        when.textContent = barText;
        track.appendChild(when);
      }
      line.appendChild(track);

      var val = document.createElement('span');
      val.className = 'claude-accs-usage-pct';
      val.textContent = Math.floor(shown) + '%';
      line.appendChild(val);

      box.appendChild(line);

      lines.push((w.title || w.label || '') + ' · ' + Math.floor(shown) + '%' + hint);
    }
    lines.push((usage.sourceLabel || 'Данные Claude Code') + ', '
      + formatAge(usage.ageSec));
    box.title = lines.join('\n');
    return box;
  }

  /**
   * Подпись под названием аккаунта.
   *
   * У логина claude.ai это тариф и почта: endpoint у него всегда
   * `api.anthropic.com`, одинаковый у любого такого аккаунта, и в
   * строке он не отличает его ни от чего. У аккаунта провайдера
   * различием остаётся адрес; модель показывается только в Usage.
   *
   * Тариф идёт первым, потому что он короткий: длинная почта уходит
   * под многоточие, и обрезаться должна именно она, а не он.
   */
  function accountSubtitle(acc) {
    // У логина claude.ai тариф и почта стоят в строке имени, а вторую
    // строку занимают полоски лимитов — endpoint там уже не нужен.
    // То же у OpenAI (почта и тариф из Codex) и Z.AI (тариф, срок и
    // квоты из его API). Но если опознаваемых данных нет (файлы CLI
    // не прочитались или API провайдера промолчал), строка не должна
    // оставаться пустой: показываем endpoint.
    var known = acc.oauth
      || acc.provider === 'openai'
      || acc.usageZai
      || (acc.subscription && acc.subscription.source === 'zai');
    if (known && (acc.plan || acc.email)) {
      return '';
    }
    return acc.baseUrl || '';
  }

  /**
   * «Pro (почта)» — приписка к названию аккаунта.
   *
   * Источник у провайдеров разный (credentials CLI, Codex App Server,
   * API Z.AI, ручной ввод), а вид один: имя аккаунта остаётся главным
   * словом строки, тариф и почта идут приглушённой припиской.
   */
  function accountMeta(acc) {
    var parts = [];
    if (acc.plan) parts.push(acc.plan);
    if (acc.email) parts.push('(' + acc.email + ')');
    return parts.join(' ');
  }

  /** «05.10», «05.10.2026 14:30» — дата из ISO-строки сервера. */
  function subDate(iso, withYear) {
    var t = Date.parse(iso);
    if (isNaN(t)) return '';
    var d = new Date(t);
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    var out = p(d.getDate()) + '.' + p(d.getMonth() + 1);
    if (!withYear) return out;
    return out + '.' + d.getFullYear() + ' ' + p(d.getHours())
      + ':' + p(d.getMinutes());
  }

  /**
   * Срок подписки в строке имени аккаунта: «до 05.10 (29д)».
   *
   * Дату оплаты задают руками в настройках аккаунта, и точность тут
   * та же — день оплаты плюс срок. Цветом отмечен близкий конец
   * (жёлтый, меньше недели) и истёкший (красный); числа без цвета —
   * ровно как у приписки с тарифом и почтой, это служебная часть
   * строки имени.
   */
  function subscriptionNote(sub) {
    if (!sub) return null;
    var short = subDate(sub.until, false);
    if (!short) return null;
    var full = subDate(sub.until, true);
    var left = formatLeft(sub.leftSec, true);

    var el = document.createElement('span');
    el.className = 'claude-accs-paid';

    // Срок пришёл с сервера Z.AI: подсказка называет тариф и
    // продление, а не дату «оплаты» — ту панель знает лишь с рук.
    if (sub.source === 'zai') {
      var head = sub.plan ? sub.plan + ' · ' : '';
      if (sub.expired) {
        el.setAttribute('data-level', '2');
        el.textContent = 'истекла ' + short;
        el.title = head + 'период кончился ' + full;
        return el;
      }
      el.setAttribute('data-level', sub.leftSec <= 7 * 86400 ? '1' : '0');
      el.textContent = 'до ' + short + (left ? ' (' + left + ')' : '');
      el.title = head + 'до ' + full + ', осталось '
        + (left || 'меньше минуты')
        + (sub.autoRenew ? ' · продлевается автоматически' : '')
        + ' · данные Z.AI';
      return el;
    }

    var paid = subDate(sub.paidAt, true) || sub.paidAt;
    if (sub.expired) {
      el.setAttribute('data-level', '2');
      el.textContent = 'истекла ' + short;
      el.title = 'Оплачена ' + paid + ' · ' + sub.days + ' дн — '
        + 'действовала до ' + full;
      return el;
    }
    // Неделя до конца — время продлевать: раньше жёлтый только мешал
    // бы стоять постоянно у кратких периодов.
    el.setAttribute('data-level', sub.leftSec <= 7 * 86400 ? '1' : '0');
    el.textContent = 'до ' + short + (left ? ' (' + left + ')' : '');
    el.title = 'Оплачена ' + paid + ' · ' + sub.days + ' дн — до '
      + full + ', осталось ' + (left || 'меньше минуты');
    return el;
  }

  function accountRow(acc, btn, body) {
    var item = document.createElement('div');
    item.className = 'claude-accs-item';

    var line = document.createElement('div');
    line.className = 'claude-accs-line';
    item.appendChild(line);

    var row = document.createElement('button');
    row.type = 'button';
    row.className = 'claude-accs-row'
      + (acc.isActive ? ' claude-accs-row-active' : '');

    var mark = document.createElement('span');
    mark.className = 'claude-accs-mark';
    mark.textContent = acc.isActive ? '✓' : '';
    row.appendChild(mark);

    var text = document.createElement('span');
    text.className = 'claude-accs-text';

    var name = document.createElement('span');
    name.className = 'claude-accs-name';
    var nameText = document.createElement('span');
    nameText.textContent = acc.name;
    name.appendChild(nameText);

    // Тариф и почта — приписка в той же строке, приглушённая: имя
    // аккаунта должно оставаться главным словом строки.
    var meta = accountMeta(acc);
    if (meta) {
      var metaEl = document.createElement('span');
      metaEl.className = 'claude-accs-meta';
      metaEl.textContent = meta;
      // Почта длинная и обрезается многоточием — под курсором должна
      // читаться целиком.
      metaEl.title = meta;
      name.appendChild(metaEl);
    }

    // Срок подписки — там же, сразу за почтой: его читают первым,
    // и второй строкой он искался бы глазами. Слово «подписка»
    // не пишем — «до 06.10» говорит само, а строка имени коротка.
    if (showSub) {
      var paidNote = subscriptionNote(acc.subscription);
      if (paidNote) name.appendChild(paidNote);
    }
    text.appendChild(name);

    var subtitle = accountSubtitle(acc);
    if (subtitle) {
      var sub = document.createElement('span');
      sub.className = 'claude-accs-sub';
      sub.textContent = subtitle;
      sub.title = subtitle;
      text.appendChild(sub);
    }

    // Лимиты приходят только у аккаунтов на OAuth-логине claude.ai —
    // у стороннего провайдера своих окон нет, и рисовать там нечего.
    // Помечаем по acc.oauth, а не по наличию acc.usage: кэша может не
    // быть вовсе, а место под свежие числа нужно всё равно.
    //
    // Полоски идут второй строкой внутри текстовой колонки, а не
    // справа от неё: почта занимает всю ширину строки имени, и справа
    // от неё места уже нет.
    if (showUsage && acc.oauth) {
      text.setAttribute(USAGE_HOST_ATTR, '1');
      text.setAttribute('data-claude-account-usage-file', acc.file);
      var usage = usageBlock(acc.usage);
      if (usage) text.appendChild(usage);
    }
    if (showUsage && acc.provider === 'openai') {
      text.setAttribute('data-claude-account-usage-file', acc.file);
      var openaiUsage = usageBlock(acc.usage);
      if (openaiUsage) text.appendChild(openaiUsage);
    }
    // Квоты Coding Plan — те же полоски: их отдаёт API Z.AI (ручка
    // страницы подписки в его кабинете), ключ уже в env аккаунта.
    if (showUsage && acc.usageZai) {
      text.setAttribute('data-claude-account-usage-file', acc.file);
      var zaiUsage = usageBlock(acc.usage);
      if (zaiUsage) text.appendChild(zaiUsage);
    }

    row.appendChild(text);

    row.addEventListener('mousedown', function (e) { e.preventDefault(); });
    row.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (switching) return;
      openAccountDetails(acc, btn, body);
    });
    line.appendChild(row);

    var gear = document.createElement('button');
    gear.type = 'button';
    gear.className = 'claude-accs-gear';
    gear.title = 'Настройки и переменные окружения этого аккаунта';
    gear.appendChild(gearIcon());
    gear.addEventListener('mousedown', function (e) { e.preventDefault(); });
    gear.addEventListener('click', function (e) {
      // Без остановки клик дошёл бы до строки и переключил аккаунт —
      // а шестерёнка обещает совсем другое.
      e.preventDefault();
      e.stopPropagation();
      openConfigEditor(item, acc, btn, body);
    });
    line.appendChild(gear);

    return item;
  }

  function accountLocalDate() {
    var now = new Date();
    return now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0');
  }

  function accountBucketLabel(key, hourly) {
    return hourly ? key.slice(-2) + ':00–' + key.slice(-2) + ':59' : key;
  }

  function accountChartValue(bucket, metric) {
    if (metric === 'api') {
      var api = bucket.api;
      return !api || api.messages === api.unknown ? null : api.usd;
    }
    var values = (bucket.windows || []).filter(function (w) { return (w.key || w.label) + '|' + w.label === metric; });
    var known = values.filter(function (w) { return typeof w.percent === 'number'; });
    return known.length ? known.reduce(function (sum, w) { return sum + w.percent; }, 0) : null;
  }

  function accountWeekTooltip(bucket) {
    var weeks = bucket.subscriptionWeeks || [];
    if (!weeks.length) return 'Нет данных о неделе подписки за этот период.';
    return weeks.map(function (week) {
      return week.number + '-я неделя подписки · '
        + new Date(week.start).toLocaleString('ru-RU') + ' — ' + new Date(week.end).toLocaleString('ru-RU')
        + (week.estimated ? ' · расчётные границы, сброс не наблюдался' : '');
    }).join('\n');
  }

  function renderAccountChart(content, data, onPeriodChange) {
    var period = data.period || { mode: 'day', date: accountLocalDate() };
    var hourly = period.mode === 'day';
    var buckets = data.buckets || [];
    var box = document.createElement('section'); box.className = 'claude-accs-chart';
    var controls = document.createElement('div'); controls.className = 'claude-accs-chart-controls';
    function button(label, title, action) {
      var el = document.createElement('button'); el.type = 'button';
      el.className = 'claude-accs-detail-button'; el.textContent = label; el.title = title;
      el.addEventListener('click', function (e) { e.preventDefault(); action(); });
      controls.appendChild(el); return el;
    }
    ['day', 'month'].forEach(function (mode) {
      var el = button(mode === 'day' ? 'День' : 'Месяц', mode === 'day' ? 'По часам' : 'По дням', function () {
        if (mode === period.mode) return;
        var date = mode === 'month' ? period.date.slice(0, 7)
          : (period.date === accountLocalDate().slice(0, 7) ? accountLocalDate() : period.date + '-01');
        onPeriodChange({ mode: mode, date: date });
      });
      el.setAttribute('aria-pressed', String(period.mode === mode));
    });
    function shift(amount) {
      var date = new Date(period.date + (hourly ? '' : '-01') + 'T12:00:00');
      if (hourly) date.setDate(date.getDate() + amount); else date.setMonth(date.getMonth() + amount);
      var next = date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0')
        + (hourly ? '-' + String(date.getDate()).padStart(2, '0') : '');
      onPeriodChange({ mode: period.mode, date: next });
    }
    button('‹', hourly ? 'Предыдущий день' : 'Предыдущий месяц', function () { shift(-1); });
    var picker = document.createElement('input'); picker.type = hourly ? 'date' : 'month';
    picker.value = period.date; picker.max = hourly ? accountLocalDate() : accountLocalDate().slice(0, 7);
    picker.setAttribute('aria-label', hourly ? 'День графика' : 'Месяц графика');
    picker.addEventListener('change', function () {
      if (picker.value && picker.value <= picker.max) onPeriodChange({ mode: period.mode, date: picker.value });
    });
    controls.appendChild(picker);
    var next = button('›', hourly ? 'Следующий день' : 'Следующий месяц', function () { shift(1); });
    next.disabled = period.date >= picker.max;
    button('Сегодня', 'Часы текущего дня', function () { onPeriodChange({ mode: 'day', date: accountLocalDate() }); });
    box.appendChild(controls);
    var metrics = Object.create(null);
    buckets.forEach(function (bucket) {
      (bucket.windows || []).forEach(function (w) { metrics[(w.key || w.label) + '|' + w.label] = w.label; });
      if (bucket.api) metrics.api = 'API · $';
    });
    // Current quotas remain selectable even when this period has history
    // only for another window (or the provider omitted a reset timestamp).
    (data.windows || []).forEach(function (w) { metrics[(w.key || w.label) + '|' + w.label] = w.label; });
    if (data.billing === 'api') metrics.api = 'API · $';
    var metricKeys = Object.keys(metrics);
    var combined = data.billing === 'subscription' && metricKeys.length === 2 && metricKeys.indexOf('api') < 0;
    if (combined) metricKeys.sort(function (a, b) {
      return Number(/^5\s*ч/.test(metrics[b])) - Number(/^5\s*ч/.test(metrics[a]));
    });
    var select = document.createElement('select'); select.setAttribute('aria-label', 'Лимит или стоимость');
    Object.keys(metrics).forEach(function (key) {
      var option = document.createElement('option'); option.value = key; option.textContent = metrics[key]; select.appendChild(option);
    });
    select.value = Object.keys(metrics)[0] || '';
    if (select.children.length > 1 && !combined) box.appendChild(select);
    else if (select.children.length === 1) {
      var metricLabel = document.createElement('div'); metricLabel.className = 'claude-accs-weekly-heading';
      metricLabel.textContent = metrics[select.value]; box.appendChild(metricLabel);
    }
    var plot = document.createElement('div'); plot.className = 'claude-accs-chart-plot'; box.appendChild(plot);
    plot.setAttribute('data-combined', String(combined));
    var legend = document.createElement('div'); legend.className = 'claude-accs-chart-legend'; box.appendChild(legend);
    var hint = document.createElement('div'); hint.className = 'claude-accs-chart-hint'; box.appendChild(hint);
    function draw() {
      plot.textContent = '';
      var series = combined ? metricKeys : [select.value];
      var visibleBuckets = buckets;
      if (hourly) {
        var firstUsed = buckets.findIndex(function (bucket) {
          return series.some(function (metric) { return accountChartValue(bucket, metric) > 0; });
        });
        var morningStart = buckets.findIndex(function (bucket) { return Number(bucket.date.slice(-2)) >= 7; });
        var firstVisible = morningStart < 0 ? 0 : firstUsed < 0 ? morningStart : Math.min(firstUsed, morningStart);
        if (firstVisible > 0) visibleBuckets = buckets.slice(firstVisible);
      }
      legend.textContent = '';
      series.forEach(function (metric, seriesIndex) {
        if (metric === 'api') return;
        [['local', 'Claude Code', seriesIndex ? '#c080ff' : '#7fff00'],
          ['external', 'Вне Claude Code', seriesIndex ? '#ff9b45' : '#409cff']].forEach(function (item) {
          var key = document.createElement('span'); key.className = 'claude-accs-chart-key-' + item[0];
          key.textContent = (combined ? metrics[metric] + ' · ' : '') + item[1];
          key.style.color = item[2]; legend.appendChild(key);
        });
      });
      legend.title = 'Для каждого лимита отдельно показаны замеры задач Claude Code и остальные замеры. При одновременном использовании аккаунта в разных приложениях лимит отражает их общий расход.';
      if (combined) legend.title = 'Меньшее значение — заливка, большее — контур. ' + legend.title;
      var values = [];
      visibleBuckets.forEach(function (b) { series.forEach(function (metric) { values.push(accountChartValue(b, metric)); }); });
      var max = Math.max.apply(Math, [series[0] === 'api' ? 0.0001 : 1].concat(values.filter(function (v) { return v != null; })));
      var axis = document.createElement('div'); axis.className = 'claude-accs-chart-axis';
      // Keep headroom for the values above the tallest bars, without a scale caption.
      axis.setAttribute('aria-hidden', 'true');
      plot.appendChild(axis);
      var bars = document.createElement('div'); bars.className = 'claude-accs-chart-bars';
      bars.setAttribute('data-combined', String(combined));
      var currentBucket = accountLocalDate() + 'T' + String(new Date().getHours()).padStart(2, '0');
      visibleBuckets.forEach(function (bucket) {
        var group = combined ? document.createElement('div') : bars;
        var outlineIndex = -1;
        if (combined) {
          var firstValue = accountChartValue(bucket, series[0]);
          var secondValue = accountChartValue(bucket, series[1]);
          // Keep the only known value filled; for equal values use a stable order.
          outlineIndex = firstValue == null ? 0 : secondValue == null ? 1 : firstValue > secondValue ? 0 : 1;
          group.className = 'claude-accs-chart-pair';
          group.setAttribute('data-current', String(bucket.date === currentBucket.slice(0, bucket.date.length)));
        }
        series.forEach(function (metric, seriesIndex) {
          var value = accountChartValue(bucket, metric);
          var localColor = seriesIndex ? '#c080ff' : '#7fff00';
          var externalColor = seriesIndex ? '#ff9b45' : '#409cff';
          var label = accountBucketLabel(bucket.date, hourly);
          var partial = metric === 'api' ? bucket.api && bucket.api.unknown
            : (bucket.windows || []).some(function (w) { return w.gaps; });
          var description = label + ' · ' + (value == null ? 'Нет данных для расчёта'
            : metric === 'api' ? '≈$' + Number(value).toFixed(4) : '≥' + value + ' п.п.')
            + (partial ? ' · неполные данные' : '');
          var bar = document.createElement('button'); bar.type = 'button';
          var tooltip = metric === 'api' ? description : accountWeekTooltip(bucket);
          if (combined) tooltip = metrics[metric] + ' · ' + description + '\n' + tooltip;
          var measured = (bucket.windows || []).filter(function (w) { return (w.key || w.label) + '|' + w.label === metric; });
          var external = measured.reduce(function (sum, w) { return sum + (w.externalPercent || 0); }, 0);
          var local = measured.reduce(function (sum, w) { return sum + (w.localPercent || 0); }, 0);
          if (local > 0) tooltip += '\nЗамеры задачи Claude Code: ' + Number(local.toFixed(2)) + ' п.п.';
          if (external > 0) tooltip += '\nВне Claude Code: ' + Number(external.toFixed(2)) + ' п.п. (остальные замеры).';
          measured.forEach(function (w) {
            if (w.observedFrom != null && w.observedTo != null) tooltip += '\nМежду проверками: '
              + new Date(w.observedFrom * 1000).toLocaleString('ru-RU') + ' — '
              + new Date(w.observedTo * 1000).toLocaleString('ru-RU')
              + '. Прирост показан по времени обнаружения.';
          });
          bar.className = 'claude-accs-chart-column'; bar.title = tooltip; bar.setAttribute('aria-label', tooltip);
          bar.setAttribute('data-current', String(bucket.date === currentBucket.slice(0, bucket.date.length)));
          if (combined) bar.setAttribute('data-outline', String(seriesIndex === outlineIndex));
          var fill = document.createElement('span'); fill.className = 'claude-accs-chart-fill';
          var height = value == null ? null : Math.max(2, value / max * 100);
          fill.style.height = height == null ? '3px' : height + '%';
          fill.setAttribute('data-missing', String(value == null));
          if (combined && value != null) {
            fill.style.background = localColor + '66';
            fill.style.borderColor = localColor;
          }
          if (external > 0 && value > 0) {
            var externalShare = Math.min(100, external / value * 100);
            fill.style.background = 'linear-gradient(to top, ' + externalColor + '88 ' + externalShare + '%, ' + localColor + '66 ' + externalShare + '%)';
            if (externalShare === 100) fill.style.borderColor = externalColor;
            else fill.style.borderImage = 'linear-gradient(to top, ' + externalColor + ' ' + externalShare + '%, ' + localColor + ' ' + externalShare + '%) 1';
            fill.setAttribute('data-external', String(external));
          }
          if (combined && seriesIndex === outlineIndex) fill.style.background = 'transparent';
          bar.appendChild(fill);
          if (value != null) {
            var number = document.createElement('span'); number.className = 'claude-accs-chart-value';
            number.textContent = String(Number(value.toFixed(metric === 'api' ? 4 : 2)));
            if (/^5\s*ч/.test(metrics[metric])) number.style.color = '#65d9ff';
            number.style.bottom = 'calc(' + height + '% + 3px)';
            bar.appendChild(number);
          }
          if (!combined) {
            var tick = document.createElement('span'); tick.className = 'claude-accs-chart-tick';
            tick.textContent = bucket.date.slice(-2); bar.appendChild(tick);
          }
          bar.addEventListener('mouseenter', function () { hint.textContent = tooltip; });
          bar.addEventListener('focus', function () { hint.textContent = tooltip; });
          bar.addEventListener('click', function () {
            if (hourly) hint.textContent = tooltip;
            else if (bucket.date <= accountLocalDate()) onPeriodChange({ mode: 'day', date: bucket.date });
          });
          group.appendChild(bar);
        });
        if (combined) {
          var tick = document.createElement('span'); tick.className = 'claude-accs-chart-tick';
          tick.textContent = bucket.date.slice(-2); group.appendChild(tick);
          bars.appendChild(group);
        }
      });
      plot.appendChild(bars);
      hint.textContent = values.some(function (v) { return v != null; })
        ? (hourly ? 'Наведите на час для подробностей.' : 'Нажмите на день, чтобы посмотреть часы.') + ' Серые отметки — нет данных.'
        : 'Нет данных для расчёта за выбранный период. Серые отметки не означают нулевой расход.';
    }
    select.addEventListener('change', draw); draw();
    content.appendChild(box);
  }

  function renderWeeklyUsage(host, data) {
    host.textContent = '';
    host.hidden = data.billing !== 'subscription';
    if (host.hidden) return;
    var expanded = host.quotaExpanded || (host.quotaExpanded = {});
    function section(key, text) {
      var group = document.createElement('section'); group.className = 'claude-accs-limit-section'; host.appendChild(group);
      var heading = document.createElement('button'); heading.type = 'button';
      heading.className = 'claude-accs-limit-toggle claude-accs-limit-' + key;
      heading.textContent = text; group.appendChild(heading);
      var body = document.createElement('div'); body.className = 'claude-accs-limit-body'; group.appendChild(body);
      function update() { body.hidden = !expanded[key]; heading.setAttribute('aria-expanded', String(!body.hidden)); }
      heading.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); expanded[key] = !expanded[key]; update(); });
      update(); return body;
    }
    function empty(body, text) {
      var note = document.createElement('div'); note.className = 'claude-accs-detail-note';
      note.textContent = text; body.appendChild(note);
    }
    function isShort(w) { return w.duration_seconds === 18000 || w.duration === 18000 || /^5\s*ч/.test(w.label || '') || w.key === 'five_hour'; }
    function column(plot, value, max, tickText, tooltip) {
      var bar = document.createElement('div'); bar.className = 'claude-accs-chart-column'; bar.tabIndex = 0;
      bar.title = tooltip; bar.setAttribute('aria-label', tooltip);
      var fill = document.createElement('span'); fill.className = 'claude-accs-chart-fill';
      var height = value == null ? null : Math.max(2, value / max * 100);
      fill.style.height = height == null ? '3px' : height + '%';
      fill.setAttribute('data-missing', String(value == null)); bar.appendChild(fill);
      if (value != null) {
        var number = document.createElement('span'); number.className = 'claude-accs-chart-value';
        number.textContent = String(Number(value.toFixed(2))); number.style.bottom = 'calc(' + height + '% + 3px)'; bar.appendChild(number);
      }
      var tick = document.createElement('span'); tick.className = 'claude-accs-chart-tick';
      tick.textContent = tickText; bar.appendChild(tick); plot.appendChild(bar);
    }
    var weeklyBody = section('weekly', 'Недельные лимиты');
    var weeks = data.weeklyUsage || [];
    var metrics = Object.create(null);
    function addMetric(w) { if (!isShort(w)) metrics[(w.key || w.label) + '|' + w.label] = w.label; }
    (data.windows || []).forEach(addMetric);
    weeks.forEach(function (week) {
      (week.windows || []).forEach(addMetric);
    });
    var select = document.createElement('select'); select.setAttribute('aria-label', 'Недельные итоги по окну лимита');
    Object.keys(metrics).forEach(function (key) {
      var option = document.createElement('option'); option.value = key; option.textContent = metrics[key]; select.appendChild(option);
    });
    // Prefer the longest quota window; short and weekly quotas must not be added together.
    var keys = Object.keys(metrics);
    select.value = keys.find(function (key) { return /дн/.test(metrics[key]); }) || keys[0] || '';
    if (keys.length > 1) weeklyBody.appendChild(select);
    var plot = document.createElement('div'); plot.className = 'claude-accs-weekly-bars';
    if (weeks.length) weeklyBody.appendChild(plot);
    else empty(weeklyBody, 'Нет данных о недельных периодах');
    function draw() {
      plot.textContent = '';
      var values = weeks.map(function (week) { return accountChartValue(week, select.value); });
      var max = Math.max.apply(Math, [100].concat(values.filter(function (value) { return value != null; })));
      weeks.forEach(function (week, index) {
        var value = values[index];
        var tooltip = accountWeekTooltip({ subscriptionWeeks: [week] }) + '\n'
          + (value == null ? 'Нет данных для расчёта' : 'Зафиксировано ≥' + value + ' п.п. (' + metrics[select.value] + ')');
        column(plot, value, max, String(week.number), tooltip);
      });
    }
    select.addEventListener('change', draw); draw();
    var short = data.shortUsage || [];
    if ((data.windows || []).some(isShort) || short.length) {
      var shortBody = section('short', '5 часовые лимиты');
      host.insertBefore(shortBody.parentNode, weeklyBody.parentNode);
      if (!short.length) {
        empty(shortBody, data.subscriptionPeriod ? 'Нет записанных пятичасовых периодов за текущую подписку' : 'Нет данных о текущем периоде подписки');
      } else {
        var scroll = document.createElement('div'); scroll.className = 'claude-accs-short-scroll'; shortBody.appendChild(scroll);
        var shortPlot = document.createElement('div'); shortPlot.className = 'claude-accs-weekly-bars claude-accs-short-bars'; scroll.appendChild(shortPlot);
        short.forEach(function (period, index) {
          var tooltip = (index + 1) + '-й пятичасовой период · ' + new Date(period.start * 1000).toLocaleString('ru-RU')
            + ' — ' + new Date(period.end * 1000).toLocaleString('ru-RU') + '\nЗафиксировано ≥' + period.used + '%';
          column(shortPlot, period.used, 100, String(index + 1), tooltip);
        });
      }
    }
  }

  function renderAccountDetails(content, data, onPeriodChange, header) {
    content.textContent = '';
    if (!header) {
      var top = document.createElement('div'); top.className = 'claude-accs-detail-overview';
      header = { weekly: document.createElement('div') };
      header.weekly.className = 'claude-accs-weekly';
      top.appendChild(header.weekly); content.appendChild(top);
    }
    renderWeeklyUsage(header.weekly, data);
    renderAccountChart(content, data, onPeriodChange || function () {});
    var buckets = data.buckets || data.days || [];
    var hourly = data.period && data.period.mode === 'day';
    var note = document.createElement('div');
    note.className = 'claude-accs-detail-note';
    note.textContent = data.billing === 'api'
      ? 'Оценка по журналам и тарифам проекта, по времени отправки сообщения. Не счёт провайдера; старые сообщения без записи аккаунта не учитываются.'
      : 'Расход между замерами внутри ' + (hourly ? 'часа' : 'дня') + ', в процентных пунктах лимита всего аккаунта. Пропуски, переходы границ периода и сбросы не включены.';
    content.appendChild(note);
    var total = 0, knownCosts = 0, unknownCosts = 0;
    buckets.forEach(function (day) {
      if (!day.api) return;
      total += day.api.usd || 0;
      knownCosts += day.api.messages - day.api.unknown;
      unknownCosts += day.api.unknown;
    });
    if (data.billing === 'api' || knownCosts || unknownCosts) {
      var totalLine = document.createElement('div');
      totalLine.className = 'claude-accs-detail-cost';
      totalLine.textContent = knownCosts ? 'Учтено за период: ≈$' + total.toFixed(4) : 'Нет записанной стоимости';
      if (unknownCosts) totalLine.textContent += ' · сообщений без стоимости: ' + unknownCosts;
      content.appendChild(totalLine);
    }
    if (data.missingLogs) renderError(content, 'Часть журналов чатов недоступна: ' + data.missingLogs);
    var foot = document.createElement('div');
    foot.className = 'claude-accs-detail-note';
    foot.textContent = 'Время этого ПК. Нет данных ≠ нулевой расход. '
      + 'Обновлено: ' + new Date(data.updatedAt * 1000).toLocaleString();
    content.appendChild(foot);
  }

  function openAccountDetails(acc, btn, body) {
    var openedPanel = panel;
    body.textContent = '';
    var detail = document.createElement('div');
    detail.className = 'claude-accs-details';
    body.appendChild(detail);
    function button(label, action) {
      var el = document.createElement('button');
      el.type = 'button'; el.className = 'claude-accs-detail-button'; el.textContent = label;
      el.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); action(); });
      return el;
    }
    var toolbar = document.createElement('div'); toolbar.className = 'claude-accs-detail-toolbar';
    toolbar.appendChild(button('← Аккаунты', function () {
      renderAccounts(body, accountsSnapshot || [], btn); positionPanel(btn);
    }));
    if (!acc.isActive) {
      var useAccount = button('Использовать аккаунт', function () {
        if (!switching) switchTo(acc.file, btn, body);
      });
      useAccount.className += ' claude-accs-use-account'; toolbar.appendChild(useAccount);
    }
    detail.appendChild(toolbar);
    var overview = document.createElement('div'); overview.className = 'claude-accs-detail-overview';
    var identity = document.createElement('div'); identity.className = 'claude-accs-detail-identity';
    overview.appendChild(identity); detail.appendChild(overview);
    var title = document.createElement('div'); title.className = 'claude-accs-head';
    title.textContent = acc.name + (acc.isActive ? ' · активный' : ''); identity.appendChild(title);
    var meta = document.createElement('div'); meta.className = 'claude-accs-detail-note';
    meta.textContent = accountMeta(acc) || accountSubtitle(acc); identity.appendChild(meta);
    meta.title = meta.textContent;
    var header = { weekly: document.createElement('div') };
    header.weekly.className = 'claude-accs-weekly'; overview.appendChild(header.weekly);
    var status = document.createElement('div'); status.className = 'claude-accs-detail-note';
    detail.appendChild(status);
    var content = document.createElement('div'); detail.appendChild(content);
    var requestRevision = 0;
    function loadPeriod(period) {
      var revision = ++requestRevision;
      var key = acc.file + '|' + period.mode + '|' + period.date;
      var cached = accountDetailsCache[key];
      renderAccountDetails(content, cached || { billing: acc.oauth || acc.provider === 'openai' || acc.usageZai ? 'subscription' : 'api',
        period: period, buckets: [], windows: [], updatedAt: Date.now() / 1000 }, loadPeriod, header);
      status.textContent = 'Обновление…';
      positionPanel(btn);
      fetch('http://127.0.0.1:18923/account-usage-history?file=' + encodeURIComponent(acc.file)
        + '&mode=' + period.mode + '&date=' + encodeURIComponent(period.date), { cache: 'no-store' })
        .then(function (res) { return res.json(); })
        .then(function (data) {
          if (!data || !data.ok) throw new Error(data && data.error || 'Нет данных');
          // Cache and paint only the response for the most recent period selection.
          if (revision !== requestRevision) return;
          accountDetailsCache[key] = data;
          if (panel !== openedPanel || !detail.isConnected) return;
          status.textContent = '';
          renderAccountDetails(content, data, loadPeriod, header); positionPanel(btn);
        }).catch(function (error) {
          if (revision !== requestRevision || panel !== openedPanel || !detail.isConnected) return;
          status.textContent = 'Не удалось обновить' + (cached ? '. Показаны сохранённые данные.' : ': ' + error.message);
          logInfo('account details failed', error);
        });
    }
    panel.scrollTop = 0;
    loadPeriod({ mode: 'day', date: accountLocalDate() });
  }

  function renderAccounts(body, accounts, btn) {
    rememberAccounts(accounts);
    accounts = accountsSnapshot;
    body.textContent = '';

    var head = document.createElement('div');
    head.className = 'claude-accs-head';
    head.textContent = 'Аккаунт провайдера';
    body.appendChild(head);

    if (!accounts || !accounts.length) {
      renderError(body, 'В ~/.claude/ нет файлов settings*.json');
      return;
    }
    activeFile = null;
    for (var i = 0; i < accounts.length; i++) {
      if (accounts[i] && accounts[i].isActive) activeFile = accounts[i].file;
      body.appendChild(accountRow(accounts[i], btn, body));
    }
    // Сноска «Смена требует перезапуска расширения» убрана: сразу после
    // выбора появляется окно с кнопкой перезапуска — она всё говорит.
  }

  /** Аккаунт из списка по имени файла (для заголовка модалки). */
  function findAccount(accounts, file) {
    for (var i = 0; accounts && i < accounts.length; i++) {
      if (accounts[i] && accounts[i].file === file) return accounts[i];
    }
    return null;
  }

  function switchTo(file, btn, body) {
    if (switching || restarting) return;
    accountsRevision++;
    var prevFile = activeFile;
    var acc = findAccount(accountsSnapshot, file);
    var prevAcc = findAccount(accountsSnapshot, prevFile);
    closePanel();
    openModal(acc, file, prevFile, prevAcc);
  }

  /* Подтверждение предшествует POST /accounts. Только после успешной
   * смены отправляем заявку на перезапуск extension host. Отмена до
   * подтверждения ничего не меняет; после сбоя перезапуска возвращает
   * прежний профиль, чтобы настройки на диске совпадали с сессией. */

  function closeModal() {
    if (!modal) return;
    if (modal.parentNode) modal.parentNode.removeChild(modal);
    modal = null;
    modalDecline = null;
    document.removeEventListener('keydown', onModalKeydown, true);
  }

  function onModalKeydown(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      if (modalDecline) modalDecline();
    }
  }

  function modalRow(parent, className, text) {
    var el = document.createElement('div');
    el.className = className;
    el.textContent = text;
    parent.appendChild(el);
    return el;
  }

  function openModal(acc, file, prevFile, prevAcc) {
    closeModal();
    var applied = false;
    var inFlight = false;

    modal = document.createElement('div');
    modal.id = MODAL_ID;
    modal.className = 'claude-accs-overlay';

    var box = document.createElement('div');
    box.className = 'claude-accs-modal';
    modal.appendChild(box);

    modalRow(box, 'claude-accs-modal-head', 'Переключение аккаунта');

    var card = document.createElement('div');
    card.className = 'claude-accs-modal-card';
    modalRow(card, 'claude-accs-modal-label', 'Будет выбран');
    modalRow(card, 'claude-accs-modal-value', (acc && acc.name) || file);
    if (acc && acc.baseUrl) {
      modalRow(card, 'claude-accs-modal-sub', acc.baseUrl);
    }
    box.appendChild(card);

    modalRow(box, 'claude-accs-modal-text',
      'После подтверждения аккаунт будет переключён, затем расширение перезапустится.');

    modalRow(box, 'claude-accs-modal-warn',
      '⚠ Текущий диалог прервётся. Переписка откроется заново, '
      + 'но идущая задача будет остановлена.');

    var status = document.createElement('div');
    status.className = 'claude-accs-modal-status';
    box.appendChild(status);

    var footer = document.createElement('div');
    footer.className = 'claude-accs-modal-foot';
    box.appendChild(footer);

    var later = document.createElement('button');
    later.type = 'button';
    later.className = 'claude-accs-modal-btn claude-accs-modal-ghost';
    later.textContent = 'Отмена';
    footer.appendChild(later);

    var go = document.createElement('button');
    go.type = 'button';
    go.className = 'claude-accs-modal-btn claude-accs-modal-primary';
    go.textContent = 'Переключить аккаунт';
    footer.appendChild(go);

    /** Отказ: возвращаем прежний аккаунт и закрываем окно. */
    function decline() {
      // Заявка уже отправлена — откатывать поздно: хост вот-вот
      // перезапустится и подхватит новый settings.json.
      if (restarting || inFlight) return;
      if (!applied || !prevFile || prevFile === file) {
        closeModal();
        return;
      }
      later.disabled = true;
      go.disabled = true;
      inFlight = true;
      setStatus(status,
        'Возврат на ' + ((prevAcc && prevAcc.name) || prevFile) + '…', 'wait');

      accountsRevision++;
      fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        // revert говорит серверу, что переключения для пользователя не
        // было: процесс CLI как работал на прежнем аккаунте, так и
        // работает. Без этого признака история панели Usage объясняла
        // бы промахи кэша двумя переключениями, которых не случилось.
        body: JSON.stringify({ file: prevFile, revert: true }),
      })
        .then(function (res) { return res.json(); })
        .then(function (d) {
          if (d && d.ok) rememberAccounts(d.accounts);
          if (!modal) return;
          if (d && d.ok) {
            logInfo('откат на', prevFile);
            closeModal();
            return;
          }
          throw new Error((d && (d.message || d.error)) || 'сервер отказал');
        })
        .catch(function (err) {
          inFlight = false;
          if (!modal) return;
          // Молча закрыться нельзя: на диске остался новый аккаунт,
          // и пользователь должен знать, что откат не удался.
          later.disabled = false;
          go.disabled = false;
          later.textContent = 'Закрыть';
          setStatus(status,
            'Не удалось вернуть прежний аккаунт: '
            + ((err && err.message) || err)
            + '. На диске остался новый — выберите нужный в панели Accs.',
            'err');
          logInfo('revert failed', err);
        });
    }

    modalDecline = decline;
    later.addEventListener('click', function () {
      // После неудачного отката кнопка становится «Закрыть»: повторять
      // запрос, который только что провалился, смысла нет.
      if (later.textContent === 'Закрыть') closeModal();
      else decline();
    });
    go.addEventListener('click', function () {
      if (inFlight || switching || restarting) return;
      if (applied) { requestRestart(go, later, status); return; }
      inFlight = true;
      switching = true;
      go.disabled = true;
      later.disabled = true;
      accountsRevision++;
      setStatus(status, 'Переключение аккаунта…', 'wait');
      fetch(API_URL, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ file: file }),
      })
        .then(function (res) { return res.json(); })
        .then(function (d) {
          if (!d || !d.ok) throw new Error((d && (d.message || d.error)) || 'не удалось переключить');
          applied = true;
          inFlight = false;
          switching = false;
          rememberAccounts(d.accounts);
          logInfo('переключено на', file);
          requestRestart(go, later, status);
        })
        .catch(function (err) {
          inFlight = false;
          switching = false;
          go.disabled = false;
          later.disabled = false;
          setStatus(status, 'Не удалось переключить аккаунт: ' + ((err && err.message) || err), 'err');
          logInfo('switch failed', err);
        });
    });

    document.body.appendChild(modal);
    document.addEventListener('keydown', onModalKeydown, true);
    try { go.focus(); } catch (e) {}

    // Клик мимо модалки = «Отмена». Перезапуск — действие с потерями,
    // случайно запустить его мимо кнопки нельзя, а отложить — можно.
    modal.addEventListener('mousedown', function (e) {
      if (e.target === modal) decline();
    });
  }

  function setStatus(status, text, kind) {
    status.textContent = text;
    status.className = 'claude-accs-modal-status'
      + (kind ? ' claude-accs-modal-status-' + kind : '');
  }

  function requestRestart(go, later, status) {
    go.disabled = true;
    later.disabled = true;
    // С этого момента отказ запрещён: откатывать подмену бессмысленно,
    // хост вот-вот перезапустится и прочитает новый settings.json.
    restarting = true;
    setStatus(status, 'Заявка отправлена, ждём расширение…', 'wait');

    // Своё имя знает только сам webview: панель, созданную умершим
    // хостом, оживить нельзя, и новый хост о ней уже ничего не помнит.
    // Без sessionId он сможет вкладку только закрыть, а открыть заново
    // ту же переписку — нет.
    var sessionId = null;
    try {
      var resolve = window.__claudeSessionId;
      if (typeof resolve === 'function') sessionId = resolve();
    } catch (e) {
      logInfo('session id получить не удалось', e);
    }
    if (!sessionId) logInfo('session id неизвестен — вкладку переоткрыть будет нечем');

    fetch(RESTART_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId: sessionId || '', windowId: window.__claudeWindowId || '' }),
    })
      .then(function (res) { return res.json(); })
      .then(function (d) {
        if (!d || !d.ok) throw new Error((d && d.error) || 'сервер отказал');
        logInfo('заявка на перезапуск', d.token);
        waitForAck(go, later, status, Date.now());
      })
      .catch(function (err) {
        restarting = false;
        go.disabled = false;
        later.disabled = false;
        setStatus(status, 'Не удалось перезапустить окно VS Code: '
          + ((err && err.message) || err), 'err');
        logInfo('restart request failed', err);
      });
  }

  /** Опрос подтверждения. Успех обычно не успевает отрисоваться —
   * расширение перезапускается и webview пересоздаётся. Ценность
   * опроса в обратном исходе: молчание значит, что блок в extension.js
   * не активен, и пользователю надо об этом сказать. */
  function waitForAck(go, later, status, startedAt) {
    if (!modal) return;
    if (Date.now() - startedAt > ACK_TIMEOUT_MS) {
      // Перезапуска не будет — значит откат снова имеет смысл.
      restarting = false;
      go.disabled = false;
      later.disabled = false;
      setStatus(status,
        'Расширение не ответило на заявку. Похоже, блок перезапуска '
        + 'в extension.js не активен — аккаунт переключён, но применить '
        + 'его придётся вручную: Developer: Reload Window.', 'err');
      return;
    }
    fetch(RESTART_URL, { cache: 'no-store' })
      .then(function (res) { return res.json(); })
      .then(function (d) {
        if (!modal) return;
        if (d && d.acked) {
          setStatus(status, 'Расширение принимает перезапуск…', 'ok');
          // Штатно эту модалку убирает не таймер, а сама вкладка: после
          // рестарта хоста расширение переоткрывает её, и DOM создаётся
          // с нуля. Таймер — на случай, когда переоткрытия не случилось:
          // модалка перекрывает окно и ввод, и висеть до конца сессии
          // она не должна. Откат отсюда уже запрещён (restarting), так
          // что закрытие безопасно — на диске нужный аккаунт.
          setTimeout(function () {
            if (modal) {
              logInfo('модалка закрыта по таймауту — вкладка не переоткрылась');
              closeModal();
            }
          }, ACK_CLOSE_MS);
          return;
        }
        setTimeout(function () {
          waitForAck(go, later, status, startedAt);
        }, ACK_POLL_MS);
      })
      .catch(function () {
        if (!modal) return;
        setTimeout(function () {
          waitForAck(go, later, status, startedAt);
        }, ACK_POLL_MS);
      });
  }

  function openPanel(btn) {
    closePanel();

    panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.className = 'claude-accs-panel';
    var openedPanel = panel;
    var revision = ++accountsRevision;

    var body = document.createElement('div');
    body.className = 'claude-accs-body';
    body.textContent = 'загрузка…';
    panel.appendChild(body);
    document.body.appendChild(panel);
    positionPanel(btn);

    document.addEventListener('mousedown', onOutside, true);
    document.addEventListener('keydown', onKeydown, true);

    if (accountsSnapshot) renderAccounts(body, accountsSnapshot, btn);
    fetch(API_URL + '?refresh_usage=1', { cache: 'no-store' })
      .then(function (res) { return res.json(); })
      .then(function (d) {
        if (revision !== accountsRevision) return;
        if (!d || !d.ok) throw new Error((d && d.error) || 'нет данных');
        rememberAccounts(d.accounts);
        if (panel !== openedPanel) return;
        // The cached rows are interactive immediately. Do not discard an
        // editor the user opened while this refresh was still in flight.
        if (!body.querySelector('.claude-accs-env') && !body.querySelector('.claude-accs-details')) {
          var scroll = panel.scrollTop;
          renderAccounts(body, accountsSnapshot, btn);
          panel.scrollTop = scroll;
        }
        // Высота стала известна только сейчас — переставляем, иначе
        // длинный список уедет за верхний край окна.
        positionPanel(btn);
        // Кэшированные числа уже на экране; свежие догоняют их через
        // расширение (и заодно обновляют кэш для остальных).
        refreshUsage(body);
      })
      .catch(function (err) {
        if (panel !== openedPanel || revision !== accountsRevision) return;
        if (!accountsSnapshot) body.textContent = '';
        renderError(body, accountsSnapshot
          ? 'Не удалось обновить. Показаны сохранённые данные.'
          : 'http-server.py недоступен (порт 18923)');
        logInfo('fetch failed', err);
      });
  }

  /* ---------- встраивание ---------- */

  /** См. одноимённую функцию в CACHE USAGE BUTTON — логика та же. */
  function findAnchor(footer) {
    var buttons = footer.querySelectorAll('button');
    var match = null;
    for (var i = 0; i < buttons.length; i++) {
      if (AUTO_EDIT_RE.test(buttons[i].textContent || '')) {
        match = buttons[i];
        break;
      }
    }
    if (match) {
      var node = match;
      while (node.parentNode && node.parentNode !== footer) node = node.parentNode;
      return {
        before: node.parentNode === footer ? node : null,
        donor: match,
      };
    }
    return {
      before: null,
      donor: footer.querySelector('[class*="footerButton_"]')
        || footer.querySelector('button'),
    };
  }

  function createButton(donor) {
    var btn = document.createElement('button');
    btn.type = 'button';
    var donorClass = claudeNativeButtonClasses(donor);
    if (donorClass) {
      btn.className = donorClass + ' ' + BTN_CLASS;
    } else {
      btn.className = BTN_CLASS + ' ' + BARE_CLASS;
    }
    btn.appendChild(accsIcon());
    var label = document.createElement('span');
    label.textContent = 'Accs';
    btn.appendChild(label);
    btn.title = 'Аккаунты провайдеров: подменить ~/.claude/settings.json';
    btn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (panel) closePanel();
      else openPanel(btn);
    });
    return btn;
  }

  function mount(container) {
    var footer = container.querySelector('[class*="inputFooter_"]');
    if (!footer) return false;
    var anchor = findAnchor(footer);
    var btn = createButton(anchor.donor);
    // Порядок в футере: Accs · Usage · Cache · ByPass · автоправки.
    // Опираемся на соседа, а не на порядок инициализации модулей:
    // React пересоздаёт футер, и кто смонтируется первым — не
    // гарантировано. Встаём перед самым левым из уже существующих.
    var neighbour = footer.querySelector('.claude-usage-btn')
      || footer.querySelector('.claude-cache-btn')
      || footer.querySelector('.claude-bypass-btn');
    if (neighbour && neighbour.parentNode === footer) {
      footer.insertBefore(btn, neighbour);
    } else if (anchor.before) {
      footer.insertBefore(btn, anchor.before);
    } else {
      var spacer = footer.querySelector('[class*="spacer_"]');
      if (spacer && spacer.parentNode === footer) {
        footer.insertBefore(btn, spacer.nextSibling);
      } else {
        footer.appendChild(btn);
      }
    }
    return true;
  }

  /**
   * Держит Accs левее соседей, даже если те смонтировались позже.
   * Вставка при монтировании этого не гарантирует — см. ensureOrder
   * в CACHE KEEPALIVE.
   */
  function ensureOrder(footer) {
    var me = footer.querySelector('.' + BTN_CLASS);
    if (!me || me.parentNode !== footer) return;
    var right = footer.querySelector('.claude-usage-btn')
      || footer.querySelector('.claude-cache-btn')
      || footer.querySelector('.claude-bypass-btn');
    if (!right || right.parentNode !== footer) return;
    // DOCUMENT_POSITION_FOLLOWING — сосед идёт ПОСЛЕ нас, всё верно.
    if (me !== right && !(me.compareDocumentPosition(right) & 4)) {
      footer.insertBefore(me, right);
      logInfo('порядок восстановлен: Accs перед соседями');
    }
  }

  function scan(ctx) {
    // Узлы даёт общий обход (см. DOM WATCH) — один на все модули.
    // Свой поиск остаётся для вызовов вне прохода: при регистрации
    // и из обработчиков самого модуля.
    var containers = (ctx && ctx.inputs)
      || document.querySelectorAll('[class*="inputContainer_"]');
    for (var i = 0; i < containers.length; i++) {
      var footer = containers[i].querySelector('[class*="inputFooter_"]');
      if (containers[i].querySelector('.' + BTN_CLASS)) {
        if (footer) ensureOrder(footer);
        continue;
      }
      if (!containers[i].querySelector('[role="textbox"][contenteditable]')) continue;
      mount(containers[i]);
    }
  }

  function init() {
    // Наблюдатель и подстраховочный таймер — общие (см. DOM WATCH).
    window.__claudeDomWatch.register('accounts', scan);
    logInfo('installed');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * LIMIT ALERT STOP BUTTON
 *
 * Плавающая круглая кнопка-плашка с иконкой «стоп», висит по центру
 * НАД панелью ввода (position: fixed, как панель Accs). Появляется
 * ТОЛЬКО пока играет звук уведомления о сбросе 5-часового лимита
 * (монитор limit_alert.py запускает ffplay; состояние — поле playing
 * в GET /limit-reset-alert) и исчезает сама, когда звук закончился
 * или остановлен. Клик — POST /limit-reset-alert-stop.
 *
 * Почему кнопка живёт по состоянию, а не постоянно: останавливать
 * нечего почти всегда — окно сбрасывается раз в часы, и постоянная
 * кнопка обещала бы действие впустую. Отдельного TOML-ключа модулю
 * не нужно: пока не сыграет звук (который включает limitResetAlert),
 * он не делает ровно ничего.
 *
 * Вид плашки — в claude-custom.css (`.claude-limit-stop-float`),
 * иконка — SVG через createElementNS (Trusted Types, приём accsIcon).
 * Опрос раз в секунду — статус сервера, не DOM-scan: общий наблюдатель
 * (DOM WATCH) здесь ради пересчёта позиции, когда React пересоздал
 * панель ввода.
 * ============================================================ */
(function () {
  if (window.__claudeLimitStopInstalled) return;
  window.__claudeLimitStopInstalled = true;

  var STATUS_URL = 'http://localhost:18923/limit-reset-alert';
  var STOP_URL = 'http://localhost:18923/limit-reset-alert-stop';
  var BTN_CLASS = 'claude-limit-stop-float';
  var POLL_MS = 1000;
  // Три промаха подряд считаются «не играет»: сервер, который не
  // отвечает, звуком не управляет, и плашка убирается до лучших
  // времён, а не висит мёртвой.
  var FAIL_TOLERANCE = 3;

  var playing = false;
  var fails = 0;
  var btn = null; // плашка одна на окно, над панелью активной вкладки

  function stopIcon() {
    var NS = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(NS, 'svg');
    // Размер иконки задаёт CSS (.claude-limit-stop-float svg):
    // правка горячая и не требует Reload Window даже окнам со
    // старым JS — CSS перебивает презентационные атрибуты.
    svg.setAttribute('viewBox', '0 0 16 16');
    var rect = document.createElementNS(NS, 'rect');
    rect.setAttribute('x', '4');
    rect.setAttribute('y', '4');
    rect.setAttribute('width', '8');
    rect.setAttribute('height', '8');
    rect.setAttribute('rx', '1.5');
    rect.setAttribute('fill', 'currentColor');
    svg.appendChild(rect);
    return svg;
  }

  function inputContainer() {
    // Самый нижний видимый контейнер поля ввода — панель активной
    // вкладки. Полей ввода бывает несколько (правая панель, вкладки),
    // плашка одна и должна висеть над тем, что сейчас перед глазами.
    var all = document.querySelectorAll('[class*="inputContainer_"]');
    var best = null;
    var bestBottom = 0;
    for (var i = 0; i < all.length; i++) {
      var r = all[i].getBoundingClientRect();
      if (r && r.height > 0 && r.bottom > bestBottom) {
        best = all[i];
        bestBottom = r.bottom;
      }
    }
    return best;
  }

  function position() {
    if (!btn) return;
    var c = inputContainer();
    if (!c) return;
    var r = c.getBoundingClientRect();
    // Центр панели по горизонтали (translateX(-50%) в CSS доворачивает
    // плашку серединой к точке), снизу — чуть выше верхнего края.
    btn.style.bottom = Math.max(8, window.innerHeight - r.top + 10) + 'px';
    btn.style.left = (r.left + r.width / 2) + 'px';
  }

  function mount() {
    if (btn) {
      position();
      return;
    }
    btn = document.createElement('button');
    btn.type = 'button';
    btn.className = BTN_CLASS;
    btn.__claudeOwnNode = true;
    btn.title = 'Остановить звук уведомления о сбросе лимита';
    btn.appendChild(stopIcon());
    btn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      // Не ждём следующего опроса: звук гасится сейчас — плашка
      // должна уйти сразу, а не через секунду.
      fetch(STOP_URL, { method: 'POST' })
        .then(poll)
        .catch(poll);
    });
    document.body.appendChild(btn);
    position();
  }

  function unmount() {
    if (btn && btn.parentNode) btn.parentNode.removeChild(btn);
    btn = null;
  }

  function scan() {
    // Общий наблюдатель (DOM WATCH) зовёт скан на мутации — панель
    // ввода могла пересоздаться, плашка должна остаться над ней.
    if (playing) mount();
    else unmount();
  }

  function poll() {
    fetch(STATUS_URL)
      .then(function (r) { return r.json(); })
      .then(function (d) {
        fails = 0;
        var now = !!(d && d.playing);
        if (now !== playing) {
          playing = now;
          scan();
        } else if (now) {
          // Панель ввода могла переехать (смена вкладки, ресайз) —
          // пересчёт дешевле, чем промахнувшаяся плашка.
          position();
        }
      })
      .catch(function () {
        fails++;
        if (fails >= FAIL_TOLERANCE && playing) {
          playing = false;
          scan();
        }
      });
  }

  function init() {
    window.__claudeDomWatch.register('limit-stop', scan);
    window.addEventListener('resize', position);
    setInterval(poll, POLL_MS);
    poll();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * MOOD GAUGE
 *
 * Индикатор «Mood» в футере поля ввода, слева от кнопки Accs.
 * Полукруглая шкала из четырёх равных секторов — красный, оранжевый,
 * жёлтый, зелёный — и стрелка поверх неё: 0 указывает в начало
 * красного (влево), 100 — в конец зелёного (вправо).
 *
 * ЧТО ИЗМЕРЯЕТ. Частоту ранних промахов: интервал между записями
 * короче настроенного TTL провайдера. Более поздние промахи не ухудшают
 * эту составляющую Mood. Причину промаха такой порог не устанавливает.
 * Считается доля ранних промахов: ни одного — зелёная зона, потери
 * изредка — жёлтая, каждый третий-второй ход — оранжевая, кэш не
 * доживает почти никогда — красная.
 *
 * Доля, а не счёт: в длинной сессии три потери на сотню ходов и три
 * подряд на четыре хода — совершенно разные истории, а по одному
 * счётчику неразличимы.
 *
 * ВТОРОЙ ФАКТОР — раскрывалось ли контекстное окно. Сессия, где
 * контекст хотя бы раз поднимался выше `moodContextGoal`, сдвигает
 * стрелку к зелёному, а та, что так и не дотянула, — к красному.
 * Это поправка к основной метрике, а не отдельная шкала: сдвиг
 * фиксированный, порядка половины сектора. Пока ходов меньше
 * MIN_CHANCES, фактор не применяется вовсе — окно свежей сессии
 * просто не успело вырасти, и штрафовать за это не за что.
 *
 * ПРИОРИТЕТ — результат последнего измеренного сжатия. Если оно
 * освободило меньше 50% максимального окна, стрелка остаётся в красной
 * зоне до следующего успешного сжатия. Незавершённый замер пропускаем.
 *
 * Данные — GET /cache-usage (тот же endpoint, что у кнопки Usage):
 * `early_misses` — ходы, потерявшие живой кэш, `early_chances` — ходы,
 * на которых он вообще мог сработать. Сравнение пауз с TTL делает
 * сервер: у него полная история промахов, а в `miss_log` для UI
 * приходит только хвост из двадцати последних.
 *
 * Значение можно поставить и вручную — `window.__claudeMood.set(0..100)`,
 * читается `.get()`; следующий опрос (`moodPollSec`) его перебьёт.
 * Это отладочный вход, а не способ показать что-то своё.
 *
 * Не кнопка: кликов не принимает и курсор не меняет. Поэтому класс
 * штатной footerButton_ не заимствуется (в отличие от Accs и Usage) —
 * hover-подсветка на неинтерактивном элементе обещала бы действие,
 * которого нет.
 *
 * Цвета секторов, толщина дуги и размер живут в claude-custom.css
 * (`.claude-mood-arc-1..4`), а не в атрибутах SVG: CSS перечитывается
 * горячо, поэтому палитру можно править без Reload Window.
 *
 * Управление: `moodGauge` в claude-custom-config.toml.
 * ============================================================ */
(function () {
  if (window.__claudeMoodGaugeInstalled) return;
  window.__claudeMoodGaugeInstalled = true;

  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  if (cfg.moodGauge !== true) return;

  var ROOT_CLASS = 'claude-mood';
  var NEEDLE_CLASS = 'claude-mood-needle';
  var NODATA_CLASS = 'claude-mood-nodata';

  var USAGE_URL = 'http://localhost:18923/cache-usage';
  var POLL_MS = (typeof cfg.moodPollSec === 'number' && cfg.moodPollSec > 0
    ? cfg.moodPollSec : 20) * 1000;

  // Сколько неудачных опросов подряд терпим, прежде чем признать, что
  // данных нет. Одиночный сбой (сервер перезапускается хуком, вкладка
  // только что открылась) не должен гасить шкалу: мигание серым
  // читалось бы как поломка индикатора.
  var FAIL_TOLERANCE = 3;

  // Позиция при нулевых потерях — середина зелёного сектора (75..100).
  // Не 100: стрелка, упёршаяся в край шкалы, выглядит сломанной.
  var VALUE_CLEAN = 94;

  // Диапазон, в котором живут все остальные исходы. Верх — почти
  // граница с зелёным: даже единственная потеря на сотню ходов
  // не должна выглядеть как «потерь нет». Низ — почти край красного,
  // это случай «кэш не доживает ни разу».
  var VALUE_LOSS_TOP = 74;
  var VALUE_LOSS_BOTTOM = 2;

  // Верхний предел с учётом поправки за контекст: у нулевых потерь
  // база и так почти у края, а прибавка не должна упирать стрелку
  // в самый конец шкалы.
  var VALUE_MAX = 98;

  // Минимальный знаменатель доли. Без него первая же потеря в начале
  // сессии давала бы «1 из 1» — сто процентов и красную зону, хотя
  // одна точка ещё ничего не говорит о том, как поведёт себя кэш
  // дальше. С ростом сессии ограничение перестаёт действовать само.
  // Этот же порог решает, созрела ли сессия для поправки за контекст.
  var MIN_CHANCES = 10;

  // Отметка, выше которой контекстное окно считается раскрывшимся.
  var CONTEXT_GOAL = typeof cfg.moodContextGoal === 'number'
    && cfg.moodContextGoal > 0 ? cfg.moodContextGoal : 250000;

  // Насколько поправка за контекст двигает стрелку — примерно
  // полсектора. Больше значило бы, что второй фактор перебивает
  // главный: потери кэша важнее того, докуда доросло окно.
  var CONTEXT_SHIFT = 12;

  // Геометрия в единицах viewBox. Центр шкалы внизу, дуга — верхняя
  // половина окружности радиуса R: 180° слева (значение 0) до 0°
  // справа (значение 100). Габариты viewBox с запасом на толщину дуги.
  var VIEW_W = 34;
  var VIEW_H = 20;
  var CX = 17;
  var CY = 17;
  var R = 13;
  var SECTORS = 4;

  // Стрелка не достаёт до дуги: на краях шкалы остриё иначе сливается
  // с сектором и перестаёт читаться.
  var NEEDLE_LEN = R - 2.2;
  var NEEDLE_HALF_W = 1.65;  // полуширина у основания
  var HUB_R = 2.1;

  // Значение общее для всех экземпляров: футеров в DOM столько,
  // сколько открытых полей ввода, и показывать в них разное было бы
  // враньём — метрика одна на окно.
  var value = VALUE_CLEAN;

  // До первого удачного опроса шкала показана серой: цветная шкала
  // с зелёной стрелкой утверждала бы «всё хорошо», хотя на деле мы
  // ещё ничего не знаем.
  var haveData = false;
  var fails = 0;
  var detail = 'данных ещё нет';

  function logInfo() {
    if (!cfg.logs) return;
    try {
      console.log.apply(console, ['[mood]'].concat([].slice.call(arguments)));
    } catch (e) {}
  }

  /* ---------- рисование ---------- */

  function round3(n) { return Math.round(n * 1000) / 1000; }

  /** Точка на дуге по углу в градусах (0° — справа, 180° — слева). */
  function polar(deg) {
    var rad = deg * Math.PI / 180;
    return { x: CX + R * Math.cos(rad), y: CY - R * Math.sin(rad) };
  }

  /**
   * Дуга i-го сектора. sweep=1 — по часовой стрелке на экране:
   * угол убывает, а ось Y в SVG направлена вниз.
   */
  function arcPath(i) {
    var step = 180 / SECTORS;
    var from = polar(180 - i * step);
    var to = polar(180 - (i + 1) * step);
    return 'M ' + round3(from.x) + ' ' + round3(from.y)
      + ' A ' + R + ' ' + R + ' 0 0 1 ' + round3(to.x) + ' ' + round3(to.y);
  }

  /**
   * SVG-шкала. Через createElementNS, а не innerHTML: SVG живёт
   * в своём namespace, а innerHTML упирается в Trusted Types
   * (тот же приём, что в accsIcon у ACCOUNT SWITCHER BUTTON).
   */
  function createSvg() {
    var NS = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 ' + VIEW_W + ' ' + VIEW_H);
    svg.setAttribute('fill', 'none');
    svg.setAttribute('class', 'claude-mood-svg');
    // Для скринридера шкала — декорация: значение и без неё есть
    // в title всего индикатора.
    svg.setAttribute('aria-hidden', 'true');

    for (var i = 0; i < SECTORS; i++) {
      var arc = document.createElementNS(NS, 'path');
      arc.setAttribute('d', arcPath(i));
      arc.setAttribute('class', 'claude-mood-arc claude-mood-arc-' + (i + 1));
      svg.appendChild(arc);
    }

    // Стрелка нарисована в положении «0» — остриём влево; значение
    // задаётся поворотом всей группы вокруг центра (см. applyTo).
    var needle = document.createElementNS(NS, 'g');
    needle.setAttribute('class', NEEDLE_CLASS);

    var pointer = document.createElementNS(NS, 'path');
    pointer.setAttribute('d',
      'M ' + round3(CX - NEEDLE_LEN) + ' ' + CY
      + ' L ' + CX + ' ' + round3(CY - NEEDLE_HALF_W)
      + ' L ' + CX + ' ' + round3(CY + NEEDLE_HALF_W) + ' Z');
    pointer.setAttribute('class', 'claude-mood-pointer');
    needle.appendChild(pointer);

    var hub = document.createElementNS(NS, 'circle');
    hub.setAttribute('cx', CX);
    hub.setAttribute('cy', CY);
    hub.setAttribute('r', HUB_R);
    hub.setAttribute('class', 'claude-mood-hub');
    needle.appendChild(hub);

    svg.appendChild(needle);
    return svg;
  }

  /**
   * Индикатор — кнопка, как Accs и Usage: заимствует класс штатной
   * `footerButton_`, поэтому размеры, шрифт и подсветка при наведении
   * достаются даром и совпадают с соседями.
   *
   * Раньше он был неинтерактивным `div`: обещать действие, которого
   * нет, было бы неправдой. Действие появилось — окно истории, —
   * и вид приведён в соответствие.
   */
  function createGauge(donor) {
    var root = document.createElement('button');
    root.type = 'button';
    var donorClass = claudeNativeButtonClasses(donor);
    root.className = donorClass
      ? donorClass + ' ' + ROOT_CLASS
      : ROOT_CLASS + ' ' + ROOT_CLASS + '-bare';
    root.appendChild(createSvg());
    var label = document.createElement('span');
    label.className = 'claude-mood-label';
    label.textContent = 'Mood';
    root.appendChild(label);
    // Без preventDefault фокус уходит из composer'а: пользователь
    // теряет позицию каретки просто посмотрев историю.
    root.addEventListener('mousedown', function (e) { e.preventDefault(); });
    root.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (panel) closePanel();
      else openPanel(root);
    });
    applyTo(root);
    return root;
  }

  /* ---------- значение ---------- */

  /** Ставит стрелку и подсказку одному экземпляру индикатора. */
  function applyTo(root) {
    var needle = root.querySelector('.' + NEEDLE_CLASS);
    if (needle) {
      // CSS-свойство transform, а не одноимённый атрибут SVG: только
      // по нему работает transition (см. .claude-mood-needle в CSS).
      needle.style.transform = 'rotate(' + round3(value * 180 / 100) + 'deg)';
    }
    if (haveData) root.classList.remove(NODATA_CLASS);
    else root.classList.add(NODATA_CLASS);
    // Подсказка многострочная: факторов несколько, и в одну строку
    // они склеивались бы в нечитаемую ленту.
    root.title = haveData
      ? 'Mood: ' + Math.round(value) + ' / 100\n' + detail
      : 'Mood: нет данных · ' + detail;
  }

  // Слушатели значения — сейчас это INPUT RING, красящий обводку поля
  // ввода. Подписка, а не опрос: значение меняется раз в moodPollSec,
  // и таймер у подписчика почти всегда заставал бы его прежним.
  var listeners = [];

  function notify() {
    for (var i = 0; i < listeners.length; i++) {
      // Падение подписчика не должно ронять обновление самой шкалы:
      // здесь мы уже посреди её отрисовки.
      try { listeners[i](); } catch (e) {}
    }
  }

  function applyAll() {
    var roots = document.querySelectorAll('.' + ROOT_CLASS);
    for (var i = 0; i < roots.length; i++) applyTo(roots[i]);
    notify();
  }

  window.__claudeMood = {
    /**
     * Ставит значение 0..100 вручную; выходящее за границы прижимается.
     * Отладочный вход: ближайший опрос перезапишет значение своим.
     */
    set: function (v) {
      var num = Number(v);
      if (!isFinite(num)) return value;
      value = Math.max(0, Math.min(100, num));
      haveData = true;
      detail = 'значение поставлено вручную';
      applyAll();
      logInfo('значение', value);
      return value;
    },
    get: function () { return value; },
    /**
     * Номер сектора шкалы под стрелкой: 0 — красный, 3 — зелёный.
     * null означает «данных ещё нет» — тот же случай, в котором сама
     * шкала обесцвечивается. Отдаём номер, а не цвет: палитра живёт
     * в CSS и правится горячо, а вторая её копия в JS разошлась бы
     * с первой на ближайшей правке.
     */
    level: function () {
      if (!haveData) return null;
      return Math.max(0, Math.min(SECTORS - 1, Math.floor(value / (100 / SECTORS))));
    },
    /** Подписка на смену значения; вызывается после отрисовки шкалы. */
    onChange: function (fn) {
      if (typeof fn === 'function') listeners.push(fn);
    },
    /** Внеочередной опрос — например после правки TTL в конфиге. */
    refresh: function () { tick(); },
  };

  /* ---------- метрика: ранние потери кэша ---------- */

  function sessionId() {
    // Резолвер регистрирует CACHE USAGE BUTTON — он же общая
    // зависимость кнопок Cache и ByPass. Без id сервер отдал бы самый
    // свежий транскрипт проекта, то есть чужую вкладку.
    var fn = window.__claudeSessionId;
    return typeof fn === 'function' ? fn() : null;
  }

  function plural(n, one, few, many) {
    var mod10 = n % 10;
    var mod100 = n % 100;
    if (mod10 === 1 && mod100 !== 11) return one;
    if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return few;
    return many;
  }

  function num(v) { return typeof v === 'number' && isFinite(v) ? v : null; }

  /** Последний полный замер; окно берём у события, а не у текущей модели. */
  function latestCompaction(history, until) {
    var latest = null;
    var latestTime = -Infinity;
    var cutoff = until == null ? Infinity : Date.parse(until);
    if (isNaN(cutoff)) return null;
    (history || []).forEach(function (ev) {
      if (ev.kind !== 'compact') return;
      var when = Date.parse(ev.ts);
      var before = num(ev.context_before);
      var after = num(ev.context_after);
      var windowSize = num(ev.context_window);
      if (!isFinite(when) || when > cutoff || when < latestTime
          || !(before > 0) || !(after > 0) || !(windowSize > 0)) return;
      latestTime = when;
      latest = {
        before: before, after: after, window: windowSize,
        reduction: before - after,
        failed: before - after < windowSize * 0.5,
      };
    });
    return latest;
  }

  /**
   * Ходы, потерявшие живой кэш, и ходы, на которых он мог сработать.
   *
   * Обычно оба числа приходят с сервера готовыми. Запасной путь —
   * пересчёт по `miss_log`: он нужен, пока в окне работает webview,
   * загруженный до обновления сервера. Там только двадцать последних
   * промахов, так что доля выйдет заниженной — но заниженная оценка
   * на несколько минут лучше серой шкалы.
   */
  function earlyStats(data) {
    var ttl = num(data.ttl_minutes) > 0 ? data.ttl_minutes : 60;
    var early = num(data.early_misses);
    var chances = num(data.early_chances);
    if (early === null || chances === null) {
      var log = data.miss_log || [];
      early = 0;
      for (var i = 0; i < log.length; i++) {
        var gap = num(log[i].gap);
        // Промах без разобранной метки времени пропускаем: неизвестную
        // паузу не с чем сравнить, а записать её в потери — соврать.
        if (gap !== null && gap < ttl) early++;
      }
      chances = Math.max((num(data.requests) || 1) - 1, 0);
    }
    return {
      early: early,
      chances: chances,
      ttl: ttl,
      // Пика может не быть у старого сервера — тогда поправку за
      // контекст просто не применяем (см. valueFor).
      peak: num(data.context_peak),
      compaction: latestCompaction(data.compactions || data.history),
    };
  }

  /**
   * Доля потерь → положение стрелки.
   *
   * Ноль потерь стоит особняком: это единственный случай, ради
   * которого держится зелёная зона, и попадать в неё «почти нулевой»
   * доле нельзя — иначе зелёный перестанет что-либо гарантировать.
   * Всё остальное раскладывается линейно от верха жёлтого (потери
   * единичны) до низа красного (кэш не доживает ни разу).
   */
  function shareOf(early, chances) {
    return Math.min(early / Math.max(chances, MIN_CHANCES), 1);
  }

  function valueFor(st) {
    // Результат сжатия важнее хорошего кэша и бонуса за пик контекста.
    if (st.compaction && st.compaction.failed) return 12.5;
    var base;
    if (st.early <= 0) {
      base = VALUE_CLEAN;
    } else {
      var share = shareOf(st.early, st.chances);
      base = VALUE_LOSS_BOTTOM
        + (VALUE_LOSS_TOP - VALUE_LOSS_BOTTOM) * (1 - share);
    }
    base += contextShift(st);
    return Math.max(VALUE_LOSS_BOTTOM, Math.min(VALUE_MAX, base));
  }

  /**
   * Поправка за контекстное окно: раскрывшееся выше CONTEXT_GOAL
   * тянет стрелку к зелёному, так и не доросшее — к красному.
   *
   * Молодая сессия поправку не получает ни в какую сторону: окно
   * там маленькое просто потому, что разговор только начался, и
   * штраф за это говорил бы о темпе работы, а не о кэше. Порог
   * зрелости — тот же MIN_CHANCES, что и у доли потерь.
   */
  function contextShift(st) {
    if (st.peak === null || st.chances < MIN_CHANCES) return 0;
    return st.peak >= CONTEXT_GOAL ? CONTEXT_SHIFT : -CONTEXT_SHIFT;
  }

  /** Токены человеку: 250000 → «250k». */
  function tokens(n) {
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1000) return Math.round(n / 1000) + 'k';
    return String(Math.round(n));
  }

  /**
   * Расшифровка для подсказки — по строке на фактор, чтобы было
   * видно, откуда взялось положение стрелки.
   */
  function describe(st) {
    // Формулировка про кэш безличная: «N ходов потеряли» ломалось бы
    // на единице, а «потерян» — на нуле.
    var lines = [st.early === 0
      ? 'живой кэш не терялся ни разу · TTL ' + st.ttl + ' мин'
      : 'живой кэш терялся на ' + st.early + ' из ' + st.chances + ' '
        + plural(st.chances, 'хода', 'ходов', 'ходов')
        + ' · ' + Math.round(shareOf(st.early, st.chances) * 100)
        + '% · TTL ' + st.ttl + ' мин'];

    if (st.peak !== null) {
      var peak = 'пик контекста ' + tokens(st.peak);
      if (st.chances < MIN_CHANCES) {
        lines.push(peak + ' — сессия ещё короткая, в счёт не идёт');
      } else if (st.peak >= CONTEXT_GOAL) {
        lines.push(peak + ' — окно раскрывалось выше '
          + tokens(CONTEXT_GOAL) + ', плюс к оценке');
      } else {
        lines.push(peak + ' — окно не дотянуло до '
          + tokens(CONTEXT_GOAL) + ', минус к оценке');
      }
    }
    if (st.compaction) {
      var c = st.compaction;
      lines.push('последнее сжатие: ' + c.before.toLocaleString('ru-RU')
        + ' → ' + c.after.toLocaleString('ru-RU') + ' токенов');
      lines.push('уменьшение ' + c.reduction.toLocaleString('ru-RU')
        + ' / требуется минимум ' + (c.window * 0.5).toLocaleString('ru-RU')
        + ' (50% окна)' + (c.failed ? ' — красная зона' : ' — норма'));
    }
    return lines.join('\n');
  }

  function onFail(reason) {
    fails++;
    if (fails < FAIL_TOLERANCE) return;
    if (haveData || detail !== reason) {
      haveData = false;
      detail = reason;
      applyAll();
      logInfo('данных нет:', reason);
    }
  }

  function tick() {
    var sid = sessionId();
    if (!sid) {
      onFail('сессия ещё не определилась');
      return;
    }
    fetch(USAGE_URL + '?session=' + encodeURIComponent(sid), { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.ok) {
          onFail((d && d.error) || 'сервер не отдал статистику');
          return;
        }
        var st = earlyStats(d);
        fails = 0;
        haveData = true;
        value = valueFor(st);
        detail = describe(st);
        applyAll();
      })
      .catch(function () { onFail('сервер недоступен'); });
  }


  /* ---------- окно истории ---------- */

  /**
   * История шкалы за сессию — по клику на индикаторе, как у Accs
   * и Usage: та же панель, то же закрытие по клику мимо и Escape.
   *
   * История не копится в браузере, а приходит с сервера: он строит её
   * пересчётом уже разобранного транскрипта (GET /mood-history), и
   * потому она полна с первого хода сессии — включая ходы, сделанные
   * до появления самого окна.
   *
   * Значение каждой точки считает `valueFor` — та же функция, что
   * ставит стрелку. Второй копии формулы нет намеренно: разойдясь
   * однажды, кривая и стрелка рассказывали бы об одном ходе разное,
   * и объяснить расхождение было бы нечем.
   */
  var HISTORY_URL = 'http://localhost:18923/mood-history';
  var PANEL_ID = 'claude-mood-panel';

  // Габариты графика в единицах viewBox. Ширина с запасом под подписи
  // слева: значения шкалы (0..100) и без них читались бы, но тогда
  // непонятно, где границы зон.
  var CH_W = 420;
  var CH_H = 150;
  var CH_PAD_L = 26;
  var CH_PAD_R = 6;
  var CH_PAD_T = 6;
  var CH_PAD_B = 16;

  var panel = null;

  function closePanel() {
    if (!panel) return;
    if (panel.parentNode) panel.parentNode.removeChild(panel);
    panel = null;
    document.removeEventListener('mousedown', onOutside, true);
    document.removeEventListener('keydown', onKeydown, true);
  }

  function onOutside(e) {
    if (!panel) return;
    if (panel.contains(e.target)) return;
    // Клик по самому индикатору обрабатывает его собственный
    // listener — иначе панель закрылась бы здесь и тут же открылась.
    if (e.target.closest && e.target.closest('.' + ROOT_CLASS)) return;
    closePanel();
  }

  function onKeydown(e) {
    if (e.key !== 'Escape') return;
    e.preventDefault();
    closePanel();
  }

  function positionPanel(btn) {
    if (!panel) return;
    // Футер прижат к низу окна — раскрываемся вверх от кнопки.
    var r = btn.getBoundingClientRect();
    panel.style.bottom = Math.max(8, window.innerHeight - r.top + 6) + 'px';
    panel.style.left = Math.max(8, r.left) + 'px';
  }

  function svgEl(name, attrs) {
    var el = document.createElementNS('http://www.w3.org/2000/svg', name);
    for (var k in attrs) {
      if (attrs.hasOwnProperty(k)) el.setAttribute(k, attrs[k]);
    }
    return el;
  }

  /** Точка ряда → значение шкалы тем же кодом, что и у стрелки. */
  function valueOfPoint(p, history) {
    return valueFor({
      early: num(p.early_misses) || 0,
      chances: num(p.early_chances) || 0,
      peak: num(p.context_peak),
      compaction: latestCompaction(history, p.ts),
    });
  }

  /**
   * График значения по ходам.
   *
   * Фон — те же четыре зоны, что у самой шкалы: без них кривая
   * читалась бы как абстрактные числа, а вопрос всегда один — в какой
   * зоне сессия шла и когда из неё вышла.
   *
   * По оси X — номер хода, а не время: паузы между ходами бывают
   * часами, и на временной оси вся работа сжалась бы в несколько
   * пятен. Время остаётся в подписи под графиком и в подсказке точки.
   */
  function chart(series, history) {
    var svg = svgEl('svg', {
      viewBox: '0 0 ' + CH_W + ' ' + CH_H,
      width: '100%',
      height: CH_H,
      preserveAspectRatio: 'none',
    });
    svg.setAttribute('class', 'claude-mood-chart');

    var x0 = CH_PAD_L;
    var y0 = CH_PAD_T;
    var w = CH_W - CH_PAD_L - CH_PAD_R;
    var h = CH_H - CH_PAD_T - CH_PAD_B;

    // Зоны: снизу вверх красная, оранжевая, жёлтая, зелёная.
    var zones = ['claude-mood-zone-1', 'claude-mood-zone-2',
      'claude-mood-zone-3', 'claude-mood-zone-4'];
    for (var z = 0; z < zones.length; z++) {
      svg.appendChild(svgEl('rect', {
        x: x0, width: w,
        y: y0 + h * (1 - (z + 1) / 4), height: h / 4,
        class: zones[z],
      }));
    }

    // Подписи границ зон — 0, 25, 50, 75, 100.
    for (var v = 0; v <= 100; v += 25) {
      var y = y0 + h * (1 - v / 100);
      svg.appendChild(svgEl('line', {
        x1: x0, x2: x0 + w, y1: y, y2: y, class: 'claude-mood-grid',
      }));
      var t = svgEl('text', {
        x: x0 - 4, y: y + 3, class: 'claude-mood-axis',
        'text-anchor': 'end',
      });
      t.textContent = String(v);
      svg.appendChild(t);
    }

    if (!series.length) return svg;

    // Кривая. Один ход — одна точка; при сотнях ходов линия и так
    // сплошная, поэтому маркеры не рисуем: они слились бы в кашу.
    var pts = [];
    for (var i = 0; i < series.length; i++) {
      var px = x0 + (series.length === 1 ? w / 2 : w * i / (series.length - 1));
      var py = y0 + h * (1 - valueOfPoint(series[i], history) / 100);
      pts.push(round3(px) + ',' + round3(py));
    }
    svg.appendChild(svgEl('polyline', {
      points: pts.join(' '), class: 'claude-mood-line',
    }));

    // Последняя точка — текущее положение стрелки. Её помечаем: глаз
    // должен находить «где мы сейчас» без пересчёта.
    var last = pts[pts.length - 1].split(',');
    svg.appendChild(svgEl('circle', {
      cx: last[0], cy: last[1], r: 3, class: 'claude-mood-dot',
    }));
    return svg;
  }

  /** Короткая сводка под графиком. */
  function summary(data) {
    var series = data.series || [];
    var box = document.createElement('div');
    box.className = 'claude-mood-summary';

    var last = series.length ? series[series.length - 1] : null;
    var first = series.length ? series[0] : null;
    var rows = [];
    if (last) {
      rows.push(['сейчас', Math.round(valueOfPoint(last, data.compactions || data.history)) + ' / 100']);
      rows.push(['ходов в сессии', String(series.length)]);
      rows.push(['потерь живого кэша',
        last.early_misses + ' из ' + last.early_chances]);
      rows.push(['пик контекста', tokens(last.context_peak)]);
      if (first && first.ts && last.ts) {
        rows.push(['период', first.ts.slice(11, 16) + ' — ' + last.ts.slice(11, 16)]);
      }
    }
    rows.push(['TTL кэша', (num(data.ttl_minutes) || 60) + ' мин']);

    for (var i = 0; i < rows.length; i++) {
      var line = document.createElement('div');
      line.className = 'claude-mood-summary-row';
      var k = document.createElement('span');
      k.textContent = rows[i][0];
      var v = document.createElement('span');
      v.className = 'claude-mood-summary-val';
      v.textContent = rows[i][1];
      line.appendChild(k);
      line.appendChild(v);
      box.appendChild(line);
    }
    return box;
  }

  function renderError(body, text) {
    var div = document.createElement('div');
    div.className = 'claude-mood-empty';
    div.textContent = text;
    body.appendChild(div);
  }

  function openPanel(btn) {
    closePanel();

    panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.className = 'claude-mood-panel';

    var head = document.createElement('div');
    head.className = 'claude-mood-head';
    head.textContent = 'История Mood за сессию';
    panel.appendChild(head);

    var body = document.createElement('div');
    body.className = 'claude-mood-body';
    body.textContent = 'загрузка…';
    panel.appendChild(body);
    document.body.appendChild(panel);
    positionPanel(btn);

    document.addEventListener('mousedown', onOutside, true);
    document.addEventListener('keydown', onKeydown, true);

    var sid = sessionId();
    fetch(HISTORY_URL + (sid ? '?session=' + encodeURIComponent(sid) : ''),
          { cache: 'no-store' })
      .then(function (res) { return res.json(); })
      .then(function (d) {
        if (!panel) return;
        body.textContent = '';
        if (!d || !d.ok) {
          renderError(body, (d && d.error) || 'нет данных');
        } else if (!(d.series || []).length) {
          renderError(body, 'в сессии ещё нет ходов');
        } else {
          body.appendChild(chart(d.series, d.compactions || d.history));
          body.appendChild(summary(d));
        }
        positionPanel(btn);
      })
      .catch(function (err) {
        if (!panel) return;
        body.textContent = '';
        renderError(body, 'http-server.py недоступен (порт 18923)');
        logInfo('история недоступна', err);
      });
  }

  /* ---------- монтирование ---------- */

  /** Самый левый из наших контролов футера — перед ним и встаём. */
  function leftmostNeighbour(footer) {
    var sel = ['.claude-accs-btn', '.claude-usage-btn',
      '.claude-cache-btn', '.claude-bypass-btn'];
    for (var i = 0; i < sel.length; i++) {
      var el = footer.querySelector(sel[i]);
      if (el && el.parentNode === footer) return el;
    }
    return null;
  }

  function mount(container) {
    var footer = container.querySelector('[class*="inputFooter_"]');
    if (!footer) return false;
    var gauge = createGauge(footer.querySelector('[class*="footerButton_"]'));
    // Порядок в футере: Mood · Accs · Usage · Cache · ByPass.
    // Опираемся на соседа, а не на порядок инициализации модулей:
    // React пересоздаёт футер, и кто смонтируется первым — не
    // гарантировано (та же логика, что в ACCOUNT SWITCHER BUTTON).
    var neighbour = leftmostNeighbour(footer);
    if (neighbour) {
      footer.insertBefore(gauge, neighbour);
    } else {
      var spacer = footer.querySelector('[class*="spacer_"]');
      if (spacer && spacer.parentNode === footer) {
        footer.insertBefore(gauge, spacer.nextSibling);
      } else {
        footer.appendChild(gauge);
      }
    }
    return true;
  }

  /**
   * Держит Mood левее соседей, даже если те смонтировались позже.
   * Вставка при монтировании этого не гарантирует — см. ensureOrder
   * в ACCOUNT SWITCHER BUTTON.
   */
  function ensureOrder(footer) {
    var me = footer.querySelector('.' + ROOT_CLASS);
    if (!me || me.parentNode !== footer) return;
    var right = leftmostNeighbour(footer);
    if (!right) return;
    // DOCUMENT_POSITION_FOLLOWING — сосед идёт ПОСЛЕ нас, всё верно.
    if (me !== right && !(me.compareDocumentPosition(right) & 4)) {
      footer.insertBefore(me, right);
      logInfo('порядок восстановлен: Mood перед соседями');
    }
  }

  function scan(ctx) {
    // Узлы даёт общий обход (см. DOM WATCH) — один на все модули.
    // Свой поиск остаётся для вызовов вне прохода: при регистрации
    // и из обработчиков самого модуля.
    var containers = (ctx && ctx.inputs)
      || document.querySelectorAll('[class*="inputContainer_"]');
    for (var i = 0; i < containers.length; i++) {
      var footer = containers[i].querySelector('[class*="inputFooter_"]');
      if (containers[i].querySelector('.' + ROOT_CLASS)) {
        if (footer) ensureOrder(footer);
        continue;
      }
      if (!containers[i].querySelector('[role="textbox"][contenteditable]')) continue;
      mount(containers[i]);
    }
  }

  function init() {
    // Наблюдатель и подстраховочный таймер — общие (см. DOM WATCH).
    window.__claudeDomWatch.register('mood', scan);
    // Первый опрос сразу: до него шкала серая, и задержка на целый
    // период читалась бы как «индикатор не работает».
    tick();
    setInterval(tick, POLL_MS);
    logInfo('installed, опрос раз в', POLL_MS / 1000, 'с');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * INPUT RING — обводка поля ввода цветом индикатора Mood
 *
 * Расширение окрашивает рамку поля ввода при фокусе по режиму
 * разрешений: оранжевый — обычный, синий — план, красный — bypass.
 * Модуль умеет заменить этот признак другим — цветом сектора, в
 * который сейчас смотрит стрелка Mood.
 *
 * Зачем: индикатор в футере занимает 27×16 точек, а рамка обрамляет
 * всё поле ввода — то место, куда смотришь, когда пишешь сообщение.
 * Состояние кэша при этом замечаешь, не отводя взгляда.
 *
 * КАК. Цвет рамки расширение держит в переменной --focus-ring-color
 * и меняет её правилами по `data-permission-mode`. Мы подменяем ту же
 * переменную: border-color, box-shadow и всё остальное расширение
 * выведет из неё само. Свои правила про саму рамку разошлись бы с
 * оригиналом на первом же обновлении расширения.
 *
 * Модуль ставит только класс и номер сектора (0..3) атрибутом —
 * цвета живут в CSS рядом с секторами шкалы, откуда и взяты.
 * О палитре JS не знает ничего, как и в самом MOOD GAUGE.
 *
 * Значение берётся у него же через `window.__claudeMood.level()`, а
 * обновления приходят подпиской: опрос своим таймером почти всегда
 * заставал бы значение прежним — оно меняется раз в moodPollSec.
 * Выключенный moodGauge не публикует этот объект вовсе, и тогда
 * красить нечем: рамка остаётся штатной.
 *
 * «Данных ещё нет» (сессия не определилась, сервер молчит) — тоже
 * штатная рамка, а не зелёная: шкала в этот момент обесцвечивается
 * ровно потому, что утверждать «всё хорошо» ещё рано.
 *
 * Управление: `inputRingColor` в claude-custom-config.toml. Параметр
 * горячий — опрашивается через /custom-config, как cacheKeepalive*.
 * ============================================================ */
(function () {
  if (window.__claudeInputRingInstalled) return;
  window.__claudeInputRingInstalled = true;

  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};

  var RING_CLASS = 'claude-ring-mood';
  var LEVEL_ATTR = 'data-claude-mood-level';

  var CONFIG_URL = 'http://localhost:18923/custom-config';
  var CONFIG_POLL_MS = 5000;

  // "mood" — красить по индикатору, всё остальное — не вмешиваться.
  // Незнакомое значение трактуется как штатное поведение: это
  // безопасная сторона, рамка остаётся такой, какой её задумало
  // расширение.
  var mode = cfg.inputRingColor === 'mood' ? 'mood' : 'mode';

  function logInfo() {
    if (!cfg.logs) return;
    try {
      console.log.apply(console, ['[input-ring]'].concat([].slice.call(arguments)));
    } catch (e) {}
  }

  /** Сектор шкалы под стрелкой либо null, если красить не по чему. */
  function currentLevel() {
    if (mode !== 'mood') return null;
    var api = window.__claudeMood;
    if (!api || typeof api.level !== 'function') return null;
    return api.level();
  }

  function applyTo(el, level) {
    if (level === null) {
      if (el.classList.contains(RING_CLASS)) {
        el.classList.remove(RING_CLASS);
        el.removeAttribute(LEVEL_ATTR);
      }
      return;
    }
    // Пишем только при изменении: присваивание мутирует DOM даже когда
    // значение то же, а каждая мутация будит общий наблюдатель — то
    // самое, из-за чего debug-оверлей однажды будил патч сам собой.
    var text = String(level);
    if (el.getAttribute(LEVEL_ATTR) !== text) el.setAttribute(LEVEL_ATTR, text);
    if (!el.classList.contains(RING_CLASS)) el.classList.add(RING_CLASS);
  }

  function scan(ctx) {
    // Узлы даёт общий обход (см. DOM WATCH); свой поиск — для вызовов
    // вне прохода: при регистрации и из подписки на значение Mood.
    var containers = (ctx && ctx.inputs)
      || document.querySelectorAll('[class*="inputContainer_"]');
    var level = currentLevel();
    for (var i = 0; i < containers.length; i++) {
      // Рамку рисует тот из двух контейнеров, которому расширение
      // ставит режим разрешений; внешний — только позиционирование,
      // и переменная на нём ничего бы не изменила: у внутреннего
      // при фокусе своё правило, оно перебило бы унаследованное.
      if (!containers[i].hasAttribute('data-permission-mode')) continue;
      applyTo(containers[i], level);
    }
  }

  function applyLiveConfig(c) {
    if (!c || typeof c !== 'object') return;
    var next = c.inputRingColor === 'mood' ? 'mood' : 'mode';
    if (next === mode) return;
    mode = next;
    logInfo('режим обводки:', mode);
    // Сразу, не дожидаясь ближайшей мутации: смена настройки — это
    // действие пользователя, и отклик на него должен быть виден.
    scan();
  }

  function pollConfig() {
    fetch(CONFIG_URL, { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (d) { if (d && d.ok) applyLiveConfig(d.config); })
      .catch(function () {});
  }

  function init() {
    // Наблюдатель и подстраховочный таймер — общие (см. DOM WATCH).
    // Якорный класс `inputContainer_` уже в RELEVANT, отдельной
    // записи фильтру не нужно.
    window.__claudeDomWatch.register('input-ring', scan);
    var api = window.__claudeMood;
    if (api && typeof api.onChange === 'function') api.onChange(scan);
    else logInfo('индикатор Mood выключен — обводка остаётся штатной');
    pollConfig();
    setInterval(pollConfig, CONFIG_POLL_MS);
    logInfo('installed, режим обводки:', mode);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * SETTINGS PANEL — окно настроек из контекстного меню
 *
 * Открывается пунктом «⚙ Настройки» контекстного меню страницы и
 * правит `claude-custom-config.toml` — тот же файл, что и рука.
 *
 * Путь до окна длиннее обычного, и это не прихоть: меню по правой
 * кнопке рисует оболочка VSCode, а не страница. Поэтому пункт
 * объявлен в манифесте расширения (patch-extension-settings.py),
 * страница помечена атрибутом `data-vscode-context`, команду ловит
 * блок в extension.js (patch-extension-csp.py), и он же шлёт сюда
 * postMessage. Здесь — последнее звено: показать окно.
 *
 * Список параметров и подсказки приходят с сервера
 * (`GET /config-schema`), а подсказки — это комментарии из самого
 * TOML. Описывать флаги второй раз здесь значило бы завести два
 * источника правды о том, что они делают, и они разошлись бы на
 * первой же правке файла.
 *
 * Модуль не имеет своего выключателя в конфиге намеренно: выключив
 * его, пользователь остался бы без единственного окна, из которого
 * флаги и включаются обратно.
 * ============================================================ */
(function () {
  if (window.__claudeSettingsPanelInstalled) return;
  window.__claudeSettingsPanelInstalled = true;

  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  var SCHEMA_URL = 'http://localhost:18923/config-schema';
  var SAVE_URL = 'http://localhost:18923/custom-config';
  var PANEL_ID = 'claude-settings-panel';

  var panel = null;
  var items = [];       // описания с сервера
  var controls = {};    // ключ → функция чтения текущего значения из UI

  function logInfo() {
    if (!cfg.logs) return;
    try {
      console.log.apply(console, ['[settings-panel]'].concat([].slice.call(arguments)));
    } catch (e) {}
  }

  /** Первая строка подсказки — она же заголовок параметра в списке. */
  function firstLine(text) {
    var line = String(text || '').split('\n')[0].trim();
    return line;
  }

  function closePanel() {
    if (!panel) return;
    if (panel.parentNode) panel.parentNode.removeChild(panel);
    panel = null;
    controls = {};
    document.removeEventListener('keydown', onKeydown, true);
  }

  function onKeydown(e) {
    if (e.key !== 'Escape') return;
    // Окно перекрывает страницу целиком, поэтому Escape закрывает его
    // и не должен уходить дальше — иначе заодно снимет выделение или
    // закроет что-то за ним.
    e.preventDefault();
    e.stopPropagation();
    closePanel();
  }

  /* ---------- элементы управления ---------- */

  /**
   * Строка параметра. Тип решает вид: булев — переключатель, строка
   * с перечнем значений — список, остальное — поле ввода. Ключ
   * показывается как есть: он же стоит в TOML, и по нему пользователь
   * найдёт параметр в файле.
   */
  function paramRow(item) {
    var row = document.createElement('div');
    row.className = 'claude-settings-row';

    var left = document.createElement('div');
    left.className = 'claude-settings-name';

    var key = document.createElement('div');
    key.className = 'claude-settings-key';
    key.textContent = item.key;
    left.appendChild(key);

    var hint = firstLine(item.hint);
    if (hint) {
      var sub = document.createElement('div');
      sub.className = 'claude-settings-hint';
      sub.textContent = hint;
      // Полный текст — в подсказке при наведении: у некоторых
      // параметров это несколько абзацев с историей поломки, и
      // разворачивать их в списке из тридцати строк нечитаемо.
      if (item.hint && item.hint !== hint) sub.title = item.hint;
      left.appendChild(sub);
    }
    row.appendChild(left);

    var wrap = document.createElement('div');
    wrap.className = 'claude-settings-control';

    if (item.type === 'bool') {
      var box = document.createElement('input');
      box.type = 'checkbox';
      box.checked = !!item.value;
      box.className = 'claude-settings-check';
      wrap.appendChild(box);
      controls[item.key] = function () { return box.checked; };
    } else if (item.options && item.options.length) {
      // Перечень значений сервер достаёт из строки `Варианты: a | b`
      // в комментарии параметра. Список, а не поле ввода: значение вне
      // перечня модуль не поймёт и молча откатится на своё поведение —
      // настройка выглядела бы заданной, ничего не делая.
      var select = document.createElement('select');
      select.className = 'claude-settings-select';
      for (var oi = 0; oi < item.options.length; oi++) {
        var opt = document.createElement('option');
        opt.value = item.options[oi];
        opt.textContent = item.options[oi];
        select.appendChild(opt);
      }
      select.value = String(item.value);
      wrap.appendChild(select);
      controls[item.key] = function () { return select.value; };
    } else {
      var input = document.createElement('input');
      input.type = item.type === 'number' ? 'number' : 'text';
      input.value = String(item.value);
      input.className = 'claude-settings-input';
      wrap.appendChild(input);
      controls[item.key] = function () {
        if (item.type !== 'number') return input.value;
        var num = Number(input.value);
        // Нечисло в числовом поле не отправляем: сервер записал бы его
        // строкой, и параметр молча перестал бы действовать.
        return isFinite(num) ? num : item.value;
      };
    }
    row.appendChild(wrap);
    return row;
  }

  /* ---------- сохранение ---------- */

  function changedValues() {
    var out = {};
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var read = controls[item.key];
      if (!read) continue;
      var now = read();
      if (now !== item.value) out[item.key] = now;
    }
    return out;
  }

  function save(status, button) {
    var values = changedValues();
    var keys = Object.keys(values);
    if (!keys.length) {
      setStatus(status, 'Менять нечего — значения те же.', '');
      return;
    }
    button.disabled = true;
    setStatus(status, 'Сохраняю…', 'wait');
    fetch(SAVE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ values: values }),
    })
      .then(function (res) { return res.json(); })
      .then(function (d) {
        button.disabled = false;
        if (!d || !d.ok) throw new Error((d && d.error) || 'сервер отказал');
        // Запоминаем новые значения как исходные, иначе повторное
        // нажатие отправило бы те же правки ещё раз.
        for (var i = 0; i < items.length; i++) {
          if (items[i].key in values) items[i].value = values[items[i].key];
        }
        // Честно про момент применения: CSS подхватывается горячо,
        // а флаги модулей живут в bootstrap, который перечитывается
        // только при перезагрузке окна.
        setStatus(status,
          'Сохранено (' + keys.length + '): ' + keys.join(', ')
          + '. Флаги модулей применятся после Developer: Reload Window.',
          'ok');
        logInfo('сохранено', values);
      })
      .catch(function (err) {
        button.disabled = false;
        setStatus(status, 'Не удалось сохранить: '
          + ((err && err.message) || err), 'err');
      });
  }

  function setStatus(el, text, kind) {
    el.textContent = text;
    el.className = 'claude-settings-status'
      + (kind ? ' claude-settings-status-' + kind : '');
  }

  /* ---------- окно ---------- */

  function render(body, status) {
    body.textContent = '';
    var search = document.createElement('input');
    search.type = 'search';
    search.className = 'claude-settings-search';
    search.placeholder = 'Поиск по названию и описанию';
    body.appendChild(search);

    var list = document.createElement('div');
    list.className = 'claude-settings-list';
    body.appendChild(list);

    /* Раскладка по разделам. Разделы заданы в самом TOML строками
     * `# ==== Название ====` и приходят с сервера у каждого параметра —
     * поэтому новый флаг попадает в свой раздел сам, а человеку,
     * читающему файл руками, видна та же структура.
     *
     * Все свёрнуты при открытии: тридцать пять параметров подряд —
     * это стена, в которой ничего не найти, а свёрнутый список из
     * тринадцати заголовков обозрим целиком.
     *
     * `<details>` вместо своей раскрывашки: он умеет разворачиваться
     * без единой строки JS, доступен с клавиатуры и ищется штатным
     * Ctrl+F браузера. */
    var rows = [];
    var groups = [];
    var byName = {};
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var name = item.section || 'Прочее';
      var group = byName[name];
      if (!group) {
        var box = document.createElement('details');
        box.className = 'claude-settings-group';
        var summary = document.createElement('summary');
        summary.className = 'claude-settings-group-head';
        var label = document.createElement('span');
        label.textContent = name;
        summary.appendChild(label);
        var count = document.createElement('span');
        count.className = 'claude-settings-group-count';
        summary.appendChild(count);
        box.appendChild(summary);
        list.appendChild(box);
        group = byName[name] = { box: box, count: count, total: 0 };
        groups.push(group);
      }
      group.total++;
      var row = paramRow(item);
      rows.push({ row: row, item: item, group: group });
      group.box.appendChild(row);
    }
    for (var g = 0; g < groups.length; g++) {
      groups[g].count.textContent = String(groups[g].total);
    }

    /* Пометка о несохранённых правках.
     *
     * «Отмена» и крестик закрывают окно, ничего не записывая, — и это
     * правильно, но молча потерять десяток переключённых флагов
     * обидно. Поэтому строка статуса говорит, что правки есть и они
     * пока только в окне.
     *
     * Слушатель один на весь список (события всплывают), а не по
     * одному на каждый из тридцати пяти элементов управления. */
    list.addEventListener('input', markDirty, true);
    list.addEventListener('change', markDirty, true);

    function markDirty() {
      var pending = Object.keys(changedValues()).length;
      if (!pending) {
        setStatus(status, '', '');
        return;
      }
      setStatus(status, 'Не сохранено: ' + pending + ' '
        + (pending === 1 ? 'изменение' : 'изменений')
        + ' — «Отмена» их отбросит.', 'wait');
    }

    /* Поиск по ключу и по описанию: половину параметров помнишь не по
     * имени, а по тому, что они делают.
     *
     * Найденное показывается сразу: раздел с совпадениями
     * разворачивается сам, а пустой прячется целиком. Иначе поиск в
     * свёрнутом списке выглядел бы как «ничего не найдено» — совпадения
     * есть, но спрятаны за закрытым заголовком.
     *
     * При очистке строки поиска разделы снова сворачиваются: это
     * исходное состояние окна, и оставлять после поиска развёрнутую
     * стену значило бы менять его молча. */
    search.addEventListener('input', function () {
      var q = search.value.trim().toLowerCase();
      var k;
      for (k = 0; k < groups.length; k++) groups[k].hits = 0;

      for (var j = 0; j < rows.length; j++) {
        var it = rows[j].item;
        var hit = !q
          || it.key.toLowerCase().indexOf(q) !== -1
          || String(it.hint || '').toLowerCase().indexOf(q) !== -1;
        rows[j].row.style.display = hit ? '' : 'none';
        if (hit) rows[j].group.hits++;
      }

      for (k = 0; k < groups.length; k++) {
        var group = groups[k];
        group.box.style.display = (!q || group.hits) ? '' : 'none';
        group.box.open = !!q && !!group.hits;
        group.count.textContent = q
          ? group.hits + ' / ' + group.total
          : String(group.total);
      }
    });

    search.focus();
  }

  function openPanel() {
    closePanel();

    panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.className = 'claude-settings-backdrop';
    // Клик мимо окна закрывает его, как у остальных панелей. Проверка
    // именно на подложку: клик внутри окна всплывает сюда же.
    panel.addEventListener('mousedown', function (e) {
      if (e.target === panel) closePanel();
    });

    var win = document.createElement('div');
    win.className = 'claude-settings-window';
    panel.appendChild(win);

    var head = document.createElement('div');
    head.className = 'claude-settings-head';
    var title = document.createElement('span');
    title.textContent = '⚙ Настройки патча';
    head.appendChild(title);

    // Крестик — третий способ закрыть окно, вдобавок к «Отмене» и
    // Escape. Своя кнопка нужна потому, что у окна нет рамки VSCode
    // с системным крестиком: это div на подложке, а не диалог
    // оболочки, и закрывать его нечем, кроме того, что нарисуем сами.
    var closeX = document.createElement('button');
    closeX.type = 'button';
    closeX.className = 'claude-settings-x';
    closeX.textContent = '✕';
    closeX.title = 'Закрыть без сохранения (Esc)';
    closeX.setAttribute('aria-label', 'Закрыть');
    closeX.addEventListener('click', closePanel);
    head.appendChild(closeX);
    win.appendChild(head);

    var sub = document.createElement('div');
    sub.className = 'claude-settings-sub';
    sub.textContent = 'claude-custom-config.toml';
    win.appendChild(sub);

    var body = document.createElement('div');
    body.className = 'claude-settings-body';
    body.textContent = 'загрузка…';
    win.appendChild(body);

    var footer = document.createElement('div');
    footer.className = 'claude-settings-footer';
    var status = document.createElement('div');
    status.className = 'claude-settings-status';
    footer.appendChild(status);

    // Порядок «Сохранить → Отмена».
    var cancelBtn = document.createElement('button');
    cancelBtn.type = 'button';
    cancelBtn.className = 'claude-settings-btn';
    cancelBtn.textContent = 'Отмена';
    cancelBtn.title = 'Закрыть, не записывая правки в файл';
    cancelBtn.addEventListener('click', closePanel);

    var saveBtn = document.createElement('button');
    saveBtn.type = 'button';
    saveBtn.className = 'claude-settings-btn claude-settings-btn-primary';
    saveBtn.textContent = 'Сохранить';
    saveBtn.addEventListener('click', function () { save(status, saveBtn); });

    footer.appendChild(saveBtn);
    footer.appendChild(cancelBtn);
    win.appendChild(footer);

    document.body.appendChild(panel);
    document.addEventListener('keydown', onKeydown, true);

    fetch(SCHEMA_URL, { cache: 'no-store' })
      .then(function (res) { return res.json(); })
      .then(function (d) {
        if (!panel) return;
        if (!d || !d.ok) throw new Error((d && d.error) || 'сервер отказал');
        items = d.items || [];
        render(body, status);
        if (d.path) sub.title = d.path;
      })
      .catch(function (err) {
        if (!panel) return;
        body.textContent = 'http-server.py недоступен (порт 18923): '
          + ((err && err.message) || err);
      });
  }

  /* ---------- вход ---------- */

  window.addEventListener('message', function (e) {
    // Сообщение приходит от блока в extension.js по нажатию пункта
    // меню. Ключ нарочно свой, чтобы не пересечься с протоколом
    // приложения — и чтобы его обработчик так же спокойно прошёл мимо
    // нашего сообщения.
    var data = e && e.data;
    if (!data || data.__claudeCustom !== 'open-settings') return;
    logInfo('открываю по команде из контекстного меню');
    openPanel();
  });

  // Отладочный вход: окно можно открыть и без меню.
  window.__claudeSettings = { open: openPanel, close: closePanel };
})();

/* ============================================================
 * IMAGE ANNOTATION EDITOR — ручная разметка вложений
 *
 * Добавляет кнопку ✎ в левый верхний угол открытого штатного preview
 * прикреплённого изображения. Редактор живёт целиком внутри webview:
 * исходник уже доступен как data URL, Canvas рисует поверх него в родном
 * разрешении, а результат возвращается React-композеру как новый File.
 *
 * Исходник удаляется только после того, как новая миниатюра появилась
 * в DOM. При ошибке добавления исходное вложение остаётся на месте.
 * ============================================================ */
(function () {
  var cfg = window.__CLAUDE_CUSTOM_CONFIG__ || {};
  if (!cfg.imageAnnotationEditor) return;
  if (window.__claudeImageAnnotationInstalled) return;
  window.__claudeImageAnnotationInstalled = true;

  var EDIT_CLASS = 'claude-image-edit-btn';
  var MARK_CLASS = 'claude-image-editable';
  // В 2.1.220 composer рисует вложения компонентом pill_lcdCYQ.
  // Ограничение родителем обязательно: pill_* встречается и в других
  // частях интерфейса, а редактор относится только к ещё не отправленным
  // вложениям активного поля ввода.
  var THUMB_SELECTOR = '[class*="attachedFilesContainer_"] [class*="pill_"]';
  var PREVIEW_SELECTOR = '[class*="previewContainer_"]';
  var PREVIEW_IMAGE_SELECTOR = 'img[class*="previewImage_"]';
  var COMPOSER_SELECTOR = '[role="textbox"][contenteditable]';
  var MIN_ZOOM = 0.25;
  var MAX_ZOOM = 4;
  var ZOOM_FACTOR = 1.2;
  var active = null;

  function own(el) {
    if (el) el.__claudeOwnNode = true;
    return el;
  }

  function button(label, className, title, handler) {
    var el = own(document.createElement('button'));
    el.type = 'button';
    el.className = className || '';
    el.textContent = label;
    if (title) {
      el.title = title;
      el.setAttribute('aria-label', title);
    }
    if (handler) el.addEventListener('click', handler);
    return el;
  }

  function clampZoom(value) {
    return Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, Number(value) || 1));
  }

  function wheelZoom(value, deltaY) {
    return clampZoom(value * Math.exp(-Number(deltaY || 0) * 0.002));
  }

  function touchDistance(points) {
    var ids = Object.keys(points);
    if (ids.length < 2) return 0;
    var a = points[ids[0]];
    var b = points[ids[1]];
    return Math.hypot(b.x - a.x, b.y - a.y);
  }

  function touchCenter(points) {
    var ids = Object.keys(points);
    if (ids.length < 2) return null;
    var a = points[ids[0]];
    var b = points[ids[1]];
    return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
  }

  function zoomControls(className, getZoom, setZoom) {
    var host = own(document.createElement('div'));
    host.className = className;
    host.addEventListener('mousedown', function (event) {
      event.preventDefault();
      event.stopPropagation();
    });
    host.addEventListener('click', function (event) { event.stopPropagation(); });
    var out = own(document.createElement('button'));
    out.type = 'button';
    out.className = 'claude-image-zoom-value';
    out.title = 'Сбросить масштаб';
    out.setAttribute('aria-label', 'Сбросить масштаб');
    out.addEventListener('click', function () { setZoom(1); });
    var minus = button('−', 'claude-image-zoom-btn', 'Уменьшить', function () {
      setZoom(getZoom() / ZOOM_FACTOR);
    });
    var plus = button('+', 'claude-image-zoom-btn', 'Увеличить', function () {
      setZoom(getZoom() * ZOOM_FACTOR);
    });
    host.appendChild(minus);
    host.appendChild(out);
    host.appendChild(plus);
    host.update = function () {
      var value = getZoom();
      out.textContent = Math.round(value * 100) + '%';
      minus.disabled = value <= MIN_ZOOM + 0.001;
      plus.disabled = value >= MAX_ZOOM - 0.001;
    };
    host.update();
    return host;
  }

  function imageOf(thumb) {
    var img = thumb && thumb.querySelector('img');
    if (!img || !/^data:image\//i.test(img.src || '')) return null;
    return img;
  }

  function previewImageOf(preview) {
    var img = preview && preview.querySelector(PREVIEW_IMAGE_SELECTOR);
    if (!img || !/^data:image\//i.test(img.src || '')) return null;
    return img;
  }

  function thumbForSource(sourceUrl, thumbs) {
    var candidates = thumbs || document.querySelectorAll(THUMB_SELECTOR);
    for (var i = 0; i < candidates.length; i++) {
      var img = imageOf(candidates[i]);
      if (img && img.src === sourceUrl) return candidates[i];
    }
    return null;
  }

  function closeEditor() {
    if (!active) return;
    document.removeEventListener('keydown', active.keyHandler, true);
    (active.cleanup || []).forEach(function (fn) { fn(); });
    if (active.overlay && active.overlay.parentNode) active.overlay.remove();
    active = null;
  }

  function cancelEditor(event) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
    }
    var state = active;
    if (!state) return;
    closeEditor();
    // Open the existing attachment through its native click handler. Defer
    // until the cancel event has finished so it cannot close the new preview.
    // Saving and editor cleanup still call closeEditor without reopening it.
    setTimeout(function () {
      if (active || !document.body.contains(state.thumb)) return;
      var image = imageOf(state.thumb);
      if (!image || image.src !== state.sourceUrl) return;
      if (document.querySelector(PREVIEW_SELECTOR)) return;
      image.click();
    }, 0);
  }

  function annotatedName(name) {
    var clean = String(name || 'image').replace(/\.[^.]+$/, '');
    return clean + '-annotated.png';
  }

  function drawAction(ctx, action) {
    if (!action) return;
    var pts = action.points || [];
    var start = action.start || pts[0];
    var end = action.end || pts[pts.length - 1];
    ctx.save();
    ctx.strokeStyle = action.color || '#ef4444';
    ctx.lineWidth = action.width || 3;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();

    if (action.tool === 'brush') {
      if (!pts.length) { ctx.restore(); return; }
      ctx.moveTo(pts[0].x, pts[0].y);
      if (pts.length === 1) ctx.lineTo(pts[0].x + 0.01, pts[0].y + 0.01);
      for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
    } else if (action.tool === 'line' && start && end) {
      ctx.moveTo(start.x, start.y);
      ctx.lineTo(end.x, end.y);
    } else if (action.tool === 'rect' && start && end) {
      ctx.rect(start.x, start.y, end.x - start.x, end.y - start.y);
    } else if (action.tool === 'ellipse' && start && end) {
      var cx = (start.x + end.x) / 2;
      var cy = (start.y + end.y) / 2;
      var rx = Math.abs(end.x - start.x) / 2;
      var ry = Math.abs(end.y - start.y) / 2;
      ctx.ellipse(cx, cy, Math.max(rx, 0.01), Math.max(ry, 0.01), 0, 0, Math.PI * 2);
    }
    ctx.stroke();
    ctx.restore();
  }

  function cloneAction(action) {
    return {
      tool: action.tool,
      color: action.color,
      width: action.width,
      start: action.start ? { x: action.start.x, y: action.start.y } : null,
      end: action.end ? { x: action.end.x, y: action.end.y } : null,
      points: (action.points || []).map(function (p) { return { x: p.x, y: p.y }; }),
    };
  }

  function translateAction(action, dx, dy) {
    var moved = cloneAction(action);
    if (moved.start) { moved.start.x += dx; moved.start.y += dy; }
    if (moved.end) { moved.end.x += dx; moved.end.y += dy; }
    moved.points.forEach(function (p) { p.x += dx; p.y += dy; });
    return moved;
  }

  function actionBounds(action) {
    var pts = (action.points || []).slice();
    if (action.start) pts.push(action.start);
    if (action.end) pts.push(action.end);
    if (!pts.length) return null;
    var minX = pts[0].x;
    var maxX = pts[0].x;
    var minY = pts[0].y;
    var maxY = pts[0].y;
    for (var i = 1; i < pts.length; i++) {
      minX = Math.min(minX, pts[i].x);
      maxX = Math.max(maxX, pts[i].x);
      minY = Math.min(minY, pts[i].y);
      maxY = Math.max(maxY, pts[i].y);
    }
    var pad = Math.max(1, Number(action.width) || 1) / 2;
    return { x: minX - pad, y: minY - pad, width: maxX - minX + pad * 2, height: maxY - minY + pad * 2 };
  }

  function segmentDistance(point, a, b) {
    var dx = b.x - a.x;
    var dy = b.y - a.y;
    if (!dx && !dy) return Math.hypot(point.x - a.x, point.y - a.y);
    var t = ((point.x - a.x) * dx + (point.y - a.y) * dy) / (dx * dx + dy * dy);
    t = Math.max(0, Math.min(1, t));
    return Math.hypot(point.x - (a.x + t * dx), point.y - (a.y + t * dy));
  }

  function hitAction(action, point, tolerance) {
    var extra = Math.max(0, tolerance || 0);
    var radius = Math.max(1, Number(action.width) || 1) / 2 + extra;
    var pts = action.points || [];
    if (action.tool === 'brush') {
      if (pts.length === 1) return Math.hypot(point.x - pts[0].x, point.y - pts[0].y) <= radius;
      for (var i = 1; i < pts.length; i++) {
        if (segmentDistance(point, pts[i - 1], pts[i]) <= radius) return true;
      }
      // У большого свободного штриха пунктирная рамка воспринимается как
      // область выбора. Разрешаем брать его за пустое место внутри этой
      // рамки; узкие линии сохраняют точное попадание по самому штриху.
      var brushBounds = actionBounds(action);
      return !!brushBounds
        && brushBounds.width >= radius * 4
        && brushBounds.height >= radius * 4
        && point.x >= brushBounds.x && point.x <= brushBounds.x + brushBounds.width
        && point.y >= brushBounds.y && point.y <= brushBounds.y + brushBounds.height;
    }
    if (action.tool === 'line' && action.start && action.end) {
      return segmentDistance(point, action.start, action.end) <= radius;
    }
    if ((action.tool === 'rect' || action.tool === 'ellipse') && action.start && action.end) {
      var left = Math.min(action.start.x, action.end.x) - radius;
      var right = Math.max(action.start.x, action.end.x) + radius;
      var top = Math.min(action.start.y, action.end.y) - radius;
      var bottom = Math.max(action.start.y, action.end.y) + radius;
      if (point.x < left || point.x > right || point.y < top || point.y > bottom) return false;
      if (action.tool === 'rect') return true;
      var cx = (action.start.x + action.end.x) / 2;
      var cy = (action.start.y + action.end.y) / 2;
      var rx = Math.abs(action.end.x - action.start.x) / 2 + radius;
      var ry = Math.abs(action.end.y - action.start.y) / 2 + radius;
      return rx > 0 && ry > 0 && ((point.x - cx) * (point.x - cx)) / (rx * rx)
        + ((point.y - cy) * (point.y - cy)) / (ry * ry) <= 1;
    }
    return false;
  }

  function drawSelection(ctx, action) {
    var bounds = actionBounds(action);
    if (!bounds) return;
    ctx.save();
    ctx.strokeStyle = '#60a5fa';
    ctx.lineWidth = 1;
    if (ctx.setLineDash) ctx.setLineDash([6, 4]);
    ctx.strokeRect(bounds.x - 4, bounds.y - 4, bounds.width + 8, bounds.height + 8);
    ctx.restore();
  }

  function dispatchFile(file, composer) {
    try {
      var transfer = new DataTransfer();
      transfer.items.add(file);
      var paste = new ClipboardEvent('paste', {
        bubbles: true,
        cancelable: true,
        clipboardData: transfer,
      });
      composer.dispatchEvent(paste);
      if (paste.defaultPrevented) return true;
    } catch (e) {}

    // Запасной путь для Electron-сборок, которые не принимают
    // clipboardData в конструкторе ClipboardEvent.
    try {
      var input = document.querySelector('input[type="file"][multiple]');
      if (!input) return false;
      var dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    } catch (e2) {
      return false;
    }
  }

  function replaceAttachment(state, file, done) {
    var composerHost = state.thumb.closest('[class*="inputContainer_"]');
    var composer = composerHost && composerHost.querySelector(COMPOSER_SELECTOR);
    if (!composer) composer = document.querySelector(COMPOSER_SELECTOR);
    if (!composer) { done(new Error('поле ввода чата не найдено')); return; }

    var before = document.querySelectorAll(THUMB_SELECTOR).length;
    if (!dispatchFile(file, composer)) {
      done(new Error('расширение не приняло новый файл'));
      return;
    }

    var started = Date.now();
    (function waitForThumbnail() {
      var now = document.querySelectorAll(THUMB_SELECTOR).length;
      if (now > before) {
        var original = state.thumb;
        if (!document.body.contains(original)) {
          var candidates = document.querySelectorAll(THUMB_SELECTOR);
          for (var i = 0; i < candidates.length; i++) {
            var img = imageOf(candidates[i]);
            if (img && img.src === state.sourceUrl) { original = candidates[i]; break; }
          }
        }
        var remove = original && original.querySelector(
          'button[class*="removeButton_"], button[title="Remove attachment"]'
        );
        if (!remove) {
          done(new Error('новая картинка добавлена, но кнопка удаления исходника не найдена'));
          return;
        }
        remove.click();
        done(null);
        return;
      }
      if (Date.now() - started > 5000) {
        done(new Error('новая миниатюра не появилась за 5 секунд'));
        return;
      }
      setTimeout(waitForThumbnail, 80);
    })();
  }

  function openEditor(thumb) {
    var sourceImg = imageOf(thumb);
    if (!sourceImg) return;
    closeEditor();

    var overlay = own(document.createElement('div'));
    overlay.className = 'claude-image-editor-overlay';
    var panel = own(document.createElement('section'));
    panel.className = 'claude-image-editor-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'true');
    panel.setAttribute('aria-label', 'Редактор изображения');
    overlay.appendChild(panel);

    var header = own(document.createElement('header'));
    header.className = 'claude-image-editor-header';
    var title = own(document.createElement('strong'));
    title.textContent = 'Разметка изображения';
    var close = button('×', 'claude-image-editor-close', 'Отменить редактирование', cancelEditor);
    header.appendChild(title);
    header.appendChild(close);
    panel.appendChild(header);

    var toolbar = own(document.createElement('div'));
    toolbar.className = 'claude-image-editor-toolbar';
    var tools = own(document.createElement('div'));
    tools.className = 'claude-image-editor-tools';
    var toolDefs = [
      ['select', '↖', 'Выбор и перемещение'],
      ['brush', '✎', 'Кисть'],
      ['line', '╱', 'Линия'],
      ['rect', '□', 'Прямоугольник'],
      ['ellipse', '○', 'Эллипс'],
    ];
    var tool = 'brush';
    var toolButtons = {};
    var editorZoom = 1;
    var fitScale = 1;
    var zoomWidget = null;
    function chooseTool(next) {
      tool = next;
      if (canvas) canvas.dataset.tool = next;
      Object.keys(toolButtons).forEach(function (key) {
        toolButtons[key].classList.toggle('is-active', key === tool);
      });
    }
    toolDefs.forEach(function (def) {
      var b = button(def[1], 'claude-image-tool-btn', def[2], function () { chooseTool(def[0]); });
      b.dataset.tool = def[0];
      toolButtons[def[0]] = b;
      tools.appendChild(b);
    });
    toolbar.appendChild(tools);

    var colors = own(document.createElement('div'));
    colors.className = 'claude-image-editor-colors';
    var color = '#ef3340';
    var swatches = [];
    ['#ef3340', '#38b879', '#4387df', '#ffd43b', '#ffffff', '#111827'].forEach(function (value) {
      var sw = button('', 'claude-image-color-btn', 'Цвет ' + value, function () {
        color = value;
        picker.value = value;
        updateColors();
      });
      sw.style.setProperty('--annotation-color', value);
      sw.dataset.color = value;
      colors.appendChild(sw);
      swatches.push(sw);
    });
    var picker = own(document.createElement('input'));
    picker.type = 'color';
    picker.value = color;
    picker.className = 'claude-image-color-picker';
    picker.title = 'Другой цвет';
    picker.setAttribute('aria-label', 'Другой цвет');
    picker.addEventListener('input', function () { color = picker.value; updateColors(); });
    colors.appendChild(picker);
    function updateColors() {
      swatches.forEach(function (sw) {
        sw.classList.toggle('is-active', sw.dataset.color.toLowerCase() === color.toLowerCase());
      });
    }
    toolbar.appendChild(colors);

    var moveHint = own(document.createElement('span'));
    moveHint.className = 'claude-image-editor-move-hint';
    moveHint.textContent = 'На ПКМ перемещение объектов';
    toolbar.appendChild(moveHint);

    var history = own(document.createElement('div'));
    history.className = 'claude-image-editor-history';
    var undoBtn = button('↶', 'claude-image-history-btn', 'Отменить действие (Ctrl+Z)', undo);
    var redoBtn = button('↷', 'claude-image-history-btn', 'Вернуть действие (Ctrl+Shift+Z)', redo);
    history.appendChild(undoBtn);
    history.appendChild(redoBtn);
    zoomWidget = zoomControls(
      'claude-image-editor-zoom',
      function () { return editorZoom; },
      setEditorZoom
    );
    var widthLabel = own(document.createElement('label'));
    widthLabel.className = 'claude-image-width-label';
    widthLabel.textContent = 'Толщина';
    var widthInput = own(document.createElement('input'));
    widthInput.type = 'range';
    widthInput.min = '1';
    widthInput.max = '24';
    widthInput.value = '4';
    widthInput.className = 'claude-image-width-input';
    widthLabel.appendChild(widthInput);
    history.appendChild(widthLabel);
    toolbar.appendChild(history);
    panel.appendChild(toolbar);

    var stage = own(document.createElement('div'));
    stage.className = 'claude-image-editor-stage';
    var canvas = own(document.createElement('canvas'));
    canvas.className = 'claude-image-editor-canvas';
    canvas.tabIndex = 0;
    stage.appendChild(canvas);
    panel.appendChild(stage);

    var footer = own(document.createElement('footer'));
    footer.className = 'claude-image-editor-footer';
    var status = own(document.createElement('span'));
    status.className = 'claude-image-editor-status';
    var cancelBtn = button('Отмена', 'claude-image-editor-action', 'Вернуться к просмотру без сохранения', cancelEditor);
    var saveBtn = button('Сохранить', 'claude-image-editor-action is-primary', 'Сохранить и заменить вложение', save);
    footer.appendChild(status);
    footer.appendChild(zoomWidget);
    footer.appendChild(cancelBtn);
    footer.appendChild(saveBtn);
    panel.appendChild(footer);

    var ctx = canvas.getContext('2d');
    var base = new Image();
    var actions = [];
    var historyEntries = [];
    var redoEntries = [];
    var draft = null;
    var drawing = false;
    var selectedIndex = -1;
    var drag = null;
    var touchPoints = {};
    var pinch = null;
    var touchZooming = false;

    function updateHistory() {
      undoBtn.disabled = historyEntries.length === 0;
      redoBtn.disabled = redoEntries.length === 0;
    }

    function render(showSelection) {
      if (!base.naturalWidth) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(base, 0, 0, canvas.width, canvas.height);
      actions.forEach(function (action) { drawAction(ctx, action); });
      drawAction(ctx, draft);
      if (showSelection !== false && selectedIndex >= 0 && actions[selectedIndex]) {
        drawSelection(ctx, actions[selectedIndex]);
      }
    }

    function undo() {
      if (!historyEntries.length) return;
      var entry = historyEntries.pop();
      if (entry.type === 'add') {
        actions.splice(entry.index, 1);
        selectedIndex = -1;
      } else if (entry.type === 'move') {
        actions[entry.index] = cloneAction(entry.before);
        selectedIndex = entry.index;
      }
      redoEntries.push(entry);
      render();
      updateHistory();
    }

    function redo() {
      if (!redoEntries.length) return;
      var entry = redoEntries.pop();
      if (entry.type === 'add') {
        actions.splice(entry.index, 0, cloneAction(entry.action));
        selectedIndex = entry.index;
      } else if (entry.type === 'move') {
        actions[entry.index] = cloneAction(entry.after);
        selectedIndex = entry.index;
      }
      historyEntries.push(entry);
      render();
      updateHistory();
    }

    function updateEditorCanvasSize(anchor) {
      if (!base.naturalWidth) return;
      var before = anchor ? canvas.getBoundingClientRect() : null;
      var relX = before && before.width ? (anchor.x - before.left) / before.width : 0.5;
      var relY = before && before.height ? (anchor.y - before.top) / before.height : 0.5;
      relX = Math.max(0, Math.min(1, relX));
      relY = Math.max(0, Math.min(1, relY));
      canvas.style.width = Math.max(1, base.naturalWidth * fitScale * editorZoom) + 'px';
      canvas.style.height = Math.max(1, base.naturalHeight * fitScale * editorZoom) + 'px';
      var shownHeight = base.naturalHeight * fitScale * editorZoom;
      canvas.style.marginTop = Math.max(14, (stage.clientHeight - shownHeight) / 2) + 'px';
      canvas.style.marginBottom = '14px';
      if (before && before.width && before.height) {
        var after = canvas.getBoundingClientRect();
        stage.scrollLeft += after.left + relX * after.width - anchor.x;
        stage.scrollTop += after.top + relY * after.height - anchor.y;
      }
    }

    function setEditorZoom(next, anchor) {
      editorZoom = clampZoom(next);
      if (!anchor && base.naturalWidth) {
        var stageRect = stage.getBoundingClientRect();
        anchor = { x: stageRect.left + stageRect.width / 2, y: stageRect.top + stageRect.height / 2 };
      }
      updateEditorCanvasSize(anchor);
      if (zoomWidget) zoomWidget.update();
    }

    function refitEditor() {
      if (!base.naturalWidth) return;
      var availableWidth = Math.max(1, stage.clientWidth - 28);
      var availableHeight = Math.max(1, stage.clientHeight - 28);
      fitScale = Math.min(1, availableWidth / base.naturalWidth, availableHeight / base.naturalHeight);
      updateEditorCanvasSize();
    }

    function point(event) {
      var rect = canvas.getBoundingClientRect();
      return {
        x: (event.clientX - rect.left) * canvas.width / rect.width,
        y: (event.clientY - rect.top) * canvas.height / rect.height,
      };
    }

    function strokeWidth() {
      var rect = canvas.getBoundingClientRect();
      var scale = rect.width ? canvas.width / rect.width : 1;
      return Number(widthInput.value) * scale;
    }

    canvas.addEventListener('contextmenu', function (event) {
      // ПКМ зарезервирована для перемещения. Не позволяем webview/VSCode
      // открыть поверх жеста штатное контекстное меню.
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
    });
    stage.addEventListener('wheel', function (event) {
      if (!base.naturalWidth) return;
      event.preventDefault();
      event.stopPropagation();
      setEditorZoom(wheelZoom(editorZoom, event.deltaY), { x: event.clientX, y: event.clientY });
    }, { passive: false });

    function cancelDrawingForPinch() {
      if (!drawing) return;
      drawing = false;
      draft = null;
      if (drag) actions[drag.index] = cloneAction(drag.before);
      drag = null;
      delete canvas.dataset.dragging;
      render();
      updateHistory();
    }

    canvas.addEventListener('pointerdown', function (event) {
      if ((event.button !== 0 && event.button !== 2) || !base.naturalWidth) return;
      if (event.pointerType === 'touch') {
        touchPoints[event.pointerId] = { x: event.clientX, y: event.clientY };
        try { canvas.setPointerCapture(event.pointerId); } catch (e) {}
        if (Object.keys(touchPoints).length >= 2) {
          cancelDrawingForPinch();
          touchZooming = true;
          pinch = { distance: touchDistance(touchPoints), zoom: editorZoom };
          event.preventDefault();
          return;
        }
        if (touchZooming) return;
      }
      event.preventDefault();
      var p = point(event);
      // Правая кнопка всегда выбирает/двигает, какой бы инструмент ни
      // был активен. Левая делает то же только в явном режиме select.
      if (event.button === 2 || tool === 'select') {
        selectedIndex = -1;
        var tolerance = 8 * (canvas.width / Math.max(1, canvas.getBoundingClientRect().width));
        for (var i = actions.length - 1; i >= 0; i--) {
          if (hitAction(actions[i], p, tolerance)) { selectedIndex = i; break; }
        }
        drag = selectedIndex >= 0 ? {
          index: selectedIndex,
          origin: p,
          before: cloneAction(actions[selectedIndex]),
        } : null;
        drawing = !!drag;
        if (drag) {
          canvas.setPointerCapture(event.pointerId);
          canvas.dataset.dragging = 'true';
        }
        render();
        return;
      }
      canvas.setPointerCapture(event.pointerId);
      draft = { tool: tool, color: color, width: strokeWidth(), start: p, end: p, points: [p] };
      drawing = true;
      render();
    });
    canvas.addEventListener('pointermove', function (event) {
      if (event.pointerType === 'touch' && touchPoints[event.pointerId]) {
        touchPoints[event.pointerId] = { x: event.clientX, y: event.clientY };
        if (touchZooming && pinch && pinch.distance && Object.keys(touchPoints).length >= 2) {
          event.preventDefault();
          setEditorZoom(
            pinch.zoom * touchDistance(touchPoints) / pinch.distance,
            touchCenter(touchPoints)
          );
          return;
        }
      }
      if (!drawing || (!draft && !drag)) return;
      var p = point(event);
      if (drag) {
        actions[drag.index] = translateAction(
          drag.before,
          p.x - drag.origin.x,
          p.y - drag.origin.y
        );
        render();
        return;
      }
      if (draft.tool === 'brush') draft.points.push(p);
      draft.end = p;
      render();
    });
    function finish(event, commit) {
      if (!drawing) return;
      drawing = false;
      try { canvas.releasePointerCapture(event.pointerId); } catch (e) {}
      if (drag) {
        var moved = actions[drag.index];
        var dx = moved.start && drag.before.start ? moved.start.x - drag.before.start.x
          : moved.points[0].x - drag.before.points[0].x;
        var dy = moved.start && drag.before.start ? moved.start.y - drag.before.start.y
          : moved.points[0].y - drag.before.points[0].y;
        if (commit && (Math.abs(dx) > 0.001 || Math.abs(dy) > 0.001)) {
          historyEntries.push({
            type: 'move',
            index: drag.index,
            before: cloneAction(drag.before),
            after: cloneAction(moved),
          });
          redoEntries.length = 0;
        } else if (!commit) {
          actions[drag.index] = cloneAction(drag.before);
        }
        drag = null;
        delete canvas.dataset.dragging;
        render();
        updateHistory();
        return;
      }
      if (commit && draft) {
        actions.push(draft);
        historyEntries.push({ type: 'add', index: actions.length - 1, action: cloneAction(draft) });
        redoEntries.length = 0;
        selectedIndex = actions.length - 1;
      }
      draft = null;
      render();
      updateHistory();
    }
    function endPointer(event, commit) {
      if (event.pointerType === 'touch') {
        delete touchPoints[event.pointerId];
        if (touchZooming) {
          event.preventDefault();
          pinch = null;
          if (!Object.keys(touchPoints).length) touchZooming = false;
          return;
        }
      }
      finish(event, commit);
    }
    canvas.addEventListener('pointerup', function (event) { endPointer(event, true); });
    canvas.addEventListener('pointercancel', function (event) { endPointer(event, false); });

    function save() {
      if (saveBtn.disabled) return;
      saveBtn.disabled = true;
      cancelBtn.disabled = true;
      status.textContent = 'Подготавливаю изображение…';
      // Рамка выбора — интерфейс редактора, в результирующий PNG она
      // попадать не должна.
      render(false);
      canvas.toBlob(function (blob) {
        // Снимок уже сформирован; возвращаем служебную рамку на случай,
        // если добавление вложения завершится ошибкой и редактор останется.
        render();
        if (!blob) {
          status.textContent = 'Не удалось создать PNG';
          saveBtn.disabled = false;
          cancelBtn.disabled = false;
          return;
        }
        var name = annotatedName(sourceImg.alt || thumb.title || 'image');
        var file = new File([blob], name, { type: 'image/png', lastModified: Date.now() });
        status.textContent = 'Прикрепляю результат…';
        replaceAttachment(active, file, function (err) {
          if (err) {
            status.textContent = err.message + '. Исходник сохранён.';
            saveBtn.disabled = false;
            cancelBtn.disabled = false;
            return;
          }
          closeEditor();
        });
      }, 'image/png');
    }

    function onKeydown(event) {
      if (event.key === 'Escape') {
        cancelEditor(event);
        return;
      }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') {
        event.preventDefault();
        event.stopPropagation();
        if (event.shiftKey) redo(); else undo();
      } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'y') {
        event.preventDefault();
        event.stopPropagation();
        redo();
      }
    }

    overlay.addEventListener('mousedown', function (event) {
      if (event.target === overlay) cancelEditor(event);
    });
    document.body.appendChild(overlay);
    document.addEventListener('keydown', onKeydown, true);
    active = {
      overlay: overlay,
      thumb: thumb,
      sourceUrl: sourceImg.src,
      keyHandler: onKeydown,
      cleanup: [],
    };
    var resizeHandler = function () { refitEditor(); };
    window.addEventListener('resize', resizeHandler);
    active.cleanup.push(function () { window.removeEventListener('resize', resizeHandler); });
    chooseTool(tool);
    updateColors();
    updateHistory();
    saveBtn.disabled = true;
    status.textContent = 'Загружаю изображение…';

    base.onload = function () {
      canvas.width = base.naturalWidth;
      canvas.height = base.naturalHeight;
      refitEditor();
      render();
      saveBtn.disabled = false;
      status.textContent = base.naturalWidth + ' × ' + base.naturalHeight;
      canvas.focus();
    };
    base.onerror = function () {
      status.textContent = 'Не удалось открыть изображение';
    };
    base.src = sourceImg.src;
  }

  function installPreviewZoom(preview, image) {
    // Panning must never start Chromium's native image/file drag. At 100%
    // and moderate zoom our pointer handler may not start a pan at all.
    image.draggable = false;
    if (preview.__claudeImageZoom && preview.__claudeImageZoom.image === image) return;
    var state = {
      image: image, value: 1, panX: 0, panY: 0,
      touches: {}, pinch: null, touchZooming: false,
      drag: null, suppressClick: false,
    };
    preview.__claudeImageZoom = state;

    function positionChrome() {
      var previewRect = preview.getBoundingClientRect();
      var imageRect = image.getBoundingClientRect();
      if (!previewRect || !imageRect || !imageRect.width || !imageRect.height) return;
      var edit = preview.querySelector('.' + EDIT_CLASS);
      var close = preview.querySelector('button[class*="previewCloseButton_"]');
      var viewportWidth = window.innerWidth || document.documentElement.clientWidth || 0;
      var viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
      var edge = 8;
      function visible(value, size, limit) {
        if (!limit) return value;
        return Math.max(edge, Math.min(limit - size - edge, value));
      }
      // Кнопки целиком стоят снаружи верхних углов изображения, а не
      // перекрывают его. Позиции считаются после transform, поэтому они
      // следуют и за колесом, и за pinch. Если внешний край картинки ушёл
      // за viewport, координата прижимается к безопасному краю окна.
      var actions = [edit, preview.querySelector('.claude-image-copy-btn'), preview.querySelector('.claude-image-save-btn')]
        .filter(function (item) { return !!item; });
      var actionsTop = visible(imageRect.top, actions.length * 34 - 6, viewportHeight);
      actions.forEach(function (item, index) {
        item.style.left = visible(imageRect.left - 34, 28, viewportWidth) - previewRect.left + 'px';
        item.style.top = actionsTop + index * 34 - previewRect.top + 'px';
      });
      if (close) {
        close.style.right = 'auto';
        close.style.left = visible(imageRect.right + 6, 28, viewportWidth) - previewRect.left + 'px';
        close.style.top = visible(imageRect.top, 28, viewportHeight) - previewRect.top + 'px';
      }
      if (state.controls) {
        var controlsRect = state.controls.getBoundingClientRect
          ? state.controls.getBoundingClientRect() : null;
        var controlsWidth = controlsRect && controlsRect.width ? controlsRect.width : 112;
        var controlsHeight = controlsRect && controlsRect.height ? controlsRect.height : 32;
        var controlsLeft = (imageRect.left + imageRect.right - controlsWidth) / 2;
        state.controls.style.right = 'auto';
        state.controls.style.bottom = 'auto';
        state.controls.style.transform = 'none';
        state.controls.style.left = visible(
          controlsLeft, controlsWidth, viewportWidth
        ) - previewRect.left + 'px';
        state.controls.style.top = visible(
          imageRect.bottom + 10, controlsHeight, viewportHeight
        ) - previewRect.top + 'px';
      }
    }
    state.position = positionChrome;

    function applyTransform() {
      image.style.transformOrigin = '0 0';
      image.style.transform = 'translate(' + state.panX + 'px,' + state.panY + 'px) scale(' + state.value + ')';
      image.dataset.previewZoomed = state.value > 1.001 ? 'true' : 'false';
      positionChrome();
    }

    function setZoom(next, anchor) {
      var value = clampZoom(next);
      var rect = image.getBoundingClientRect();
      if (!anchor && Math.abs(value - 1) > 0.001) {
        anchor = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
      }
      if (anchor && state.value) {
        var ratio = value / state.value;
        state.panX += (anchor.x - rect.left) * (1 - ratio);
        state.panY += (anchor.y - rect.top) * (1 - ratio);
      } else if (!anchor) {
        state.panX = 0;
        state.panY = 0;
      }
      state.value = value;
      applyTransform();
      controls.update();
    }

    var controls = zoomControls(
      'claude-image-preview-zoom',
      function () { return state.value; },
      setZoom
    );
    state.controls = controls;
    preview.appendChild(controls);
    positionChrome();

    image.addEventListener('wheel', function (event) {
      event.preventDefault();
      event.stopPropagation();
      setZoom(wheelZoom(state.value, event.deltaY), { x: event.clientX, y: event.clientY });
    }, { passive: false });
    image.addEventListener('pointerdown', function (event) {
      if (event.pointerType !== 'touch') {
        if (event.button !== 0 || state.value <= 1.001) return;
        var rect = image.getBoundingClientRect();
        var viewportWidth = window.innerWidth || document.documentElement.clientWidth || 0;
        var viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
        var overflowX = !!viewportWidth && rect.width > viewportWidth - 16;
        var overflowY = !!viewportHeight && rect.height > viewportHeight - 16;
        if (!overflowX && !overflowY) return;
        state.drag = {
          pointerId: event.pointerId,
          x: event.clientX,
          y: event.clientY,
          overflowX: overflowX,
          overflowY: overflowY,
          moved: false,
        };
        image.dataset.previewPanning = 'true';
        try { image.setPointerCapture(event.pointerId); } catch (e) {}
        event.preventDefault();
        event.stopPropagation();
        return;
      }
      state.touches[event.pointerId] = { x: event.clientX, y: event.clientY };
      try { image.setPointerCapture(event.pointerId); } catch (e) {}
      if (Object.keys(state.touches).length >= 2) {
        state.pinch = { distance: touchDistance(state.touches), zoom: state.value };
        state.touchZooming = true;
        event.preventDefault();
      }
    });
    image.addEventListener('pointermove', function (event) {
      if (state.drag && event.pointerId === state.drag.pointerId) {
        event.preventDefault();
        event.stopPropagation();
        var rect = image.getBoundingClientRect();
        var viewportWidth = window.innerWidth || document.documentElement.clientWidth || 0;
        var viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
        var keep = 40;
        var dx = state.drag.overflowX ? event.clientX - state.drag.x : 0;
        var dy = state.drag.overflowY ? event.clientY - state.drag.y : 0;
        if (viewportWidth) dx = Math.max(keep - rect.right, Math.min(viewportWidth - keep - rect.left, dx));
        if (viewportHeight) dy = Math.max(keep - rect.bottom, Math.min(viewportHeight - keep - rect.top, dy));
        state.panX += dx;
        state.panY += dy;
        state.drag.x = event.clientX;
        state.drag.y = event.clientY;
        if (Math.abs(dx) > 1 || Math.abs(dy) > 1) state.drag.moved = true;
        applyTransform();
        return;
      }
      if (event.pointerType !== 'touch' || !state.touches[event.pointerId]) return;
      state.touches[event.pointerId] = { x: event.clientX, y: event.clientY };
      if (!state.pinch || !state.pinch.distance) return;
      event.preventDefault();
      var center = touchCenter(state.touches);
      setZoom(state.pinch.zoom * touchDistance(state.touches) / state.pinch.distance, center);
    });
    function endTouch(event) {
      if (state.drag && event.pointerId === state.drag.pointerId) {
        state.suppressClick = state.drag.moved;
        state.drag = null;
        delete image.dataset.previewPanning;
        try { image.releasePointerCapture(event.pointerId); } catch (e) {}
        event.preventDefault();
        event.stopPropagation();
        return;
      }
      if (event.pointerType !== 'touch') return;
      delete state.touches[event.pointerId];
      if (Object.keys(state.touches).length < 2) state.pinch = null;
      if (state.touchZooming) {
        event.preventDefault();
        event.stopPropagation();
        if (!Object.keys(state.touches).length) state.touchZooming = false;
      }
    }
    image.addEventListener('pointerup', endTouch);
    image.addEventListener('pointercancel', endTouch);
    image.addEventListener('click', function (event) {
      if (!state.suppressClick) return;
      state.suppressClick = false;
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
    }, true);
  }

  function exportPreviewImage(preview, action, control, label, title) {
    var image = previewImageOf(preview);
    if (!image || control.disabled) return;
    var status = preview.querySelector('.claude-image-export-status');
    if (!status) {
      status = own(document.createElement('div'));
      status.className = 'claude-image-export-status';
      status.setAttribute('role', 'status');
      preview.appendChild(status);
    }
    if (status.__hideTimer) clearTimeout(status.__hideTimer);
    status.hidden = false;
    status.textContent = action === 'copy' ? 'Копирование…' : 'Выберите файл для сохранения…';
    control.disabled = true;
    control.textContent = '…';
    var source;
    try {
      source = image.src;
      if (action === 'copy') {
        var canvas = document.createElement('canvas');
        canvas.width = image.naturalWidth;
        canvas.height = image.naturalHeight;
        if (!canvas.width || !canvas.height) throw new Error('Изображение ещё не загружено');
        canvas.getContext('2d').drawImage(image, 0, 0);
        source = canvas.toDataURL('image/png');
      }
    } catch (error) {
      finish(error);
      return;
    }
    fetch('http://127.0.0.1:18923/image-export', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: action, data_url: source, name: image.alt || 'image' }),
    }).then(function (response) { return response.json(); }).then(function (result) {
      if (!result || !result.ok) throw new Error(result && result.error || 'Не удалось выполнить действие');
      finish(null, result.cancelled);
    }).catch(function (error) { finish(error); });

    function finish(error, cancelled) {
      control.disabled = false;
      if (action === 'save' && !error && !cancelled) control.setAttribute('data-saved', 'true');
      control.textContent = error ? '!' : cancelled ? label : '✓';
      control.title = error ? String(error.message || error) : title;
      status.textContent = error ? 'Ошибка: ' + String(error.message || error)
        : cancelled ? 'Сохранение отменено' : action === 'copy' ? 'Изображение скопировано' : 'Изображение сохранено';
      status.__hideTimer = setTimeout(function () {
        control.textContent = label;
        control.title = title;
        status.hidden = true;
      }, error ? 7000 : 2500);
    }
  }

  function addImageExportButtons(preview) {
    ['copy', 'save'].forEach(function (action) {
      var className = 'claude-image-' + action + '-btn';
      if (preview.querySelector('.' + className)) return;
      var label = action === 'copy' ? '⧉' : '↓';
      var title = action === 'copy' ? 'Копировать изображение в буфер' : 'Сохранить изображение в файл';
      var armed = false;
      var control = button(label, 'claude-image-export-btn ' + className, title, function (event) {
        event.preventDefault(); event.stopPropagation();
        if (event.stopImmediatePropagation) event.stopImmediatePropagation();
        if (!armed && event.detail !== 0) return;
        armed = false;
        exportPreviewImage(preview, action, control, label, title);
      });
      control.addEventListener('pointerdown', function (event) {
        armed = true; event.preventDefault(); event.stopPropagation();
      });
      control.addEventListener('mousedown', function (event) { event.preventDefault(); event.stopPropagation(); });
      preview.appendChild(control);
    });
  }

  function blockPreviewAttachmentDrag(event) {
    var target = event.target;
    if (target && target.nodeType === 3) target = target.parentElement;
    if (!target || !target.closest || !target.closest('[class*="previewOverlay_"]')) return;
    // React portal events still bubble to the chat's attachment drop handler,
    // even though the preview is mounted under document.body. Intercept them
    // before React sees the drop, including the backdrop and zoom controls.
    event.preventDefault();
    event.stopPropagation();
    if (event.stopImmediatePropagation) event.stopImmediatePropagation();
  }

  function addEditButton(preview, thumbs) {
    var sourceImg = previewImageOf(preview);
    if (!sourceImg) return;
    preview.classList.add(MARK_CLASS);
    installPreviewZoom(preview, sourceImg);
    addImageExportButtons(preview);
    preview.__claudeImageZoom.position();
    var thumb = thumbForSource(sourceImg.src, thumbs);
    if (!thumb) return;
    if (preview.querySelector('.' + EDIT_CLASS)) {
      preview.__claudeImageZoom.position();
      return;
    }
    var pointerArmed = false;
    var edit = button('✎', EDIT_CLASS, 'Редактировать изображение', function (event) {
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
      // Preview может смонтироваться синхронно в ответ на тот же click,
      // которым пользователь открыл миниатюру. Требуем отдельный
      // pointerdown именно на уже существующей кнопке; detail=0 оставляет
      // доступным запуск с клавиатуры.
      if (!pointerArmed && event.detail !== 0) return;
      pointerArmed = false;
      var closePreview = preview.querySelector('button[class*="previewCloseButton_"]');
      if (closePreview) closePreview.click();
      // React снимает штатный preview после обработчика close. Следующий
      // task гарантирует, что редактор не окажется под его z-index и не
      // унаследует чужие кнопки ✎/× по краям экрана.
      setTimeout(function () { openEditor(thumb); }, 0);
    });
    edit.addEventListener('pointerdown', function (event) {
      pointerArmed = true;
      event.preventDefault();
      event.stopPropagation();
    });
    edit.addEventListener('mousedown', function (event) {
      event.preventDefault();
      event.stopPropagation();
    });
    preview.insertBefore(edit, preview.firstChild);
    if (preview.__claudeImageZoom) preview.__claudeImageZoom.position();
  }

  function scan(ctx) {
    var thumbs = (ctx && ctx.imageAttachments) || document.querySelectorAll(THUMB_SELECTOR);
    var previews = (ctx && ctx.imagePreviews) || document.querySelectorAll(PREVIEW_SELECTOR);
    for (var i = 0; i < previews.length; i++) addEditButton(previews[i], thumbs);
    if (active && active.thumb && !document.body.contains(active.thumb)) closeEditor();
  }

  function init() {
    ['dragstart', 'dragover', 'drop'].forEach(function (type) {
      document.addEventListener(type, blockPreviewAttachmentDrag, true);
    });
    window.__claudeDomWatch.register('image-annotation', scan);
  }

  // Отладочный вход и минимальная поверхность для автономного стенда.
  window.__claudeImageAnnotation = {
    open: openEditor,
    close: closeEditor,
    scan: scan,
    _test: {
      drawAction: drawAction,
      annotatedName: annotatedName,
      dispatchFile: dispatchFile,
      replaceAttachment: replaceAttachment,
      cloneAction: cloneAction,
      translateAction: translateAction,
      actionBounds: actionBounds,
      hitAction: hitAction,
      clampZoom: clampZoom,
      wheelZoom: wheelZoom,
      touchDistance: touchDistance,
    },
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ============================================================
 * BLANK VIEW DETECTOR — датчик пустой вкладки
 *
 * Отказ 2026-09-01: вкладки расширения пусты, при этом бандл цел,
 * наш JS исполняется, протокол webview работает, исключений нет.
 * Разбор упёрся в то, что о самом факте «ничего не нарисовано» не
 * оставалось ни одной записи — приложение не падает, оно просто не
 * рисует, и через сутки об этом уже не спросишь.
 *
 * Датчик через BLANK_AFTER_MS смотрит, есть ли в #root содержимое, и
 * при пустоте один раз отправляет снимок состояния: смонтировался ли
 * React, сколько узлов в body, какие ключевые классы приложения
 * присутствуют, установились ли наши модули. Этого набора хватит,
 * чтобы в следующий раз сразу отделить «React не смонтировался» от
 * «нарисовал, но невидимо».
 *
 * Диагностика, а не функция: safeMode её не гасит — иначе в самом
 * безопасном режиме, куда уходят при поломке, мы снова остались бы
 * без данных.
 * ============================================================ */
(function () {
  if (window.__claudeBlankDetectorInstalled) return;
  window.__claudeBlankDetectorInstalled = true;

  var BLANK_AFTER_MS = 12000;

  function snapshot() {
    var root = document.getElementById('root');
    var body = document.body;
    var text = '';
    try { text = (root && root.innerText || '').trim(); } catch (e) {}
    return {
      hasRoot: !!root,
      rootChildren: root ? root.children.length : -1,
      rootTextLen: text.length,
      bodyChildren: body ? body.children.length : -1,
      bodyClass: body ? String(body.className).slice(0, 120) : '',
      // Классы приложения, по которым видно, дошёл ли рендер до чата
      appNodes: {
        message: document.querySelectorAll('[data-testid="assistant-message"]').length,
        container: document.querySelectorAll('[class*="messageContainer_"]').length,
        input: document.querySelectorAll('[class*="inputContainer_"]').length,
        footer: document.querySelectorAll('[class*="inputFooter_"]').length,
        session: document.querySelectorAll('[class*="sessionItem_"]').length,
      },
      ours: {
        boot: !!window.__claudeCustomBootInstalled,
        base: !!window.__claudeCustomScriptInstalled,
        accs: !!window.__claudeAccountsButtonInstalled,
        mood: !!window.__claudeMoodGaugeInstalled,
        emoji: !!window.__claudeEmojiPickerInstalled,
        mover: !!window.__claudeSessionMoverInstalled,
      },
    };
  }

  setTimeout(function () {
    var s = snapshot();
    // Признак нормы: React смонтировался и что-то нарисовал. Пустой
    // #root при живом бандле — это и есть тот самый отказ.
    if (s.hasRoot && s.rootChildren > 0 && s.rootTextLen > 0) return;
    try {
      fetch('http://localhost:18923/webview-error', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          kind: 'blank-view',
          message: 'вкладка пуста через ' + (BLANK_AFTER_MS / 1000) + ' с после загрузки',
          href: location.href.slice(0, 200),
          snapshot: s,
          ts: Date.now(),
        }),
        keepalive: true,
      }).catch(function () {});
    } catch (e) {}
  }, BLANK_AFTER_MS);
})();
